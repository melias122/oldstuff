#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

#include "comparator.h"

class QLabel;
class QLineEdit;
class QPushButton;

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = 0);
    ~Widget();

private slots:
//    Kombinacie readFile(QString &path);
//    void file1_readed(QString path);
//    void file2_readed(QString path);
//    void set_kombs1(Kombinacie &k);

private:


    Kombinacie kombinacie1;
    Kombinacie kombinacie2;

    QString path1, path2;

    QLabel *info;
    QLineEdit *line1, *line2;
    QPushButton *btnFile1, *btnFile2, *btnVT1, *btnVT2, *btnVST1, *btnVST2, *btnPor11, *btnPor22, *btnV11, *btnV22;
};

#endif // WIDGET_H

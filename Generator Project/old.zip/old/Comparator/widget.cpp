#include "widget.h"

#include "qfiledialog.h"
#include "qpushbutton.h"
#include "qlineedit.h"
#include "qspinbox.h"
#include "qlabel.h"
#include "qlayout.h"

#include "qfile.h"
#include "qtextstream.h"

#include "qthread.h"
#include "qdesktopservices.h"
#include "qurl.h"

#include "qdebug.h"

int strToPos(QString s){
    if(s.isEmpty() || s.size() > 2)
        return -1;

    int res = 0, tmp = 0;

    for(int i = s.length()-1; i >=0 ; --i){
        if(!s[i].isLetter()){
            res = -1;
            break;
        }
        int asciiNum = s[i].toUpper().toLatin1() - 'A';

        if(tmp > 0){
            auto j = asciiNum + 1;
            tmp = 1;
            while(j > 0){
                tmp += 'Z' - 'A';
                --j;
            }
        }

        res += asciiNum + tmp;
        ++tmp;
    }
    return res;
}


Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    btnFile1 = new QPushButton(tr("Načítaj súbor 1"));
    btnFile2 = new QPushButton(tr("Načítaj súbor 2"));
    btnVST1 = new QPushButton(tr("Výstup ∑ + tab"));
    btnVST2 = new QPushButton(tr("Výstup ∑ + tab"));
    btnPor22 = new QPushButton(tr("Porovnaj"));
    btnV22 = new QPushButton(tr("Otvor výstup"));
    info = new QLabel(tr(""));
    line1 = new QLineEdit;
    line2 = new QLineEdit;

    QHBoxLayout *layTop = new QHBoxLayout;
    QHBoxLayout *layBottom = new QHBoxLayout;
    QHBoxLayout *layDown = new QHBoxLayout;
    QVBoxLayout *layMain = new QVBoxLayout;
    QVBoxLayout *layLeft = new QVBoxLayout;
    QVBoxLayout *layRight = new QVBoxLayout;
    QVBoxLayout *layMainLeft = new QVBoxLayout;
    QVBoxLayout *layMainRight = new QVBoxLayout;
    QSpinBox *sp1 = new QSpinBox;
    QSpinBox *sp2 = new QSpinBox;
    QSpinBox *sp3 = new QSpinBox;
    QSpinBox *sp4 = new QSpinBox;

    line1->setPlaceholderText(tr("A-F"));
    line2->setPlaceholderText(tr("A-F"));

    sp1->setMinimum(1);
    sp1->setMaximum(30);
    sp1->setValue(5);

    sp2->setMinimum(2);
    sp2->setMaximum(90);
    sp2->setValue(35);

    sp3->setMinimum(1);
    sp3->setMaximum(30);
    sp3->setValue(5);

    sp4->setMinimum(2);
    sp4->setMaximum(90);
    sp4->setValue(35);

    layTop->addWidget(sp1);
    layTop->addWidget(new QLabel(tr("/")));
    layTop->addWidget(sp2);
    layTop->addWidget(btnFile1);
    layTop->addWidget(sp3);
    layTop->addWidget(new QLabel(tr("/")));
    layTop->addWidget(sp4);
    layTop->addWidget(btnFile2);

    layLeft->addWidget(line1);
//    layLeft->addWidget(btnVT1);
    layLeft->addWidget(btnVST1);

    layRight->addWidget(line2);
//    layRight->addWidget(btnVT2);
    layRight->addWidget(btnVST2);

    layBottom->addLayout(layLeft);
    layBottom->addLayout(layRight);

    layMainLeft->addLayout(layTop);
    layMainLeft->addLayout(layBottom);
    layMainLeft->addLayout(layDown);

//    QHBoxLayout *l1 = new QHBoxLayout;
    QHBoxLayout *l2 = new QHBoxLayout;

//    l1->addWidget(btnPor11);
//    l1->addWidget(btnV11);

    l2->addWidget(btnPor22);
    l2->addWidget(btnV22);


    QHBoxLayout *layZH = new QHBoxLayout;
    QHBoxLayout *laySum = new QHBoxLayout;

    layZH->addWidget(new QLabel(tr("ZH")));
    QLineEdit *lineZH = new QLineEdit;
    layZH->addWidget(lineZH);

    laySum->addWidget(new QLabel(tr("∑ ")));
    QLineEdit *line_SumOD = new QLineEdit;
    QLineEdit *line_SumDO = new QLineEdit;
    laySum->addWidget(line_SumOD);
    laySum->addWidget(line_SumDO);


    layMainRight->addLayout(layZH);
    layMainRight->addLayout(laySum);
    layMainRight->addLayout(l2);

    QHBoxLayout *l3 = new QHBoxLayout;
    l3->addLayout(layMainLeft);
    l3->addLayout(layMainRight);
    layMain->addLayout(l3);
//    layMain->addLayout(lay);
    layMain->addWidget(info);

    setLayout(layMain);

    connect(btnFile1, &QPushButton::clicked, [=](){
        if(!path1.isEmpty()){
            info->setText(tr("Subor 1 uz bol nacitany"));
            return;
        }
        auto path = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
        if(path.isEmpty()){
            info->setText(tr("Nepodarilo sa nacitat subor \"%1\"").arg(path));
            return;
        }
        if(line1->text().isEmpty()){
            info->setText(tr("Nebolo zadané rozpätie"));
            return;
        }

        int n = sp1->text().toInt();
        int m = sp2->text().toInt();

        auto rzpt = line1->text().split("-");
        auto from = strToPos(rzpt[0]);
        auto to = strToPos(rzpt[1]);

        if((to - from + 1) != n){
            info->setText(QString::number(to-from+1) + "(" + QString(line1->text()) + ")" +  " nie je " + QString::number(n));
            return;
        }

        QThread *t = new QThread;
        step *s = new step(path, from, to, n, m, "_1");

        s->moveToThread(t);

        connect(t, &QThread::started, s, &step::process);
        connect(t, &QThread::finished, t, &QThread::deleteLater);
        connect(s, &step::done, t, &QThread::quit);
        connect(s, &step::done, s, &step::deleteLater);

        connect(s, &step::send_kombs, [=](Kombinacie k){
            kombinacie1 = k;
        });
        connect(s, &step::done, [=](QString s){
            path1 = s;
            info->setText(tr("Subor %1 nacitany").arg(s));
        });

        t->start();
    });

    connect(btnFile2, &QPushButton::clicked, [=](){
        if(!path2.isEmpty()){
            info->setText(tr("Subor 2 uz bol nacitany"));
            return;
        }
        auto path = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
        if(path.isEmpty()){
            info->setText(tr("Nepodarilo sa nacitat subor \"%1\"").arg(path));
            return;
        }
        if(line2->text().isEmpty()){
            info->setText(tr("Nebolo zadané rozpätie"));
            return;
        }

        int n = sp3->text().toInt();
        int m = sp4->text().toInt();

        auto rzpt = line2->text().split("-");
        int from = strToPos(rzpt[0]);
        int to = strToPos(rzpt[1]);

        if((to - from + 1) != n){
            info->setText(QString::number(to-from+1)+ "(" + QString(line2->text()) + ")" + " nie je " + QString::number(n));
            return;
        }

        QThread *t = new QThread;
        step *s = new step(path, from, to, n, m, "_2");

        connect(t, &QThread::started, s, &step::process);
        connect(t, &QThread::finished, t, &QThread::deleteLater);
        connect(s, &step::done, t, &QThread::quit);
        connect(s, &step::done, s, &step::deleteLater);

        connect(s, &step::send_kombs, [=](Kombinacie k){
            kombinacie2 = k;
        });
        connect(s, &step::done, [=](QString s){
            path2 = s;
            info->setText(tr("Subor %1 nacitany").arg(s));
        });

        s->moveToThread(t);
        t->start();
    });

    connect(btnPor22, &QPushButton::clicked, [=](){

        if(path1.isEmpty() || path2.isEmpty()){
            info->setText(tr("Subory este noboli nacitane"));
            return;
        }
        if(kombinacie1.empty() || kombinacie2.empty()){
            info->setText(tr("Subory boli asi nacitane zle, nemozem nic robit. Skus restart programu"));
            return;
        }

        QThread *t = new QThread;
        comparator *c = new comparator(kombinacie1, kombinacie2);

        // settting
        int less = sp1->text().toInt() < sp3->text().toInt() ? sp1->text().toInt() : sp3->text().toInt();

        if(lineZH->text().isEmpty()){
            c->set_zh(less);
        } else {
            int zh = lineZH->text().toInt();
            if(zh > 0 && zh <= less){
                c->set_zh(zh);
            } else {
                c->set_zh(less);
            }
        }

        if(!line_SumOD->text().isEmpty()){
            int sod = line_SumOD->text().toInt();
            if(sod > 0)
                c->set_sumOD(sod);
        }
        if(!line_SumDO->text().isEmpty()){
            int sdo = line_SumDO->text().toInt();
            if(sdo > 0)
                c->set_sumDO(sdo);
        } // setting end

        c->set_n_m(sp3->text().toInt(), sp4->text().toInt());

        connect(t, &QThread::started, c, &comparator::process);
        connect(t, &QThread::finished, t, &QThread::deleteLater);
        connect(c, &comparator::done, t, &QThread::quit);
        connect(c, &comparator::done, c, &comparator::deleteLater);

        connect(c, &comparator::info, [=](QString msg){
            info->setText(msg);
        });

        c->moveToThread(t);
        t->start();

        info->setText(tr("Porovnavam ..."));
    });

    connect(btnVST1, &QPushButton::clicked, [=](){
        QDir d;
//        qDebug() << QUrl(QString("file:///%1").arg(d.absoluteFilePath("krok2_1.csv"))).toString();
        QDesktopServices::openUrl(QUrl(QString("file:///%1").arg(d.absoluteFilePath("krok2_1.csv"))));
    });

    connect(btnVST2, &QPushButton::clicked, [=](){
        QDir d;
        QDesktopServices::openUrl(QUrl(QString("file:///%1").arg(d.absoluteFilePath("krok2_2.csv"))));
    });

    connect(btnV22, &QPushButton::clicked, [=](){
        QDir d;
        QDesktopServices::openUrl(QUrl(QString("file:///%1").arg(d.absoluteFilePath("vystup.csv"))));
    });
}

Widget::~Widget(){}


#include "comparator.h"

#include "qfile.h"
#include "qtextstream.h"
#include "qalgorithms.h"

#include "qvector.h"
#include "qset.h"
#include "qhash.h"
#include "qstringlist.h"

#include "qdebug.h"

class K{
public:

    K(){}
    K(int sum, int zh, Kombinacia *k): sum{sum}, zh{zh}, k{k} {}

    int Sum() const {
        return sum;
    }

    int Zh() const {
        return zh;
    }

    Kombinacia* Komb() const {
        return k;
    }

    QStringList toQstringList(){
        QStringList l;
        auto e = k->end();
        for(auto b = k->begin(); b!=e; ++b)
            l.append(QString::number(*b));
        l.append(QString::number(sum));
//        l.append(QString::number(zh));
        return l;
    }

//private:
    int sum, zh;
    Kombinacia *k;
};

inline bool operator==(const K &k1, const K &k2){
    return k1.Sum() == k2.Sum() && k1.Zh() == k2.Zh() && *k1.Komb() == *k2.Komb();
}

inline bool bySum(K a, K b){
    return a.Sum() < b.Sum();
}

inline bool byKombOrder(K a, K b){
    return *a.Komb() < *b.Komb();
}

//inline bool bySumAndKombOrder(K a, K b){
//    return a.Sum() < b.Sum() && *a.Komb() < *b.Komb();
//}

class _key{
public:
    _key(int sucet, int cislo, int stlpec): m_suc{sucet}, m_cis{cislo}, m_stl{stlpec}{}
    int m_suc, m_cis, m_stl;
};

inline bool operator==(const _key &k1, const _key &k2)
{
    return k1.m_suc == k2.m_suc
            && k1.m_cis == k2.m_cis
            && k1.m_stl == k2.m_stl;
}

inline uint qHash(const _key &k, uint seed)
{
    return qHash(k.m_suc, seed)
            ^ qHash(k.m_cis, seed)
            ^ qHash(k.m_stl, seed);
}

class stat_sum_helper{
public:

    void insert(Kombinacia &k){
        int suc = sumKomb(k);
        m_sucty.insert(suc);
        for(int i{0}; i < k.size(); ++i){
            int c = k[i];
            int s = i+1;
            m_cisloSlpec_pocet[_key(suc, c, s)] += 1;
            m_cislo_pocetCelkom[c] += 1;
        }
    }

    QVector<int> sucty(){
        return m_sucty.toList().toVector();
    }

    int pocet(int sucet, int cislo, int stlpec){
        return m_cisloSlpec_pocet[_key(sucet, cislo, stlpec)];
    }
    int pocetCelkom(int cislo){
        return m_cislo_pocetCelkom[cislo];
    }

private:
    QSet<int> m_sucty;
    QHash<int, int> m_cislo_pocetCelkom;
    QHash<_key, int> m_cisloSlpec_pocet;
};

Kombinacie readFile(QString &path, int from, int to){
    QFile file(path);
    Kombinacie kombinacie;

    if(!file.open(QFile::ReadOnly)){
        return kombinacie;
    }
    QTextStream in(&file);

    // header skip
    in.readLine();

    while(!in.atEnd()){
        QStringList line = in.readLine().split(";");
//        qDebug() << line;
        if(line.isEmpty() || line.size() < to)
            continue;

        Kombinacia k;
        for(auto i = from; i <= to; ++i){
//            qDebug() << line[i] << line[i].toUShort() << line[i].toInt() << QString::fromStdString(line[i].toStdString()).toInt();
//            k.push_back(line[i].toInt());
            k.push_back(QString::fromStdString(line[i].toStdString()).toInt()); // fuj, fuj
        }
        kombinacie.push_back(k);
    }

    file.close();
    return kombinacie;
}

int compareKombs(Kombinacia k1, Kombinacia k2){

    int i=0, j=0, ret=0, k1size=k1.size(), k2size=k2.size();
    while((i < k1size) && (j < k2size)){
        if(k1[i] == k2[j]){
            ++ret;
            ++i;
            ++j;
        } else if(k1[i] > k2[j]){
            ++j;
        } else {
            ++i;
        }
    }
    return ret;
}

int sumKomb(Kombinacia k){
    int sum = 0;
    for(int i : k){
        sum += i;
    }
    return sum;
}

QString kombToQStr(Kombinacia k){
    QString s;
    for(auto c : k){
        s += QString::number(c) + " ";
    }
    return s;
}

using vk_itt = std::vector<K>::iterator;
std::vector<K> compare_vk(vk_itt begin, vk_itt end){
    std::vector<K> res;
    Kombinacia akt_k = *(*begin).Komb();

    (*begin).zh = 0;
    res.push_back(*begin);

    ++begin;
    for(;begin != end; ++begin){
        Kombinacia next_k = *(*begin).Komb();
        int zh = compareKombs(akt_k, next_k);
        (*begin).zh = zh;
        res.push_back(*begin);
    }
    return res;
}

QVector<QStringList> stat_sum(Kombinacie &kombinacie, int n, int m){
    QVector<QStringList> ret;

    if(kombinacie.empty())
        return ret;

//    int poc_stl = kombinacie.front().size();
    QStringList sl;
    stat_sum_helper ssh;

    for(auto &k : kombinacie){
        ssh.insert(k);
    }

    auto sucty = ssh.sucty();
    qSort(sucty);

    sl << "Sucty";
    for(auto &s : sucty){
        sl << QString("VpG p.c. / Sucet ∑ ").append(QString::number(s)).append(QString(" / stl"));
        for(int i=1; i < n; ++i)
            sl << "";
    }
    ret.push_back(sl);
    sl.clear();

    sl << "Cislo";

    for(auto &_ : sucty){
        for(int i=1; i<=n; ++i)
            sl << QString("S").append(QString::number(i));
    }
    sl << "Pocet cisel vo VpG v STL";
    ret.push_back(sl);
//    sl.clear();

    for(int c=1; c<=m; ++c){
        sl.clear();
        sl << QString::number(c);
        for(auto &suc : sucty){
            for(int s=1; s<=n; ++s){
                sl << QString::number(ssh.pocet(suc,c,s));
            }
        }
        sl << QString::number(ssh.pocetCelkom(c));
        ret.push_back(sl);
    }

    return ret;
}

void step::krok(Kombinacie &k, QString suffix, int n, int m){

    // for out
    QFile k2("krok2"+suffix+".csv");
    if(!k2.open(QFile::WriteOnly)){
        return;
    }
    QTextStream out(&k2);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);
    QStringList header;
    for(int i=0; i < k.front().size(); ++i){
        header.append("S" + QString::number(i+1));
    }
//    header.append({"∑", "ZH"});
    header.append("∑");
//    out << header.join(";") << "\n";
    //
    QHash<int, std::vector<K>> kombs;

    qSort(k.begin(), k.end());
    auto kend = k.end();
    for(auto begin = k.begin(); begin != kend; ++begin){
        int sum = sumKomb(*begin);
        kombs[sum].push_back(K(sumKomb(*begin), 0, &(*begin)));
    }

    auto keys = kombs.keys();
    qSort(keys);
    for(int &key : keys){
        auto vecK = kombs.value(key);
        std::sort(vecK.begin(), vecK.end(), byKombOrder);

//        std::vector<std::vector<K>> vvk;
//        auto begin = vecK.begin();
//        auto end = vecK.end();

        // podskupiny zh
//        if(vecK.size() > 1){
//            for(; begin+1 != end; ++begin){
//                vvk.push_back(compare_vk(begin, end));
//            }
//        } else{
//            vvk.push_back({*begin});
//        }

        //Out
//        for(auto &vk : vvk){
//            out << header.join(";") << "\n";
//            for(auto &k : vk){
//                out << k.toQstringList().join(";") << "\n";
//            }
//            out << ";" << "\n";
//        }
        //OUT2
        out << header.join(";") << "\n";
        for(auto &cK : vecK)
            out << cK.toQstringList().join(";") << "\n";
        out << ";" << "\n";
    }

    auto vsl = stat_sum(k, n, m);

    out << ";" << "\n";
    for(auto &sl : vsl)
        out << sl.join(";") << "\n";
}

void step::process(){
    emit info("Nacitavam subor...");
    auto k = readFile(path, from, to);

    if(k.empty()){
        emit info("Nepodarilo sa nacitat subor :(");
        return;
    }

//    for(auto &komb : k)
//        qDebug() << kombToQStr(komb);

    krok(k, suf, n, m);
    emit send_kombs(k);
    emit done(path);
}

void comparator::process(){

    emit info("Porovnavam subory...");

    cmpKombs(k1, k2);

    emit info("Porovnavanie dokoncene");
    emit done();
}

void comparator::cmpKombs(Kombinacie kombs1, Kombinacie kombs2){

    QVector<K> vk1;
    Kombinacie kombinacie;

//    for(auto &k1 : kombs1){

//    }


//    QVector<QVector<K>> vvk1;

    for(Kombinacia &k1 : kombs1){
//        QVector<K> vk1;

//        int k1_sum = sumKomb(k1);
//        if(k1_sum >= m_sod && k1_sum <= m_sdo){
//            vk1.push_back(K(k1_sum, 0, &k1));
//        } else {
//            continue;
//        }

        for(auto &k2 : kombs2){
            int k2_sum = sumKomb(k2);
            if(k2_sum >= m_sod && k2_sum <= m_sdo){
                int zh_k12 = compareKombs(k1, k2);
                if(zh_k12 > 0 && zh_k12 == m_zh){
                    auto k = K(k2_sum, zh_k12, &k2);
                    if(!vk1.contains(k)){
                        vk1.push_back(k);
                        kombinacie.push_back(k2);
                    }
                }
            } else{
                continue;
            }
        }
//        if(!vk1.empty())
//            vvk1.push_back(vk1);
    }

//    int size = kombs1.front().size() > kombs2.front().size() ? kombs1.front().size() : kombs2.front().size();

    QFile f("vystup.csv");
    f.open(QFile::WriteOnly);
    QTextStream out(&f);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);
    QStringList header;

    for(int i=0; i < m_n; ++i){
        header.append("S" + QString::number(i+1));
    }
    header.append({"∑", "ZH"});
    //    out << header.join(";") << "\n";

    //    for(auto &vk1 : vvk1){
    //        if(vk1.size() <= 1)
    //            continue;
    out << header.join(";") << "\n";

    qSort(vk1.begin(), vk1.end(), bySum);

    if(vk1.size() > 1){
        auto ittA = vk1.begin();
        auto ittB = vk1.begin() + 1;
        auto ittEnd = vk1.end();

        while(ittA != ittEnd){
            if(ittB == ittEnd){
                qSort(ittA, ittB, byKombOrder);
                break;
            } else if((*ittA).Sum() == (*ittB).Sum()){
                ++ittB;
            } else {
                qSort(ittA, ittB, byKombOrder);
                ittA = ittB;
            }
        }
    }

    for(auto &k1 : vk1){

        QStringList l = k1.toQstringList();
        l.append(QString::number(k1.Zh()));
        int k1s = k1.Komb()->size();

//        while(k1s < m_n){
//            l.insert(l.size()-2,"");
//            ++k1s;
//        }
        out << l.join(";") << "\n";
    }
    out << ";" << "\n";
    //    }

    auto vsl = stat_sum(kombinacie, m_n, m_m);
    out << ";" << "\n";
    for(auto &sl : vsl)
        out << sl.join(";") << "\n";

    f.close();
}

#ifndef COMPARATOR_H
#define COMPARATOR_H

#include "qobject.h"

#include "vector"
#include "limits.h"

using Kombinacia = std::vector<char>;
using Kombinacie = std::vector<Kombinacia>;

class step : public QObject
{
    Q_OBJECT

public:
    step(QString path, int from, int to ,int n, int m, QString suf): path{path}, from{from}, to{to}, n{n}, m{m}, suf{suf}{}
public slots:
    void process();
signals:
    void info(QString msg = "");
    void send_kombs(Kombinacie k);
    void done(QString msg = "");
private:
    int from, to, n, m;
    QString path, suf;

    void krok(Kombinacie &k, QString suffix, int n, int m);
};

class comparator : public QObject
{
    Q_OBJECT

public:
    comparator(Kombinacie k1, Kombinacie k2): k1{k1}, k2{k2}{}
    void set_zh(int zh){m_zh = zh;}
    void set_sumOD(int sod){m_sod = sod;}
    void set_sumDO(int sdo){m_sdo = sdo;}
    void set_n_m(int n, int m){m_m = m; m_n = n;}
public slots:
    void process();
signals:
    void info(QString msg);
    void done();
private:
    void cmpKombs(Kombinacie kombs1, Kombinacie kombs2);

    int m_n, m_m;
    int m_sod = std::numeric_limits<int>::min();
    int m_sdo = std::numeric_limits<int>::max();
    int m_zh;
    Kombinacie k1, k2;
};

//void cmpKombs(Kombinacie kombs1, Kombinacie kombs2){

//    QVector<QVector<K>> vvk1;

//    for(auto &komb1 : kombs1){
//        QVector<K> vk1;
//        vk1.push_back(K(sumKomb(komb1), 0, &komb1));
//        for(auto &komb2 : kombs2){
//            int c = compareKombs(komb1, komb2);
//            if(c > 0)
//                vk1.push_back(K(sumKomb(komb2), c, &komb2));
//        }
//        vvk1.push_back(vk1);
//    }
//    QFile f("vystup11.csv");
//    f.open(QFile::WriteOnly);
//    QTextStream out(&f);
//    out.setCodec("UTF-8");
//    out.setGenerateByteOrderMark(true);
//    QStringList header;
//    for(int i=0; i < kombs1.front().size(); ++i){
//        header.append("S" + QString::number(i+1));
//    }
//    header.append({"∑", "ZH"});
//    out << header.join(";") << "\n";

//    for(auto &vk1 : vvk1){
//        for(auto &k1 : vk1){
//            out << k1.toQstringList().join(";") << "\n";
//        }
//        out << ";" << "\n";
//    }
//    f.close();
//}

int compareKombs(Kombinacia k1, Kombinacia k2);
int sumKomb(Kombinacia k);
QString kombToQStr(Kombinacia k);
Kombinacie readFile(QString &path, int from, int to);

#endif // COMPARATOR_H

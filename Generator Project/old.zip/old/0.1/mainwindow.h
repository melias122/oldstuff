#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "numbers.h"
#include "generator.h"
#include "fileop.h"

#include "combination.h"
#include "FindCombByIdx.h"
#include "FindTotalComb.h"
#include "IndexCombination.h"
#include "BigIntegerLibrary.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
private slots:
    void on_actionKoniec_triggered();
    void on_pushButton_File_browser_clicked();

    void on_actionGeneruj_triggered();

    void on_spinBox_N_editingFinished();

    void on_spinBox_M_editingFinished();

    void on_actionNacitaj_subor_triggered();

private:
    std::vector<unsigned> ca,cb;
    Ui::MainWindow *ui;
    Numbers n;
    QString file_path;
    stdcomb::CFindCombByIdx< CFindTotalComb<BigInteger>, BigInteger > findcomb;
};

#endif // MAINWINDOW_H

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<iostream>

#include<QFileDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionKoniec_triggered()
{
//    qApp->exit(0);
    std::vector<unsigned> nums(7);
    findcomb.FindCombByIdx(7, 45, 10, nums );
    for(std::vector<unsigned>::iterator it = nums.begin(); it != nums.end(); it++){
        std::cout << *it << " ";
//        cb.push_back(nums[u] + 1);
    }
}

void MainWindow::on_pushButton_File_browser_clicked()
{
    file_path = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    ui->lineEdit_Path->setText(file_path);
}

template<class T>
QString comb_to_str(T begin, T end){
    QString s;
    for(T i=begin; i!=end; i++){
        s.append(QString::number(*i));
        s.append(" ");
    }
    return s;
}

template<class T>
unsigned comb_sum(T begin, T end, unsigned from, unsigned to){
    unsigned sum=0;
    for(T i=begin; i!=end; i++){
        sum += *i;
    }
    return ((sum >= from) && (sum <= to)) ? sum : 0;
}

void MainWindow::on_actionGeneruj_triggered()
{
    int i = 0, col = 0;
    double sum_R=0,sum_R_Lpi=0,sum_STL=0,sum_STL_Lpi=0,sum_comb=0;

    cb.clear();
//    for(unsigned i = 1; i <= n.get_N(); i++) cb.push_back(i);

//    if(ui->rows_limit_OD->text().toLong() > 1){
//        while(stdcomb::next_combination(ca.begin (),ca.end (),cb.begin (),cb.end()) && (i <= ui->rows_limit_OD->text().toLong()))
//            i++;
//    }
    std::vector<unsigned int> nums(n.get_N());
    findcomb.FindCombByIdx(n.get_N(), n.get_M(), (ui->rows_limit_OD->text().toLong() - 1), nums );
    for(unsigned u=0; u < nums.size(); u++){
        std::cout << nums[u] + 1 << " ";
        cb.push_back(nums[u] + 1);
    }

    // sirka tabulky
    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(((n.get_N())*5) + n.get_N());
    //

    do {
        if(i == ui->tableWidget->rowCount())
            ui->tableWidget->insertRow(ui->tableWidget->rowCount());

        sum_R=n.sum_R(cb.begin(),cb.end(), ui->R_OD->text().toDouble(), ui->R_DO->text().toDouble());
        sum_R_Lpi=n.sum_R_Lpi(cb.begin(),cb.end(), ui->R_Lpi_OD->text().toDouble(), ui->R_Lpi_DO->text().toDouble());
        sum_STL=n.sum_STL(cb.begin(),cb.end(),ui->STL_OD->text().toDouble(),ui->STL_DO->text().toDouble());
        sum_STL_Lpi=n.sum_STL_Lpi(cb.begin(),cb.end(),ui->STL_Lpi_OD->text().toDouble(), ui->STL_Lpi_DO->text().toDouble());
        sum_comb=comb_sum(cb.begin(),cb.end(), ui->SUM_Komb_OD->text().toInt(), ui->SUM_Komb_DO->text().toInt());

        if( (sum_R == 0) || (sum_R_Lpi == 0) || (sum_STL == 0) || (sum_STL_Lpi == 0) || (sum_comb == 0))
            continue;

        col = 0;
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(comb_to_str(cb.begin(),cb.end())));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_R)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_R_Lpi)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_STL)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_STL_Lpi)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_comb)));

        // ciastocne sucty
        for(unsigned cs = 0; cs < cb.size(); cs++){
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(cb[cs])));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_R(cb.begin()+cs,cb.begin()+cs+1))));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_R_Lpi(cb.begin()+cs,cb.begin()+cs+1))));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_STL(cb.begin()+cs,cb.begin()+cs+1))));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_STL_Lpi(cb.begin()+cs,cb.begin()+cs+1))));
        }
        //

        i++;
    } while(stdcomb::next_combination(ca.begin (),ca.end (),cb.begin (),cb.end()) && (i < ui->rows_limit_DO->text().toLong()));
    // header
}


void MainWindow::on_spinBox_N_editingFinished()
{
    this->n = Numbers(ui->spinBox_N->text().toInt(), ui->spinBox_M->text().toInt());
    cb.clear();
    for(unsigned i = 1; i <= n.get_N(); i++) cb.push_back(i);
}

void MainWindow::on_spinBox_M_editingFinished()
{
    this->n = Numbers(ui->spinBox_N->text().toInt(), ui->spinBox_M->text().toInt());
    ca.clear();
    for(unsigned i = 1; i <= n.get_M(); i++) ca.push_back(i);
}

void MainWindow::on_actionNacitaj_subor_triggered()
{
    read_numbers_STL(n, ui->lineEdit_Path->text().toStdString());
    read_numbers_R(n, ui->lineEdit_Path->text().toStdString());
}

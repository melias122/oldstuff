#ifndef GENERATOR_H_
#define GENERATOR_H_

#include <vector>
#include<iostream>

#include "numbers.h"

template<class BidIt>
void display(BidIt begin,BidIt end)
{
  for (BidIt it=begin;it!=end;++it)
      std::cout<<*it<<" ";
//  std::cout<<std::endl;
}

class Generator {
public:

	Generator();
	Generator(const Numbers &numbers);
	~Generator();

    template<class T>
    unsigned sum_num(T begin, T end){
        unsigned sum = 0;
        for(T it = begin; it != end; ++it){
            sum += *it;
        }
        return sum;
    }

	void comb_all();
    void comb();


private:
    std::vector<unsigned> ca, cb;
	Numbers numbers;

};

#endif /* GENERATOR_H_ */

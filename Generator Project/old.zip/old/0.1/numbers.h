#include <map>
#include<limits>

#ifndef NUMBERS_H
#define NUMBERS_H

class N {
public:

    N(unsigned n){
        R = R_Lpi = 0;
        for(unsigned i=1; i <=n; i++){
            STL.insert(std::pair<unsigned,double>(i,0));
            STL_Lpi.insert(std::pair<unsigned,double>(i,0));
        }
    }
    ~N(){}

    void set_R(double R){
        this->R = R;
    }

    void set_R_Lpi(double R_Lpi){
        this->R_Lpi = R_Lpi;
    }

    void set_STL(unsigned stl, double STL){
        if(stl > 0)
            this->STL.at(stl) = STL;
//        else
//            std::cerr << "Error: 'Nepodarilo sa vlozit hodnotu STL " << stl << ": " << STL << "'";
    }
    void set_STL_Lpi(unsigned stl, double STL_Lpi){
        if(stl > 0)
            this->STL_Lpi.at(stl) = STL_Lpi;
//        else
//            std::cerr << "Error: 'Nepodarilo sa vlozit hodnotu STL " << stl << ": " << STL << "'";
    }

    double get_R(){
        return R;
    }
    double get_R_Lpi(){
        return R_Lpi;
    }
    double get_STL(unsigned stl){
       return (stl>0) ? STL.at(stl) : 0;
    }
    double get_STL_Lpi(unsigned stl){
        return (stl>0) ? STL_Lpi.at(stl) : 0;
    }

private:

    double R, R_Lpi;
    std::map<unsigned, double> STL, STL_Lpi;

};

class Numbers {
public:

    Numbers(){}

    Numbers(unsigned n, unsigned m){
        this->n = n;
        this->m = m;
        for(unsigned i=1; i <= m; i++){
            numbers.insert(std::pair<unsigned, N>(i, N(n)));
        }
    }

    ~Numbers(){}

    template<class T>
    double sum_R(T begin, T end, double from = 0, double to = std::numeric_limits<double>::max()){ // OD DO
        if(to <= 0) to = std::numeric_limits<double>::max();
        double sum = 0;
        for(T it = begin; it != end; ++it){
                sum += get_R(*it);
        }
        return ((sum >= from) && (sum <= to)) ? sum : 0;
    }

    template<class T>
    double sum_STL(T begin, T end, double from = 0, double to = std::numeric_limits<double>::max()){
        if(to <= 0) to = std::numeric_limits<double>::max();
        double sum = 0; int i = 1;
        for(T it = begin; it != end; ++it, ++i){
                sum += get_STL(*it,i);
        }
        return ((sum >= from) && (sum <= to)) ? sum : 0;
    }

    template<class T>
    double sum_R_Lpi(T begin, T end, double from = 0, double to = std::numeric_limits<double>::max()){
        if(to <= 0) to = std::numeric_limits<double>::max();
        double sum = 0;
        for(T it = begin; it != end; ++it){
                sum += get_R_Lpi(*it);
        }
        return ((sum >= from) && (sum <= to)) ? sum : 0;
    }

    template<class T>
    double sum_STL_Lpi(T begin, T end, double from = 0, double to = std::numeric_limits<double>::max()){
        if(to <= 0) to = std::numeric_limits<double>::max();
        double sum =0; int i=1;
        for(T it = begin; it != end; ++it,++i){
                sum += get_STL_Lpi(*it,i);
        }
        return ((sum >= from) && (sum <= to)) ? sum : 0;
    }

    void set_R(unsigned c, double R){
        numbers.at(c).set_R(R);
    }

    void set_R_Lpi(unsigned c, double R_Lpi){
        numbers.at(c).set_R_Lpi(R_Lpi);
    }

    void set_STL(unsigned c, unsigned stl, double STL){
        numbers.at(c).set_STL(stl,STL);
    }

    void set_STL_Lpi(unsigned c, unsigned stl, double STL_Lpi){
        numbers.at(c).set_STL_Lpi(stl, STL_Lpi);
    }

    double get_R(unsigned c){
        return numbers.at(c).get_R();
    }
    double get_R_Lpi(unsigned c){
        return numbers.at(c).get_R_Lpi();
    }
    double get_STL(unsigned c, unsigned stl){
        return numbers.at(c).get_STL(stl);
    }
    double get_STL_Lpi(unsigned c, unsigned stl){
        return numbers.at(c).get_STL_Lpi(stl);
    }

    unsigned get_N(){
        return n;
    }
    unsigned get_M(){
        return m;
    }

private:
//    bool
    unsigned n, m;
    std::map<unsigned, N> numbers;

};

#endif // NUMBERS_H

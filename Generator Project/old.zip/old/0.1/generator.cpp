//#include "IndexCombination.h"
#include "combination.h"

#include "generator.h"

using namespace std;
using namespace stdcomb;

/*
 * public
 */

Generator::Generator(){}

//Generator::Generator(const Numbers &numbers){
//    for(unsigned i = 1; i <= numbers.get_M(); i++) ca.push_back (i);
//    for(unsigned i = 1; i <= numbers.get_N(); i++) cb.push_back (i);

//}

Generator::~Generator(){}

void Generator::comb_all(){

	vector<int> ca, cb;

    for(unsigned i = 1; i <= numbers.get_M(); i++) ca.push_back (i);
    for(unsigned i = 1; i <= numbers.get_N(); i++) cb.push_back (i);

	do {
		display(cb.begin(),cb.end());
	} while(next_combination(ca.begin (),ca.end (),cb.begin (),cb.end()) );

	cout<<"Complete!"<<endl;
}

void Generator::comb(){

	vector<unsigned> ca, cb;

    for(unsigned i = 1; i <= numbers.get_M(); i++) ca.push_back (i);
    for(unsigned i = 1; i <= numbers.get_N(); i++) cb.push_back (i);

    do {
        display(cb.begin(),cb.end());
        cout << numbers.sum_R(cb.begin(),cb.end()) << " " << numbers.sum_STL(cb.begin(),cb.end()) << " " << numbers.sum_R_Lpi(cb.begin(),cb.end()) << " " << numbers.sum_STL_Lpi(cb.begin(),cb.end()) << " " << sum_num(cb.begin(),cb.end()) << endl;
	} while(next_combination(ca.begin (),ca.end (),cb.begin (),cb.end()) );
    cout<<"Complete!"<<endl;
}


#include "mainwindow.h"
#include <QApplication>

//#include<vector>
//#include<iostream>
//#include<string>
//#include<fileop.h>
//#include"generator.h"


//template <class T>
//void func(T a, T b){
//    std::cout << a << " " << b;
//}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    
    return a.exec();

//    std::vector<int> v;
//    Numbers n(7,45);
//    read_numbers_R(n,"/home/melias122_elementary/745R.csv");
//    read_numbers_STL(n, "/home/melias122_elementary/745STL.csv");
//    for(int i=1; i <= 7; i++)
//        v.push_back(i);
//    std::cout << n.sum_R(v.begin(),v.end());
//    Generator g(n);
//    g.comb();
}

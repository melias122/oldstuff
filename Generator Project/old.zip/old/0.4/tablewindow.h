#ifndef TABLEWINDOW_H
#define TABLEWINDOW_H

#include <QMainWindow>
#include<deque>
#include<vector>
#include<limits>

#include "db.h"
#include "numbers.h"

namespace Ui {
class TableWindow;
}

class TableWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit TableWindow(QWidget *parent = 0);
    ~TableWindow();

    void header(int c);
    void header_csum(int c);
    void size(int size);
    void insert_row();
    void insert_item(int row, int col, int i);
    void insert_item(int row, int col, double d);
    void insert_item(int row, int col, QString s);
    void create_worklist(std::deque< std::vector<quint8> > worklist, Numbers n1, Numbers n2);
    void create_arch(std::deque< std::vector<quint8> > arch, Numbers n);
    void create_filt(std::deque< std::vector<quint8> > worklist, Numbers n1, Numbers n2, std::vector<std::vector<double> > limits);

    template<class T>
    bool is_ok(T begin, T end, Numbers &n1, Numbers &n2, std::vector<std::vector<double> > &limits);

    template<class T>
    void insert_sums(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2);

    template<class T>
    void insert_csums(T begin, T end, int row, int &col, Numbers &n);

    template<class T>
    void insert_csums2(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2);

    template<class T>
    QString comb_to_str(T begin, T end);

    template<class T>
    double sum_R(T begin, T end, Numbers &n, double from = 0, double to = std::numeric_limits<double>::max());

    template<class T>
    double sum_STL(T begin, T end, Numbers &n, double from = 0, double to = std::numeric_limits<double>::max());

    template<class T>
    double sum_R_Lpi(T begin, T end, Numbers &n, double from = 0, double to = std::numeric_limits<double>::max());

    template<class T>
    double sum_STL_Lpi(T begin, T end, Numbers &n, double from = 0, double to = std::numeric_limits<double>::max());

    template<class T>
    int sum_comb(T begin, T end, int from = 0, int to = std::numeric_limits<int>::max());
    
private slots:
    void on_pushButton_clicked();

private:
    Ui::TableWindow *ui;
};

#endif // TABLEWINDOW_H

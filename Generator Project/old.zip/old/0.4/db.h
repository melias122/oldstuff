#ifndef DB_H
#define DB_H

#include "fileop.h"
#include "numbers.h"

#include<deque>
#include<map>
#include<vector>

#include<QtGlobal>

class DB
{
public:

    DB();

    DB operator =(std::deque<std::vector<quint8> > n){
        this->nums = n;
        return *this;
    }

    DB operator =(Numbers n){
        this->numbers = n;
        return *this;
    }

    int get_N();
    int get_M();

//    void save(QString filename);
    bool save();
    bool load(QString filename);

    void clear();
    bool empty();
    std::deque<std::vector<quint8> > get_nums();
    Numbers get_numbers();

private:
    Numbers numbers;
    std::deque< std::vector<quint8> > nums;
};

#endif // DB_H

#include "db.h"

#include<QFile>
#include<QDebug>
#include<QDataStream>
#include<QIODevice>
#include<QFileDialog>
//#include<QFileInfo>

DB::DB(){}

int DB::get_N(){
    return numbers.get_N();
}
int DB::get_M(){
    return numbers.get_M();
}

void DB::clear(){
    this->nums.clear();
}

bool DB::empty(){
    return this->nums.empty();
}

std::deque<std::vector<quint8> > DB::get_nums(){
    return this->nums;
}

Numbers DB::get_numbers(){
    return this->numbers;
}

bool DB::save(){

    QString filename = QFileDialog::getSaveFileName();

    if(filename.isEmpty())
        return false;
    else
        filename.append(".db");

    QFile file(filename);

    if(!file.open(QIODevice::WriteOnly)){
        qDebug() << "Error: Nepodarilo sa otvorit subor " << filename << endl;
        return false;
    }
    QDataStream out(&file);

    out << (int)numbers.get_N() << (int)numbers.get_M();
    for(int i=1; i <= numbers.get_M(); i++){
        out << (double)numbers.get_R(i) << (double)numbers.get_R_Lpi(i);
    }
    for(int i=1; i <= numbers.get_M(); i++){
        for(int j=1; j <= numbers.get_N(); j++){
            out << (double)numbers.get_STL(i,j) << (double)numbers.get_STL_Lpi(i,j);
        }
    }
    for(int i=0;i<nums.size();i++){
        for(int j=0;j<nums[i].size();j++){
            out << (quint8)nums[i][j];
        }
    }
    file.close();

    return true;
}

bool DB::load(QString filename){

    int N,M;
    double d1, d2;
    quint8 qu;

    QFile file(filename);

    if(!file.open(QIODevice::ReadOnly)){
        qDebug() << "Error: Nepodarilo sa otvorit subor " << filename << endl;
        return false;
    }
    QDataStream in(&file);\

    in >> N >> M;
    Numbers numbers(N,M);

    for(int i=1; i <= numbers.get_M(); i++){
        in >> d1 >> d2;
        numbers.set_R(i,d1);
        numbers.set_R_Lpi(i,d2);
    }
    for(int i=1; i <= numbers.get_M(); i++){
        for(int j=1; j <= numbers.get_N(); j++){
            in >> d1 >> d2;
            numbers.set_STL(i,j, d1);
            numbers.set_STL_Lpi(i,j, d2);
        }
    }
    this->numbers = numbers;

    this->nums.clear();
    while(!in.atEnd()){
        std::vector<quint8> v;
        for(int j=0;j<this->numbers.get_N();j++){
            in >> qu;
            v.push_back(qu);
        }
        nums.push_back(v);
    }


//    qDebug() << (int)this->numbers.get_N() << (int)this->numbers.get_M();
//    for(int i=1; i <= this->numbers.get_M(); i++){
//        qDebug() << (double)this->numbers.get_R(i) << (double)this->numbers.get_R_Lpi(i);
//    }
//    for(int i=1; i <= this->numbers.get_M(); i++){
//        for(int j=1; j <= this->numbers.get_N(); j++){
//            qDebug() << (double)this->numbers.get_STL(i,j) << (double)this->numbers.get_STL_Lpi(i,j);
//        }
//    }
//    for(int i=0;i<this->nums.size();i++){
//        for(int j=0;j<this->nums[i].size();j++){
//            qDebug() << (quint8)this->nums[i][j];
//        }
//    }

    file.close();

    return true;
}

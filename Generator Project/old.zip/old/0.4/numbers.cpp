#include "numbers.h"
#include "utils.h"
#include "fileop.h"

#include <algorithm>

using namespace std;

//N

N::N(unsigned n){
    R = R_Lpi = 0;
    for(unsigned i=1; i <=n; i++){
        STL.insert(std::pair<unsigned,double>(i,0));
        STL_Lpi.insert(std::pair<unsigned,double>(i,0));
    }
}

N::~N(){}

void N::set_R(double R){
    this->R = R;
}

void N::set_R_Lpi(double R_Lpi){
    this->R_Lpi = R_Lpi;
}

void N::set_STL(unsigned stl, double STL){
    if(stl > 0)
        this->STL.at(stl) = STL;
//        else
//            std::cerr << "Error: 'Nepodarilo sa vlozit hodnotu STL " << stl << ": " << STL << "'";
}

void N::set_STL_Lpi(unsigned stl, double STL_Lpi){
    if(stl > 0)
        this->STL_Lpi.at(stl) = STL_Lpi;
//        else
//            std::cerr << "Error: 'Nepodarilo sa vlozit hodnotu STL " << stl << ": " << STL << "'";
}

double N::get_R(){
    return R;
}

double N::get_R_Lpi(){
    return R_Lpi;
}

double N::get_STL(unsigned stl){
    return (stl>0) ? STL.at(stl) : 0;
}
double N::get_STL_Lpi(unsigned stl){
    return (stl>0) ? STL_Lpi.at(stl) : 0;
}

//N end


//Numbers

Numbers::Numbers(){
    init();
}

Numbers::Numbers(unsigned n, unsigned m){
    this->n = n;
    this->m = m;
    this->init();
}

Numbers::~Numbers(){}

void Numbers::set_N(unsigned n){ this->n = n;}

void Numbers::set_M(unsigned m){ this->m = m;}

template<class T>
double Numbers::sum_R(T begin, T end){ // OD DO
    double sum = 0;
    for(T it = begin; it != end; ++it){
        int i = (int)*it;
        sum += get_R(i);
    }
    return sum;
}

template<class T>
double Numbers::sum_STL(T begin, T end){
    double sum =0;
    for(T it = begin; it != end; ++it){
//        sum += get_STL(*it,1);
    }
    return sum;
}

template<class T>
double Numbers::sum_R_Lpi(T begin, T end){
    double sum = 0;
    for(T it = begin; it != end; ++it){
        sum += get_R_Lpi(*it);
    }
    return sum;
}

template<class T>
double Numbers::sum_STL_Lpi(T begin, T end){
    double sum =0;
    for(T it = begin; it != end; ++it){
//        sum += get_STL_Lpi(*it,1);
    }
    return sum;
}


void Numbers::set_R(unsigned c, double R){
    numbers.at(c).set_R(R);
}

void Numbers::set_R_Lpi(unsigned c, double R_Lpi){
    numbers.at(c).set_R_Lpi(R_Lpi);
}

void Numbers::set_STL(unsigned c, unsigned stl, double STL){
    numbers.at(c).set_STL(stl, STL);
}

void Numbers::set_STL_Lpi(unsigned c, unsigned stl, double STL_Lpi){
    numbers.at(c).set_STL_Lpi(stl, STL_Lpi);
}

double Numbers::get_R(unsigned c){
    return numbers.at(c).get_R();
}

double Numbers::get_R_Lpi(unsigned c){
    return numbers.at(c).get_R_Lpi();
}

double Numbers::get_STL(unsigned c, unsigned stl){
    return numbers.at(c).get_STL(stl);
}

double Numbers::get_STL_Lpi(unsigned c, unsigned stl){
    return numbers.at(c).get_STL_Lpi(stl);
}

unsigned Numbers::get_N(){
    return n;
}

unsigned Numbers::get_M(){
    return m;
}

//deque< vector<quint8> > Numbers::gen_R(){

//    deque< vector<quint8> > cmp1;
//    vector<double> perms;
//    map<double, vector<int> > m;
//    vector<int> ca, cb;

//    // Init
//    for(int i = 1; i <= get_M(); i++){
//        m.insert(pair<double, vector<int> >(get_R(i), vector<int>()));
//        m[get_R(i)].push_back(i);
//    }

//    map<double, vector<int> >::iterator it = m.begin(), end=m.end();
//    for(int i=0; i < get_N();i++){
//    }
//    //

////    for(;;){
//    do{
//        perms.clear();
////        for(int i = 0; i < size - 1; i++){
//        for(int i=0;i<get_N();i++){
//            perms.push_back(v[i]->first);
//        }
////        perms.push_back(k[poz-1]);

//        do {
//            check(perms, m, cmp1);
//        } while(next_permutation(perms.begin(), perms.end()));

//        // Perm na mnozine

//        int j=get_N()-1;
//        while(j > 0){
//            if(v[j]!=end){
//                v[j]++;
//                break;
//            }
//            --j;
//        }

//    }while(next_combination(ca.begin (),ca.end (),cb.begin (),cb.end()) );

//    for(int i=get_N()-1; i>=0 ; --i ){

//    }

//    return cmp1;
//}

//orig
//deque< vector<quint8> > Numbers::gen_R(){

//    deque< vector<quint8> > cmp1;
//    vector<double> perms,k;
//    map<double, vector<int> > m;

//    // Init
//    for(int i = 1; i <= get_M(); i++){
//        m.insert(pair<double, vector<int> >(get_R(i), vector<int>()));
//        m[get_R(i)].push_back(i);
//    }
//    for (map<double, vector<int> >::iterator it = m.begin(); it != m.end(); it++) {
//        k.push_back(it->first);
//    }
//    //

//    int size = get_N();
//    int poz = size;

//    for(;;){
//        perms.clear();
//        for(int i = 0; i < size - 1; i++){
//            perms.push_back(k[i]);
//        }
//        perms.push_back(k[poz-1]);

//        do {
//            check(perms, m, cmp1);
//        } while(next_permutation(perms.begin(), perms.end()));

//        // Perm na mnozine
//        if(poz < k.size()) poz++;
//        else if(k.size() > size){ k.erase(k.begin()); poz = size; }
//        else break;
//        //
//    }
//    return cmp1;
//}

#include<iostream>
deque< vector<quint8> > Numbers::gen_R(){

    using namespace std;

    deque< vector<quint8> > cmp1;
//    vector<double> perms,k;
    vector< set<quint8> > cmp2(get_N());
    vector<double> ca, cb;
    map<double, vector<int> > m;

    // Init
    for(int i = 1; i <= get_M(); i++){
        m.insert(pair<double, vector<int> >(get_R(i), vector<int>()));
        m[get_R(i)].push_back(i);
    }
    for (map<double, vector<int> >::iterator it = m.begin(); it != m.end(); it++) {
        ca.push_back(it->first);
    }
    for(int i = 0; i < get_N(); i++){
        cb.push_back(ca[i]);
    }
    //

    do{
        do {
            check2(cb, m, cmp2);
        } while(next_permutation(cb.begin(), cb.end()));

    }while(next_combination(ca.begin (),ca.end (),cb.begin (),cb.end()) );

    for(int i =0;i<cmp2.size();i++){
        for(set<quint8>::iterator it=cmp2[i].begin();it!=cmp2[i].end();it++){
            cout << (int)*it << " ";
        }
        cout << endl;
    }

    return cmp1;
}

vector< map<quint8, bool> > Numbers::gen_STL(){

    vector< map<quint8, bool> > cmp2(get_N());

    for(int stl = 1; stl <= get_N(); stl++){
        for(int cisl = stl; cisl <= (get_M() - get_N() + stl); cisl++){
            if(get_STL(cisl,stl) > 0)
                cmp2[stl - 1].insert(pair<quint8, bool>((quint8)cisl, true));
            else
                cmp2[stl - 1].insert(pair<quint8, bool>((quint8)cisl, false));
        }
    }

    return cmp2;
}

deque< vector<quint8> > Numbers::get_RxSTL(){

    vector< map<quint8, bool> > cmp2;
    deque< vector<quint8> > cmp1, out;

    cmp1 = gen_R();
    cmp2 = gen_STL();

    bool exist = false;
    while(!cmp1.empty()){

        for(int i =0; i < get_N();i++){
            exist = cmp2[i][cmp1.front()[i]];
            if(!exist)
                break;
        }
        if(exist){
            vector<quint8> v;
            for(vector<quint8>::iterator it = cmp1.front().begin(); it != cmp1.front().end(); it++){
                v.push_back(*it);
            }
            out.push_back(v);
        }
        cmp1.pop_front();
    }
    return out;
}


void Numbers::init(){
    numbers.clear();
    for(unsigned i=1; i <= 90; i++){
        numbers.insert(std::pair<unsigned, N>(i, N(30)));
    }
}

void Numbers::check2(vector<double> &perms, map<double, vector<int> > &m, vector< set<quint8> > &cmp1){

    vector<int> v;
    for(int i = 0; i < perms.size(); i++){
        v.push_back(0);
    }

    bool p;
    int i;

    for(;;){
        i = perms.size();
        p = true;

        for(int j = 0; j < perms.size() -1; j++){
            if((m[perms[j]])[v[j]] > (m[perms[j+1]])[v[j+1]]){
                p = false;
                break;
            }
        }
        if(p){
            for(int j = 0; j < perms.size(); j++){
//                    out.push_back((quint8)(m[perms[j]])[v[j]]);
//                cmp1[j].insert((quint8)(m[perms[j]])[v[j]]);
                cout << (int) m[perms[j]][v[j]] << " ";
            }
            cout << endl;
        }

        --i;
        while(i > 0){
            if(v[i] < (m[perms[i]]).size() - 1){
                v[i]++;
                break;
            }
            else{
                v[i] = 0;
            }
            --i;
        }
        if(i == 0) break;
    }
}

//void Numbers::check(vector<double> &perms, map<double, vector<int> > &m, deque< vector<quint8> > &cmp1){

//    vector<int> v;
//    for(int i = 0; i < perms.size(); i++){
//        v.push_back(0);
//    }

//    bool p;
//    int i;
//    for(;;){
//        i = perms.size();
//        p = true;
//        for(int j = 0; j < perms.size() -1; j++){
//            if((m[perms[j]])[v[j]] > (m[perms[j+1]])[v[j+1]]){
//                p = false;
//                break;
//            }
//        }
//        if(p){
//            vector<quint8> out;
////            out.clear();
//            for(int j = 0; j < perms.size(); j++){
//                out.push_back((quint8)(m[perms[j]])[v[j]]);
//            }
//            cmp1.push_back(out);
////            cmp1.push_back(out);
////            write_comb(out, "Rcomb");
//        }

//        --i;
//        while(i > 0){
//            if(v[i] < (m[perms[i]]).size() - 1){
//                v[i]++;
//                break;
//            }
//            else{
//                v[i] = 0;
//            }
//            --i;
//        }
//        if(i == 0) break;
//    }
//}

//Numbers end

#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}

//#include"utils.h"
//#include"fileop.h"
//#include"numbers.h"
////#include"generator.h"

//#include<iostream>
//#include<vector>
//#include<deque>
//#include<algorithm>
//#include<set>

//using namespace std;

//template<class T>
//double sum(T begin, T end){}

//set<int> r_combs(vector<double> &rperc, double min, double max, Numbers &n1){

//    set<int> nums;
//    vector<int> ca, cb;
//    vector<double> pperc;

//    for(int i=1; i<= n1.get_M();i++){
//        ca.push_back(i);
//    }
//    for(int i=1;i<=n1.get_N();i++){
//        cb.push_back(i);
//    }

//    do{
//        pperc.clear();
//        for(int i=0;i<cb.size();i++){
//            pperc.push_back(rperc[cb[i]-1]);
//        }
//        double s = sum(pperc.begin(),pperc.end());
//        if((s>=min) && (s<=max)){
//            for(int i=0;i<pperc.size();i++){
////                nums.insert(cb[i]);
//                cout << cb[i] << " ";
//            }
//            cout << endl;
//        }
//    }while (next_combination(ca.begin(),ca.end(),cb.begin(),cb.end()) /*&& nums.size() < n1.get_M()*/);

//    cout << nums.size() << endl;
//    for(set<int>::iterator it=nums.begin(); it!=nums.end(); it++){
//        cout << *it << " ";
//    }
//    cout << endl;


//    return nums;
//}

//void Rc(Numbers &n1, double min, double max){

//    vector<double> rperc;

//    for(int i=1; i<= n1.get_M();i++){
//        rperc.push_back(n1.get_R(i));
//    }
//    r_combs(rperc,min, max, n1);
//}

//void RLpic(Numbers &n1, double min, double max){

//    vector<double> rperc;

//    for(int i=1; i<= n1.get_M();i++){
//        rperc.push_back(n1.get_R_Lpi(i));
//    }
//    r_combs(rperc,min, max, n1);
//}



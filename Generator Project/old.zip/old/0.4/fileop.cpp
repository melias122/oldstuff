#include "fileop.h"

#include <QRegExp>
#include <QStringList>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QDateTime>
#include <QDir>

using namespace std;

bool read_numbers_R(Numbers &numbers, QString filename){

    QFile file(filename);
    QString strc;
    QRegExp rx("(\\;)"); //RegEx for ';' or ',' or '.' or ':' or '\t'

    if(!file.open(QFile::ReadOnly)){
        qDebug() << "Error: Nepodarilo sa otvorit subor " << filename;
        return false;
    }

    QTextStream in(&file);
    unsigned n = 1;
    while(!in.atEnd()){
//        getline(file, line);
        QString line = in.readLine();
        QStringList query = line.split(rx);

        strc.append("chcem(1):"); strc.append(QString::number(n));
        if(strc.compare(query[0]) == 0 ){
            unsigned j = 0;
            for(QStringList::Iterator it = query.begin(); it != query.end(); it++, j++){
                (*it).replace(QString(","), QString("."));
//                cout << (*it).toStdString() << " ";
                if(j == 5){
                    numbers.set_R(n, (*it).toDouble());
//                    cout << (*it).toDouble() << " ";
                }
                if(j == 9){
                    numbers.set_R_Lpi(n, (*it).toDouble());
//                    cout << (*it).toDouble() << " ";
                }
            }
//            cout << endl;
            n++;
        }
        strc.clear();
    }

    file.close();
    return (n > 1) ? true : false;
}

bool read_numbers_STL(Numbers &numbers, QString filename){

    bool readed = false;
    unsigned n,m;

    QFile file(filename);
    QString strc;
    QRegExp rx("(\\;)"); //RegEx for ';' or ',' or '.' or ':' or '\t'

    if(!file.open(QFile::ReadOnly)){
        qDebug() << "Error: Nepodarilo sa otvorit subor " << filename << endl;
        return false;
    }

    QTextStream in(&file);
    n = m = 1;
    while(!in.atEnd()){

        QString line = in.readLine();
        QStringList query = line.split(rx);

        strc.append("stlchce("); strc.append(QString::number(n));
        strc.append("):"); strc.append(QString::number(m));

        if(strc.compare(query[0]) == 0 ){
            unsigned j = 0;
            for(QStringList::Iterator it = query.begin(); it != query.end(); it++, j++){
                (*it).replace(QString(","), QString("."));
//                cout << (*it).toDouble() << " ";
                if(j == 5){
                    numbers.set_STL(m, n, (*it).toDouble());
//                    cout << (*it).toDouble() << " ";
                    readed = true;
                }
                if(j == 9){
                    numbers.set_STL_Lpi(m, n, (*it).toDouble());
//                    cout << (*it).toDouble() << " ";
                    readed = true;
                }
            }
//            cout << endl;
            if(n == numbers.get_N()){ n = 1; m++; }
            else n++;
        }
        strc.clear();
    }

    file.close();
    if(readed)
        return true;
    else
        return false;
}

void write_protocol(QString filename, QString text){

    QDateTime t = QDateTime::currentDateTime();

    if(!filename.isEmpty()){
        QFile file(filename);

        if(!file.open(QFile::WriteOnly | QFile::Append)){
            qDebug() << "Error: Nepodarilo sa otvorit subor " << filename << endl;
            return;
        }
        QTextStream out(&file);
        out << t.toString("dd/MM/yyyy hh.mm.ss: ") << text << "\n";

        file.close();
    }
    else{
        qDebug() << t.toString("dd/MM/yyyy hh.mm.ss: ") << "Debug: " << text;
    }
}

//void write_db(DB &db, QString filename){

////    QString path(QDir::currentPath().append("/").append(filename));
//    QFile file(filename);

//    QDataStream out(&file);

//    if(!file.open(QFile::WriteOnly | QFile::Append)){
//        qDebug() << "Error: Nepodarilo sa otvorit subor " << filename << endl;
//        return;
//    }

//    file.close();
//}

//void write_comb(vector<int> &v, QString filename){

////    QString path(QDir::currentPath().append("/").append(filename));

//    QFile file(filename);
//    QDataStream out(&file);

//    if(!file.open(QFile::WriteOnly | QFile::Append)){
//        qDebug() << "Error: Nepodarilo sa otvorit subor " << filename << endl;
//        return;
//    }

//    for(vector<int>::iterator it = v.begin(); it != v.end(); it++){
//        out << (qint8)*it;
//    }
//    file.close();
//}


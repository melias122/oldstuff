#include "tablewindow.h"
#include "ui_tablewindow.h"

//#include<QDebug>
#include<QStringList>
#include<QTextStream>
#include<QFileDialog>
#include<algorithm>

TableWindow::TableWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::TableWindow)
{
    ui->setupUi(this);
}

TableWindow::~TableWindow()
{
    ui->tableWidget->clearContents();
//    while (ui->tableWidget->rowCount() > 0){ ui->tableWidget->removeRow(0); }
    delete ui;
}

void TableWindow::header(int c){

    QStringList t_header;

    t_header << "Kombinacie" << "ƩR1-DO"<< "ƩRLp-i1-DO"<< "ƩSTL1-DO"<< "ƩSTLLp-i1-DO"<< "ƩR OD-DO"<< "ƩRLp-i OD-DO"<< "ƩSTL OD-DO"<< "ƩSTLLp-i OD-DO" << "ƩKombinacie";

    for(int i=0; i < c; i++){
        t_header << "Cislo" << "R1-DO"<< "RLp-i1-DO"<< "STL1-DO"<< "STLLp-i1-DO"<< "R OD-DO"<< "RLp-i OD-DO"<< "STL OD-DO"<< "STLLp-i OD-DO";
    }

    ui->tableWidget->setHorizontalHeaderLabels(t_header);
    ui->tableWidget->horizontalHeader()->setVisible(true);

}

void TableWindow::header_csum(int c){

    QStringList t_header;

    for(int i=0; i < c; i++){
        t_header << "Cislo" << "R"<< "RLp-i"<< "STL"<< "STLLp-i";
    }

    ui->tableWidget->setHorizontalHeaderLabels(t_header);
    ui->tableWidget->horizontalHeader()->setVisible(true);
}

//void header_csum(int c){
//    QStringList t_header;

//    for(int i=0; i < c; i++){
//        t_header << "Cislo" << "R1-DO"<< "RLp-i1-DO"<< "STL1-DO"<< "STLLp-i1-DO"<< "R OD-DO"<< "RLp-i OD-DO"<< "STL OD-DO"<< "STLLp-i OD-DO";
//    }

//    ui->tableWidget->setHorizontalHeaderLabels(t_header);
//    ui->tableWidget->horizontalHeader()->setVisible(true);
//}

void TableWindow::insert_item(int row, int col, int i){
    insert_item(row, col, QString::number(i));
}

void TableWindow::insert_item(int row, int col, double d){
    insert_item(row, col, QString::number(d, 'g', 14));
}

void TableWindow::insert_item(int row, int col, QString s){
    ui->tableWidget->setItem(row ,col, new QTableWidgetItem(s));
}

void TableWindow::size(int size){
    ui->tableWidget->setColumnCount(size);
}

void TableWindow::insert_row(){
    ui->tableWidget->insertRow(ui->tableWidget->rowCount());
}

template<class T>
QString TableWindow::comb_to_str(T begin, T end){
    QString s;
    for(T i=begin; i!=end; i++){
        s.append(QString::number(*i));
        s.append(" ");
    }
    return s;
}

template<class T>
double TableWindow::sum_R(T begin, T end, Numbers &n, double from, double to){
    if(to <= 0) to = std::numeric_limits<double>::max();
    double sum = 0;
    for(T it = begin; it != end; ++it){
        int i = (int)*it;
        sum += n.get_R(i);
    }
    return ((sum >= from) && (sum <= to)) ? sum : 0;
}

template<class T>
double TableWindow::sum_STL(T begin, T end, Numbers &n, double from, double to){
    if(to <= 0) to = std::numeric_limits<double>::max();
    double sum =0;
    int i=1;
    for(T it = begin; it != end; ++it,++i){
        int j = (int)*it;
        sum += n.get_STL(j,i);
    }
    return ((sum >= from) && (sum <= to)) ? sum : 0;
}

template<class T>
double TableWindow::sum_R_Lpi(T begin, T end, Numbers &n, double from, double to){
    if(to <= 0) to = std::numeric_limits<double>::max();
    double sum = 0;
    for(T it = begin; it != end; ++it){
        int i = (int)*it;
        sum += n.get_R_Lpi(i);
    }
    return ((sum >= from) && (sum <= to)) ? sum : 0;
}

template<class T>
double TableWindow::sum_STL_Lpi(T begin, T end, Numbers &n, double from, double to){
    if(to <= 0) to = std::numeric_limits<double>::max();
    double sum =0;
    int i=1;
    for(T it = begin; it != end; ++it,++i){
        int j = (int)*it;
        sum += n.get_STL_Lpi(j,i);
    }
    return ((sum >= from) && (sum <= to)) ? sum : 0;
}

template<class T>
int TableWindow::sum_comb(T begin, T end, int from, int to){
    if(to <= 0) to = std::numeric_limits<int>::max();
    int sum = 0;
    for(T it = begin; it != end; ++it){
        int i = (int)*it;
        sum += i;
    }
    return ((sum >= from) && (sum <= to)) ? sum : 0;
}

template<class T>
void TableWindow::insert_sums(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2){

    insert_item(row, col++, comb_to_str(begin, end));
    insert_item(row, col++, sum_R(begin, end, n1));
    insert_item(row, col++, sum_R_Lpi(begin, end, n1));
    insert_item(row, col++, sum_STL(begin, end, n1));
    insert_item(row, col++, sum_STL_Lpi(begin, end, n1));
    insert_item(row, col++, sum_R(begin, end, n2));
    insert_item(row, col++, sum_R_Lpi(begin, end, n2));
    insert_item(row, col++, sum_STL(begin, end, n2));
    insert_item(row, col++, sum_STL_Lpi(begin, end, n2));
    insert_item(row, col++, sum_comb(begin, end));
}

template<class T>
void TableWindow::insert_csums(T begin, T end, int row, int &col, Numbers &n){
    int stl=1;
    for(T it = begin; it != end; it++ ){
        int c = (int)(*it);
        insert_item(row, col++, c);
        insert_item(row, col++, n.get_R(c));
        insert_item(row, col++, n.get_R_Lpi(c));
        insert_item(row, col++, n.get_STL(c, stl));
        insert_item(row, col++, n.get_STL_Lpi(c, stl));
        stl++;
    }
}

template<class T>
void TableWindow::insert_csums2(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2){

    int stl=1;
    for(T it = begin; it != end; it++ ){
        int c = (int)(*it);
        insert_item(row, col++, c);
        insert_item(row, col++, n1.get_R(c));
        insert_item(row, col++, n1.get_R_Lpi(c));
        insert_item(row, col++, n1.get_STL(c, stl));
        insert_item(row, col++, n1.get_STL_Lpi(c, stl));
        insert_item(row, col++, n2.get_R(c));
        insert_item(row, col++, n2.get_R_Lpi(c));
        insert_item(row, col++, n2.get_STL(c, stl));
        insert_item(row, col++, n2.get_STL_Lpi(c, stl));
        stl++;
    }

}

void TableWindow::create_worklist(std::deque< std::vector<quint8> > worklist, Numbers n1, Numbers n2){

    int col = 0, row = 0;
    std::vector<quint8>::iterator begin, end;

    this->size((9*n1.get_N()) + 10);

    while(!worklist.empty()){

        col = 0;
        begin = worklist.front().begin();
        end = worklist.front().end();

        this->insert_row();

        insert_sums(begin, end, row, col, n1, n2);
        insert_csums2(begin, end, row, col, n1, n2);

        worklist.pop_front();
        row++;
    }
    header(n1.get_N());
}

template<class T>
bool TableWindow::is_ok(T begin, T end, Numbers &n1, Numbers &n2, std::vector<std::vector<double> > &limits){
    if(sum_R(begin,end, n1, limits[0][0], limits[0][1]) == 0) return false;
    if(sum_R_Lpi(begin,end, n1, limits[1][0], limits[1][1]) == 0) return false;
    if(sum_STL(begin,end, n1, limits[2][0], limits[2][1]) == 0) return false;
    if(sum_STL_Lpi(begin,end, n1, limits[3][0], limits[3][1]) == 0) return false;
    if(sum_R(begin,end, n2, limits[0][2], limits[0][3]) == 0) return false;
    if(sum_R_Lpi(begin,end, n2, limits[1][2], limits[1][3]) == 0) return false;
    if(sum_STL(begin,end, n2, limits[2][2], limits[2][3]) == 0) return false;
    if(sum_STL_Lpi(begin,end, n2, limits[3][2], limits[3][3]) == 0) return false;
    if(sum_comb(begin,end,limits[4][0],limits[4][1]) == 0) return false;
    return true;
}

void TableWindow::create_filt(std::deque< std::vector<quint8> > worklist, Numbers n1, Numbers n2, std::vector<std::vector<double> > limits){

    int col = 0, row = 0;
    std::vector<quint8>::iterator begin, end;

    this->size((9*n1.get_N()) + 10);

    while(!worklist.empty()){

        col = 0;
        begin = worklist.front().begin();
        end = worklist.front().end();

        if(is_ok(begin,end,n1,n2,limits)){
            insert_row();
            insert_sums(begin, end, row, col, n1, n2);
            insert_csums2(begin, end, row, col, n1, n2);
            row++;
        }

        worklist.pop_front();
    }
    header(n1.get_N());
}

void TableWindow::create_arch(std::deque< std::vector<quint8> > arch, Numbers n){
    int col = 0, row = 0;
    std::vector<quint8>::iterator begin, end;

    this->size(5*n.get_N());

    std::sort(arch.begin(), arch.end());
    while(!arch.empty()){

        col = 0;
        begin = arch.front().begin();
        end = arch.front().end();

        this->insert_row();

        insert_csums(begin, end, row, col, n);

        arch.pop_front();
        row++;
    }
    header_csum(n.get_N());
}

void TableWindow::on_pushButton_clicked()
{
    QString filename;
    if((filename = QFileDialog::getSaveFileName(this, tr("Ulozit subor"), "", tr("Export (*.csv)"))) == "")
        return;
    filename.append(".csv");
    QFile f( filename );

    if (f.open(QFile::WriteOnly)) {

        QTextStream data( &f );
        QStringList strList;
        strList.clear();

        for( int c = 0; c < ui->tableWidget->columnCount(); ++c ) {
            strList << ui->tableWidget->horizontalHeaderItem(c)->data(Qt::DisplayRole).toString();
        }

        data << strList.join( ";" )+"\n";
        for( int r = 0; r < ui->tableWidget->rowCount(); ++r ) {

            strList.clear();
            for( int c = 0; c < ui->tableWidget->columnCount(); ++c ) {
                strList << ui->tableWidget->item( r, c )->text().replace(QString("."), QString(","));
            }

            data << strList.join( ";" )+"\n";
        }
        f.close();
    }
}

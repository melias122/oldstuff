#include "generator.h"

#include<QDebug>
#include<QThread>

GeneratorThread::GeneratorThread(QObject *parent) :
    QObject(parent)
{
}

void GeneratorThread::generate(){

    qDebug() << "hello";

    emit finished();
}


Generator::Generator(QObject *parent) :
    QObject(parent)
{
    this->threads_count = QThread::idealThreadCount();
}

void Generator::process() {

    for(int i = 0; i < threads_count; i++){

        QThread* thread = new QThread;
        GeneratorThread* worker = new GeneratorThread();

        worker->moveToThread(thread);

//      connect(worker, SIGNAL(error(QString)), this, SLOT(errorString(QString)));
        connect(thread, SIGNAL(started()), worker, SLOT(generate()));
        connect(worker, SIGNAL(finished()), thread, SLOT(quit()));
        connect(worker, SIGNAL(finished()), worker, SLOT(deleteLater()));
        connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));

        thread->start();
    }

//    qDebug() << QThread::idealThreadCount();
    emit finished();
}

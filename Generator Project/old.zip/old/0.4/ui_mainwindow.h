/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_10;
    QHBoxLayout *horizontalLayout_9;
    QHBoxLayout *horizontalLayout_6;
    QHBoxLayout *horizontalLayout_3;
    QSpinBox *spinBoxN;
    QLabel *label_12;
    QSpinBox *spinBoxM;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *db_R1;
    QPushButton *arch_R1;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *prac_list;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_7;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *db_ROD;
    QPushButton *arch_OD_R;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *protokol;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_10;
    QPushButton *file_R1;
    QPushButton *file_STL1;
    QPushButton *gen_dbR1;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_4;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *file_ROD;
    QPushButton *file_STLOD;
    QPushButton *gen_dbODR;
    QSpacerItem *verticalSpacer_4;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_12;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_11;
    QLabel *label_15;
    QLabel *label_18;
    QLabel *label_2;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *r1od;
    QLineEdit *r1lpiod;
    QLineEdit *stl1od;
    QLineEdit *stl1lpiod;
    QLineEdit *kombod;
    QVBoxLayout *verticalLayout_3;
    QLineEdit *r1do;
    QLineEdit *r1lpido;
    QLineEdit *stl1do;
    QLineEdit *stl1lpido;
    QLineEdit *kombdo;
    QVBoxLayout *verticalLayout_9;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *filtruj;
    QSpacerItem *horizontalSpacer_7;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_21;
    QLabel *label_24;
    QLabel *label_27;
    QLabel *label_30;
    QVBoxLayout *verticalLayout_5;
    QLineEdit *r2od;
    QLineEdit *r2lpiod;
    QLineEdit *stl2od;
    QLineEdit *stl2lpiod;
    QVBoxLayout *verticalLayout_6;
    QLineEdit *r2do;
    QLineEdit *r2lpido;
    QLineEdit *stl2do;
    QLineEdit *stl2lpido;
    QLabel *Info;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(776, 329);
        MainWindow->setLocale(QLocale(QLocale::Slovak, QLocale::Slovakia));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout_10 = new QVBoxLayout(centralWidget);
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setContentsMargins(11, 11, 11, 11);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        spinBoxN = new QSpinBox(centralWidget);
        spinBoxN->setObjectName(QStringLiteral("spinBoxN"));
        spinBoxN->setFrame(true);
        spinBoxN->setMinimum(1);
        spinBoxN->setMaximum(45);
        spinBoxN->setValue(5);

        horizontalLayout_3->addWidget(spinBoxN);

        label_12 = new QLabel(centralWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_3->addWidget(label_12);

        spinBoxM = new QSpinBox(centralWidget);
        spinBoxM->setObjectName(QStringLiteral("spinBoxM"));
        spinBoxM->setMinimum(2);
        spinBoxM->setMaximum(90);
        spinBoxM->setValue(15);

        horizontalLayout_3->addWidget(spinBoxM);


        horizontalLayout_6->addLayout(horizontalLayout_3);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        db_R1 = new QPushButton(centralWidget);
        db_R1->setObjectName(QStringLiteral("db_R1"));

        horizontalLayout_4->addWidget(db_R1);

        arch_R1 = new QPushButton(centralWidget);
        arch_R1->setObjectName(QStringLiteral("arch_R1"));

        horizontalLayout_4->addWidget(arch_R1);


        horizontalLayout_6->addLayout(horizontalLayout_4);


        horizontalLayout_9->addLayout(horizontalLayout_6);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_2);

        prac_list = new QPushButton(centralWidget);
        prac_list->setObjectName(QStringLiteral("prac_list"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(prac_list->sizePolicy().hasHeightForWidth());
        prac_list->setSizePolicy(sizePolicy);
        prac_list->setCheckable(false);
        prac_list->setChecked(false);
        prac_list->setFlat(false);

        horizontalLayout_8->addWidget(prac_list);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_3);


        horizontalLayout_9->addLayout(horizontalLayout_8);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        db_ROD = new QPushButton(centralWidget);
        db_ROD->setObjectName(QStringLiteral("db_ROD"));

        horizontalLayout_5->addWidget(db_ROD);

        arch_OD_R = new QPushButton(centralWidget);
        arch_OD_R->setObjectName(QStringLiteral("arch_OD_R"));

        horizontalLayout_5->addWidget(arch_OD_R);


        horizontalLayout_7->addLayout(horizontalLayout_5);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_6);

        protokol = new QPushButton(centralWidget);
        protokol->setObjectName(QStringLiteral("protokol"));

        horizontalLayout_7->addWidget(protokol);


        horizontalLayout_9->addLayout(horizontalLayout_7);


        verticalLayout_10->addLayout(horizontalLayout_9);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        file_R1 = new QPushButton(centralWidget);
        file_R1->setObjectName(QStringLiteral("file_R1"));

        horizontalLayout_10->addWidget(file_R1);

        file_STL1 = new QPushButton(centralWidget);
        file_STL1->setObjectName(QStringLiteral("file_STL1"));

        horizontalLayout_10->addWidget(file_STL1);


        verticalLayout_7->addLayout(horizontalLayout_10);

        gen_dbR1 = new QPushButton(centralWidget);
        gen_dbR1->setObjectName(QStringLiteral("gen_dbR1"));

        verticalLayout_7->addWidget(gen_dbR1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer);


        horizontalLayout_14->addLayout(verticalLayout_7);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_4);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        file_ROD = new QPushButton(centralWidget);
        file_ROD->setObjectName(QStringLiteral("file_ROD"));

        horizontalLayout_13->addWidget(file_ROD);

        file_STLOD = new QPushButton(centralWidget);
        file_STLOD->setObjectName(QStringLiteral("file_STLOD"));

        horizontalLayout_13->addWidget(file_STLOD);


        verticalLayout_8->addLayout(horizontalLayout_13);

        gen_dbODR = new QPushButton(centralWidget);
        gen_dbODR->setObjectName(QStringLiteral("gen_dbODR"));

        verticalLayout_8->addWidget(gen_dbODR);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_4);


        horizontalLayout_14->addLayout(verticalLayout_8);


        verticalLayout_10->addLayout(horizontalLayout_14);

        verticalSpacer_3 = new QSpacerItem(20, 1, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_3);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        label_11 = new QLabel(centralWidget);
        label_11->setObjectName(QStringLiteral("label_11"));

        verticalLayout->addWidget(label_11);

        label_15 = new QLabel(centralWidget);
        label_15->setObjectName(QStringLiteral("label_15"));

        verticalLayout->addWidget(label_15);

        label_18 = new QLabel(centralWidget);
        label_18->setObjectName(QStringLiteral("label_18"));

        verticalLayout->addWidget(label_18);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout->addWidget(label_2);


        horizontalLayout_2->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        r1od = new QLineEdit(centralWidget);
        r1od->setObjectName(QStringLiteral("r1od"));
        r1od->setFrame(true);

        verticalLayout_2->addWidget(r1od);

        r1lpiod = new QLineEdit(centralWidget);
        r1lpiod->setObjectName(QStringLiteral("r1lpiod"));
        r1lpiod->setFrame(true);

        verticalLayout_2->addWidget(r1lpiod);

        stl1od = new QLineEdit(centralWidget);
        stl1od->setObjectName(QStringLiteral("stl1od"));
        stl1od->setFrame(true);

        verticalLayout_2->addWidget(stl1od);

        stl1lpiod = new QLineEdit(centralWidget);
        stl1lpiod->setObjectName(QStringLiteral("stl1lpiod"));
        stl1lpiod->setFrame(true);

        verticalLayout_2->addWidget(stl1lpiod);

        kombod = new QLineEdit(centralWidget);
        kombod->setObjectName(QStringLiteral("kombod"));

        verticalLayout_2->addWidget(kombod);


        horizontalLayout_2->addLayout(verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        r1do = new QLineEdit(centralWidget);
        r1do->setObjectName(QStringLiteral("r1do"));
        r1do->setFrame(true);

        verticalLayout_3->addWidget(r1do);

        r1lpido = new QLineEdit(centralWidget);
        r1lpido->setObjectName(QStringLiteral("r1lpido"));
        r1lpido->setFrame(true);

        verticalLayout_3->addWidget(r1lpido);

        stl1do = new QLineEdit(centralWidget);
        stl1do->setObjectName(QStringLiteral("stl1do"));
        stl1do->setFrame(true);

        verticalLayout_3->addWidget(stl1do);

        stl1lpido = new QLineEdit(centralWidget);
        stl1lpido->setObjectName(QStringLiteral("stl1lpido"));
        stl1lpido->setFrame(true);

        verticalLayout_3->addWidget(stl1lpido);

        kombdo = new QLineEdit(centralWidget);
        kombdo->setObjectName(QStringLiteral("kombdo"));

        verticalLayout_3->addWidget(kombdo);


        horizontalLayout_2->addLayout(verticalLayout_3);


        horizontalLayout_12->addLayout(horizontalLayout_2);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_2);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_5);

        filtruj = new QPushButton(centralWidget);
        filtruj->setObjectName(QStringLiteral("filtruj"));

        horizontalLayout_11->addWidget(filtruj);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_7);


        verticalLayout_9->addLayout(horizontalLayout_11);


        horizontalLayout_12->addLayout(verticalLayout_9);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        label_21 = new QLabel(centralWidget);
        label_21->setObjectName(QStringLiteral("label_21"));

        verticalLayout_4->addWidget(label_21);

        label_24 = new QLabel(centralWidget);
        label_24->setObjectName(QStringLiteral("label_24"));

        verticalLayout_4->addWidget(label_24);

        label_27 = new QLabel(centralWidget);
        label_27->setObjectName(QStringLiteral("label_27"));

        verticalLayout_4->addWidget(label_27);

        label_30 = new QLabel(centralWidget);
        label_30->setObjectName(QStringLiteral("label_30"));

        verticalLayout_4->addWidget(label_30);


        horizontalLayout->addLayout(verticalLayout_4);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        r2od = new QLineEdit(centralWidget);
        r2od->setObjectName(QStringLiteral("r2od"));
        r2od->setFrame(true);

        verticalLayout_5->addWidget(r2od);

        r2lpiod = new QLineEdit(centralWidget);
        r2lpiod->setObjectName(QStringLiteral("r2lpiod"));
        r2lpiod->setFrame(true);

        verticalLayout_5->addWidget(r2lpiod);

        stl2od = new QLineEdit(centralWidget);
        stl2od->setObjectName(QStringLiteral("stl2od"));
        stl2od->setFrame(true);

        verticalLayout_5->addWidget(stl2od);

        stl2lpiod = new QLineEdit(centralWidget);
        stl2lpiod->setObjectName(QStringLiteral("stl2lpiod"));
        stl2lpiod->setFrame(true);

        verticalLayout_5->addWidget(stl2lpiod);


        horizontalLayout->addLayout(verticalLayout_5);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        r2do = new QLineEdit(centralWidget);
        r2do->setObjectName(QStringLiteral("r2do"));
        r2do->setFrame(true);

        verticalLayout_6->addWidget(r2do);

        r2lpido = new QLineEdit(centralWidget);
        r2lpido->setObjectName(QStringLiteral("r2lpido"));
        r2lpido->setFrame(true);

        verticalLayout_6->addWidget(r2lpido);

        stl2do = new QLineEdit(centralWidget);
        stl2do->setObjectName(QStringLiteral("stl2do"));
        stl2do->setFrame(true);

        verticalLayout_6->addWidget(stl2do);

        stl2lpido = new QLineEdit(centralWidget);
        stl2lpido->setObjectName(QStringLiteral("stl2lpido"));
        stl2lpido->setFrame(true);

        verticalLayout_6->addWidget(stl2lpido);


        horizontalLayout->addLayout(verticalLayout_6);


        horizontalLayout_12->addLayout(horizontalLayout);


        verticalLayout_10->addLayout(horizontalLayout_12);

        Info = new QLabel(centralWidget);
        Info->setObjectName(QStringLiteral("Info"));
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        font.setKerning(true);
        Info->setFont(font);
        Info->setFrameShape(QFrame::NoFrame);
        Info->setFrameShadow(QFrame::Raised);
        Info->setScaledContents(false);

        verticalLayout_10->addWidget(Info);

        MainWindow->setCentralWidget(centralWidget);
        protokol->raise();
        spinBoxN->raise();
        spinBoxM->raise();
        db_R1->raise();
        arch_R1->raise();
        prac_list->raise();
        arch_OD_R->raise();
        gen_dbR1->raise();
        file_R1->raise();
        file_STL1->raise();
        gen_dbODR->raise();
        file_ROD->raise();
        file_STLOD->raise();
        label->raise();
        filtruj->raise();
        r1od->raise();
        r1do->raise();
        label_12->raise();
        r1lpido->raise();
        stl1do->raise();
        stl1lpido->raise();
        r2do->raise();
        r2lpido->raise();
        stl2do->raise();
        stl2lpido->raise();
        Info->raise();

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Generator", 0));
        label_12->setText(QApplication::translate("MainWindow", "/", 0));
        spinBoxM->setPrefix(QString());
#ifndef QT_NO_TOOLTIP
        db_R1->setToolTip(QApplication::translate("MainWindow", "Nacitanie databazy zo suboru", 0));
#endif // QT_NO_TOOLTIP
        db_R1->setText(QApplication::translate("MainWindow", "Databaza R1-DO", 0));
#ifndef QT_NO_TOOLTIP
        arch_R1->setToolTip(QApplication::translate("MainWindow", "Archiv databazy R1-DO", 0));
#endif // QT_NO_TOOLTIP
        arch_R1->setText(QApplication::translate("MainWindow", "Archiv R1-DO", 0));
#ifndef QT_NO_TOOLTIP
        prac_list->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        prac_list->setText(QApplication::translate("MainWindow", "Pracovny list", 0));
#ifndef QT_NO_TOOLTIP
        db_ROD->setToolTip(QApplication::translate("MainWindow", "Nacitanie databazy zo suboru", 0));
#endif // QT_NO_TOOLTIP
        db_ROD->setText(QApplication::translate("MainWindow", "Databaza OD-DO", 0));
#ifndef QT_NO_TOOLTIP
        arch_OD_R->setToolTip(QApplication::translate("MainWindow", "Archiv databazy OD-DO", 0));
#endif // QT_NO_TOOLTIP
        arch_OD_R->setText(QApplication::translate("MainWindow", "Archiv OD-DO", 0));
#ifndef QT_NO_TOOLTIP
        protokol->setToolTip(QApplication::translate("MainWindow", "Vytvorenie protokolu", 0));
#endif // QT_NO_TOOLTIP
        protokol->setText(QApplication::translate("MainWindow", "Protokol", 0));
#ifndef QT_NO_TOOLTIP
        file_R1->setToolTip(QApplication::translate("MainWindow", "Nacitanie suboru R1-DO", 0));
#endif // QT_NO_TOOLTIP
        file_R1->setText(QApplication::translate("MainWindow", "Nacitaj R1-DO", 0));
#ifndef QT_NO_TOOLTIP
        file_STL1->setToolTip(QApplication::translate("MainWindow", "Nacitanie suboru STL1-DO", 0));
#endif // QT_NO_TOOLTIP
        file_STL1->setText(QApplication::translate("MainWindow", "Nacitaj STL1-DO", 0));
#ifndef QT_NO_TOOLTIP
        gen_dbR1->setToolTip(QApplication::translate("MainWindow", "Vygenerovanie a ulozenie databazy", 0));
#endif // QT_NO_TOOLTIP
        gen_dbR1->setText(QApplication::translate("MainWindow", "Vytvor databazu R1-DO", 0));
#ifndef QT_NO_TOOLTIP
        file_ROD->setToolTip(QApplication::translate("MainWindow", "Nacitanie suboru R OD-DO", 0));
#endif // QT_NO_TOOLTIP
        file_ROD->setText(QApplication::translate("MainWindow", "Nacitaj ROD-DO", 0));
#ifndef QT_NO_TOOLTIP
        file_STLOD->setToolTip(QApplication::translate("MainWindow", "Nacitanie suboru STL OD-DO", 0));
#endif // QT_NO_TOOLTIP
        file_STLOD->setText(QApplication::translate("MainWindow", "Nacitaj STLOD-DO", 0));
#ifndef QT_NO_TOOLTIP
        gen_dbODR->setToolTip(QApplication::translate("MainWindow", "Vygenerovanie a ulozenie databazy", 0));
#endif // QT_NO_TOOLTIP
        gen_dbODR->setText(QApplication::translate("MainWindow", "Vytvor Databazu OD-DO", 0));
        label->setText(QApplication::translate("MainWindow", "\306\251%R 1-DO", 0));
        label_11->setText(QApplication::translate("MainWindow", "\306\251%RLpi1-DO", 0));
        label_15->setText(QApplication::translate("MainWindow", "\306\251%STL 1-DO", 0));
        label_18->setText(QApplication::translate("MainWindow", "\306\251%STLpi 1-DO", 0));
        label_2->setText(QApplication::translate("MainWindow", "\306\251Kombinacie", 0));
        r1od->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        r1lpiod->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        stl1od->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        stl1lpiod->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        kombod->setPlaceholderText(QApplication::translate("MainWindow", "0", 0));
        r1do->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        r1lpido->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        stl1do->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        stl1lpido->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        kombdo->setPlaceholderText(QApplication::translate("MainWindow", "999", 0));
        filtruj->setText(QApplication::translate("MainWindow", "Filtruj", 0));
        label_21->setText(QApplication::translate("MainWindow", "\306\251%R OD-DO", 0));
        label_24->setText(QApplication::translate("MainWindow", "\306\251%RLpi OD-DO", 0));
        label_27->setText(QApplication::translate("MainWindow", "\306\251%STL OD-DO", 0));
        label_30->setText(QApplication::translate("MainWindow", "\306\251%STLpi OD-DO", 0));
        r2od->setText(QString());
        r2od->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        r2lpiod->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        stl2od->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        stl2lpiod->setPlaceholderText(QApplication::translate("MainWindow", "0,0000", 0));
        r2do->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        r2lpido->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        stl2do->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        stl2lpido->setPlaceholderText(QApplication::translate("MainWindow", "999,9999", 0));
        Info->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

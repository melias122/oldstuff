#include "utils.h"

#include<QDir>

using namespace std;

deque<vector<quint8> > work_list(deque< vector<quint8> > cmp1, deque< vector<quint8> > cmp2){

    deque<vector<quint8> > out;

    sort(cmp1.begin(), cmp1.end());
    sort(cmp2.begin(), cmp2.end());

    while(!cmp1.empty() && !cmp2.empty()){
        if(cmp1.front() == cmp2.front()){
            vector<quint8> v;
            for(vector<quint8>::iterator it = cmp1.front().begin(); it != cmp1.front().end(); it++){
                v.push_back(*it);
            }
            out.push_back(v);
        }
        if(cmp1.front() < cmp2.front()){
            cmp1.pop_front();
        }
        else{
            cmp2.pop_front();
        }
    }
    return out;
}

QString fname(QString path){
    return path.split(QDir::separator()).last();
}

#ifndef GENERATOR_H
#define GENERATOR_H

#include <QObject>

#include "lib/FindCombByIdx.h"
#include "lib/FindTotalComb.h"

class GeneratorThread : public QObject
{
    Q_OBJECT
public:
    explicit GeneratorThread(QObject *parent = 0);
//    ~GeneratorThread();

signals:
    void finished();

public slots:
    void generate();

private:

};



class Generator : public QObject
{
    Q_OBJECT
public:
    explicit Generator(QObject *parent = 0);
//    ~Generator();
    
signals:
    void finished();
//    void error(QString err);
    
public slots:
    void process();

private:
    int threads_count;
    stdcomb::CFindCombByIdx< CFindTotalComb<BigInteger>, BigInteger > findcomb;
};

#endif // GENERATOR_H

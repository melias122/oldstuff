#ifndef RESULT_H
#define RESULT_H

//#include "types.h"
#include "archiv.h"

#include <QStringList>
#include <QDateTime>
#include <QTextStream>
#include <QFile>

class Result : public QObject
{
    Q_OBJECT
public:
    Result(Numbers a, Numbers b);
    Result(Archiv *archiv, int state1_r=0, int stateod_r=0);
    ~Result();

    QStringList header();
    bool next_comb_str(QByteArray &arr);
    int size();
    bool empty();

    template<class T>
    QString combs_to_str( T begin, T end){
        QString s;
        for(T i=begin; i!=end; i++){
            s.append(QString::number(*i));
            s.append(" ");
        }
        return s;
    }

    template<class T>
    int sum_comb(T begin, T end){
        int sum = 0;
        for(T it = begin; it != end; ++it){
            int i = (int)*it;
            sum += i;
        }
        return sum;
    }

signals:
    void finished();
    void info(QString);

public slots:
    void insert(qvect v);
    void end();
    void stop();
    void write_combs();

private:
    unsigned exp_size, exp_num;
    Numbers num1_R, numOD_R;
    Numberings numberings;
    QLinkedList<qvect>::Iterator result_iterator;
    QLinkedList<qvect> result;
    qvect last_comb;

    QFile *f;
    QTextStream *data;
    QDateTime dt;
    QString dir_name, dir_date;
    QDir dir;

    void strl_insert(QStringList &list, double d);
};

#endif // RESULT_H

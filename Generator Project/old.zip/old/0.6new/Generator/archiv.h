#ifndef ARCHIV_H
#define ARCHIV_H

#include <QObject>
#include <QLinkedList>
#include <QDir>
#include <QFile>
#include <QtAlgorithms>

#include <boost/multiprecision/cpp_dec_float.hpp>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/math/special_functions/binomial.hpp>

#include "utils.h"
#include "fileop.h"
#include "numbers.h"

class Archiv : public QObject
{
    Q_OBJECT
public:

    //
    QLinkedList< QStringList > lines, archiv;

    Archiv();
    Archiv(unsigned n, unsigned m, QString &filename);

    Numbers get_1DO() const;
    Numbers get_1DO1() const;
    Numbers get_ODDO() const;
    Numbers get_ODDO1() const;
    Numbers get_ODDO2() const;
    qvect get_last_comb() const;
    qvect get_last_numberings() const;
    unsigned get_n() const;
    unsigned get_m() const;
    QLinkedList< qvect > get_qvnums() const;
    unsigned get_UC() const;
    unsigned get_UC_line_num() const;

    QString get_cwd() const;

    boost::multiprecision::cpp_int get_stlcc(int c, int stl);

    void set_n(unsigned n);
    void set_m(unsigned m);
    void set_1DO(Numbers n);
    void set_ODDO(Numbers n);
    void set_qvnums(QLinkedList< qvect > qvn);
    void set_lastcomb(qvect qv);
    void set_od_do(unsigned a, unsigned b);

signals:
    void finished();
    void info(QString);
    
public slots:
    void process();
    void process_od_do();
    void save();
    void load(QString filename);
    
private:
    //
    unsigned n, m, a_od, a_do, UC, UC_line_num;
    Numbers n_1DO, n_ODDO, n_1DO_1, n_ODDO_1, nODDO_2;
    Reader *r;

    QString filepath;
    QLinkedList< qvect > qvnums;
    qvect last_comb;
    //


    void poc_stl(QString od_do = "");
    void poc_R(QString od_do = "");
//    void gen_sums();
    void copy_file();
    void export_arch();
    void make_rp1();
    void parse();
    void n1DO(int to);
    void nODDO(int from);
    Numbers make_numbers(Nmap &pocetnost);

};

QDataStream &operator<<(QDataStream &out, const Archiv &ar);
QDataStream &operator>>(QDataStream &in, Archiv &ar);

void save_archiv(const Archiv &a);
void load_archiv(Archiv &a, QString &filename);

#endif // ARCHIV_H

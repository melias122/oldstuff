#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    qRegisterMetaType<qvect>("qvect");
    qRegisterMetaType<qvect2d>("qvect2d");
    
    return a.exec();
}

//#include <QDebug>
//#include <math.h>

//int main() {

//    QVector< QSet<size_t> > xc_stl;

//    QString xtice("1-2,4 1-5 0-4 1,2-4,5 1-2,4");

//    foreach (const QString &qs, xtice.split(" ")) {
//        QSet<size_t> stl;
//        foreach (const QString &qsp, qs.split(",")) {
//            if(qsp.contains("-")){
//                QStringList a = qsp.split("-");
//                for(int i=a[0].toInt(); i<=a[1].toInt(); i++){
//                    stl.insert((size_t)i);
//                    qDebug() << i;
//                }
//            }
//            else
//                stl.insert((size_t)qsp.toUInt());
//        }
//        xc_stl.push_back(stl);
//    }

//    return 0;
//}




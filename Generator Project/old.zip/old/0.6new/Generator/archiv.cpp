#include "archiv.h"

#include <QDateTime>

Archiv::Archiv(){}

Archiv::Archiv(unsigned n, unsigned m, QString &filename){
    this->n = n;
    this->m = m;
    this->filepath = filename;
    this->r = new Reader(filename);
}

void Archiv::save(){
    QFile file(get_cwd().append("db").append(QString::number(n)).append(QString::number(m)).append(".dat"));
    file.open(QIODevice::WriteOnly);

    QDataStream out(&file);

    out << n << m << UC << UC_line_num;
    out << lines << archiv;
    out << n_1DO << n_ODDO << n_1DO_1 << n_ODDO_1;
    out << qvnums;
    out << last_comb;

    if(file.isOpen())
        file.close();
}

void Archiv::copy_file(){
    QString filename(get_cwd().append(QString::number(n).append(QString::number(m)).append(".csv")));

    QFile f(filepath);
    QFile f_new(filename);

    if(filepath == filename)
        return;

    if(f_new.exists()){
//        f_new.remove();
        QDateTime dt = QDateTime::currentDateTime();
        f.rename(get_cwd().append(QString::number(n).append(QString::number(m)).append(dt.toString("-yyyy-MM-dd-hh-mm")).append(".csv")));
    }

    f.copy(get_cwd().append(QString::number(n).append(QString::number(m)).append(".csv")));

    if(f.isOpen())
        f.close();
    if(f_new.isOpen())
        f_new.close();
}

void Archiv::load(QString filename){
    QFile file(filename);
    file.open(QIODevice::ReadOnly);

    QDataStream in(&file);

    in >> n >> m >> UC >> UC_line_num;
    in >> lines >> archiv;
    in >> n_1DO >> n_ODDO >> n_1DO_1 >> n_ODDO_1;
    in >> qvnums;
    in >> last_comb;

    if(file.isOpen())
        file.close();
}

Numbers Archiv::get_1DO() const{
    return n_1DO;
}
Numbers Archiv::get_1DO1() const{
    return n_1DO_1;
}

Numbers Archiv::get_ODDO() const{
    return n_ODDO;
}

Numbers Archiv::get_ODDO1() const{
    return n_ODDO_1;
}

Numbers Archiv::get_ODDO2() const{
    return nODDO_2;
}

qvect Archiv::get_last_comb() const{
    return last_comb;
}

qvect Archiv::get_last_numberings() const{
    qvect v;
    for(int i = 1; i < 12; i++){
        v.push_back((quint8)archiv.last()[i].toInt());
    }
    return v;
}

void Archiv::process(){

    emit info("Vyvaram archiv");

    parse();

    Numberings numberings(n,m);
    int at=1;

    foreach (const qvect &vi, qvnums) {

//        qDebug() << "spracovavam riadok " << at << " z " << lines.size();
        emit info(QString("Archiv: Spracovavam riadok ").append(QString::number(at)).append("/").append(QString::number(lines.size())));

        n1DO(at);
        nODDO(at);

        QStringList line;

        line << combs_to_str(vi.begin(),vi.end());
        line << numberings.result(vi,last_comb);
        line << numberings.ntice(vi);
        line << numberings.xtice(vi,this->m);
        line << double_to_qstr(n_1DO.sum_R(vi.begin(),vi.end()));        //R 1-r
        line << double_to_qstr(n_1DO.sum_STL(vi.begin(),vi.end()));      //STL 1-r
        line << double_to_qstr(n_ODDO.sum_R(vi.begin(),vi.end()));       //R OD
        line << double_to_qstr(n_ODDO.sum_STL(vi.begin(),vi.end()));     //STL OD
        line << QString::number(sum_comb(vi.begin(),vi.end()));           //SUM komb

        int stl=1;
        foreach (const num &qvn, vi) {
            line << QString::number(qvn);
            line << double_to_qstr(n_1DO.get_R(qvn));
            line << double_to_qstr(n_1DO.get_STL(qvn,stl));
            line << double_to_qstr(n_ODDO.get_R(qvn));
            line << double_to_qstr(n_ODDO.get_STL(qvn,stl));
            stl++;
        }

        archiv.push_back(line);
        last_comb = vi;
        at++;
    }

    make_rp1();         // r+1

    QDir dir(QString::number(n).append(QString::number(m)).append("/"));
    if(!dir.exists())
        dir.mkpath(".");

    copy_file();        // copy orig file
    export_arch();
    save();             // save
    poc_R();            // save pocetnost R
    poc_stl();          // save pocetnost STL

    while (lines.size() > 1) {
       lines.pop_front();
    }

    emit info("Archiv vytvoreny");
    emit finished();
}

void Archiv::export_arch(){
    QFile f(get_cwd().append(QString("Archiv")).append(QString::number(n)).append(QString::number(m)).append(".csv"));

    if(!f.open(QFile::WriteOnly)){
    }

    QStringList t_header;
    t_header << "Kombinacie" <<"P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH"<<"Sm"<<"Kk"<<"N-tice"<<"X-tice"<< "ƩR1-DO"<< "ƩSTL1-DO" << "ƩR OD-DO"<< "ƩSTL OD-DO" << "ƩKombinacie";
    for(unsigned i=0; i < n; i++){
        t_header << "Cislo" << "R1-DO"<< "STL1-DO"<< "R OD-DO"<< "STL OD-DO";
    }

    QTextStream data(&f);
    data << t_header.join(";").append("\n");
    while (!archiv.empty()) {
        data << archiv.front().join(";").append("\n");
        if(archiv.size() > 1)
            archiv.pop_front();
        else
            break;
    }

    if(f.isOpen())
        f.close();
}

void Archiv::set_od_do(unsigned a, unsigned b){
    this->a_od = a;
    this->a_do = b;
}

void Archiv::process_od_do(){

    Nmap pocetnost;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    unsigned pos = 1;
    while(pos < a_od){
        qi.next();
        pos++;
    }

    for(unsigned at = a_od; at <= a_do; at++){
        emit info(QString("Archiv: Spracovavam riadok ").append(QString::number(at)).append("/").append(QString::number(a_do)));

        int stl=1;
        foreach (const num &poc, qi.next()) {
            pocetnost[poc].set_R(pocetnost[poc].get_R()+1);
            pocetnost[poc].set_STL(stl,pocetnost[poc].get_STL(stl)+1);
            stl++;
        }
    }
    this->nODDO_2 = make_numbers(pocetnost);

    Numbers zaloha;
    zaloha = n_ODDO;

    this->n_ODDO = nODDO_2;
    poc_R(QString::number(a_od).append("-").append(QString::number(a_do)));
    poc_stl(QString::number(a_od).append("-").append(QString::number(a_do)));

    n_ODDO = zaloha;

    emit info(QString("Archiv: OD-DO spracovane"));
    emit finished();
}

void Archiv::make_rp1(){
    Nmap poc_1_do, poc_od_do;
    poc_1_do = this->n_1DO.get_pocetnost();
    poc_od_do = this->n_ODDO.get_pocetnost();

    for(unsigned i=1; i <= m; i++){
        poc_1_do[i].set_R(poc_1_do[i].get_R() + 1);
        poc_od_do[i].set_R(poc_od_do[i].get_R() + 1);
    }

    for(unsigned i=1; i <= n; i++){
        for(unsigned j=i; j<=m-n+i; j++){
            poc_1_do[j].set_STL(i, poc_1_do[j].get_STL(i)+1);
            poc_od_do[j].set_STL(i,poc_od_do[j].get_STL(i)+1);
        }
    }
    this->n_1DO_1 = make_numbers(poc_1_do);
    this->n_ODDO_1= make_numbers(poc_od_do);
}

void Archiv::poc_stl(QString od_do){

//    using namespace boost::multiprecision;
//    using namespace boost::math;

    QFile f(get_cwd().append(QString("pocetnostSTL")).append(od_do).append(".csv"));
    QStringList list;

    if(!f.open(QFile::WriteOnly)){
        // emit error();
        // return;
    }

    QTextStream data(&f);

    for(unsigned stl=1; stl<=n; stl++ ){
        list << QString("Stlpec ").append(QString::number(stl)).append("/cislo")
             << "Teor. pocet" << "Teor. %"
             << "Pocet STL1-DO" << "% STL1-DO"
             << "Pocet STL1-DO (r+1)" << "% STL1-DO (r+1)"
             << "Pocet STLOD-DO" << "% STLOD-DO"
             << "Pocet STLOD-DO (r+1)" << "% STLOD-DO (r+1)"; // hlavicka
    }
    data << list.join(";") << "\n";

    // zapis so zarovnanim  1
    //                      2 2
    // ...
    for(unsigned c=1; c <= m; c++){

        list.clear();

        for(unsigned stl=1; stl <= n; stl++){

            // spodok zarovnanie
            if(c-stl >= m-n+1){
                for(int i=1; i<=11; i++)
                    list << "\"\"";
                continue;
            }

            boost::multiprecision::cpp_rational t_perc = get_stlcc(c,stl)/(boost::multiprecision::cpp_rational)get_stlcc(1,1);

            list        << QString::number(c)
                        << QString(get_stlcc(c,stl).str().c_str()) << double_to_qstr(t_perc.convert_to<double>()*100)
                        << QString::number((long)n_1DO.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_1DO.get_STL((num)c,stl))
                        << QString::number((long)n_1DO_1.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_1DO_1.get_STL((num)c,stl))
                        << QString::number((long)n_ODDO.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_ODDO.get_STL((num)c,stl))
                        << QString::number((long)n_ODDO_1.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_ODDO_1.get_STL((num)c,stl));

            // zarovnanie vrch
            if(c == stl)
                break;
        }

        data << list.join(";").append("\n");
    }

    // zapis bez zarovnania 1,2,3...
//    for(unsigned nr=0; nr < m-n+1; nr++){
//        list.clear();

//        for(unsigned stl=1; stl<=n; stl++ ){
//            unsigned c = nr+stl;

//            cpp_rational t_perc = get_stlcc(c,stl)/(cpp_rational)get_stlcc(1,1);

//            list        << QString::number(c)
//                        << QString(get_stlcc(c,stl).str().c_str()) << double_to_qstr(t_perc.convert_to<double>()*100)
//                        << QString::number((long)n_1DO.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_1DO.get_STL((num)c,stl))
//                        << QString::number((long)n_1DO_1.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_1DO_1.get_STL((num)c,stl))
//                        << QString::number((long)n_ODDO.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_ODDO.get_STL((num)c,stl))
//                        << QString::number((long)n_ODDO_1.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_ODDO_1.get_STL((num)c,stl));
//        }
//        data << list.join(";").append("\n");
//    }
    if(f.isOpen())
        f.close();
}

void Archiv::poc_R(QString od_do){

//    using namespace boost::multiprecision;

    QFile f(get_cwd().append(QString("pocetnostR")).append(od_do).append(".csv"));
    QStringList list;

    if(!f.open(QFile::WriteOnly)){
        // emit error();
        // return;
    }
    QTextStream data(&f);

    list << "Cislo"
         << "Teor. pocet" << "Teor. %"
         << "Pocet R1-DO" << "% R1-DO"
         << "Pocet R1-DO (r+1)" << "% R1-DO (r+1)"
         << "Pocet ROD-DO" << "% ROD-DO"
         << "Pocet ROD-DO (r+1)" << "% ROD-DO (r+1)"; // hlavicka
    data << list.join(";") << "\n";


    boost::multiprecision::cpp_int t_pocet = get_stlcc(1,1);       // teoreticky pocet
    unsigned t_perc = 100;                  // teoreticke perc

    // cisla v riadkoch
    for(unsigned r=1; r <=m; r++){
        list.clear();
        list        << QString::number(r)
                    << QString(t_pocet.str().c_str()) << QString::number(t_perc)
                    << QString::number((long)n_1DO.get_pocetnost().value(r).get_R()) << double_to_qstr(n_1DO.get_R((num)r))
                    << QString::number((long)n_1DO_1.get_pocetnost().value(r).get_R()) << double_to_qstr(n_1DO_1.get_R((num)r))
                    << QString::number((long)n_ODDO.get_pocetnost().value(r).get_R()) << double_to_qstr(n_ODDO.get_R((num)r))
                    << QString::number((long)n_ODDO_1.get_pocetnost().value(r).get_R()) << double_to_qstr(n_ODDO_1.get_R((num)r));
        data << list.join(";").append("\n");
    }
    if(f.isOpen())
        f.close();
}

//void Archiv::gen_sums(){
//    using namespace stdcomb;

//    cpp_rational act=0,total = (cpp_int)binomial_coefficient<double>(m, n);
//    cpp_rational perc;

//    qvect va, vb;

//    for(num cisl=1; cisl <=m; cisl++){
//        va.push_back(cisl);
//    }
//    for(num cisl=1; cisl <=n; cisl++){
//        vb.push_back(cisl);
//    }

//    QVector< QMap<double, ulong> > poct(4);
//    QVector<double> qd(4);

//    do{
//        act++;
//        perc = act/total;
//        double hotovo = perc.convert_to<double>()*100;
//        emit info(QString("Archiv: Hladam Ʃ%, hotovo ").append(QString::number(hotovo,'f', 4)).append("%"));

//        qd[0] = n_1DO.sum_R(vb.begin(),vb.end());
//        qd[1] = n_1DO.sum_STL(vb.begin(),vb.end());
//        qd[2] = n_ODDO.sum_R(vb.begin(),vb.end());
//        qd[3] = n_ODDO.sum_STL(vb.begin(),vb.end());

//        for(int i=0; i < qd.size(); i++){
//            if(poct[i].contains(qd[i])) poct[i][qd[i]]++;
//            else poct[i][qd[i]] = 1;
//        }
//    }while(next_combination(va.begin(),va.end(),vb.begin(),vb.end()));

//    for(int i=0; i < poct.size(); i++){

//        emit info(QString("Archiv: Ukladam subor ").append(QString::number(i+1)));

//        QFile f(get_cwd().append(QString("perc")).append(QString::number(i)).append(".csv"));
//        f.open(QFile::WriteOnly);

//        QTextStream data(&f);

//        data << "Suma %" << ";" << "Pocet" <<";\n";

//        QList<double> list = poct[i].keys();
//        qSort(list);

//        foreach (const double &d, list) {
//            data << QString::number(d,'g',10) << ";" << QString::number(poct[i].value(d)) << ";\n";
////            qDebug() << QString::number(d,'g',10) << " " << poct[i].value(d);
//        }

//        f.close();
//    }
//}

void Archiv::parse(){

    QStringList list;
    this->r->next_line(list);

    while(this->r->next_line(list)){
        QStringList l = list;

        if(l.first().size() > 0)
            lines.push_back(l);
    }

    QLinkedList< QStringList >::Iterator it = lines.begin();

    while(it != lines.end()){

        QStringList list = *it;
        QVector<num> v;
        for(unsigned i=3; i<n+3;i++){
            num cislo = (num)list[i].toInt();
            v.push_back(cislo);
        }
        qvnums.push_back(v);
        it++;
    }
}

void Archiv::n1DO(int to){

    Nmap pocetnost;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    while(qi.hasNext() && to > 0){
       int stl = 1;
       foreach (const num &qvn, qi.next()) {
           pocetnost[qvn].set_R(pocetnost[qvn].get_R() + 1);
           pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
           stl++;
       }
       to--;
    }
    n_1DO = make_numbers(pocetnost);
    return;
}

void Archiv::nODDO(int from){

    bool has_UC = false;
//    bool has_UC_line = false;
    Nmap pocetnost;
    QSet<num> vyskyt;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    while(qi.hasNext() && from >= 0/* && vyskyt.size() != m*/){
        foreach (const num &qvn, qi.next()) {
            vyskyt.insert(qvn);
        }
//        if(vyskyt.size() == (int)m && !has_UC_line){
//            UC_line_num = from+2;
//            has_UC_line = true;
//        }

        from--;
    }

    // este nie je 100% vyskyt
    if((unsigned)vyskyt.size() < m){
        Numbers n1(n,m);
        n_ODDO = n1;
        return;
    }

    vyskyt.clear();
    size_t r=qvnums.size();
    while(qi.hasPrevious() && (unsigned)vyskyt.size() < m){
        int stl = 1;
        foreach (const num &qvn, qi.previous()) {
            vyskyt.insert(qvn);

            // UC cislo
            if(vyskyt.size() == (int)m && !has_UC){
                UC = (unsigned)qvn;
                UC_line_num = r;
                has_UC = true;

            }

            pocetnost[qvn].set_R(pocetnost[qvn].get_R() + 1);
            pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
            stl++;
        }
        r--;
    }
    n_ODDO = make_numbers(pocetnost);
    return;
}

boost::multiprecision::cpp_int Archiv::get_stlcc(int c, int stl){

//    using namespace boost::multiprecision;
//    using namespace boost::math;

    if((c-stl < 0) || (c-stl > (int)(m-n))) return 0;


    boost::multiprecision::cpp_int c1 = (boost::multiprecision::cpp_int)boost::math::binomial_coefficient<double>(m-c, n-stl);
    boost::multiprecision::cpp_int c2 = (boost::multiprecision::cpp_int)boost::math::binomial_coefficient<double>(c-1, stl-1);


    if(stl==1)      return c1;
    else if(stl==(int)n) return c2;
    else            return (c1*c2);
}

Numbers Archiv::make_numbers(Nmap &pocetnost){

//    using namespace boost::multiprecision;

    Numbers n1(n,m);
    n1.set_pocetnost(pocetnost);
    boost::multiprecision::cpp_rational y;

    foreach (const num &key, pocetnost.keys()) {

        // vypocet %r
        N np = pocetnost.value(key);
        y = (boost::multiprecision::cpp_rational)np.get_R()/get_stlcc(1,1);
        n1.set_R(key, y.convert_to<double>());

        // vypocet %stl pre stlpce
        for(unsigned i=1;i<=n;i++){
            boost::multiprecision::cpp_rational div = get_stlcc((unsigned)key,i);
            if(!div.is_zero()){
                boost::multiprecision::cpp_rational stl = (boost::multiprecision::cpp_rational)np.get_STL(i)/div;
                if(!stl.is_zero()){
                    n1.set_STL(key,i,stl.convert_to<double>());
                }
            }
        }
    }
    return n1;
}

unsigned Archiv::get_n() const{
    return this->n;
}
unsigned Archiv::get_m() const{
    return this->m;
}
QLinkedList<qvect> Archiv::get_qvnums() const{
    return this->qvnums;
}

unsigned Archiv::get_UC() const{
    return UC;
}
unsigned Archiv::get_UC_line_num() const{
    return UC_line_num;
}

QString Archiv::get_cwd() const{
    return QString(QDir::currentPath()).append("/").append(QString::number(n)).append(QString::number(m)).append("/");
}

void Archiv::set_n(unsigned n){
    this->n = n;
}
void Archiv::set_m(unsigned m){
    this->m = m;
}
void Archiv::set_1DO(Numbers n){
    this->n_1DO = n;
}
void Archiv::set_ODDO(Numbers n){
    this->n_ODDO = n;
}
void Archiv::set_qvnums(QLinkedList< qvect > qvn){
    this->qvnums = qvn;
}
void Archiv::set_lastcomb(qvect qv){
    this->last_comb = qv;
}

QDataStream &operator<<(QDataStream &out, const Archiv &ar){

    out << ar.get_n() << ar.get_m();
    out << ar.lines << ar.archiv;
    out << ar.get_1DO() << ar.get_ODDO();
    out << ar.get_qvnums();
    out << ar.get_last_comb();

    return out;
}

QDataStream &operator>>(QDataStream &in, Archiv &ar){

    unsigned n,m;
    Numbers n1,n2;
    QLinkedList<qvect> qvnums;
    qvect last_comb;

    in >> n >> m;
    in >> ar.lines >> ar.archiv;
    in >> n1 >> n2;
    in >> qvnums;
    in >> last_comb;

    ar.set_n(n);
    ar.set_m(m);
    ar.set_1DO(n1);
    ar.set_ODDO(n2);
    ar.set_qvnums(qvnums);
    ar.set_lastcomb(last_comb);

    return in;
}

void save_archiv(const Archiv &a){

    QFile file(QString(a.get_cwd().append("archiv.dat")));
    file.open(QIODevice::WriteOnly);

    QDataStream out(&file);
    out << a;

    file.close();
}

void load_archiv(Archiv &a, QString &filename){

    QFile file(filename);
    file.open(QIODevice::ReadOnly);

    QDataStream in(&file);
    in >> a;

    file.close();
}

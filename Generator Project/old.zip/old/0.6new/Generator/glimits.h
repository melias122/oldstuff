#ifndef GLIMITS_H
#define GLIMITS_H

#include <QtAlgorithms>

#include "numbers.h"

class Glimits
{
public:
    Glimits(){}
    Glimits(int n, int m);
    Glimits(int n, int m, Numbers n1_r, Numbers nod_r, qvect last_comb);

    //15
    void set_r1od(double r1);
    void set_r1do(double r1);

    //16
    void set_r2od(double r2);
    void set_r2do(double r2);

    //17
    void set_stl1od(double s);
    void set_stl1do(double s);

    //18
    void set_stl2od(double s);
    void set_stl2do(double s);

    //19
    void set_kombod(unsigned u);
    void set_kombdo(unsigned u);

    //2
    void set_Smod(double d);
    void set_Smdo(double d);

    //3
    void set_Kkod(double d);
    void set_Kkdo(double d);

    //4
    void set_Nod(unsigned u);
    void set_Ndo(unsigned u);

    //5
    void set_Pod(unsigned u);
    void set_Pdo(unsigned u);

    //6
    void set_PRod(unsigned u);
    void set_PRdo(unsigned u);

    //7
    void set_Mcod(unsigned u);
    void set_Mcdo(unsigned u);

    //8
    void set_Vcod(unsigned u);
    void set_Vcdo(unsigned u);

    //9
    void set_ZHod(unsigned u);
    void set_ZHdo(unsigned u);

    //10
    void set_c19od(unsigned u);
    void set_c19do(unsigned u);

    //11
    void set_c0od(unsigned u);
    void set_c0do(unsigned u);

    //12
    void set_cCod(unsigned u);
    void set_cCdo(unsigned u);

    //13
    void set_Ccod(unsigned u);
    void set_Ccdo(unsigned u);

    //14
    void set_CCod(unsigned u);
    void set_CCdo(unsigned u);

    void set_ntice(qvect &ntice);
    void set_zakazane(QSet<num> &zakazane);
    void set_povinne(QSet<num> &povinne);
    void set_xtice(QString xstr);


    void add(num c);
    void remove();
    int size();


    void nastav(QString &nastavenie, num pos); // pre protokol
    QString get_settings(); // pre protokol

    // 0: --
    // 1: --
    // 2: Sm
    // 3: Kk
    // 4: N
    // 5: P
    // 6: PR
    // 7: Mc
    // 8: Vc
    // 9: ZH
    //10: c19
    //11: c0
    //12: cC
    //13: Cc
    //14: CC
    //15: r1-do
    //16: rod-do
    //17: stl1-do
    //18: stlod-do
    //19: kombinacie
    bool check();
    bool check_ntice();
    bool check_xtice();
    bool check_povinne();
    bool check_Sm();
    bool check_Kk();

    QList<num> povinne;

private:
    int level, m;
    qvect last, result, func_od, func_do, ntice_vect;
    QVector<double> count, max, min;
    Numberings n;
    Numbers num1_R, numOD_R;
    QSet<num> zakazane, func_using;
    QMap<num,num> ntice;
    QVector< QSet<int> > xtice_vect;
    QString xtice_str;
};

#endif // GLIMITS_H

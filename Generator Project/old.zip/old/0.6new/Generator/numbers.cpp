#include "numbers.h"

//N

N::N(unsigned n){
    R = 0;
    for(unsigned i=1; i <=n; i++){
        STL.insert(i, 0);
    }
}

N::~N(){}

void N::set_R(double R){
    this->R = R;
}

void N::set_STL(unsigned stl, double STL){
    if(stl > 0)
        this->STL[stl] = STL;
}

double N::get_R() const{
    return R;
}

double N::get_STL(unsigned stl) const{
    return (stl>0) ? STL[stl] : 0;
}

stl_map N::get_stlmap() const{
    return this->STL;
}
void N::set_stlmap(stl_map STL){
    this->STL = STL;
}

QDataStream &operator<<(QDataStream &out,const N &n){
    out << n.get_R() << n.get_stlmap();
    return out;
}
QDataStream &operator>>(QDataStream &in, N &n){

    double R;
    stl_map STL;

    in >> R >> STL;

    n.set_R(R);
    n.set_stlmap(STL);

    return in;
}

// N end

// Numbers

Numbers::Numbers(){
    init();
}

Numbers::Numbers(unsigned n, unsigned m){
    this->n = n;
    this->m = m;
    this->init(n,m);
}

Numbers::~Numbers(){
    numbers.clear();
}

void Numbers::set_N(unsigned n){ this->n = n;}

void Numbers::set_M(unsigned m){ this->m = m;}

unsigned Numbers::sum_komb_min(){
    unsigned sum=0;
    for(unsigned i=1; i<=get_N(); i++){
        sum += i;
    }
    return sum;
}
unsigned Numbers::sum_komb_max(){
    unsigned sum=0;
    for(unsigned i=get_M()-get_N()+1; i<=get_M(); i++){
        sum += i;
    }
    return sum;
}

double Numbers::sum_R_min(){

    QVector<double> qvd(get_N(),0);
    double sum=0;

    for(unsigned i=1;i<=get_N();i++){
        for(unsigned j=i; j<=get_M()-get_N()+i;j++){
            if(i==j)
                qvd[i-1] = get_R(j);
            else if(get_R(j) < qvd[i-1])
                qvd[i-1] = get_R(j);
        }
        sum += qvd[i-1];
    }
    return sum;
}

double Numbers::sum_R_max(){
    QVector<double> qvd(get_N(),0);
    double sum=0;

    for(unsigned i=1;i<=get_N();i++){
        for(unsigned j=i; j<=get_M()-get_N()+i;j++){
            if(i==j)
                qvd[i-1] = get_R(j);
            else if(get_R(j) > qvd[i-1])
                qvd[i-1] = get_R(j);
        }
        sum += qvd[i-1];
    }
    return sum;
}

double Numbers::sum_STL_min(){

    QVector<double> qvd(get_N(),0);
    double sum=0;

    for(unsigned i=1;i<=get_N();i++){
        for(unsigned j=i; j<=get_M()-get_N()+i;j++){
            if(i==j)
                qvd[i-1] = get_STL(j,i);
            else if(get_STL(j,i) < qvd[i-1])
                qvd[i-1] = get_STL(j,i);
        }
        sum += qvd[i-1];
    }
    return sum;
}
double Numbers::sum_STL_max(){
    QVector<double> qvd(get_N(),0);
    double sum=0;

    for(unsigned i=1;i<=get_N();i++){
        for(unsigned j=i; j<=get_M()-get_N()+i;j++){
            if(i==j)
                qvd[i-1] = get_STL(j,i);
            else if(get_STL(j,i) > qvd[i-1])
                qvd[i-1] = get_STL(j,i);
        }
        sum += qvd[i-1];
    }
    return sum;
}

void Numbers::set_R(num c, double R){
    numbers[c].set_R(R);
}

void Numbers::set_STL(num c, unsigned stl, double STL){
    numbers[c].set_STL(stl, STL);
}

double Numbers::get_R(num c){
    return numbers[c].get_R();
}

double Numbers::get_STL(num c, unsigned stl){
    return numbers[c].get_STL(stl);
}

unsigned Numbers::get_N() const{
    return n;
}

unsigned Numbers::get_M() const{
    return m;
}

void Numbers::init(unsigned n, unsigned m){
    numbers.clear();
    for(unsigned i=1; i <= m; i++){
        numbers.insert((num)i, N(n));
    }
}

Nmap Numbers::get_numbers() const{
    return this->numbers;
}
Nmap Numbers::get_pocetnost() const{
    return this->pocetnost;
}

void Numbers::set_numbers(Nmap numbers){
    this->numbers = numbers;
}
void Numbers::set_pocetnost(Nmap pocetnost){
    this->pocetnost = pocetnost;
}

QDataStream &operator<<(QDataStream &out, const Numbers &n){

    out << n.get_N() << n.get_M();
    out << n.get_numbers() << n.get_pocetnost();

    return out;
}
QDataStream &operator>>(QDataStream &in, Numbers &n){
    unsigned n1, m;
    Nmap numbers, pocetnost;

    in >> n1 >> m;
    in >> numbers >> pocetnost;

    n.set_N(n1);
    n.set_M(m);
    n.set_numbers(numbers);
    n.set_pocetnost(pocetnost);

    return in;
}


// Numberings class

Numberings::Numberings(size_t n, size_t m){
    this->n = n;
    this->m = m;
    pr <<2<<3<<5<<7<<11<<13<<17<<19<<23<<29<<31<<37<<41<<43<<47<<53<<59<<61<<67<<71<<73<<79<<83<<89;
}

bool Numberings::P(num c){ return ((c%2) == 0); }

bool Numberings::N(num c){ return !P(c); }

bool Numberings::PR(num c){ return pr.contains(c); }

bool Numberings::Mc(num c){
    if(C0(c))
        return false;
    QString s = QString::number(c);
    return (s[s.size()-1] < QChar('6'));
}

bool Numberings::Vc(num c){ return !Mc(c); }

bool Numberings::C19(num c){ return (c < 10); }

bool Numberings::C0(num c){
   QString s = QString::number(c);
   if(s.size() < 2)
       return false;
   return (s[s.length() -1] == QChar('0'));
}

bool Numberings::cC(num c){
    QString s = QString::number(c);
    if(s.size() < 2)
        return false;
    return (s[0] < s[1]);
}

bool Numberings::Cc(num c){
    QString s = QString::number(c);
    if(s.size() < 2)
        return false;
    if(C0(c))
        return false;
    return (s[0] > s[1]);
}

bool Numberings::CC(num c){
    QString s = QString::number(c);
    if(s.size() < 2)
        return false;
    return (s[0] == s[1]);
}

double Numberings::korelacia(const qvect &x, const qvect &y) {

//    size_t N = x.size(), TINY_VALUE=1e-20;
//    double ex(0), ey(0), xt(0), yt(0), sxy(0), sxx(0), syy(0);

//    // Find the means
//    for (size_t i = 0; i < N; i++) {
//        ex += x[i];
//        ey += y[i];
//    }
//    ex /= N;
//    ey /= N;

//    //Compute the correlation coeﬃcient.
//    for (size_t i = 0; i < N; i++) {
//        xt = x[i] - ex;
//        yt = y[i] - ey;
//        sxx += xt * xt;
//        syy += yt * yt;
//        sxy += xt * yt;
//    }
//    return sxy/(sqrt(sxx*syy)+TINY_VALUE);

    double dKorelacia = 0.0;

    for(size_t i=0; i < n; i++){
        dKorelacia += pow((x[i]-y[i])/(double)m,4)/n;
    }

    dKorelacia = pow(1.0 - sqrt(dKorelacia),8);

    return dKorelacia;
}

double Numberings::smernica(const qvect &a){

//    qvect x;
//    size_t N = y.size();
//    double A(0), B(0), C(0), D(0), smernica(0);
////        double c(0);

//    for(size_t i = 1; i <= N; i++)
//        x.push_back(i);

//    for(size_t i = 0; i < N; i++) {
//        A+=x[i];
//        B+=y[i];
//        C+=x[i]*x[i];
//        D+=x[i]*y[i];
//    }

//    smernica = ((N*D)-(A*B))/((N*C)-(A*A));
//    //    c=(B-(smernica*A))/N;

//    return atan(smernica);


    double dSmernica = 0.0;
    int pocetSmernic = 0;

    for(size_t i=0; i < n-1; i++) {
        for(size_t j=i+1; j < n; j++){

            dSmernica += (((a[j]-a[i])/(double)(m-1))/((j-i)/(double)(n-1)));
            pocetSmernic++;
        }
    }

    if(pocetSmernic > 0)
        dSmernica /= pocetSmernic;

    return dSmernica;
}

QString Numberings::ntice(const qvect &vect){

    // hladame ntcie/volne
    qvect tice(vect.size(),0), result(vect);
    QString ntice_str;

    int tica=0;
    result.push_back(0);
    for(int i = 0; i < result.size(); i++){

//            if((i == result.size()-2) && (level == result.size()-1)){ // posledny je volny

        if(i == result.size()-2){
            if(tica > 0) tice[tica]++;
            else tice[0]++;
            break;
        }

        int c = (int)(result[i] - result[i+1]);
        if(c == result[i]){
            if(tica > 0) tice[tica]++;
            break;
        }
        if(c < -1){
            if(tica==0){ tice[0]++; }
            else{
                tice[tica]++;
                tica=0;
            }
        }
        else{ tica++; }
    }
    result.pop_back();

    foreach (const num &qvn, tice) {
        ntice_str.append(QString::number(qvn)).append(" ");
    }
    return ntice_str;
}

QString Numberings::xtice(const qvect &vect, unsigned max_size){

    qvect vysl(((max_size+9)/10),0);
    QString xtice_str;

    foreach (const num &qvn, vect) {
        num pos = 0;
        for(num i=10; i <= 90; i+=10, pos++){
            if(qvn <= i){
                vysl[pos]++;
                break;
            }
//                pos++;
        }
    }
    foreach (const num &qvn, vysl) {
        xtice_str.append(QString::number(qvn)).append(" ");
    }
    return xtice_str;
}

QStringList Numberings::result(const qvect &first,const qvect &prev){

    QStringList result;
    QVector<int> vi(11,0);

    foreach (const num &qvn, first) {
        if(P(qvn))      // Par
            vi[0]++;
        if(N(qvn))      // Nepar
            vi[1]++;
        if(PR(qvn))     // Prvocislo
            vi[2]++;
        if(Mc(qvn))     // Male cifry
            vi[3]++;
        if(Vc(qvn))     // Velke cifry
            vi[4]++;
        if(C19(qvn))
            vi[5]++;
        if(C0(qvn))
            vi[6]++;
        if(cC(qvn))
            vi[7]++;
        if(Cc(qvn))
            vi[8]++;
        if(CC(qvn))
            vi[9]++;
        if(!prev.isEmpty() && prev.contains(qvn)) // Zhoda
            vi[10]++;
    }

    foreach (const int &i, vi) {
        result << QString::number(i);
    }

    // smernica
    result << double_to_qstr(smernica(first),6);

    // korelacia
    if(prev.isEmpty())
        result << double_to_qstr(0.0);
    else
        result << double_to_qstr(korelacia(prev,first),6);

    return result;
}

qvect Numberings::result2(const qvect &first,const qvect &prev){

    qvect vi(11,0);

    foreach (const num &qvn, first) {
        if(P(qvn))      // Par
            vi[0]++;
        if(N(qvn))      // Nepar
            vi[1]++;
        if(PR(qvn))     //  Prvocislo
            vi[2]++;
        if(Mc(qvn))     // Male cifry
            vi[3]++;
        if(Vc(qvn))     // Velke cifry
            vi[4]++;
        if(C19(qvn))
            vi[5]++;
        if(C0(qvn))
            vi[6]++;
        if(cC(qvn))
            vi[7]++;
        if(Cc(qvn))
            vi[8]++;
        if(CC(qvn))
            vi[9]++;
        if(!prev.isEmpty() && prev.contains(qvn)) // Zhoda
            vi[10]++;
    }
    return vi;
}

//Numbers end

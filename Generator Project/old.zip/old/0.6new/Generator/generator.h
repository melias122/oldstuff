#ifndef GENERATOR_H
#define GENERATOR_H

#include <QObject>
//#include <QMutex>
//#include <QMutexLocker>

#include "glimits.h"

// Thread
class Generator : public QObject
{
    Q_OBJECT
public:

    Generator(unsigned n, unsigned m, Glimits g);
    ~Generator();

signals:
    void finished();
    void ended();
    void send_result(qvect);
    void generator_state(bool);
    void info(QString);

public slots:

    void stop();
    void process();
//    void print();

private:

    volatile bool stopped;
    num level, n, m;
    qvect2d combs;
    qvect result, pos;
    Glimits limit;

//    QMutex mutex;

    void next();
};

#endif // GENERATOR_H

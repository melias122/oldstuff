#include "result.h"

Result::Result(Numbers a, Numbers b){
    last_comb = qvect();
    num1_R = a;
    numOD_R = b;
    f=NULL;
    data=NULL;
    this->numberings = Numberings(a.get_N(),a.get_M());
}

Result::Result(Archiv *archiv, int state1_r, int stateod_r)
{
    last_comb = archiv->get_last_comb();

    if(state1_r==1)
        num1_R =archiv->get_1DO1();
    else
        num1_R =archiv->get_1DO();

    if(stateod_r==2)
        numOD_R = archiv->get_ODDO2();
    else if(stateod_r == 1)
        numOD_R = archiv->get_ODDO1();
    else
        numOD_R = archiv->get_ODDO();


    f=NULL;
    data=NULL;
    exp_num = 0;
    exp_size = 0;

    dt = QDateTime::currentDateTime();

    dir_name.append(QString::number(archiv->get_1DO().get_N())).append(QString::number(archiv->get_1DO().get_M()));
    dir_date.append(dt.toString("yyyy-MM-dd-hh-mm-ss"));

    dir = QDir(dir_name.append("/").append(dir_date));

    if(!dir.exists()){
        dir.mkpath(".");
    }
    this->numberings = Numberings(archiv->get_n(),archiv->get_m());
}

Result::~Result()
{
    result.clear();
}

QStringList Result::header()
{
    QStringList header;
    header  << "Kombinacie"
            <<"P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH"<<"Sm"<<"Kk"<<"N-tice"<<"X-tice"
            << QString(SUM_SIGN)+"R1-DO"<< "ƩSTL1-DO"
            << "ƩR OD-DO"<< "ƩSTL OD-DO"
            << "ƩKombinacie";

    for(int i=0; i < (int)num1_R.get_N(); i++){
        header << "Cislo" << "R1-DO"<< "STL1-DO"<< "R OD-DO"<< "STL OD-DO";
    }

    return header;
}

bool Result::next_comb_str(QByteArray &arr)
{
    if(result.isEmpty())
        return false;

    QStringList strList;
    result_iterator = result.begin();

    strList << combs_to_str((*result_iterator).begin(),(*result_iterator).end());
    strList << numberings.result(*result_iterator, last_comb);
    strList << numberings.ntice(*result_iterator);
    strList << numberings.xtice(*result_iterator, this->num1_R.get_M());
    strl_insert(strList,num1_R.sum_R((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList, num1_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));

    strl_insert(strList, numOD_R.sum_R((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList, numOD_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));

    strList << QString::number(sum_comb((*result_iterator).begin(),(*result_iterator).end()));

    int stl = 1;
    for(qvect::Iterator iq=(*result_iterator).begin();iq!=(*result_iterator).end();iq++){

        strList << QString::number(*iq);

        strl_insert(strList, num1_R.get_R(*iq));
        strl_insert(strList, num1_R.get_STL(*iq,stl));

        strl_insert(strList, numOD_R.get_R(*iq));
        strl_insert(strList, numOD_R.get_STL(*iq,stl));

        stl++;
    }

    arr.clear();
    arr.append(strList.join(";")).append("\n");
    result.pop_front();
    return true;
}
int Result::size()
{
    return result.size();
}

bool Result::empty()
{
    return result.empty();
}
void Result::insert(qvect v)
{
    this->result.push_back(v);
    if(result.size() > 500000)
        write_combs();
}

void Result::strl_insert(QStringList &list, double d)
{
    list << double_to_qstr(d);
}

void Result::stop(){

    if(f){
        if(f->isOpen())
            f->close();
        delete f;
        f=NULL;
    }
    emit finished();
}

void Result::end(){

    while(!result.isEmpty()){
        emit info(QString("Exportujem subory. Ostava ").append(QString::number(result.size())));
        write_combs();
    }

    //close
    if(f){
        if(f->isOpen())
            f->close();
        delete f;
        f=NULL;
    }
    emit info("Exportovanie dokoncene");
    emit finished();
}

void Result::write_combs(){

    if(f==NULL){
        exp_num++;
        exp_size = 0;
        f = new QFile(dir.path().append("/").append(QString::number(exp_num).append(".csv")));

        f->open(QFile::WriteOnly);

        f->write(header().join(";").append("\n").toUtf8());
    }

    QByteArray qbarray;

    while(next_comb_str(qbarray) && exp_size < 500000){
        f->write(qbarray);
        exp_size++;
    }

    if(exp_size > 450000){
        // close
        if(f){
            if(f->isOpen())
                f->close();
            delete f;
            f = NULL;
        }
    }
}

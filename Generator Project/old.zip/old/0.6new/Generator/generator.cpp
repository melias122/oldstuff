#include "generator.h"

Generator::Generator(unsigned n, unsigned m, Glimits g){

    this->n = (num)n;
    this->m = (num)m;
    this->limit = g;
    level = 0;
    result = qvect(n,0);
    stopped = false;

    for(num i=0; i<n; i++){
        pos.push_back(0);
    }

    for(num i=1; i <= n; i++){
        qvect lev;
        for(num j=i; j <= m-n+i; j++){
            lev.push_back(j);
        }
        combs.push_back(lev);
    }

    if(!g.povinne.isEmpty()){

        for(int i=0; i<g.povinne.size();i++){
            num min =g.povinne[i];
            for(int j=combs[i].size()-1;j>=0;j--){
                num akt = combs[i][j];
                if(akt > min)
                    combs[i].pop_back();
                else
                    break;
            }
        }
    }

}

Generator::~Generator(){
    combs.clear();
    pos.clear();
    result.clear();
}

void Generator::stop(){

    stopped = true;
    generator_state(false);
    emit ended();
    emit finished();
}

void Generator::process(){

    generator_state(true);

    while (!combs.first().empty() && !stopped) {

        limit.add(combs[level][pos[level]]);

        // podmienka vlozenia
        if(limit.check()){
            result[level] = combs[level][pos[level]];
        }

        // posuniem sa na leveli
        else{
            next();
            continue;
        }

        // up
        if(level < n-1){
            level++;
            continue;
        }

//      print();                // nasli sme kombinaciu
        emit send_result(result);
        next();                 // hladame dalej
    }

//  emit ended();
//  emit finished();
    stop();
}

//void Generator::print(){
//    foreach (num i, result) {
//        std::cout << (int)i << " ";
//    }
//    std::cout << std::endl;
//}

//private
void Generator::next(){

    limit.remove();
    if(level == 0){
        for(int i=0; i<n; i++){
            combs[i].pop_front();
            pos[i] = 0;
        }
        return;
    }

    if(pos[level] < combs[level].size()-1){

        pos[level]++;
        if(level < n){

            for(int i=level; i<n; i++){
                pos[i] = pos[level];
            }
        }
    }
    else{
        level--;
        next();
    }
}

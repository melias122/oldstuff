#ifndef UTILS_H
#define UTILS_H

#include <QString>

QString double_to_qstr(double d, int prec=12);

template<class T>
int sum_comb(T begin, T end){
    int sum = 0;
    for(T it = begin; it != end; ++it){
        int i = (int)*it;
        sum += i;
    }
    return sum;
}

template<class T>
QString combs_to_str(T begin, T end){
    QString s;
    for(T i=begin; i!=end; i++){
        s.append(QString::number(*i));
        s.append(" ");
    }
    return s;
}

#endif // UTILS_H

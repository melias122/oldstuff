#include "fileop.h"

#include <QDateTime>

//#include <QDebug>

Reader::Reader(QString filename){
    this->filename = filename;
    is_open = false;
    line_readed = 0;
    file = NULL;
    in = NULL;
    open();
}

Reader::~Reader(){
    close();
}

bool Reader::opened(){
    return is_open;
}

bool Reader::next_line(QStringList &list){

    if(!opened()) return false;
    if(in->atEnd()){
        close();
        return false;
    }

    list = in->readLine().split(";");
//    qDebug() << list.front().size();

    return true;
}

void Reader::close(){
    if(is_open){
        file->close();
        is_open = false;
    }
    delete file;
    delete in;
}

void Reader::reset(){
    if(opened()){
        close();
        open();
    }
    else{
        open();
    }
}

void Reader::open(){
    file = new QFile(filename);
    if(file->open(QFile::ReadOnly)){
        is_open = true;
        in = new QTextStream(file);
    }
    else
        is_open = false;
}

// Reader end

void write_protocol(QString filename, QString text){

    QDateTime t = QDateTime::currentDateTime();

    if(!filename.isEmpty()){
        QFile file(filename);

        if(!file.open(QFile::WriteOnly | QFile::Append)){
//            qDebug() << "Error: Nepodarilo sa otvorit subor " << filename << endl;
            return;
        }
        QTextStream out(&file);
        out << t.toString("dd/MM/yyyy hh.mm.ss: ") << text << "\n";

        file.close();
    }
    else{
//        qDebug() << t.toString("dd/MM/yyyy hh.mm.ss: ") << "Debug: " << text;
    }
}


#include "archiv.h"

#include <QDateTime>

//#include <qdebug.h>

Archiv::Archiv(){}

Archiv::Archiv(unsigned n, unsigned m, QString &filename){
    this->n = n;
    this->m = m;
    this->delta = QVector<double>(7+(n*4),0);
    this->deltar = QVector<double>(4,0);
    this->filepath = filename;
    this->filename = filename.split("/").last().split(".").first();
    this->r = new Reader(filename);
}

void Archiv::save(){
    QFile file(get_cwd().append("db_").append(filename).append(".dat"));
    file.open(QIODevice::WriteOnly);

    QDataStream out(&file);

    out << n << m << UC << UC_line_num;
    out << lines << archiv;
    out << n_1DO << n_ODDO << n_1DO_1 << n_ODDO_1;
    out << qvnums;
    out << last_comb;
    out << delta << deltar;
    out << filename << filepath;

    if(file.isOpen())
        file.close();
}

void Archiv::load(QString filename){
    QFile file(filename);
    file.open(QIODevice::ReadOnly);

    QDataStream in(&file);

    in >> n >> m >> UC >> UC_line_num;
    in >> lines >> archiv;
    in >> n_1DO >> n_ODDO >> n_1DO_1 >> n_ODDO_1;
    in >> qvnums;
    in >> last_comb;
    in >> delta >> deltar;
    in >> this->filename >> filepath;

    if(file.isOpen())
        file.close();
}

void Archiv::copy_file(){
    QString filename(get_cwd().append(this->filename).append(".csv"));

    QFile source(filepath), destination(filename);

    if(filename == filepath)
        return;

    if(destination.exists())
        destination.remove();

    source.copy(get_cwd().append(this->filename).append(".csv"));
}

Numbers Archiv::get_1DO() const{
    return n_1DO;
}
Numbers Archiv::get_1DO1() const{
    return n_1DO_1;
}

Numbers Archiv::get_ODDO() const{
    return n_ODDO;
}

Numbers Archiv::get_ODDO1() const{
    return n_ODDO_1;
}

Numbers Archiv::get_ODDO2() const{
    return nODDO_2;
}

qvect Archiv::get_last_comb() const{
    return last_comb;
}

qvect Archiv::get_last_numberings() const{
    qvect v;
    for(int i = 1; i < 12; i++){
        v.push_back((quint8)archiv.last()[i].toInt());
    }
    return v;
}

void Archiv::process(){

    emit info("Vyvaram archiv");

    parse();

//    this->delta = delta(6,0);
    Numberings numberings(n,m);
    int at=1;

    foreach (const qvect &vi, qvnums) {

//        qDebug() << "spracovavam riadok " << at << " z " << lines.size();
        emit info(QString("Archiv: Spracovavam riadok ").append(QString::number(at)).append("/").append(QString::number(lines.size())));

        n1DO(at);
        nODDO(at);

        QStringList line;

        line << combs_to_str(vi.begin(),vi.end());
        line << numberings.result(vi,last_comb);
        line << numberings.ntice(vi);
        line << numberings.xtice(vi,this->m);

        line << double_to_qstr(n_1DO.sum_R(vi.begin(),vi.end()));        //R 1-r
        line << double_to_qstr( n_1DO.sum_R(vi.begin(),vi.end()) - delta[0] );
        deltar[0] = n_1DO.sum_R(vi.begin(),vi.end()) - delta[0];
        delta[0] = n_1DO.sum_R(vi.begin(),vi.end());

        line << double_to_qstr(n_1DO.sum_STL(vi.begin(),vi.end()));      //STL 1-r
        line << double_to_qstr( n_1DO.sum_STL(vi.begin(),vi.end()) - delta[1] );
        deltar[1] = n_1DO.sum_STL(vi.begin(),vi.end()) - delta[1];
        delta[1] = n_1DO.sum_STL(vi.begin(),vi.end());

        delta[4] = n_1DO.sum_R(vi.begin(),vi.end()) - n_1DO.sum_STL(vi.begin(),vi.end());
        line << double_to_qstr(delta[4]);      // r1-stl1

        line << double_to_qstr(n_ODDO.sum_R(vi.begin(),vi.end()));       //R OD
        line << double_to_qstr( n_ODDO.sum_R(vi.begin(),vi.end()) - delta[2] );
        deltar[2] = n_ODDO.sum_R(vi.begin(),vi.end()) - delta[2];
        delta[2] = n_ODDO.sum_R(vi.begin(),vi.end());

        line << double_to_qstr(n_ODDO.sum_STL(vi.begin(),vi.end()));     //STL OD
        line << double_to_qstr( n_ODDO.sum_STL(vi.begin(),vi.end()) - delta[3] );
        deltar[3] = n_ODDO.sum_STL(vi.begin(),vi.end()) - delta[3];
        delta[3] = n_ODDO.sum_STL(vi.begin(),vi.end());

        delta[5] = n_ODDO.sum_R(vi.begin(),vi.end()) - n_ODDO.sum_STL(vi.begin(),vi.end());
        line << double_to_qstr(delta[5]);    // rOD-stlDO


        line << QString::number(sum_comb(vi.begin(),vi.end()));           //SUM komb
        if(at>1)
            line << QString::number(sum_comb(vi.begin(),vi.end()) - delta[6] );
        else
            line << QString::number(0);
        delta[6] = sum_comb(vi.begin(),vi.end());

        int stl=1, pos=7;
        foreach (const num &qvn, vi) {
            line << QString::number(qvn);

            line << double_to_qstr(n_1DO.get_R(qvn));
            line << double_to_qstr(n_1DO.get_R(qvn)-delta[pos]);
            delta[pos] = n_1DO.get_R(qvn);
            pos++;

            line << double_to_qstr(n_1DO.get_STL(qvn,stl));
            line << double_to_qstr(n_1DO.get_STL(qvn,stl)-delta[pos]);
            delta[pos] = n_1DO.get_STL(qvn,stl);
            pos++;

            line << double_to_qstr(n_ODDO.get_R(qvn));
            line << double_to_qstr(n_ODDO.get_R(qvn)-delta[pos]);
            delta[pos] = n_ODDO.get_R(qvn);
            pos++;

            line << double_to_qstr(n_ODDO.get_STL(qvn,stl));
            line << double_to_qstr(n_ODDO.get_STL(qvn,stl)-delta[pos]);
            delta[pos] = n_ODDO.get_STL(qvn,stl);
            pos++;

            stl++;
        }

        archiv.push_back(line);
        last_comb = qvect(vi);
        at++;
    }

    make_rp1();         // r+1

//    QDir dir(QString::number(n).append(QString::number(m)).append(this->filename).append("/"));
    QDir dir(get_cwd());
    if(!dir.exists())
        dir.mkpath(".");

    copy_file();        // copy orig file
    export_arch();
    save();             // save
    poc_R();            // save pocetnost R
    poc_stl();          // save pocetnost STL
    mapa_zh();
    mapa_ntice();
    stat_ntice();
    stat_zh();

    while (lines.size() > 1) {
       lines.pop_front();
    }

    emit info("Archiv vytvoreny");
    emit finished();
}

void Archiv::export_arch(){
    QFile f(get_cwd().append(QString("Archiv_")).append(this->filename).append(".csv"));

    if(!f.open(QFile::WriteOnly)){
    }

    QStringList t_header;
    t_header << "Kombinacie"
             << "P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH"
             << "Sm"
//             << "ΔSm"
             << "Kk"
//             << "ΔKk"
             << "N-tice"<<"X-tice"
             << "ƩR1-DO"<< "ΔƩR1-DO" << "ƩSTL1-DO" << "ΔƩSTL1-DO" << "Δ(ƩR1-DO-ƩSTL1-DO)"
             << "ƩR OD-DO" << "ΔƩR OD-DO"<< "ƩSTL OD-DO"<< "ΔƩSTL OD-DO" << "Δ(ƩROD-DO-ƩSTLOD-DO)"
             << "ƩKombinacie" << "ΔƩKombinacie";
    for(unsigned i=0; i < n; i++){
        t_header << "Cislo"
                 << "R1-DO" << "ΔR1-DO"
                 << "STL1-DO"<< "ΔSTL1-DO"
                 << "R OD-DO"<< "ΔR OD-DO"
                 << "STL OD-DO"<< "ΔSTL OD-DO";
    }

    QTextStream data(&f);
    data.setCodec("UTF-8");
    data.setGenerateByteOrderMark(true);

    data << t_header.join(";").append("\n").toUtf8();
    while (archiv.size() > 1) {
        data << archiv.front().join(";").append("\n").toUtf8();
        archiv.pop_front();
    }

    if(f.isOpen())
        f.close();
}

void Archiv::set_od_do(unsigned a, unsigned b){
    this->a_od = a;
    this->a_do = b;
}

void Archiv::process_od_do(){

    Nmap pocetnost;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    unsigned pos = 1;
    while(pos < a_od){
        qi.next();
        pos++;
    }

    for(unsigned at = a_od; at <= a_do; at++){
        emit info(QString("Archiv: Spracovavam riadok ").append(QString::number(at)).append("/").append(QString::number(a_do)));

        int stl=1;
        foreach (const num &poc, qi.next()) {
            pocetnost[poc].set_R(pocetnost[poc].get_R()+1);
            pocetnost[poc].set_STL(stl,pocetnost[poc].get_STL(stl)+1);
            stl++;
        }
    }
    this->nODDO_2 = make_numbers(pocetnost);

    Numbers zaloha;
    zaloha = n_ODDO;

    this->n_ODDO = nODDO_2;
    poc_R(QString::number(a_od).append("-").append(QString::number(a_do)));
    poc_stl(QString::number(a_od).append("-").append(QString::number(a_do)));

    n_ODDO = zaloha;

    emit info(QString("Archiv: OD-DO spracovane"));
    emit finished();
}

void Archiv::make_rp1(){
    Nmap poc_1_do, poc_od_do;
    poc_1_do = this->n_1DO.get_pocetnost();
    poc_od_do = this->n_ODDO.get_pocetnost();

    for(unsigned i=1; i <= m; i++){
        poc_1_do[i].set_R(poc_1_do[i].get_R() + 1);
        poc_od_do[i].set_R(poc_od_do[i].get_R() + 1);
    }

    for(unsigned i=1; i <= n; i++){
        for(unsigned j=i; j<=m-n+i; j++){
            poc_1_do[j].set_STL(i, poc_1_do[j].get_STL(i)+1);
            poc_od_do[j].set_STL(i,poc_od_do[j].get_STL(i)+1);
        }
    }
    this->n_1DO_1 = make_numbers(poc_1_do);
    this->n_ODDO_1= make_numbers(poc_od_do);
}

// vrati vsetky ntice   n 0 0 0 0..
//                      ..0 0 0 0 n
QMap<QString, int> Archiv::ntice_all(){

    int idx=0, ntice_pos_idx=0;
    QMap<QString, int> ntice_pos;
    QVector<int> nt(n,0), nt_end(n,0);
    QString str;

    // Ntice
    nt[0] = n;
    nt_end[n-1] = 1;

    while(nt != nt_end){

        int sum=0;

        for(int j=1; j <=nt.size(); j++){
            sum += nt[j-1]*j;
        }

        if(sum == n){
            str.clear();
            for(int i=0; i< nt.size(); i++)
                str.append(QString::number(nt[i])).append(" ");
            ntice_pos.insert(str,ntice_pos_idx);
            ntice_pos_idx++;

            nt[idx]--;
            idx++;
        }

        else if(sum < n){
            nt[idx]++;
        }
        else {
            nt[idx]--;
            idx++;
        }

        if(idx == nt.size()){
            idx--;
            while(nt[idx] == 0)
                idx--;
            nt[idx]--;
            idx++;
        }
    }
    str.clear();
    for(int i=0; i< nt.size(); i++)
        str.append(QString::number(nt[i])).append(" ");
    ntice_pos.insert(str,ntice_pos_idx);
    ntice_pos_idx++;
    // Ntice end

    return ntice_pos;
}

void Archiv::stat_zh(){

    QStringList out_stringl;
    boost::multiprecision::cpp_rational cr;

    QFile f_out(get_cwd().append(QString("statZhoda_")).append(this->filename).append(".csv"));

    if(!f_out.open(QFile::WriteOnly)){}

    QTextStream out(&f_out);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    // header
    out_stringl << "Zhoda" << "Pocetnost teor." << "Teoreticka moznost v %" << "Pocetnost" << "Realne dosiahnute %";
    out << out_stringl.join(";").append("\n");

    for(int i=this->n; i>=0; i--){

        out_stringl.clear();

        cr = get_nCm(i,n)*get_nCm(m-n-(n-i),m-n);
        out_stringl << QString::number(i)                       // ZH
                    << double_to_qstr(cr.convert_to<double>()); // pocet teor

        cr /= get_nCm(this->n,this->m).convert_to<boost::multiprecision::cpp_rational>();
        out_stringl << double_to_qstr(cr.convert_to<double>()*100)      // teor %
                    << QString::number(zhoda_pocet[QString::number(i)]);// pocet

        out_stringl << double_to_qstr(((double)zhoda_pocet[QString::number(i)]/lines.size())*100);     // real %

        out << out_stringl.join(";").append("\n");
    }
    out << ";" << "\n";

    for(int i=1; i<=n; i++){

        out_stringl.clear();

        QString zhs = QString::number(i);

        // header
        out_stringl << QString("Zhoda ").append(zhs) << "Pocetnost" << QString("Realne %");
        out << out_stringl.join(";").append("\n"); out_stringl.clear();
        //

        // vsetky
        out_stringl << QString("Zhoda ").append(zhs) << QString::number(zhoda_pocet[zhs]) << double_to_qstr(((double)zhoda_pocet[zhs]/lines.size())*100);
        out << out_stringl.join(";").append("\n"); out_stringl.clear();
        //

        foreach (const QString &poz, zhoda_typ_pocet[zhs].keys()) {

            out_stringl << poz // poz
                        << QString::number(zhoda_typ_pocet[zhs][poz]) // pocet
                        << double_to_qstr(((double)zhoda_typ_pocet[zhs][poz]/lines.size())*100);
            out << out_stringl.join(";").append("\n"); out_stringl.clear();

        }
        out << QString(";").append("\n");
    }

    if(f_out.isOpen())
        f_out.close();
}

void Archiv::stat_ntice(){

    QStringList header, out_stringl;
    QMap<QString, int> ntice_pos;
    QMap<QString, boost::multiprecision::cpp_int> ntice_poc_teor;

    QFile f_out(get_cwd().append(QString("statNtice_")).append(this->filename).append(".csv"));

    if(!f_out.open(QFile::WriteOnly)){}

    QTextStream out(&f_out);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    // header
    header << "N-tica" << "Pocetnost teor." << "Teoreticka moznost v %" << "Realne dosiahnute %";
    out << header.join(";").append("\n").toUtf8();
    // header end

    // ntice
    ntice_pos = ntice_all();

    foreach (const QString &ntica, ntice_pos.keys()) {

        int tica, k = m-n+1;
        boost::multiprecision::cpp_int poc_real(1);
        QVector<QString> qs = ntica.split(" ").toVector();

        for(int i=0; i<qs.size(); i++){
            if(qs[i].toInt() == 0)
                continue;
            tica = qs[i].toInt();
            poc_real *= get_nCm(k-tica,k);
            k -= tica;
        }
        ntice_poc_teor.insert(ntica, poc_real);
    }

    for(int i=ntice_pos.size()-1; i>=0; i--){

        QString tica = ntice_pos.key(i);
        boost::multiprecision::cpp_rational cr;

        out_stringl << tica << ntice_poc_teor.value(tica).str().c_str();

        //tero moznost
        cr.assign(ntice_poc_teor.value(tica).convert_to<boost::multiprecision::cpp_rational>()/get_nCm(n,m).convert_to<boost::multiprecision::cpp_rational>());
        out_stringl << double_to_qstr(cr.convert_to<double>()*100);

        //real dosiah
        out_stringl << double_to_qstr((ntice_pocet[tica]/(double)lines.size())*100);

        out << out_stringl.join(";").append("\n").toUtf8();
        out_stringl.clear();
    }

    out << ";" << "\n";
    out << "N-tica;" << "Sucin pozicie a stlpca;" << "Pocet vyskytov;" << "%" << "\n";

    for(int i=ntice_pos.size()-1; i>=0; i--){
        QString tica = ntice_pos.key(i);
        QMap<QString, int> qmi = ntice_typ_pocet.value(tica);

        out_stringl.clear();
        out_stringl << tica << "vsetky" << QString::number(ntice_pocet.value(tica)) << double_to_qstr(ntice_pocet[tica]/(double)lines.size()*100);
        out << out_stringl.join(";") << "\n";

        foreach (const QString &p, qmi.keys()) {
            out_stringl.clear();
            out_stringl << tica << p << QString::number(qmi.value(p)) << double_to_qstr((qmi.value(p)/(double)lines.size())*100);
            out << out_stringl.join(";") << "\n";
        }
    }

    if(f_out.isOpen())
        f_out.close();
}

void Archiv::mapa_zh(){

    QList<QStringList> arch_orig, mp_zh;
    QStringList out_stringl;
    QStringList header;
    QVector<int> prd,akt;
    int zhoda=0, l_len=0, krok=-1;
    QStringList zh_anl;
    QMap<int, int> zh_pos;


    QFile f_out(get_cwd().append(QString("mapaZhoda_")).append(this->filename).append(".csv"));
    QFile f_in(filepath);

    if(!f_out.open(QFile::WriteOnly)){}
    if(!f_in.open(QFile::ReadOnly)){}

    QTextStream out(&f_out), in(&f_in);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    while(!in.atEnd()){
        QStringList l;
        l = in.readLine().split(";");
        arch_orig.append(l);
    }

    // dlzka riadku
    if(arch_orig.size() > 0)
        l_len = arch_orig[1].length();
    else
        l_len = arch_orig.front().length();

    // header
    header << "Zhoda";
    for(int i=1; i <= get_n(); i++)
        header << QString::number(i);
    header << "Pozicia ZH" << "Krok";
    for(int i=1; i <= get_n(); i++)
        header << QString::number(i).append(" Stl r-1/r");

    out_stringl << arch_orig.front() << header;
    out << out_stringl.join(";").append("\n").toUtf8();
    // header end

    //header pop
    arch_orig.pop_front();

    for(int i=0; i<=this->n; i++){
        this->zhoda_pocet.insert(QString::number(i), 0);
    }
    foreach (const QStringList &akt_r, arch_orig) {

        if(!akt.isEmpty())
            akt.clear();

        for(int i=3; i < get_n()+3;i++)
            akt.push_back(akt_r[i].toInt());

        zhoda=0;
        zh_anl.clear();
        zh_pos.clear();

        for(int i=0; i < 2*get_n()+3;i++){
            zh_anl << "";
        }

        for(int i=0; i<akt.size() && !prd.empty(); i++){
            for(int j=0; j <prd.size();j++){
                if(akt[i] == prd[j]){
                    zhoda++;
                    zh_pos.insert(i,j);
                }
            }
        }

        // Zhoda
        zh_anl[0] = QString::number(zhoda);

        // Krok
        if(zhoda > 0){
            if(krok == -1)
                zh_anl[get_n()+2] = QString::number(0);
            else
                zh_anl[get_n()+2] = QString::number(krok);
            krok=1;
        }
        else if(krok >= 0)
            krok++;

        QString pos_zh;
        foreach (const int &i, zh_pos.keys()) {
            // 1-n
            mp_zh.back()[l_len+1+zh_pos[i]] = QString::number(prd[zh_pos[i]]);
            zh_anl[i+1] = QString::number(akt[i]);

            // Pozicia zhoda
            pos_zh = QString::number(zh_pos[i]+1).append("|").append(QString::number(i+1));
            if(zh_anl[get_n()+1].size() > 0)
                zh_anl[get_n()+1].append(", ").append(pos_zh);
            else
                zh_anl[get_n()+1].append(pos_zh);

            // nstl r-1/r
            zh_anl[get_n()+3+i] = pos_zh;
        }

        //stat aln
        QString zhs = zh_anl[0];
        zhoda_pocet[zhs]++;
        if(zhs.toInt() > 0){  // len zhoda 1,2,3,..
            if(!zhoda_typ_pocet.contains(zhs))
                zhoda_typ_pocet.insert(zhs,QMap<QString, int>());

            if(!zhoda_typ_pocet[zhs].contains(pos_zh))
                zhoda_typ_pocet[zhs].insert(pos_zh,1);
            else
                zhoda_typ_pocet[zhs][pos_zh]++;
        }
        //

        out_stringl.clear();
        out_stringl << akt_r << zh_anl;

        mp_zh.push_back(QStringList(out_stringl));

        prd = akt;
    }

    while(!mp_zh.empty()){
        out << mp_zh.front().join(";").append("\n").toUtf8();
        mp_zh.pop_front();
    }

    out.flush();

    if(f_out.isOpen())
        f_out.close();
    if(f_in.isOpen())
        f_in.close();
}

void Archiv::mapa_ntice(){

    QList<QStringList> arch_orig, mp_zh;
    QStringList out_stringl, header, ntica_anl;
    QVector<num> akt;
    QMap<QString, int> ntice_pos, ntice_krok;
    Numberings numberings;


    QFile f_out(get_cwd().append(QString("mapaNtice_")).append(this->filename).append(".csv"));
    QFile f_in(filepath);

    if(!f_out.open(QFile::WriteOnly)){}
    if(!f_in.open(QFile::ReadOnly)){}

    QTextStream out(&f_out), in(&f_in);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    while(!in.atEnd()){
        QStringList l;
        l = in.readLine().split(";");
        arch_orig.append(l);
    }

    // ntice
    ntice_pos = ntice_all();
    ntice_krok = QMap<QString, int>(ntice_pos);
    ntice_pocet = QMap<QString, int>(ntice_pos);
    foreach (const QString &strp, ntice_krok.keys()) {
        ntice_krok[strp] = -1;
        ntice_pocet[strp] = 0;
    }

    // header
    header << "N-tica";
    for(int i=1; i <= get_n(); i++)
        header << QString::number(i);
    header << "Sucet N-tic" << "Sucin pozicie a stlpca";

    for(int i=0; i < ntice_pos.size(); i++)
        header << QString(ntice_pos.key(i)).prepend("Krok ");

    out_stringl << arch_orig.front() << header;
    out << out_stringl.join(";").append("\n").toUtf8();
    // header end

    //header pop
    arch_orig.pop_front();

    // analyza
    int pos=0;
    foreach (const QStringList &akt_r, arch_orig) {
        pos++;

        if(!akt.isEmpty())
            akt.clear();

        for(int i=3; i < get_n()+3;i++)
            akt.push_back(akt_r[i].toInt());

        if(!ntica_anl.empty())
            ntica_anl.clear();

        for(int i=0; i < get_n()+3+ntice_pos.size(); i++){
            ntica_anl << "";
        }
        ntica_anl[0] = numberings.ntice(akt);

        if(ntica_anl[0] != ntice_pos.key(0)){ // ak neni n 0 0 0 ...

            int start=-1, end=-1;
            for(int i=0; i<akt.size()-1;i++){

                for(int j=i; j <akt.size()-1;j++){
                    if((akt[j+1] - akt[j]) == 1){
                        if(start==-1)
                            start=j;
                        end=j+1;
                        i=j;
                    }
                    else
                        break;
                }
                if(start != end) {
                    int sum=0,sum_stl=1;
                    for(int j=start; j <= end; j++){
                        sum += (int)akt[j];
                        sum_stl *= (j+1);
                        // cislo v stl
                        ntica_anl[j+1] = QString::number(akt[j]);
                    }

                    // sucet ntic
                    if(ntica_anl[n+1].size() > 0)
                        ntica_anl[n+1].append(QString::number(sum).prepend(", "));
                    else
                        ntica_anl[n+1] = QString::number(sum);

                    // sucin stlpcov
                    if(ntica_anl[n+2].size() > 0)
                        ntica_anl[n+2].append(QString::number(sum_stl).prepend(", "));
                    else
                        ntica_anl[n+2] = QString::number(sum_stl);

                    start=end=-1;
                }
            }
        }

        // ntice stat
        QString tica = ntica_anl[0], sucin_stl = ntica_anl[n+2];
        ntice_pocet[tica]++;
        if(!sucin_stl.isEmpty()){
            if(ntice_typ_pocet[tica].value(sucin_stl) > 0){
                int p = ntice_typ_pocet[tica].value(sucin_stl);
                ntice_typ_pocet[tica].insert(sucin_stl, p + 1);
            }
            else{
                ntice_typ_pocet[ntica_anl[0]].insert(ntica_anl[n+2], 1);
            }
        }
        //

        foreach (const QString &strp, ntice_krok.keys()) {
            if(ntice_krok[strp] != -1)
                ntice_krok[strp]++;
        }

        if(ntice_krok[ntica_anl[0]] == -1){
            ntica_anl[n+3+ntice_pos[ntica_anl[0]]] = QString::number(0);
        }
        else{
            ntica_anl[n+3+ntice_pos[ntica_anl[0]]] = QString::number(ntice_krok[ntica_anl[0]]);
        }
        ntice_krok[ntica_anl[0]] = 0;

        out_stringl.clear();
        out_stringl << akt_r << ntica_anl;

        out << out_stringl.join(";").append("\n").toUtf8();
    }
    out.flush();

    if(f_out.isOpen())
        f_out.close();
    if(f_in.isOpen())
        f_in.close();

}

void Archiv::poc_stl(QString od_do){

    unsigned por_c = 1;
    Numberings numberings;

    QFile f(get_cwd().append(QString("pocetnostSTL_")).append(this->filename).append(od_do).append(".csv"));
    QStringList list;

    if(!f.open(QFile::WriteOnly)){
        // emit error();
        // return;
    }

    QTextStream data(&f);
    data.setCodec("UTF-8");
    data.setGenerateByteOrderMark(true);

//    for(unsigned stl=1; stl<=n; stl++ ){
//        list << QString("Stlpec ").append(QString::number(stl)).append("/cislo")
//             << "Teor. pocet" << "Teor. %"
//             << "Pocet STL1-DO" << "% STL1-DO"
//             << "Pocet STL1-DO (r+1)" << "% STL1-DO (r+1)"
//             << "Pocet STLOD-DO" << "% STLOD-DO"
//             << "Pocet STLOD-DO (r+1)" << "% STLOD-DO (r+1)"; // hlavicka
//    }
//    data << list.join(";") << "\n";

    // hlavicka
    list << "Cislo"
         << "ZH \"r\"" << "P" << "N" <<	"PR" <<	"Mc" <<	"Vc" << "c1-c9" << "C0" <<	"cC" <<	"Cc" <<	"CC"
         << "Stlpec/Cislo"
         << "Teor. pocet" << "Teor. %"
         << "Pocet R1-DO" << "% R1-DO"
         << "Pocet R1-DO (r+1)" << "% R1-DO (r+1)"
         << "Pocet ROD-DO" << "% ROD-DO"
         << "Pocet ROD-DO (r+1)" << "% ROD-DO (r+1)";

    data << list.join(";").append("\n").toUtf8();

    for(unsigned c=1; c <= m; c++){

//        list.clear();

        for(unsigned stl=1; stl <= n; stl++){

            list.clear();

//            boost::multiprecision::cpp_rational t_perc = get_stlcc(c,stl)/(boost::multiprecision::cpp_rational)get_stlcc(1,1);
            unsigned t_perc=1;

            if(get_stlcc(c,stl).is_zero())
                t_perc = 0;

            list        << QString::number(por_c++);

            if(last_comb.contains(c))           // ZH "r"
                list << QString::number(c);
            else
                list << "";

            if(numberings.P(c))                 // P N
                list << QString::number(c) << "";
            else
                list << "" << QString::number(c);

            if(numberings.PR(c))                // PR
                list << QString::number(c);
            else
                list << "";

            if(numberings.Mc(c))                // Mc Vc
                list << QString::number(c) << "";
            else
                list << "" << QString::number(c);

            if(numberings.C19(c))               //c19
                list << QString::number(c);
            else
                list << "";

            if(numberings.C0(c))                //c0
                list << QString::number(c);
            else
                list << "";

            if(numberings.cC(c))                //cC
                list << QString::number(c);
            else
                list << "";

            if(numberings.Cc(c))                //Cc
                list << QString::number(c);
            else
                list << "";

            if(numberings.CC(c))                //CC
                list << QString::number(c);
            else
                list << "";

            list        << QString("stlchce(").append(QString::number(stl)).append("):").append(QString::number(c));
            list        << QString(get_stlcc(c,stl).str().c_str()) << QString::number(t_perc)
                        << QString::number((long)n_1DO.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_1DO.get_STL((num)c,stl))
                        << QString::number((long)n_1DO_1.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_1DO_1.get_STL((num)c,stl))
                        << QString::number((long)n_ODDO.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_ODDO.get_STL((num)c,stl))
                        << QString::number((long)n_ODDO_1.get_pocetnost().value(c).get_STL(stl)) << double_to_qstr(n_ODDO_1.get_STL((num)c,stl));

//            list << "\n";
            data << list.join(";").append("\n").toUtf8();
        }

//        data << list.join(";");
    }

    if(f.isOpen())
        f.close();
}

void Archiv::poc_R(QString od_do){

    Numberings numberings;

    QFile f(get_cwd().append(QString("pocetnostR_")).append(this->filename).append(od_do).append(".csv"));
    QStringList list;

    if(!f.open(QFile::WriteOnly)){
        // emit error();
        // return;
    }
    QTextStream data(&f);
    data.setCodec("UTF-8");
    data.setGenerateByteOrderMark(true);

    // hlavicka
    list << "Cislo"
         << "ZH \"r\"" << "P" << "N" <<	"PR" <<	"Mc" <<	"Vc" << "c1-c9" << "C0" <<	"cC" <<	"Cc" <<	"CC"
         << "Cislo"
         << "Teor. pocet" << "Teor. %"
         << "Pocet R1-DO" << "% R1-DO"
         << "Pocet R1-DO (r+1)" << "% R1-DO (r+1)"
         << "Pocet ROD-DO" << "% ROD-DO"
         << "Pocet ROD-DO (r+1)" << "% ROD-DO (r+1)";

    data << list.join(";").append("\n").toUtf8();


    boost::multiprecision::cpp_int t_pocet = get_stlcc(1,1);       // teoreticky pocet
    unsigned t_perc = 1;                  // teoreticke perc

    // cisla v riadkoch
    for(unsigned r=1; r <=m; r++){
        list.clear();
        list        << QString::number(r);

        if(last_comb.contains(r))           // ZH "r"
            list << QString::number(r);
        else
            list << "";

        if(numberings.P(r))                 // P N
            list << QString::number(r) << "";
        else
            list << "" << QString::number(r);

        if(numberings.PR(r))                // PR
            list << QString::number(r);
        else
            list << "";

        if(numberings.Mc(r))                // Mc Vc
            list << QString::number(r) << "";
        else
            list << "" << QString::number(r);

        if(numberings.C19(r))               //c19
            list << QString::number(r);
        else
            list << "";

        if(numberings.C0(r))                //c0
            list << QString::number(r);
        else
            list << "";

        if(numberings.cC(r))                //cC
            list << QString::number(r);
        else
            list << "";

        if(numberings.Cc(r))                //Cc
            list << QString::number(r);
        else
            list << "";

        if(numberings.CC(r))                //CC
            list << QString::number(r);
        else
            list << "";

        list        << QString::number(r)
                    << QString(t_pocet.str().c_str()) << QString::number(t_perc)
                    << QString::number((long)n_1DO.get_pocetnost().value(r).get_R()) << double_to_qstr(n_1DO.get_R((num)r))
                    << QString::number((long)n_1DO_1.get_pocetnost().value(r).get_R()) << double_to_qstr(n_1DO_1.get_R((num)r))
                    << QString::number((long)n_ODDO.get_pocetnost().value(r).get_R()) << double_to_qstr(n_ODDO.get_R((num)r))
                    << QString::number((long)n_ODDO_1.get_pocetnost().value(r).get_R()) << double_to_qstr(n_ODDO_1.get_R((num)r));
        data << list.join(";").append("\n").toUtf8();
    }
    if(f.isOpen())
        f.close();
}

void Archiv::parse(){

    QStringList list;
    this->r->next_line(list);

    while(this->r->next_line(list)){
        QStringList l = list;

        if(l.first().size() > 0)
            lines.push_back(l);
    }

    QLinkedList< QStringList >::Iterator it = lines.begin();

    while(it != lines.end()){

        QStringList list = *it;
        QVector<num> v;
        for(unsigned i=3; i<n+3;i++){
            num cislo = (num)list[i].toInt();
            v.push_back(cislo);
        }
        qvnums.push_back(v);
        it++;
    }
}

void Archiv::n1DO(int to){

    QSet<num> obsadenie; // aby ratalo % od 0% v archive
    QVector< QSet<num> > obsadenie_stl(this->n);

    Nmap pocetnost;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    while(qi.hasNext() && to > 0){
       int stl = 1;
       foreach (const num &qvn, qi.next()) {

           if(!obsadenie.contains(qvn)){
               obsadenie.insert(qvn);
//               continue;
           }
           else{
               pocetnost[qvn].set_R(pocetnost[qvn].get_R() + 1);
//               pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
           }
           if(!obsadenie_stl[stl-1].contains(qvn)){
               obsadenie_stl[stl-1].insert(qvn);
           }
           else{
               pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
           }
           stl++;
       }
       to--;
    }
    n_1DO = make_numbers(pocetnost);
    return;
}

void Archiv::nODDO(int from){

    bool has_UC = false;
//    bool has_UC_line = false;
    Nmap pocetnost;
    QSet<num> vyskyt;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    QSet<num> obsadenie; // aby ratalo % od 0% v archive
    QVector< QSet<num> > obsadenie_stl(this->n);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    while(qi.hasNext() && from >= 0/* && vyskyt.size() != m*/){
        foreach (const num &qvn, qi.next()) {
            vyskyt.insert(qvn);
        }
//        if(vyskyt.size() == (int)m && !has_UC_line){
//            UC_line_num = from+2;
//            has_UC_line = true;
//        }

        from--;
    }

    // este nie je 100% vyskyt
    if((unsigned)vyskyt.size() < m){
        Numbers n1(n,m);
        n_ODDO = n1;
        return;
    }

    vyskyt.clear();
    size_t r=qvnums.size();
    while(qi.hasPrevious() && (unsigned)vyskyt.size() < m){
        int stl = 1;
        foreach (const num &qvn, qi.previous()) {
            vyskyt.insert(qvn);

            // UC cislo
            if(vyskyt.size() == (int)m && !has_UC){
                UC = (unsigned)qvn;
                UC_line_num = r;
                has_UC = true;

            }
//            if(!obsadenie.contains(qvn)){
//                obsadenie.insert(qvn);
// //               continue;
//            }
//            else{
//                pocetnost[qvn].set_R(pocetnost[qvn].get_R() + 1);
// //               pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
//            }
//            if(!obsadenie_stl[stl-1].contains(qvn)){
//                obsadenie_stl[stl-1].insert(qvn);
//            }
//            else{
//                pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
//            }

            pocetnost[qvn].set_R(pocetnost[qvn].get_R() + 1);
            pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
            stl++;
        }
        r--;
    }
    n_ODDO = make_numbers(pocetnost);
    return;
}

boost::multiprecision::cpp_int Archiv::get_nCm(int n, int m){
    return (boost::multiprecision::cpp_int)boost::math::binomial_coefficient<double>(m, n);
}

boost::multiprecision::cpp_int Archiv::get_stlcc(int c, int stl){

    if((c-stl < 0) || (c-stl > (int)(m-n)))
        return 0;

    boost::multiprecision::cpp_int c1 = get_nCm(n-stl,m-c);
    boost::multiprecision::cpp_int c2 = get_nCm(stl-1,c-1);

    if(stl==1)
        return c1;

    else if(stl==(int)n)
        return c2;

    else
        return (c1*c2);
}

Numbers Archiv::make_numbers(Nmap &pocetnost){

//    using namespace boost::multiprecision;

    Numbers n1(n,m);
    n1.set_pocetnost(pocetnost);
    boost::multiprecision::cpp_rational y;

    foreach (const num &key, pocetnost.keys()) {

        // vypocet %r
        N np = pocetnost.value(key);
        y = (boost::multiprecision::cpp_rational)np.get_R()/get_stlcc(1,1);
        n1.set_R(key, y.convert_to<double>());

        // vypocet %stl pre stlpce
        for(unsigned i=1;i<=n;i++){
            boost::multiprecision::cpp_rational div = get_stlcc((unsigned)key,i);
            if(!div.is_zero()){
                boost::multiprecision::cpp_rational stl = (boost::multiprecision::cpp_rational)np.get_STL(i)/div;
                if(!stl.is_zero()){
                    n1.set_STL(key,i,stl.convert_to<double>());
                }
            }
        }
    }
    return n1;
}

unsigned Archiv::get_n() const{
    return this->n;
}
unsigned Archiv::get_m() const{
    return this->m;
}
QLinkedList<qvect> Archiv::get_qvnums() const{
    return this->qvnums;
}

double Archiv::get_delta(int dt){
    if(dt < 0 || dt >= deltar.size())
        return 0;

    return deltar[dt];
}

unsigned Archiv::get_UC() const{
    return UC;
}
unsigned Archiv::get_UC_line_num() const{
    return UC_line_num;
}

QString Archiv::get_cwd() const{
//    return QString(QDir::currentPath()).append("/").append(QString::number(n)).append(QString::number(m)).append(this->filename).append("/");
    return QString(QDir::currentPath()).append("/").append(this->filename).append("/");

}

void Archiv::set_n(unsigned n){
    this->n = n;
}
void Archiv::set_m(unsigned m){
    this->m = m;
}
void Archiv::set_1DO(Numbers n){
    this->n_1DO = n;
}
void Archiv::set_ODDO(Numbers n){
    this->n_ODDO = n;
}
void Archiv::set_qvnums(QLinkedList< qvect > qvn){
    this->qvnums = qvn;
}
void Archiv::set_lastcomb(qvect qv){
    this->last_comb = qv;
}

QDataStream &operator<<(QDataStream &out, const Archiv &ar){

    out << ar.get_n() << ar.get_m();
    out << ar.lines << ar.archiv;
    out << ar.get_1DO() << ar.get_ODDO();
    out << ar.get_qvnums();
    out << ar.get_last_comb();

    return out;
}

QDataStream &operator>>(QDataStream &in, Archiv &ar){

    unsigned n,m;
    Numbers n1,n2;
    QLinkedList<qvect> qvnums;
    qvect last_comb;

    in >> n >> m;
    in >> ar.lines >> ar.archiv;
    in >> n1 >> n2;
    in >> qvnums;
    in >> last_comb;

    ar.set_n(n);
    ar.set_m(m);
    ar.set_1DO(n1);
    ar.set_ODDO(n2);
    ar.set_qvnums(qvnums);
    ar.set_lastcomb(last_comb);

    return in;
}

void save_archiv(const Archiv &a){

    QFile file(QString(a.get_cwd().append("archiv.dat")));
    file.open(QIODevice::WriteOnly);

    QDataStream out(&file);
    out << a;

    file.close();
}

void load_archiv(Archiv &a, QString &filename){

    QFile file(filename);
    file.open(QIODevice::ReadOnly);

    QDataStream in(&file);
    in >> a;

    file.close();
}

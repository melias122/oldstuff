#include "mainwindow.h"
#include <QApplication>

//int main(int argc, char *argv[])
//{
//    QApplication a(argc, argv);

//    qRegisterMetaType<qvect>("qvect");
//    qRegisterMetaType<qvect2d>("qvect2d");

//    MainWindow w;
//    w.show();
    
//    return a.exec();
//}

#include <QDebug>

#include <archiv.h>
int main(){

    Archiv a;
    a.set_n(3);
    a.set_m(5);

    qDebug() << a.get_stlcc(4,1).str().c_str();

////    QString tica = "1 2 0 0 0 ";

    return 0;
}




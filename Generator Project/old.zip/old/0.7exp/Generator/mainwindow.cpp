#include "mainwindow.h"
#include "ui_mainwindow.h"

QString fname(QString path){
    return path.split(QDir::separator()).last();
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    generator_running = false;
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::get_M(){
    return ui->spinBoxM->text().toInt();
}

int MainWindow::get_N(){
    return ui->spinBoxN->text().toInt();
}

void MainWindow::info(QString s){
    ui->Info->setText(s);
}

void MainWindow::last_line(){
    QString pc, dat, cisla("");

//    line = archiv->lines.last();
    pc = archiv->lines.last()[0];
    dat = archiv->lines.last()[1];

    for(int i=0; i<archiv->get_n();i++){
        cisla.append(archiv->lines.last()[i+3]).append(" ");
    }
    ui->datc_R->setText(pc.append(": ").append(dat).append(" ").append(cisla));
}

void MainWindow::set_UC(){
    ui->UC->setText(QString::number(archiv->get_UC()).append("(").append(QString::number(archiv->get_UC_line_num())).append(")"));
}

void MainWindow::running(bool state){
    generator_running = state;
    if(generator_running){
        info("Hladam kombinacie");
//        ui->generateButton->setText("Stop");
//        ui->generate_rplus1->sett
    }
    else{
        info("Hladanie dokoncene");
        ui->generate_mix->setText("G");
        ui->generateButton->setText("Gen r");
        ui->generate_rplus1->setText("Gen r+1");
    }
}

void MainWindow::on_read_file_clicked()
{
    path_file = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_file.isEmpty()){

//        Archivtab = NULL;

        Archiv *a = new Archiv(get_N(), get_M(), path_file);
        this->archiv = a;
        QThread* archiv_thread = new QThread;
//        QThread archiv_thread;

        a->moveToThread(archiv_thread);

        connect(archiv_thread, SIGNAL(started()), a, SLOT(process()));
        connect(a, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(a, SIGNAL(finished()), archiv_thread, SLOT(quit()));
        connect(a, SIGNAL(finished()), this, SLOT(show_btns()));
        connect(a, SIGNAL(finished()), this, SLOT(last_line()));
        connect(a, SIGNAL(finished()), this, SLOT(set_UC()));
//        connect(a, SIGNAL(finished()), a, SLOT(deleteLater()));
//        connect(a, SIGNAL(finished()), this, SLOT(save_arch()));
        connect(archiv_thread, SIGNAL(finished()), archiv_thread, SLOT(deleteLater()));

        archiv_thread->start();

        info(QString("Subor ").append(fname(path_file)).append(" uspesne nacitany"));
        return;
    }
    info(QString("Nepodarilo sa nacitat subor ").append(fname(path_file)));
}

void MainWindow::on_read_arch_clicked()
{
    QString path_db;
    path_db = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("DAT (*.dat)"));
    if(!path_db.isEmpty()){
        Archiv *a = new Archiv();
        a->load(path_db);
        this->archiv = a;
        ui->spinBoxN->setValue(archiv->get_n());
        ui->spinBoxM->setValue(archiv->get_m());
        path_file.append(".");
        show_btns();
        last_line();
        set_UC();
        info("Archiv uspesne nacitany");
    }
}

void MainWindow::on_generate_mix_clicked()
{
    if(path_file.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(!min2()){
        info("Musia byt zadane aspon 2 kriteria pre vyhladavanie");
        return;
    }

    if(ui->mix_r->text().toInt() == 0)
        return;

    if(!generator_running){

        ui->generate_mix->setText("X");

        Glimits lim(archiv->get_n(), archiv->get_m(), archiv->get_1DO(),archiv->get_ODDO(),archiv->get_last_comb(),archiv->get_deltav());
        set_limits(lim);

        write_protocol("protokol.txt",lim.get_settings());

        QThread *generator_thread, *result_thread;
        Result *res = new Result(archiv);
        Generator *gen = new Generator(archiv,ui->mix_r->text().toInt(),lim);

        generator_thread = new QThread;
        result_thread = new QThread;

        gen->moveToThread(generator_thread);
        res->moveToThread(result_thread);

        connect(generator_thread, SIGNAL(started()), gen, SLOT(process_mix()));
        connect(this, SIGNAL(stop_generator()), gen, SLOT(stop()),Qt::DirectConnection);
        connect(gen, SIGNAL(finished()), generator_thread, SLOT(quit()));
        connect(gen, SIGNAL(finished()), gen, SLOT(deleteLater()));
        connect(gen, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(generator_thread, SIGNAL(finished()), generator_thread, SLOT(deleteLater()));
        connect(gen, SIGNAL(generator_state(bool)), this, SLOT(running(bool)));

        connect(gen,SIGNAL(send_result2(qvect,Numbers,Numbers)), res, SLOT(insert2(qvect,Numbers,Numbers)), Qt::BlockingQueuedConnection);
        connect(gen,SIGNAL(ended()), res, SLOT(end()));
//        connect(this,SIGNAL(stop_generator()),res, SLOT(stop()), Qt::DirectConnection);
        connect(res,SIGNAL(finished()), res, SLOT(deleteLater()));
        connect(res, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(result_thread, SIGNAL(finished()), result_thread, SLOT(deleteLater()));

        result_thread->start();
        generator_thread->start();

    }
    else{
        emit stop_generator();
    }
}


void MainWindow::on_generateButton_clicked()
{
    if(path_file.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(!min2()){
        info("Musia byt zadane aspon 2 kriteria pre vyhladavanie");
        return;
    }

    if(!generator_running){

        ui->generateButton->setText("Stop");

        int oddo=0;
        if(!ui->oddo_rozpetie->text().isEmpty()){
            on_vytvor_oddo_clicked();
            oddo=2;
        }

        Glimits lim(archiv->get_n(), archiv->get_m(), archiv->get_1DO(),archiv->get_ODDO(),archiv->get_last_comb(),archiv->get_deltav());
        set_limits(lim);

        write_protocol("protokol.txt",lim.get_settings());

        QThread *generator_thread, *result_thread;
        Result *res = new Result(archiv,0,oddo);
        Generator *gen = new Generator(get_N(),get_M(),lim);

        generator_thread = new QThread;
        result_thread = new QThread;

        gen->moveToThread(generator_thread);
        res->moveToThread(result_thread);

        connect(generator_thread, SIGNAL(started()), gen, SLOT(process()));
        connect(this, SIGNAL(stop_generator()), gen, SLOT(stop()),Qt::DirectConnection);
        connect(gen, SIGNAL(finished()), generator_thread, SLOT(quit()));
        connect(gen, SIGNAL(finished()), gen, SLOT(deleteLater()));
        connect(gen, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(generator_thread, SIGNAL(finished()), generator_thread, SLOT(deleteLater()));
        connect(gen, SIGNAL(generator_state(bool)), this, SLOT(running(bool)));

        connect(gen,SIGNAL(send_result(qvect)), res, SLOT(insert(qvect)), Qt::BlockingQueuedConnection);
        connect(gen,SIGNAL(ended()), res, SLOT(end()));
//        connect(this,SIGNAL(stop_generator()),res, SLOT(stop()), Qt::DirectConnection);
        connect(res,SIGNAL(finished()), res, SLOT(deleteLater()));
        connect(res, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(result_thread, SIGNAL(finished()), result_thread, SLOT(deleteLater()));

        result_thread->start();
        generator_thread->start();
    }
    else{
        emit stop_generator();
    }
}

void MainWindow::on_generate_rplus1_clicked()
{

    if(path_file.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(!min2()){
        info("Musia byt zadane aspon 2 kriteria pre vyhladavanie");
        return;
    }

    if(!generator_running){

        ui->generate_rplus1->setText("Stop");

        int oddo=1;
        if(!ui->oddo_rozpetie->text().isEmpty()){
            on_vytvor_oddo_clicked();
            oddo=2;
        }

        Glimits lim(archiv->get_n(), archiv->get_m(),archiv->get_1DO1(),archiv->get_ODDO1(), archiv->get_last_comb(),archiv->get_deltav());
        set_limits(lim);

        write_protocol("protokol.txt",lim.get_settings());

        QThread *generator_thread, *result_thread;
        Result *res = new Result(archiv,1,oddo);
        Generator *gen = new Generator(get_N(),get_M(),lim);

        generator_thread = new QThread;
        result_thread = new QThread;

        gen->moveToThread(generator_thread);
        res->moveToThread(result_thread);

        connect(generator_thread, SIGNAL(started()), gen, SLOT(process()));
        connect(this, SIGNAL(stop_generator()), gen, SLOT(stop()),Qt::DirectConnection);
        connect(gen, SIGNAL(finished()), generator_thread, SLOT(quit()));
        connect(gen, SIGNAL(finished()), gen, SLOT(deleteLater()));
        connect(gen, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(generator_thread, SIGNAL(finished()), generator_thread, SLOT(deleteLater()));
        connect(gen, SIGNAL(generator_state(bool)), this, SLOT(running(bool)));

        connect(gen,SIGNAL(send_result(qvect)), res, SLOT(insert(qvect)), Qt::BlockingQueuedConnection);
        connect(gen,SIGNAL(ended()), res, SLOT(end()));
//        connect(this,SIGNAL(stop_generator()),res, SLOT(stop()));
        connect(res,SIGNAL(finished()), res, SLOT(deleteLater()));
        connect(res, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(result_thread, SIGNAL(finished()), result_thread, SLOT(deleteLater()));

        result_thread->start();
        generator_thread->start();
    }
    else{
        emit stop_generator();
    }
}

void MainWindow::on_vytvor_oddo_clicked()
{
    if(path_file.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(ui->oddo_rozpetie->text().isEmpty()){
        info("OD-DO nebolo zadane rozpetie");
        return;
    }

    QStringList l = ui->oddo_rozpetie->text().split("-");
    if(l.size() == 2){
        archiv->set_od_do(l[0].toUInt(), l[1].toUInt());
        archiv->process_od_do();
        info("OD-DO vytvorene");
    }
}

void MainWindow::on_del_all_clicked(){
    on_del_r1_clicked();
    on_del_rod_clicked();
    on_del_stl1_clicked();
    on_del_stlod_clicked();
    on_del_sum_komb_clicked();
    on_del_C0_clicked();
    on_del_c1c9_clicked();
    on_del_CC_clicked();
    on_del_Cc_clicked();
    on_del_cC_clicked();
    on_del_Mc_clicked();
    on_del_N_clicked();
    on_del_PR_clicked();
    on_del_P_clicked();
    on_del_Vc_clicked();
    on_del_ZH_clicked();
    on_del_povinne_clicked();
    on_del_zakazane_clicked();
    on_del_Ntice_clicked();
    on_del_Xtice_clicked();
    on_del_Sm_clicked();
    on_del_Kor_clicked();

    on_del_dtr1_clicked();
    on_del_dtr2_clicked();
    on_del_dtRSTL1_clicked();
    on_del_dtRSTL2_clicked();
    on_del_dtSTL1_clicked();
    on_del_dtstl2_clicked();
}

void MainWindow::show_btns(){
    ui->show_limits->setEnabled(true);
    ui->generate_mix->setEnabled(true);
    ui->generateButton->setEnabled(true);
    ui->generate_rplus1->setEnabled(true);
    ui->lim_r->setEnabled(true);
    ui->lim_r1->setEnabled(true);
    ui->lim_zh->setEnabled(true);
    if(get_N() >= 1) ui->n1->setEnabled(true);
    if(get_N() >= 2) ui->n2->setEnabled(true);
    if(get_N() >= 3) ui->n3->setEnabled(true);
    if(get_N() >= 4) ui->n4->setEnabled(true);
    if(get_N() >= 5) ui->n5->setEnabled(true);
    if(get_N() >= 6) ui->n6->setEnabled(true);
    if(get_N() >= 7) ui->n7->setEnabled(true);
    if(get_N() >= 8) ui->n8->setEnabled(true);
    if(get_N() >= 9) ui->n9->setEnabled(true);
    if(get_N() >= 10) ui->n10->setEnabled(true);

    if(get_N() >= 11) ui->n11->setEnabled(true);
    if(get_N() >= 12) ui->n12->setEnabled(true);
    if(get_N() >= 13) ui->n13->setEnabled(true);
    if(get_N() >= 14) ui->n14->setEnabled(true);
    if(get_N() >= 15) ui->n15->setEnabled(true);
    if(get_N() >= 16) ui->n16->setEnabled(true);
    if(get_N() >= 17) ui->n17->setEnabled(true);
    if(get_N() >= 18) ui->n18->setEnabled(true);
    if(get_N() >= 19) ui->n19->setEnabled(true);
    if(get_N() >= 20) ui->n20->setEnabled(true);

    if(get_N() >= 21) ui->n21->setEnabled(true);
    if(get_N() >= 22) ui->n22->setEnabled(true);
    if(get_N() >= 23) ui->n23->setEnabled(true);
    if(get_N() >= 24) ui->n24->setEnabled(true);
    if(get_N() >= 25) ui->n25->setEnabled(true);
    if(get_N() >= 26) ui->n26->setEnabled(true);
    if(get_N() >= 27) ui->n27->setEnabled(true);
    if(get_N() >= 28) ui->n28->setEnabled(true);
    if(get_N() >= 29) ui->n29->setEnabled(true);
    if(get_N() >= 30) ui->n30->setEnabled(true);
}

void MainWindow::on_show_limits_clicked()
{
    qvect v = archiv->get_last_numberings(), comb = archiv->get_last_comb();
//    qvector

    ui->r1R->setText(QString::number(archiv->get_1DO().sum_R(comb.begin(),comb.end())).replace(".",","));
    ui->stl1R->setText(QString::number(archiv->get_1DO().sum_STL(comb.begin(),comb.end())).replace(".",","));
    ui->r2R->setText(QString::number(archiv->get_ODDO().sum_R(comb.begin(),comb.end())).replace(".",","));
    ui->stl2R->setText(QString::number(archiv->get_ODDO().sum_STL(comb.begin(),comb.end())).replace(".",","));
    ui->kombR->setText(QString::number(sum_comb(comb.begin(),comb.end())));

    ui->dtr1->setText(QString::number(archiv->get_delta(0)));
    ui->dtstl1->setText(QString::number(archiv->get_delta(1)));
    ui->dtRSTL1->setText(QString::number( archiv->get_1DO().sum_R(comb.begin(),comb.end()) - archiv->get_1DO().sum_STL(comb.begin(),comb.end()) ));

    ui->dtr2->setText(QString::number(archiv->get_delta(2)));
    ui->dtstl2->setText(QString::number(archiv->get_delta(3)));
    ui->dtRSTL2->setText(QString::number( archiv->get_ODDO().sum_R(comb.begin(),comb.end()) - archiv->get_ODDO().sum_STL(comb.begin(),comb.end()) ));

    ui->P->setText(QString::number(v[0]));
    ui->N->setText(QString::number(v[1]));
    ui->PR->setText(QString::number(v[2]));

    ui->Mc->setText(QString::number(v[3]));
    ui->Vc->setText(QString::number(v[4]));
    ui->c1_c9->setText(QString::number(v[5]));

    ui->C0->setText(QString::number(v[6]));
    ui->cC->setText(QString::number(v[7]));
    ui->Cc->setText(QString::number(v[8]));

    ui->CC->setText(QString::number(v[9]));
    ui->ZH->setText(QString::number(v[10]));

    ui->Sm->setText(archiv->archiv.last()[12].replace("\"",""));
    ui->Kor->setText(archiv->archiv.last()[13].replace("\"",""));

    ui->n_tice->setText(archiv->archiv.last()[14].remove(archiv->archiv.last()[14].size()-1,1));
//    ui->x_tice->setText(archiv->archiv.last()[15]);

    QStringList xtice = archiv->archiv.last()[15].split(" ");

    if(xtice.size() < 9){
        while(xtice.size() != 9)
            xtice.append("");
    }
    ui->x_tice1->setText(xtice[0]);
    ui->x_tice2->setText(xtice[1]);
    ui->x_tice3->setText(xtice[2]);
    ui->x_tice4->setText(xtice[3]);
    ui->x_tice5->setText(xtice[4]);
    ui->x_tice6->setText(xtice[5]);
    ui->x_tice7->setText(xtice[6]);
    ui->x_tice8->setText(xtice[7]);
    ui->x_tice9->setText(xtice[8]);

}

void MainWindow::on_lim_r_clicked()
{
    ui->r1od->setText(QString::number(archiv->get_1DO().sum_R_min()).replace(".",","));
    ui->r1do->setText(QString::number(archiv->get_1DO().sum_R_max()).replace(".",","));
    ui->stl1od->setText(QString::number(archiv->get_1DO().sum_STL_min()).replace(".",","));
    ui->stl1do->setText(QString::number(archiv->get_1DO().sum_STL_max()).replace(".",","));
    ui->kombod->setText(QString::number(archiv->get_1DO().sum_komb_min()).replace(".",","));
    ui->kombdo->setText(QString::number(archiv->get_1DO().sum_komb_max()).replace(".",","));
    ui->r2od->setText(QString::number(archiv->get_ODDO().sum_R_min()).replace(".",","));
    ui->r2do->setText(QString::number(archiv->get_ODDO().sum_R_max()).replace(".",","));
    ui->stl2od->setText(QString::number(archiv->get_ODDO().sum_STL_min()).replace(".",","));
    ui->stl2do->setText(QString::number(archiv->get_ODDO().sum_STL_max()).replace(".",","));
}

void MainWindow::on_lim_r1_clicked()
{
    ui->r1od->setText(QString::number(archiv->get_1DO1().sum_R_min()).replace(".",","));
    ui->r1do->setText(QString::number(archiv->get_1DO1().sum_R_max()).replace(".",","));
    ui->stl1od->setText(QString::number(archiv->get_1DO1().sum_STL_min()).replace(".",","));
    ui->stl1do->setText(QString::number(archiv->get_1DO1().sum_STL_max()).replace(".",","));
    ui->kombod->setText(QString::number(archiv->get_1DO1().sum_komb_min()).replace(".",","));
    ui->kombdo->setText(QString::number(archiv->get_1DO1().sum_komb_max()).replace(".",","));
    ui->r2od->setText(QString::number(archiv->get_ODDO1().sum_R_min()).replace(".",","));
    ui->r2do->setText(QString::number(archiv->get_ODDO1().sum_R_max()).replace(".",","));
    ui->stl2od->setText(QString::number(archiv->get_ODDO1().sum_STL_min()).replace(".",","));
    ui->stl2do->setText(QString::number(archiv->get_ODDO1().sum_STL_max()).replace(".",","));
}

#include"combination.h"
void MainWindow::on_lim_zh_clicked()
{
    if(ui->mix_r->text().toInt() < 1)
        return;
    if(ui->mix_r->text().isEmpty())
        return;

    qvect a, b;

    double r1_min=999, r1_max=0, stl1_min=999, stl1_max=0, r2_min=999, r2_max=0, stl2_min=999, stl2_max=0;

    for(int i=0; i<get_N(); i++){
        a << i;
    }
    for(int i=0; i<ui->mix_r->text().toInt(); i++){
        b << i;
    }

    do{

        Nmap poc_1_do, poc_od_do;
        poc_1_do = archiv->get_1DO().get_pocetnost();
        poc_od_do = archiv->get_ODDO().get_pocetnost();

        for(unsigned i=0; i < b.size(); i++){

            int stl = b[i] + 1;
            int j= archiv->get_last_comb()[b[i]];

            poc_1_do[j].set_R(poc_1_do[j].get_R() + 1);
            poc_od_do[j].set_R(poc_od_do[j].get_R() + 1);

            poc_1_do[j].set_STL(stl, poc_1_do[j].get_STL(stl)+1);
            poc_od_do[j].set_STL(stl,poc_od_do[j].get_STL(stl)+1);
        }
//        for(unsigned i=1; i <= get_M(); i++){
//            if(archiv->get_last_comb().contains(i))
//                continue;
//            poc_1_do[i].set_R(poc_1_do[i].get_R() + 1);
//            poc_od_do[i].set_R(poc_od_do[i].get_R() + 1);
//        }

//        for(unsigned i=1; i <= get_N(); i++){
//            for(unsigned j=i; j<=get_M()-get_N()+i; j++){
//                if(archiv->get_last_comb().contains(j))
//                    continue;
//                poc_1_do[j].set_STL(i, poc_1_do[j].get_STL(i)+1);
//                poc_od_do[j].set_STL(i,poc_od_do[j].get_STL(i)+1);
//            }
//        }
        Numbers n1 = archiv->make_numbers(poc_1_do);
        Numbers n2 = archiv->make_numbers(poc_od_do);

        if(n1.sum_R_min() < r1_min)
            r1_min = n1.sum_R_min();
        if(n1.sum_R_max() > r1_max)
            r1_max = n1.sum_R_max();
        if(n1.sum_STL_min() < stl1_min)
            stl1_min = n1.sum_STL_min();
        if(n1.sum_STL_max() > stl1_max)
            stl1_max = n1.sum_STL_max();

        if(n2.sum_R_min() < r2_min)
            r2_min = n2.sum_R_min();
        if(n2.sum_R_max() > r2_max)
            r2_max = n2.sum_R_max();
        if(n2.sum_STL_min() < stl2_min)
            stl2_min = n2.sum_STL_min();
        if(n2.sum_STL_max() > stl2_max)
            stl2_max = n2.sum_STL_max();

    }while(stdcomb::next_combination(a.begin(),a.end(),b.begin(),b.end()));

    ui->r1od->setText(QString::number(r1_min ).replace(".",","));
    ui->r1do->setText(QString::number(r1_max ).replace(".",","));
    ui->stl1od->setText(QString::number(stl1_min ).replace(".",","));
    ui->stl1do->setText(QString::number(stl1_max ).replace(".",","));
    ui->kombod->setText(QString::number(archiv->get_1DO1().sum_komb_min()).replace(".",","));
    ui->kombdo->setText(QString::number(archiv->get_1DO1().sum_komb_max()).replace(".",","));
    ui->r2od->setText(QString::number(r2_min ).replace(".",","));
    ui->r2do->setText(QString::number(r2_max ).replace(".",","));
    ui->stl2od->setText(QString::number(stl2_min ).replace(".",","));
    ui->stl2do->setText(QString::number(stl2_max ).replace(".",","));
}

bool MainWindow::min2(){

    Glimits g(get_N(), get_M());
    set_limits(g);

    return (g.size() > 1);
}

void MainWindow::set_limits(Glimits &g){

    bool ok;
    unsigned u;
    double d;
    qvect ntice;
    QSet<num> povinne,zakazane;

//    if(ui->r1od->isEnabled()){
//        if(!ui->r1od->text().isEmpty()){
//            d = ui->r1od->text().replace(",",".").toDouble(&ok);
//            if(ok){
//                g.set_r1od(d);
//            }
//        }
//        if(!ui->r1R->text().isEmpty()){
//            d = ui->r1R->text().replace(",",".").toDouble(&ok);
//            if(ok){
//                g.set_r1do(d);
//            }
//        }
//    }
    // dt R1
    if(ui->dtr1od->isEnabled()){
        if(!ui->dtr1od->text().isEmpty()){
            d = ui->dtr1od->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR1od(d);
        }
        if(!ui->dtr1->text().isEmpty()){
            d = ui->dtr1->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR1do(d);
        }
    }
    else{
        if(!ui->dtr1->text().isEmpty()){
            d = ui->dtr1->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR1od(d);
        }
        if(!ui->dtr1do->text().isEmpty()){
            d = ui->dtr1do->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR1do(d);
        }
    }

    // dt STL1
    if(ui->dtstl1od->isEnabled()){
        if(!ui->dtstl1od->text().isEmpty()){
            d = ui->dtstl1od->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL1od(d);
        }
        if(!ui->dtstl1->text().isEmpty()){
            d = ui->dtstl1->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL1do(d);
        }
    }
    else{
        if(!ui->dtstl1->text().isEmpty()){
            d = ui->dtstl1->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL1od(d);
        }
        if(!ui->dtstl1do->text().isEmpty()){
            d = ui->dtstl1do->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL1do(d);
        }
    }

    // dt R2
    if(ui->dtr2od->isEnabled()){
        if(!ui->dtr2od->text().isEmpty()){
            d = ui->dtr2od->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR2od(d);
        }
        if(!ui->dtr2->text().isEmpty()){
            d = ui->dtr2->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR2do(d);
        }
    }
    else{
        if(!ui->dtr2->text().isEmpty()){
            d = ui->dtr2->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR2od(d);
        }
        if(!ui->dtr2do->text().isEmpty()){
            d = ui->dtr2do->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtR2do(d);
        }
    }

    // dt STL2
    if(ui->dtstl2od->isEnabled()){
        if(!ui->dtstl2od->text().isEmpty()){
            d = ui->dtstl2od->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL2od(d);
        }
        if(!ui->dtstl2->text().isEmpty()){
            d = ui->dtstl2->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL2do(d);
        }
    }
    else{
        if(!ui->dtstl2->text().isEmpty()){
            d = ui->dtstl2->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL2od(d);
        }
        if(!ui->dtstl2do->text().isEmpty()){
            d = ui->dtstl2do->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dtSTL2do(d);
        }
    }

    // dt R1-STL1
    if(ui->dtRSTL1od->isEnabled()){
        if(!ui->dtRSTL1->text().isEmpty()){
            d = ui->dtRSTL1->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dt_rs1do(d);
        }
    }
    else {
        if(!ui->dtRSTL1->text().isEmpty()){
            d = ui->dtRSTL1->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dt_rs1od(d);
        }
    }

    // dt R2-STL2
    if(ui->dtRSTL2od->isEnabled()){
        if(!ui->dtRSTL2->text().isEmpty()){
            d = ui->dtRSTL2->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dt_rs2do(d);
        }
    }
    else{
        if(!ui->dtRSTL2->text().isEmpty()){
            d = ui->dtRSTL2->text().replace(",",".").toDouble(&ok);
            if(ok)
                g.set_dt_rs2od(d);
        }
    }

    if(!ui->x_tice1->text().isEmpty()){
        QString xstr;

        xstr.append(ui->x_tice1->text()).append("|");

        if(!ui->x_tice2->text().isEmpty())
            xstr.append(ui->x_tice2->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice3->text().isEmpty())
            xstr.append(ui->x_tice3->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice4->text().isEmpty())
            xstr.append(ui->x_tice4->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice5->text().isEmpty())
            xstr.append(ui->x_tice5->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice6->text().isEmpty())
            xstr.append(ui->x_tice6->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice7->text().isEmpty())
            xstr.append(ui->x_tice7->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice8->text().isEmpty())
            xstr.append(ui->x_tice8->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice9->text().isEmpty())
            xstr.append(ui->x_tice9->text()).append("|");
        else
            xstr.append("0 ");

        g.set_xtice(xstr);

    }

    // ntice
    if(!ui->n_tice->text().isEmpty()){
        QStringList l = ui->n_tice->text().split(" ");
        unsigned sum = 0;

        for(int i=1; i<=l.size() && i<=get_N(); i++){
            sum += l[i-1].toUInt()*i;
            ntice.push_back((num)l[i-1].toUInt());
        }
        if(sum != (unsigned)get_N())
            info("N-tice zle zadane");
        else
            g.set_ntice(ntice);
    }

    // nticeStl
    if(!ui->n_tice->text().isEmpty()){
        qvect ntice_stl;

        if(ui->n1->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n2->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n3->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n4->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n5->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n6->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n7->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n8->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n9->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n10->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n11->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n12->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n13->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n14->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n15->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n16->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n17->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n18->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n19->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n20->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n21->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n22->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n23->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n24->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n25->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n26->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n27->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n28->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n29->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);
        if(ui->n30->isChecked()) ntice_stl.push_back(1);
        else ntice_stl.push_back(0);

        QStringList l = ui->n_tice->text().split(" ");
        unsigned sum = 0, sum2=0;

        for(int i=1; i<l.size() && i<=get_N(); i++){
            sum += l[i].toUInt()*(i+1);
//            ntice.push_back((num)l[i-1].toUInt());
        }

        foreach (const int &i, ntice_stl) {
            if(i == 1)
                sum2 += 1;
        }
        if(sum != sum2){
            // zadane zle
        }
        else{
            g.set_ntice_stl(ntice_stl);
        }
    }

    if(!ui->Povinne->text().isEmpty()){

        QStringList pov = ui->Povinne->text().split(",");
        foreach (const QString &str, pov) {
            if(str.contains("-")){
                QStringList a=str.split("-");
                for(int i=a[0].toInt(); i<=a[1].toInt(); i++){
                    povinne.insert((num)i);
                }
            }
            else if(str.toInt() == 0)
                continue;
            else
                povinne.insert((num)str.toUInt());
        }

        if(povinne.size() > get_N())
            info("Povinnych je prilis vela");
        else
            g.set_povinne(povinne);
    }

    if(!ui->Zakazane->text().isEmpty()){

        QStringList zak = ui->Zakazane->text().split(",");
        foreach (const QString &str, zak) {
            if(str.contains("-")){
                QStringList a=str.split("-");
                for(int i=a[0].toInt(); i<=a[1].toInt(); i++){
                    zakazane.insert((num)i);
                }
            }
            else if(str.toInt() == 0)
                continue;
            else
                zakazane.insert((num)str.toUInt());
        }

        if(zakazane.size() > get_M()-get_N())
            info("Zakazanych je prilis vela");
        else
            g.set_zakazane(zakazane);
    }

    if(ui->Korod->isEnabled()){
        if(!ui->Korod->text().isEmpty()){
            d = ui->Korod->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Kkod(d);
            }
        }
        if(!ui->Kor->text().isEmpty()){
            d = ui->Kor->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Kkdo(d);
            }
        }
    }
    else{
        if(!ui->Kor->text().isEmpty()){
            d = ui->Kor->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Kkod(d);
            }
        }
        if(!ui->Kordo->text().isEmpty()){
            d = ui->Kordo->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Kkdo(d);
            }
        }
    }

    if(ui->Smod->isEnabled()){
        if(!ui->Smod->text().isEmpty()){
            d = ui->Smod->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Smod(d);
            }
        }
        if(!ui->Sm->text().isEmpty()){
            d = ui->Sm->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Smdo(d);
            }
        }
    }
    else{
        if(!ui->Sm->text().isEmpty()){
            d = ui->Sm->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Smod(d);
            }
        }
        if(!ui->Smdo->text().isEmpty()){
            d = ui->Smdo->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_Smdo(d);
            }
        }
    }

    if(ui->r1od->isEnabled()){
        if(!ui->r1od->text().isEmpty()){
            d = ui->r1od->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r1od(d);
            }
        }
        if(!ui->r1R->text().isEmpty()){
            d = ui->r1R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r1do(d);
            }
        }
    }
    else{
        if(!ui->r1R->text().isEmpty()){
            d = ui->r1R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r1od(d);
            }
        }
        if(!ui->r1do->text().isEmpty()){
            d = ui->r1do->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r1do(d);
            }
        }
    }
    if(ui->r2od->isEnabled()){
        if(!ui->r2od->text().isEmpty()){
            d = ui->r2od->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r2od(d);
            }
        }
        if(!ui->r2R->text().isEmpty()){
            d = ui->r2R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r2do(d);
            }
        }
    }
    else{
        if(!ui->r2R->text().isEmpty()){
            d = ui->r2R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r2od(d);
            }
        }
        if(!ui->r2do->text().isEmpty()){
            d = ui->r2do->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_r2do(d);
            }
        }
    }

    if(ui->stl1od->isEnabled()){
        if(!ui->stl1od->text().isEmpty()){
            d = ui->stl1od->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl1od(d);
            }
        }
        if(!ui->stl1R->text().isEmpty()){
            d = ui->stl1R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl1do(d);
            }
        }
    }
    else{
        if(!ui->stl1R->text().isEmpty()){
            d = ui->stl1R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl1od(d);
            }
        }
        if(!ui->stl1do->text().isEmpty()){
            d = ui->stl1do->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl1do(d);
            }
        }
    }

    if(ui->stl2od->isEnabled()){
        if(!ui->stl2od->text().isEmpty()){
            d = ui->stl2od->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl2od(d);
            }
        }
        if(!ui->stl2R->text().isEmpty()){
            d = ui->stl2R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl2do(d);
            }
        }
    }
    else{
        if(!ui->stl2R->text().isEmpty()){
            d = ui->stl2R->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl2od(d);
            }
        }
        if(!ui->stl2do->text().isEmpty()){
            d = ui->stl2do->text().replace(",",".").toDouble(&ok);
            if(ok){
                g.set_stl2do(d);
            }
        }
    }

    if(ui->kombod->isEnabled()){
        if(!ui->kombod->text().isEmpty()){
            u = ui->kombod->text().toUInt(&ok);
            if(ok){
                g.set_kombod(u);
            }
        }
        if(!ui->kombR->text().isEmpty()){
            u = ui->kombR->text().toUInt(&ok);
            if(ok){
                g.set_kombdo(u);
            }
        }
    }
    else{
        if(!ui->kombR->text().isEmpty()){
            u = ui->kombR->text().toUInt(&ok);
            if(ok){
                g.set_kombod(u);
            }
        }
        if(!ui->kombdo->text().isEmpty()){
            u = ui->kombdo->text().toUInt(&ok);
            if(ok){
                g.set_kombdo(u);
            }
        }
    }

    if(ui->Pod->isEnabled()){
        if(!ui->Pod->text().isEmpty()){
            u = ui->Pod->text().toUInt(&ok);
            if(ok){
                g.set_Pod(u);
            }
        }
        if(!ui->P->text().isEmpty()){
            u = ui->P->text().toUInt(&ok);
            if(ok){
                g.set_Pdo(u);
            }
        }
    }
    else{
        if(!ui->P->text().isEmpty()){
            u = ui->P->text().toUInt(&ok);
            if(ok){
                g.set_Pod(u);
            }
        }
        if(!ui->Pdo->text().isEmpty()){
            u = ui->Pdo->text().toUInt(&ok);
            if(ok){
                g.set_Pdo(u);
            }
        }
    }

    if(ui->Nod->isEnabled()){
        if(!ui->Nod->text().isEmpty()){
            u = ui->Nod->text().toUInt(&ok);
            if(ok){
                g.set_Nod(u);
            }
        }
        if(!ui->N->text().isEmpty()){
            u = ui->N->text().toUInt(&ok);
            if(ok){
                g.set_Ndo(u);
            }
        }
    }
    else{
        if(!ui->N->text().isEmpty()){
            u = ui->N->text().toUInt(&ok);
            if(ok){
                g.set_Nod(u);
            }
        }
        if(!ui->Ndo->text().isEmpty()){
            u = ui->Ndo->text().toUInt(&ok);
            if(ok){
                g.set_Ndo(u);
            }
        }
    }

    if(ui->PRod->isEnabled()){
        if(!ui->PRod->text().isEmpty()){
            u = ui->PRod->text().toUInt(&ok);
            if(ok){
                g.set_PRod(u);
            }
        }
        if(!ui->PR->text().isEmpty()){
            u = ui->PR->text().toUInt(&ok);
            if(ok){
                g.set_PRdo(u);
            }
        }
    }
    else{
        if(!ui->PR->text().isEmpty()){
            u = ui->PR->text().toUInt(&ok);
            if(ok){
                g.set_PRod(u);
            }
        }
        if(!ui->PRdo->text().isEmpty()){
            u = ui->PRdo->text().toUInt(&ok);
            if(ok){
                g.set_PRdo(u);
            }
        }
    }

    if(ui->Mcod->isEnabled()){
        if(!ui->Mcod->text().isEmpty()){
            u = ui->Mcod->text().toUInt(&ok);
            if(ok){
                g.set_Mcod(u);
            }
        }
        if(!ui->Mc->text().isEmpty()){
            u = ui->Mc->text().toUInt(&ok);
            if(ok){
                g.set_Mcdo(u);
            }
        }
    }
    else{
        if(!ui->Mc->text().isEmpty()){
            u = ui->Mc->text().toUInt(&ok);
            if(ok){
                g.set_Mcod(u);
            }
        }
        if(!ui->Mcdo->text().isEmpty()){
            u = ui->Mcdo->text().toUInt(&ok);
            if(ok){
                g.set_Mcdo(u);
            }
        }
    }

    if(ui->Vcod->isEnabled()){
        if(!ui->Vcod->text().isEmpty()){
            u = ui->Vcod->text().toUInt(&ok);
            if(ok){
                g.set_Vcod(u);
            }
        }
        if(!ui->Vc->text().isEmpty()){
            u = ui->Vc->text().toUInt(&ok);
            if(ok){
                g.set_Vcdo(u);
            }
        }
    }
    else{
        if(!ui->Vc->text().isEmpty()){
            u = ui->Vc->text().toUInt(&ok);
            if(ok){
                g.set_Vcod(u);
            }
        }
        if(!ui->Vcdo->text().isEmpty()){
            u = ui->Vcdo->text().toUInt(&ok);
            if(ok){
                g.set_Vcdo(u);
            }
        }
    }

    if(ui->ZHod->isEnabled()){
        if(!ui->ZHod->text().isEmpty()){
            u = ui->ZHod->text().toUInt(&ok);
            if(ok){
                g.set_ZHod(u);
            }
        }
        if(!ui->ZH->text().isEmpty()){
            u = ui->ZH->text().toUInt(&ok);
            if(ok){
                g.set_ZHdo(u);
            }
        }
    }
    else{
        if(!ui->ZH->text().isEmpty()){
            u = ui->ZH->text().toUInt(&ok);
            if(ok){
                g.set_ZHod(u);
            }
        }
        if(!ui->ZHdo->text().isEmpty()){
            u = ui->ZHdo->text().toUInt(&ok);
            if(ok){
                g.set_ZHdo(u);
            }
        }
    }

    if(ui->c1_c9od->isEnabled()){
        if(!ui->c1_c9od->text().isEmpty()){
            u = ui->c1_c9od->text().toUInt(&ok);
            if(ok){
                g.set_c19od(u);
            }
        }
        if(!ui->c1_c9->text().isEmpty()){
            u = ui->c1_c9->text().toUInt(&ok);
            if(ok){
                g.set_c19do(u);
            }
        }
    }
    else{
        if(!ui->c1_c9->text().isEmpty()){
            u = ui->c1_c9->text().toUInt(&ok);
            if(ok){
                g.set_c19od(u);
            }
        }
        if(!ui->c1_c9do->text().isEmpty()){
            u = ui->c1_c9do->text().toUInt(&ok);
            if(ok){
                g.set_c19do(u);
            }
        }
    }

    if(ui->C0od->isEnabled()){
        if(!ui->C0od->text().isEmpty()){
            u = ui->C0od->text().toUInt(&ok);
            if(ok){
                g.set_c0od(u);
            }
        }
        if(!ui->C0->text().isEmpty()){
            u = ui->C0->text().toUInt(&ok);
            if(ok){
                g.set_c0do(u);
            }
        }
    }
    else{
        if(!ui->C0->text().isEmpty()){
            u = ui->C0->text().toUInt(&ok);
            if(ok){
                g.set_c0od(u);
            }
        }
        if(!ui->C0do->text().isEmpty()){
            u = ui->C0do->text().toUInt(&ok);
            if(ok){
                g.set_c0do(u);
            }
        }
    }

    if(ui->cCod->isEnabled()){
        if(!ui->cCod->text().isEmpty()){
            u = ui->cCod->text().toUInt(&ok);
            if(ok){
                g.set_cCod(u);
            }
        }
        if(!ui->cC->text().isEmpty()){
            u = ui->cC->text().toUInt(&ok);
            if(ok){
                g.set_cCdo(u);
            }
        }
    }
    else{
        if(!ui->cC->text().isEmpty()){
            u = ui->cC->text().toUInt(&ok);
            if(ok){
                g.set_cCod(u);
            }
        }
        if(!ui->cCdo->text().isEmpty()){
            u = ui->cCdo->text().toUInt(&ok);
            if(ok){
                g.set_cCdo(u);
            }
        }
    }

    if(ui->Ccod->isEnabled()){
        if(!ui->Ccod->text().isEmpty()){
            u = ui->Ccod->text().toUInt(&ok);
            if(ok){
                g.set_Ccod(u);
            }
        }
        if(!ui->Cc->text().isEmpty()){
            u = ui->Cc->text().toUInt(&ok);
            if(ok){
                g.set_Ccdo(u);
            }
        }
    }
    else{
        if(!ui->Cc->text().isEmpty()){
            u = ui->Cc->text().toUInt(&ok);
            if(ok){
                g.set_Ccod(u);
            }
        }
        if(!ui->Ccdo->text().isEmpty()){
            u = ui->Ccdo->text().toUInt(&ok);
            if(ok){
                g.set_Ccdo(u);
            }
        }
    }

    if(ui->CCod->isEnabled()){
        if(!ui->CCod->text().isEmpty()){
            u = ui->CCod->text().toUInt(&ok);
            if(ok){
                g.set_CCod(u);
            }
        }
        if(!ui->CC->text().isEmpty()){
            u = ui->CC->text().toUInt(&ok);
            if(ok){
                g.set_CCdo(u);
            }
        }
    }
    else{
        if(!ui->CC->text().isEmpty()){
            u = ui->CC->text().toUInt(&ok);
            if(ok){
                g.set_CCod(u);
            }
        }
        if(!ui->CCdo->text().isEmpty()){
            u = ui->CCdo->text().toUInt(&ok);
            if(ok){
                g.set_CCdo(u);
            }
        }
    }
}

void MainWindow::on_r1gl_clicked(){
    ui->r1od->setEnabled(true);
    ui->r1do->setEnabled(false);
}

void MainWindow::on_r1gl_2_clicked(){
    ui->r1od->setEnabled(false);
    ui->r1do->setEnabled(true);
}

void MainWindow::on_pgl_clicked(){
    ui->Pod->setEnabled(true);
    ui->Pdo->setEnabled(false);
}

void MainWindow::on_pgl_2_clicked(){
    ui->Pod->setEnabled(false);
    ui->Pdo->setEnabled(true);
}


void MainWindow::on_mcgl_clicked(){
    ui->Mcod->setEnabled(true);
    ui->Mcdo->setEnabled(false);
}

void MainWindow::on_mcgl_2_clicked(){
    ui->Mcod->setEnabled(false);
    ui->Mcdo->setEnabled(true);
}

void MainWindow::on_c1c9gl_clicked(){
    ui->c1_c9od->setEnabled(true);
    ui->c1_c9do->setEnabled(false);
}

void MainWindow::on_c1c9gl_2_clicked(){
    ui->c1_c9od->setEnabled(false);
    ui->c1_c9do->setEnabled(true);
}

void MainWindow::on_ngl_clicked()
{
    ui->Nod->setEnabled(true);
    ui->Ndo->setEnabled(false);
}

void MainWindow::on_ngl_2_clicked()
{
    ui->Nod->setEnabled(false);
    ui->Ndo->setEnabled(true);
}

void MainWindow::on_Ccgl_clicked()
{
    ui->Ccod->setEnabled(true);
    ui->Ccdo->setEnabled(false);
}

void MainWindow::on_Ccgl_2_clicked()
{
    ui->Ccod->setEnabled(false);
    ui->Ccdo->setEnabled(true);
}

void MainWindow::on_c0gl_clicked()
{
    ui->C0od->setEnabled(true);
    ui->C0do->setEnabled(false);
}

void MainWindow::on_c0gl_2_clicked()
{
    ui->C0od->setEnabled(false);
    ui->C0do->setEnabled(true);
}

void MainWindow::on_prgl_clicked()
{
    ui->PRod->setEnabled(true);
    ui->PRdo->setEnabled(false);
}

void MainWindow::on_prgl_2_clicked()
{
    ui->PRod->setEnabled(false);
    ui->PRdo->setEnabled(true);
}

void MainWindow::on_vcgl_clicked()
{
    ui->Vcod->setEnabled(true);
    ui->Vcdo->setEnabled(false);
}

void MainWindow::on_vcgl_2_clicked()
{
    ui->Vcod->setEnabled(false);
    ui->Vcdo->setEnabled(true);
}

void MainWindow::on_cCgl_clicked()
{
    ui->cCod->setEnabled(true);
    ui->cCdo->setEnabled(false);
}

void MainWindow::on_cCgl_2_clicked()
{
    ui->cCod->setEnabled(false);
    ui->cCdo->setEnabled(true);
}

void MainWindow::on_zhgl_clicked()
{
    ui->ZHod->setEnabled(true);
    ui->ZHdo->setEnabled(false);
}

void MainWindow::on_zhgl_2_clicked()
{
    ui->ZHod->setEnabled(false);
    ui->ZHdo->setEnabled(true);
}

void MainWindow::on_CCgl_clicked()
{
    ui->CCod->setEnabled(true);
    ui->CCdo->setEnabled(false);
}

void MainWindow::on_CCgl_2_clicked()
{
    ui->CCod->setEnabled(false);
    ui->CCdo->setEnabled(true);
}

void MainWindow::on_stl1gl_clicked()
{
    ui->stl1od->setEnabled(true);
    ui->stl1do->setEnabled(false);
}

void MainWindow::on_stl1gl_2_clicked()
{
    ui->stl1od->setEnabled(false);
    ui->stl1do->setEnabled(true);
}

void MainWindow::on_kombgl_clicked()
{
    ui->kombod->setEnabled(true);
    ui->kombdo->setEnabled(false);
}

void MainWindow::on_kombgl_2_clicked()
{
    ui->kombod->setEnabled(false);
    ui->kombdo->setEnabled(true);
}

void MainWindow::on_r2gl_clicked()
{
    ui->r2od->setEnabled(true);
    ui->r2do->setEnabled(false);
}

void MainWindow::on_r2gl_2_clicked()
{
    ui->r2od->setEnabled(false);
    ui->r2do->setEnabled(true);
}

void MainWindow::on_stl2gl_clicked()
{
    ui->stl2od->setEnabled(true);
    ui->stl2do->setEnabled(false);
}

void MainWindow::on_stl2gl_2_clicked()
{
    ui->stl2od->setEnabled(false);
    ui->stl2do->setEnabled(true);
}

void MainWindow::on_smgl_clicked()
{
    ui->Smod->setEnabled(true);
    ui->Smdo->setEnabled(false);
}

void MainWindow::on_smgl_2_clicked()
{
    ui->Smod->setEnabled(false);
    ui->Smdo->setEnabled(true);
}

void MainWindow::on_korgl_clicked()
{
    ui->Korod->setEnabled(true);
    ui->Kordo->setEnabled(false);
}

void MainWindow::on_korgl_2_clicked()
{
    ui->Korod->setEnabled(false);
    ui->Kordo->setEnabled(true);
}


void MainWindow::on_del_r1_clicked(){
    ui->r1od->clear();
    ui->r1R->clear();
    ui->r1do->clear();
}

void MainWindow::on_del_stl1_clicked(){
    ui->stl1do->clear();
    ui->stl1R->clear();
    ui->stl1od->clear();
}

void MainWindow::on_del_sum_komb_clicked(){
    ui->kombdo->clear();
    ui->kombR->clear();
    ui->kombod->clear();
}

void MainWindow::on_del_rod_clicked() {
    ui->r2do->clear();
    ui->r2R->clear();
    ui->r2od->clear();
}

void MainWindow::on_del_stlod_clicked() {
    ui->stl2do->clear();
    ui->stl2R->clear();
    ui->stl2od->clear();
}

void MainWindow::on_del_P_clicked()
{
    ui->Pod->clear();
    ui->Pdo->clear();
    ui->P->clear();
}

void MainWindow::on_del_Mc_clicked()
{
    ui->Mcod->clear();
    ui->Mcdo->clear();
    ui->Mc->clear();
}

void MainWindow::on_del_c1c9_clicked()
{
    ui->c1_c9od->clear();
    ui->c1_c9do->clear();
    ui->c1_c9->clear();
}

void MainWindow::on_del_N_clicked()
{
    ui->Nod->clear();
    ui->Ndo->clear();
    ui->N->clear();
}

void MainWindow::on_del_Cc_clicked()
{
    ui->Ccod->clear();
    ui->Ccdo->clear();
    ui->Cc->clear();
}

void MainWindow::on_del_C0_clicked()
{
    ui->C0od->clear();
    ui->C0do->clear();
    ui->C0->clear();
}

void MainWindow::on_del_PR_clicked()
{
    ui->PRod->clear();
    ui->PRdo->clear();
    ui->PR->clear();
}

void MainWindow::on_del_Vc_clicked()
{
    ui->Vcod->clear();
    ui->Vcdo->clear();
    ui->Vc->clear();
}

void MainWindow::on_del_cC_clicked()
{
    ui->cCod->clear();
    ui->cCdo->clear();
    ui->cC->clear();
}

void MainWindow::on_del_ZH_clicked()
{
    ui->ZHod->clear();
    ui->ZHdo->clear();
    ui->ZH->clear();
}

void MainWindow::on_del_CC_clicked()
{
    ui->CCod->clear();
    ui->CCdo->clear();
    ui->CC->clear();
}

void MainWindow::on_del_Sm_clicked()
{
    ui->Sm->clear();
    ui->Smdo->clear();
    ui->Smod->clear();
}

void MainWindow::on_del_Kor_clicked()
{
    ui->Kor->clear();
    ui->Korod->clear();
    ui->Kordo->clear();
}

void MainWindow::on_del_povinne_clicked()
{
    ui->Povinne->clear();
}

void MainWindow::on_del_zakazane_clicked()
{
    ui->Zakazane->clear();
}

void MainWindow::on_del_Ntice_clicked()
{
    ui->n_tice->clear();
}

void MainWindow::on_del_Xtice_clicked()
{
    ui->x_tice1->clear();
    ui->x_tice2->clear();
    ui->x_tice3->clear();
    ui->x_tice4->clear();
    ui->x_tice5->clear();
    ui->x_tice6->clear();
    ui->x_tice7->clear();
    ui->x_tice8->clear();
    ui->x_tice9->clear();
}



void MainWindow::on_Pod_editingFinished()
{
    if(ui->Nod->isEnabled()){
        ui->N->setText(QString::number(get_N() - ui->Pod->text().toInt()));
    }
    else{
        ui->Ndo->setText(QString::number(get_N() - ui->Pod->text().toInt()));
    }
}

void MainWindow::on_Pdo_editingFinished()
{
    if(ui->Nod->isEnabled()){
        ui->Nod->setText(QString::number(get_N() - ui->Pdo->text().toInt()));
    }
    else{
        ui->N->setText(QString::number(get_N() - ui->Pdo->text().toInt()));
    }
}

void MainWindow::on_P_editingFinished()
{
    if(ui->Pod->isEnabled()){
        if(ui->Nod->isEnabled()){
            ui->Nod->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
        else{
            ui->N->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
    }
    else{
        if(ui->Nod->isEnabled()){
            ui->N->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
        else{
            ui->Ndo->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
    }
}

void MainWindow::on_Nod_editingFinished()
{
    if(ui->Pod->isEnabled()){
        ui->P->setText(QString::number(get_N() - ui->Nod->text().toInt()));
    }
    else{
        ui->Pdo->setText(QString::number(get_N() - ui->Nod->text().toInt()));
    }

}

void MainWindow::on_N_editingFinished()
{
    if(ui->Nod->isEnabled()){
        if(ui->Pod->isEnabled()){
            ui->Pod->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
        else{
            ui->P->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
    }
    else{
        if(ui->Pod->isEnabled()){
            ui->P->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
        else{
            ui->Pdo->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
    }
}

void MainWindow::on_Ndo_editingFinished()
{
    if(ui->Pod->isEnabled()){
        ui->Pod->setText(QString::number(get_N() - ui->Ndo->text().toInt()));
    }
    else{
        ui->P->setText(QString::number(get_N() - ui->Ndo->text().toInt()));
    }
}

void MainWindow::on_Mcod_editingFinished()
{
    if(ui->Vcod->isEnabled()){
        ui->Vc->setText(QString::number(get_N() - ui->Mcod->text().toInt()));
    }
    else{
        ui->Vcdo->setText(QString::number(get_N() - ui->Mcod->text().toInt()));
    }
}

void MainWindow::on_Mcdo_editingFinished()
{
    if(ui->Vcod->isEnabled()){
        ui->Vcod->setText(QString::number(get_N() - ui->Mcdo->text().toInt()));
    }
    else{
        ui->Vc->setText(QString::number(get_N() - ui->Mcdo->text().toInt()));
    }
}

void MainWindow::on_Mc_editingFinished()
{
    if(ui->Mcod->isEnabled()){
        if(ui->Vcod->isEnabled()){
            ui->Vcod->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
        else{
            ui->Vc->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
    }
    else{
        if(ui->Vcod->isEnabled()){
            ui->Vc->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
        else{
            ui->Vcdo->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
    }
}

void MainWindow::on_Vcod_editingFinished()
{
    if(ui->Mcod->isEnabled()){
        ui->Mc->setText(QString::number(get_N() - ui->Vcod->text().toInt()));
    }
    else{
        ui->Mcdo->setText(QString::number(get_N() - ui->Vcod->text().toInt()));
    }
}

void MainWindow::on_Vcdo_editingFinished()
{
    if(ui->Mcod->isEnabled()){
        ui->Mcod->setText(QString::number(get_N() - ui->Vcdo->text().toInt()));
    }
    else{
        ui->Mc->setText(QString::number(get_N() - ui->Vcdo->text().toInt()));
    }
}

void MainWindow::on_Vc_editingFinished()
{
    if(ui->Vcod->isEnabled()){
        if(ui->Mcod->isEnabled()){
            ui->Mcod->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
        else{
            ui->Mc->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
    }
    else{
        if(ui->Mcod->isEnabled()){
            ui->Mc->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
        else{
            ui->Mcdo->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
    }
}

void MainWindow::on_mix_r_textChanged(const QString &arg1)
{
//    arg1.replace(" ", "");

    if(arg1.isEmpty()){
        ui->mix_r1->clear();
        return;
    }

    if(arg1.toInt() >= get_N()){
        ui->mix_r->setText(QString::number(get_N()-1));
        ui->mix_r1->setText(QString::number(1));
    }
    else
        ui->mix_r1->setText(QString::number(get_N()-arg1.toInt()));
}

//void MainWindow::on_dt_rs1minus_clicked()
//{
//    if(ui->dt_rs1plus->isChecked())
//        ui->dt_rs1plus->setChecked(false);

//    if(ui->dt_rs1minus->isChecked())
//        ui->dt_rs1minus->setChecked(true);
//    else
//        ui->dt_rs1minus->setChecked(false);
//}

//void MainWindow::on_dt_rs1plus_clicked()
//{
//    if(ui->dt_rs1minus->isChecked())
//        ui->dt_rs1minus->setChecked(false);
//    if(ui->dt_rs1plus->isChecked())
//        ui->dt_rs1plus->setChecked(true);
//    else
//        ui->dt_rs1plus->setChecked(false);
//}

//void MainWindow::on_dt_rs2minus_clicked()
//{
//    if(ui->dt_rs2plus->isChecked())
//        ui->dt_rs2plus->setChecked(false);

//    if(ui->dt_rs2minus->isChecked())
//        ui->dt_rs2minus->setChecked(true);
//    else
//        ui->dt_rs2minus->setChecked(false);
//}

//void MainWindow::on_dt_rs2plus_clicked()
//{
//    if(ui->dt_rs2minus->isChecked())
//        ui->dt_rs2minus->setChecked(false);
//    if(ui->dt_rs2plus->isChecked())
//        ui->dt_rs2plus->setChecked(true);
//    else
//        ui->dt_rs2plus->setChecked(false);
//}

//void MainWindow::on_reset_dt1_clicked()
//{
//    ui->dt_r1->clear();
//    ui->dt_stl1->clear();
//    ui->dt_rs1minus->setChecked(false);
//    ui->dt_rs1plus->setChecked(false);
//}

//void MainWindow::on_reset_dt2_clicked()
//{
//    ui->dt_r2->clear();
//    ui->dt_stl2->clear();
//    ui->dt_rs2minus->setChecked(false);
//    ui->dt_rs2plus->setChecked(false);
//}

void MainWindow::on_dtr1gl_clicked()
{
    ui->dtr1od->setEnabled(true);
    ui->dtr1do->setEnabled(false);
}

void MainWindow::on_dtslt1gl_clicked()
{
    ui->dtstl1od->setEnabled(true);
    ui->dtstl1do->setEnabled(false);
}

void MainWindow::on_dtRSTL1gl_clicked()
{
    ui->dtRSTL1od->setEnabled(true);
    ui->dtRSTL1do->setEnabled(false);
}

void MainWindow::on_dtr1gl2_clicked()
{
    ui->dtr1od->setEnabled(false);
    ui->dtr1do->setEnabled(true);
}

void MainWindow::on_dtstl1gl2_clicked()
{
    ui->dtstl1od->setEnabled(false);
    ui->dtstl1do->setEnabled(true);
}

void MainWindow::on_dtRSTL1gl2_clicked()
{
    ui->dtRSTL1od->setEnabled(false);
    ui->dtRSTL1do->setEnabled(true);
}

void MainWindow::on_dtr2gl_clicked()
{
    ui->dtr2od->setEnabled(true);
    ui->dtr2do->setEnabled(false);
}

void MainWindow::on_dtRSTL2gl_clicked()
{
    ui->dtRSTL2od->setEnabled(true);
    ui->dtRSTL2do->setEnabled(false);
}

void MainWindow::on_dtstl2gl_clicked()
{
    ui->dtstl2do->setEnabled(false);
    ui->dtstl2od->setEnabled(true);
}

void MainWindow::on_dtr2gl2_clicked()
{
    ui->dtr2od->setEnabled(false);
    ui->dtr2do->setEnabled(true);
}

void MainWindow::on_dtstl2gl2_clicked()
{
    ui->dtstl2do->setEnabled(true);
    ui->dtstl2od->setEnabled(false);
}

void MainWindow::on_dtRSTL2gl2_clicked()
{
    ui->dtRSTL2od->setEnabled(false);
    ui->dtRSTL2do->setEnabled(true);
}

void MainWindow::on_del_dtr1_clicked()
{
    ui->dtr1->clear();
    ui->dtr1od->clear();
    ui->dtr1do->clear();
}

void MainWindow::on_del_dtSTL1_clicked()
{
    ui->dtstl1->clear();
    ui->dtstl1do->clear();
    ui->dtstl1od->clear();
}

void MainWindow::on_del_dtRSTL1_clicked()
{
    ui->dtRSTL1->clear();
    ui->dtRSTL1do->clear();
    ui->dtRSTL1od->clear();
}

void MainWindow::on_del_dtr2_clicked()
{
    ui->dtr2->clear();
    ui->dtr2od->clear();
    ui->dtr2do->clear();
}

void MainWindow::on_del_dtstl2_clicked()
{
    ui->dtstl2->clear();
    ui->dtstl2od->clear();
    ui->dtstl2do->clear();
}

void MainWindow::on_del_dtRSTL2_clicked()
{
    ui->dtRSTL2->clear();
    ui->dtRSTL2od->clear();
    ui->dtRSTL2do->clear();
}

void MainWindow::on_del_Ntice_2_clicked()
{
    ui->n1->setChecked(false);
    ui->n2->setChecked(false);
    ui->n3->setChecked(false);
    ui->n4->setChecked(false);
    ui->n5->setChecked(false);
    ui->n6->setChecked(false);
    ui->n7->setChecked(false);
    ui->n8->setChecked(false);
    ui->n9->setChecked(false);
    ui->n10->setChecked(false);

    ui->n11->setChecked(false);
    ui->n12->setChecked(false);
    ui->n13->setChecked(false);
    ui->n14->setChecked(false);
    ui->n15->setChecked(false);
    ui->n16->setChecked(false);
    ui->n17->setChecked(false);
    ui->n18->setChecked(false);
    ui->n19->setChecked(false);
    ui->n20->setChecked(false);

    ui->n21->setChecked(false);
    ui->n22->setChecked(false);
    ui->n23->setChecked(false);
    ui->n24->setChecked(false);
    ui->n25->setChecked(false);
    ui->n26->setChecked(false);
    ui->n27->setChecked(false);
    ui->n28->setChecked(false);
    ui->n29->setChecked(false);
    ui->n30->setChecked(false);
}

#ifndef GENERATOR_H
#define GENERATOR_H

#include <QObject>

#include "glimits.h"
#include "archiv.h"

// Thread
class Generator : public QObject
{
    Q_OBJECT
public:

    Generator(Archiv *archiv, int r, Glimits g);
    Generator(unsigned n, unsigned m, Glimits g);
    ~Generator();

signals:
    void finished();
    void ended();
    void send_result(qvect);
    void send_result2(qvect, Numbers, Numbers);
    void generator_state(bool);
    void info(QString);

public slots:

    void stop();
    void process();
    void process_mix();
//    void print();

private:

    volatile bool stopped;
    num level, n, m;
    qvect2d combs;
    qvect result, pos;
    Glimits limit;

    Archiv *archiv;
    int r, r1;

//    QMutex mutex;

    void next();
    void init(Glimits g);
};

#endif // GENERATOR_H

#include "utils.h"

QString double_to_qstr(double d, int prec){
    return QString::number(d, 'g', prec).replace(".",",").prepend("\"").append("\"");
}

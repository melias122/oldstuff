#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    qRegisterMetaType<qvect>("qvect");
    qRegisterMetaType<qvect2d>("qvect2d");

    MainWindow w;
    w.show();
    
    return a.exec();
}

//#include <QDebug>
//int main(){

//    int n=30,m=52,sum=650, sSum;
//    QList<int> set, idx, ttest;

//    ttest.push_back(0);
//    ttest.push_back(11);
//    ttest.push_back(12);
//    ttest.push_back(13);
//    ttest.push_back(34);

//    for(int i=1; i<=m; i++)
//        set.push_back(i);

//    for(int j=0; j<n-1; j++)
//        idx.push_back(j);
//    idx.push_back(set.size()-1);

//    forever{

//        if(ttest == idx){
//            qDebug()<<"has";
//        }

//        sSum=0;
//        foreach (const int &i, idx)
//            sSum += set[i];

//        if(sSum == sum){
//            qDebug() << idx;
//        }

//        if(sSum > sum){
//            idx[idx.size()-1]--;
//        }
//        else /*if(sSum < sum)*/ {
//            int j;
//            for(j=idx.size()-2; j >= 0; j--){
//                if(idx[j+1] - idx[j] > 1){
//                    idx[j]++;
//                    break;
//                }
//            }
//            for(j += 1;j<idx.size()-1;j++){
//                idx[j] = idx[j-1]+1;
//                idx[idx.size()-1]=set.size()-1;
//            }
//        }

//    }

//    qDebug() << "END";

//    return 0;
//}

#include "archiv.h"

#include "utils.h"

Archiv::Archiv(){}

Archiv::Archiv(unsigned n, unsigned m, QString &filename){
    this->n = n;
    this->m = m;
    this->r = new Reader(filename);
}

Numbers Archiv::get_1DO() const{
    return n_1DO;
}

Numbers Archiv::get_ODDO() const{
    return n_ODDO;
}

qvect Archiv::get_last_comb() const{
    return last_comb;
}

qvect Archiv::get_last_numberings() const{
    qvect v;
    for(int i = 1; i < 12; i++){
        v.push_back((quint8)archiv.last()[i].toInt());
    }
    return v;
}

//#include "QDebug"

void Archiv::process(){

    emit info("Vyvaram archiv");

    parse();

    Numberings numberings;
    int at=1;

    foreach (const qvect &vi, qvnums) {

//        qDebug() << "spracovavam riadok " << at << " z " << lines.size();

        n1DO(at);
        nODDO(at);

        QStringList line;

        line << comb_to_str(vi.begin(),vi.end());
        line << numberings.result(vi,last_comb);
        line << double_to_str(n_1DO.sum_R(vi.begin(),vi.end()));        //R 1-r
        line << double_to_str(n_1DO.sum_STL(vi.begin(),vi.end()));      //STL 1-r
        line << double_to_str(n_ODDO.sum_R(vi.begin(),vi.end()));       //R OD
        line << double_to_str(n_ODDO.sum_STL(vi.begin(),vi.end()));     //STL OD
        line << double_to_str(sum_comb(vi.begin(),vi.end()));           //SUM komb

        int stl=1;
        foreach (const num &qvn, vi) {
            line << QString::number(qvn);
            line << double_to_str(n_1DO.get_R(qvn));
            line << double_to_str(n_1DO.get_STL(qvn,stl));
            line << double_to_str(n_ODDO.get_R(qvn));
            line << double_to_str(n_ODDO.get_STL(qvn,stl));
            stl++;
        }

        archiv.push_back(line);
        last_comb = vi;
        at++;
    }

    emit info("Archiv vytvoreny");
    // r+1
    // r a stl kombinacie
    // save
    emit finished();
}

void Archiv::parse(){

    QStringList list;
    this->r->next_line(list);

    while(this->r->next_line(list)){
        QStringList l = list;

        if(l.first().size() > 0)
            lines.push_back(l);
    }

    QLinkedList< QStringList >::Iterator it = lines.begin();

    while(it != lines.end()){

        QStringList list = *it;
        QVector<num> v;
        for(unsigned i=3; i<n+3;i++){
            num cislo = (num)list[i].toInt();
            v.push_back(cislo);
        }
        qvnums.push_back(v);
        it++;
    }
}

void Archiv::n1DO(int to){

    Nmap pocetnost;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    while(qi.hasNext() && to > 0){
       int stl = 1;
       foreach (const num &qvn, qi.next()) {
           pocetnost[qvn].set_R(pocetnost[qvn].get_R() + 1);
           pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
           stl++;
       }
       to--;
    }
    n_1DO = make_numbers(pocetnost);
    return;
}

void Archiv::nODDO(int from){

    Nmap pocetnost;
    QSet<num> vyskyt;
    QLinkedListIterator< QVector<num> > qi(qvnums);

    for(unsigned i=1; i <= m; i++){
        pocetnost.insert((num)i, N(n));
    }

    while(qi.hasNext() && from >= 0){
        foreach (const num &qvn, qi.next()) {
            vyskyt.insert(qvn);
        }
        from--;
    }
    if((unsigned)vyskyt.size() < m){
        Numbers n1(n,m);
        n_ODDO = n1;
        return;
    }

    vyskyt.clear();
    while(qi.hasPrevious() && (unsigned)vyskyt.size() < m){
        int stl = 1;
        foreach (const num &qvn, qi.previous()) {
            vyskyt.insert(qvn);
            pocetnost[qvn].set_R(pocetnost[qvn].get_R() + 1);
            pocetnost[qvn].set_STL(stl, pocetnost[qvn].get_STL(stl) + 1);
            stl++;
        }
    }
    n_ODDO = make_numbers(pocetnost);
    return;
}

cpp_int Archiv::get_stlcc(int c, int stl){

    if((c-stl < 0) || (c-stl > m-n)) return 0;


    cpp_int c1 = (cpp_int)binomial_coefficient<double>(m-c, n-stl);
    cpp_int c2 = (cpp_int)binomial_coefficient<double>(c-1, stl-1);


    if(stl==1)      return c1;
    else if(stl==n) return c2;
    else            return (c1*c2);
}

Numbers Archiv::make_numbers(Nmap &pocetnost){

    Numbers n1(n,m);
    cpp_rational y;

    foreach (const num &key, pocetnost.keys()) {
        N np = pocetnost.value(key);
        y = (cpp_rational)np.get_R()/get_stlcc(1,1);
        n1.set_R(key, y.convert_to<double>());
        for(unsigned i=1;i<=n;i++){
            cpp_rational stl = (cpp_rational)np.get_STL(i)/get_stlcc((unsigned)key,i);
            if(stl > 0){
                n1.set_STL(key,i,stl.convert_to<double>());
            }
        }
    }
    return n1;
}

unsigned Archiv::get_n() const{
    return this->n;
}
unsigned Archiv::get_m() const{
    return this->m;
}
QLinkedList<qvect> Archiv::get_qvnums() const{
    return this->qvnums;
}

void Archiv::set_n(unsigned n){
    this->n = n;
}
void Archiv::set_m(unsigned m){
    this->m = m;
}
void Archiv::set_1DO(Numbers n){
    this->n_1DO = n;
}
void Archiv::set_ODDO(Numbers n){
    this->n_ODDO = n;
}
void Archiv::set_qvnums(QLinkedList< qvect > qvn){
    this->qvnums = qvn;
}
void Archiv::set_lastcomb(qvect qv){
    this->last_comb = qv;
}

QDataStream &operator<<(QDataStream &out, const Archiv &ar){

    out << ar.get_n() << ar.get_m();
    out << ar.lines << ar.archiv;
    out << ar.get_1DO() << ar.get_ODDO();
    out << ar.get_qvnums();
    out << ar.get_last_comb();

    return out;
}

QDataStream &operator>>(QDataStream &in, Archiv &ar){

    unsigned n,m;
    Numbers n1,n2;
    QLinkedList<qvect> qvnums;
    qvect last_comb;

    in >> n >> m;
    in >> ar.lines >> ar.archiv;
    in >> n1 >> n2;
    in >> qvnums;
    in >> last_comb;

    ar.set_n(n);
    ar.set_m(m);
    ar.set_1DO(n1);
    ar.set_ODDO(n2);
    ar.set_qvnums(qvnums);
    ar.set_lastcomb(last_comb);

    return in;
}

void save_archiv(const Archiv &a){

    QFile file("archiv.dat");
    file.open(QIODevice::WriteOnly);

    QDataStream out(&file);
    out << a;

    file.close();
}

void load_archiv(Archiv &a){

    QFile file("archiv.dat");
    file.open(QIODevice::ReadOnly);

    QDataStream in(&file);
    in >> a;

    file.close();
}

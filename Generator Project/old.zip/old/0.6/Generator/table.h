#ifndef TABLE_H
#define TABLE_H

//#include "fileop.h"
#include "archiv.h"
#include "numbers.h"
#include "types.h"

#include <QWidget>

namespace Ui {
class Table;
}

class Table : public QWidget
{
    Q_OBJECT
    
public:
    explicit Table(QWidget *parent = 0);
    ~Table();
    
    void size(int size);
    void insert_row();
    void insert_item(int row, int col, int i);
    void insert_item(int row, int col, double d);
    void insert_item(int row, int col, QString s);
    void header(int c);

    template<class T>
    QString comb_to_str(T begin, T end);

    template<class T>
    int sum_comb(T begin, T end);

    template<class T>
    void insert_sums(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2);

    template<class T>
    void insert_csums2(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2);

    template<class T>
    void insert_numberings(T begin, T end, int row, int &col);

    void create_result(qvect2d &result, Archiv *archiv);

    void create_archiv(Archiv *archiv);

private slots:
    void on_Export_clicked();

private:
    Ui::Table *ui;
};

#endif // TABLE_H

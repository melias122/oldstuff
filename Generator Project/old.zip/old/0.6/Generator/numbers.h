#ifndef NUMBERS_H
#define NUMBERS_H

#include "types.h"

#include <QSet>
#include <QStringList>

class N {
public:

    N(){}

    N(unsigned n);
    ~N();

    void set_R(double R);
    void set_STL(unsigned stl, double STL);

    double get_R() const;
    double get_STL(unsigned stl);

    stl_map get_stlmap() const;
    void set_stlmap(stl_map STL);

private:

    double R;
    stl_map STL;
};

QDataStream &operator<<(QDataStream &out, const N &n);
QDataStream &operator>>(QDataStream &in, N &n);

class Numbers {
public:

    Numbers();
    Numbers(unsigned n, unsigned m);
    ~Numbers();

    void set_N(unsigned n);
    void set_M(unsigned m);

    template<class T>
    double sum_R(T begin, T end){
        double sum = 0;
        for(T it = begin; it != end; ++it){
            sum += get_R((num)*it);
        }
        return sum;
    }

    template<class T>
    double sum_STL(T begin, T end){
        double sum = 0;
        int stl = 1;
        for(T it = begin; it != end; ++it, ++stl){
            sum += get_STL((num)*it,stl);
        }
        return sum;
    }

    template<class T>
    unsigned sum_komb(T begin, T end){
        unsigned sum=0;
        for(T it = begin; it != end; ++it){
            sum += (unsigned)(*it);
        }
        return sum;
    }

    unsigned sum_komb_min();
    unsigned sum_komb_max();

    double sum_min(QVector<double> &qvd);
    double sum_max(QVector<double> &qvd);

    double sum_R_min();
    double sum_R_max();

    double sum_STL_min();
    double sum_STL_max();


    void set_R(num c, double R);
    void set_STL(num c, unsigned stl, double STL);

    double get_R(num c);
    double get_STL(num c, unsigned stl);

    unsigned get_N() const;
    unsigned get_M() const;

    Nmap get_numbers() const;
    Nmap get_pocetnost() const;

    void set_numbers(Nmap numbers);
    void set_pocetnost(Nmap pocetnost);

private:
    unsigned n, m;
    Nmap numbers;
    Nmap pocetnost;

    void init(unsigned n=30, unsigned m=90);
};

QDataStream &operator<<(QDataStream &out, const Numbers &n);
QDataStream &operator>>(QDataStream &in, Numbers &n);


class Numberings{
public:
    Numberings(){
        pr <<2<<3<<5<<7<<11<<13<<17<<19<<23<<29<<31<<37<<41<<43<<47<<53<<59<<61<<67<<71<<73<<79<<83<<89;
    }

    bool P(num c){
        return ((c%2) == 0);
    }
    bool N(num c){
        return !P(c);
    }
    bool PR(num c){
        return pr.contains(c);
    }
    bool Mc(num c){
        if(C0(c))
            return false;
        QString s = QString::number(c);
        return (s[s.size()-1] < QChar('6'));
    }
    bool Vc(num c){
        return !Mc(c);
    }
    bool C19(num c){
        return (c < 10);
    }
    bool C0(num c){
        QString s = QString::number(c);
        if(s.size() < 2)
            return false;
        return (s[s.length() -1] == QChar('0'));
    }
    bool cC(num c){
        QString s = QString::number(c);
        if(s.size() < 2)
            return false;
        return (s[0] < s[1]);
    }
    bool Cc(num c){
        QString s = QString::number(c);
        if(s.size() < 2)
            return false;
        return (s[0] > s[1]);
    }
    bool CC(num c){
       QString s = QString::number(c);
       if(s.size() < 2)
           return false;
       return (s[0] == s[1]);
    }

    QStringList result(const qvect &first,const qvect &prev){
        QStringList result;

        QVector<int> vi(11,0);

        foreach (const num &qvn, first) {
            if(P(qvn))      // Par
                vi[0]++;
            if(N(qvn))      // Nepar
                vi[1]++;
            if(PR(qvn))     //  Prvocislo
                vi[2]++;
            if(Mc(qvn))     // Male cifry
                vi[3]++;
            if(Vc(qvn))     // Velke cifry
                vi[4]++;
            if(C19(qvn))
                vi[5]++;
            if(C0(qvn))
                vi[6]++;
            if(cC(qvn))
                vi[7]++;
            if(Cc(qvn))
                vi[8]++;
            if(CC(qvn))
                vi[9]++;
            if(!prev.isEmpty() && prev.contains(qvn)) // Zhoda
                vi[10]++;
        }

        foreach (const int &i, vi) {
            result << QString::number(i);
        }

        return result;
    }

    qvect result2(const qvect &first,const qvect &prev){
        qvect vi(11,0);
        foreach (const num &qvn, first) {
            if(P(qvn))      // Par
                vi[0]++;
            if(N(qvn))      // Nepar
                vi[1]++;
            if(PR(qvn))     //  Prvocislo
                vi[2]++;
            if(Mc(qvn))     // Male cifry
                vi[3]++;
            if(Vc(qvn))     // Velke cifry
                vi[4]++;
            if(C19(qvn))
                vi[5]++;
            if(C0(qvn))
                vi[6]++;
            if(cC(qvn))
                vi[7]++;
            if(Cc(qvn))
                vi[8]++;
            if(CC(qvn))
                vi[9]++;
            if(!prev.isEmpty() && prev.contains(qvn)) // Zhoda
                vi[10]++;
        }
        return vi;
    }

private:
    QSet<num> pr;
};


#endif // NUMBERS_H

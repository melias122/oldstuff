#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "numbers.h"
#include "table.h"
#include "archiv.h"
#include "result.h"
#include "export.h"
#include "glimits.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int get_M();
    int get_N();
    bool min2();
    void set_limits(Glimits &g);

signals:
    void stop_generator();

public slots:
    void info(QString s);
    void running(bool state);
    void create_export();
    
private slots:
    void on_read_file_clicked();

    void on_show_db2_clicked();

    void on_generateButton_clicked();

    void on_del_r1_clicked();

    void on_del_stl1_clicked();

    void on_del_sum_komb_clicked();

    void on_del_rod_clicked();

    void on_del_stlod_clicked();

    void on_del_all_clicked();

    void on_show_limits_clicked();

    void show_btns();

    void on_r1gl_clicked(bool checked);

    void on_kombgl_clicked(bool checked);

    void on_r2gl_clicked(bool checked);

    void on_stl2gl_clicked(bool checked);

    void on_stl1gl_clicked(bool checked);

    void on_pgl_clicked(bool checked);

    void on_ngl_clicked(bool checked);

    void on_prgl_clicked(bool checked);

    void on_mcgl_clicked(bool checked);

    void on_vcgl_clicked(bool checked);

    void on_zhgl_clicked(bool checked);

    void on_c1c9gl_clicked(bool checked);

    void on_c0gl_clicked(bool checked);

    void on_cCgl_clicked(bool checked);

    void on_Ccgl_clicked(bool checked);

    void on_CCgl_clicked(bool checked);

    void on_nticegl_clicked(bool checked);

private:
    Ui::MainWindow *ui;

    Archiv *archiv;
    QString path_file;
    bool generator_running;
    Result *result;
    Table *Archivtab;
};

#endif // MAINWINDOW_H

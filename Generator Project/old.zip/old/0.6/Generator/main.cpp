#include "mainwindow.h"
#include <QApplication>

//int main(int argc, char *argv[])
//{
//    QApplication a(argc, argv);
//    MainWindow w;
//    w.show();

//    qRegisterMetaType<qvect>("qvect");
//    qRegisterMetaType<qvect2d>("qvect2d");
    
//    return a.exec();
//}

#include <iostream>
#include <QThread>

#include <glimits.h>

//#include<boost/multiprecision/cpp_dec_float.hpp>

using namespace std;

// Thread
class G
{
public:
    
    G(unsigned n, unsigned m, qvect2d combs, Glimits g){

        this->n = (num)n;
        this->m = (num)m;
        this->combs = combs;
        this->g = g;
        level = 0;
        result = qvect(n,0);
        stopped = false;
        for(num i=0; i<n; i++){
            pos.push_back(0);
        }
    }
    
    ~G(){
        combs.clear();
        pos.clear();
        result.clear();
    }

    void stop(){
        stopped = true;
    }

    void next(){
        if(level == 0){
            for(int i=0; i<n; i++){
                combs[i].pop_front();
                pos[i] = 0;
            }
            return;
        }

        if(pos[level] < combs[level].size()-1){
            pos[level]++;
            if(level < n){
                for(int i=level; i<n; i++){
                    pos[i] = pos[level];
                }
            }
        }
        else{
            level--;
            next();
        }
    }
    
    void process(){
        if(combs[0][0] != 1){
            int i = 1;
            while(i < combs[0][0]){
                i++;
            }
        }

        while (!combs.first().empty() && !stopped) {
            qvect v;

            for(int i=0; i<=level; i++){
                v.push_back(combs[level][pos[level]]);
            }

            // podmienka vlozenia
            if(g.check(v)){
                result[level] = combs[level][pos[level]];
            }
            // posuniem sa na leveli
            else{
                next();
                continue;
            }
            // up
            if(level < n-1){
                level++;
                continue;
            }
            print();
//            emit result(result);
            next();
        }
//        emit finished();
    }

    void print(){
        foreach (num i, result) {
            std::cout << (int)i << " ";
        }
        std::cout << std::endl;
    }
    
private:
    volatile bool stopped;
    num level, n, m;
    qvect2d combs;
    qvect result, pos;
    Glimits g;
};

class GeneratorManager
{
public:
    GeneratorManager(unsigned n, unsigned m) {
        this->n = n;
        this->m = m;
    }
    ~GeneratorManager() {}

//    void find_max_threads(){

//        int thrds = QThread::idealThreadCount();
//        if(thrds < 2){
//            threads_count = 1;
//            return;
//        }
//        cpp_int combs_max = (cpp_int)binomial_coefficient<double>(m, n);
//        cpp_int cft_max = (cpp_int)binomial_coefficient<double>(m-1, n-1);

//        while(thrds > 1){
////            cout << combs_max << " " << combs_max/thrds << " " << cft_max << ";;;";
//            if(combs_max/thrds < cft_max)
//                thrds--;
//            else
//                break;
//        }
//        threads_count = thrds;
//    }

    void make_combs_v(){

//        unsigned last = 1;
//        cpp_int cft_max = (cpp_int)binomial_coefficient<double>(m, n)/threads_count;

//        for (int c = 0; c < threads_count; ++c) {
//            qvect qv;

//            while(last <= (m-n+1)){
//                qv.push_back(last);
//                last++;
//                if(last <= m-n+1){
//                    if((cpp_int)binomial_coefficient<double>(m-last-1, n-1) > cft_max){}
//                }
//            }
//            qvect2d qv2;
//            qv2.push_back(qv);
//            for(unsigned i=1; i < n; i++){
//                qvect ost;
//                for(num j=qv.first()+i; j <= (num)(m-n+1+i); j++){
//                    ost.push_back(j);
//                }
//                qv2.push_back(ost);
//            }
//            combs.push_back(qv2);
//        }

        qvect2d qv2;
        for(unsigned i=1; i <= n; i++){
            qvect qv;
            for(num j=i; j <= (num)(m-n+i); j++){
                qv.push_back(j);
            }
            qv2.push_back(qv);
        }
        combs.push_back(qv2);
    }

    void process(){

        threads_count = QThread::idealThreadCount();
//        find_max_threads();
        make_combs_v();

//        for(int t=0; t<QThread::idealThreadCount(); t++){
            // make  G_threads
            Glimits gl;
            G g(n,m,combs.value(0), gl);
            g.process();
//        }
    }

private:
    int threads_count;
    unsigned n, m;
    QVector<qvect2d> combs;
};

class Gcheck
{
public:
    Gcheck(){}
    ~Gcheck(){}

private:

};

int main() {


    int m =20, n=5;

    GeneratorManager gm(n,m);
    gm.process();
//    cpp_int cft = (cpp_int)binomial_coefficient<double>(m-1, n-1);

//    cout << cft;

//    G g(5,80);
//    g.process();

//    cpp_int cpi;
//    Archiv a;
//    a.set_n(7);
//    a.set_m(45);

//    for(int i=1;i<=45;i++){
//        for(int j=1;j<=7;j++){
//            cpi = a.get_stlcc(i,j);
//            cout << cpi << " ";
//        }
//        cout << endl;
//    }

    return 0;
}


#include "numbers.h"

//N

N::N(unsigned n){
    R = 0;
    for(unsigned i=1; i <=n; i++){
        STL.insert(i, 0);
    }
}

N::~N(){}

void N::set_R(double R){
    this->R = R;
}

void N::set_STL(unsigned stl, double STL){
    if(stl > 0)
        this->STL[stl] = STL;
}

double N::get_R() const{
    return R;
}

double N::get_STL(unsigned stl){
    return (stl>0) ? STL[stl] : 0;
}

stl_map N::get_stlmap() const{
    return this->STL;
}
void N::set_stlmap(stl_map STL){
    this->STL = STL;
}

QDataStream &operator<<(QDataStream &out,const N &n){
    out << n.get_R() << n.get_stlmap();
    return out;
}
QDataStream &operator>>(QDataStream &in, N &n){

    double R;
    stl_map STL;

    in >> R >> STL;

    n.set_R(R);
    n.set_stlmap(STL);

    return in;
}

// N end

// Numbers

Numbers::Numbers(){
    init();
}

Numbers::Numbers(unsigned n, unsigned m){
    this->n = n;
    this->m = m;
    this->init(n,m);
}

Numbers::~Numbers(){
    numbers.clear();
}

void Numbers::set_N(unsigned n){ this->n = n;}

void Numbers::set_M(unsigned m){ this->m = m;}

unsigned Numbers::sum_komb_min(){
    unsigned sum=0;
    for(unsigned i=n; i<n+n; i++){
        sum += i;
    }
    return sum;
}
unsigned Numbers::sum_komb_max(){
    unsigned sum=0;
    for(unsigned i=m; i>m-n; i--){
        sum += i;
    }
    return sum;
}

double Numbers::sum_min(QVector<double> &qvd){
    double sum=0;
    qSort(qvd);

    for(unsigned i=0;i<get_N();i++){
        sum += qvd[i];
    }
    return sum;
}

double Numbers::sum_max(QVector<double> &qvd){
    double sum=0;
    qSort(qvd);

    for(unsigned i=qvd.size()-1; i>qvd.size()-get_N()-1;i--){
        sum += qvd[i];
    }
    return sum;
}

double Numbers::sum_R_min(){
    QVector<double> qvd;
    for(unsigned i=1;i<=get_M();i++){
        qvd.push_back(get_R(i));
    }
    return sum_min(qvd);
}

double Numbers::sum_R_max(){
    QVector<double> qvd;
    for(unsigned i=1;i<=get_M();i++){
        qvd.push_back(get_R(i));
    }
    return sum_max(qvd);
}

double Numbers::sum_STL_min(){
    QVector<double> qvd;
    for(unsigned i=1;i<=get_M();i++){
        for(unsigned j=1;j<=get_N();j++){
                qvd.push_back(get_STL(i,j));
        }
    }
    return sum_min(qvd);
}
double Numbers::sum_STL_max(){
    QVector<double> qvd;
    for(unsigned i=1;i<=get_M();i++){
        for(unsigned j=1;j<=get_N();j++){
                qvd.push_back(get_STL(i,j));
        }
    }
    return sum_max(qvd);
}

void Numbers::set_R(num c, double R){
    numbers[c].set_R(R);
}

void Numbers::set_STL(num c, unsigned stl, double STL){
    numbers[c].set_STL(stl, STL);
}

double Numbers::get_R(num c){
    return numbers[c].get_R();
}

double Numbers::get_STL(num c, unsigned stl){
    return numbers[c].get_STL(stl);
}

unsigned Numbers::get_N() const{
    return n;
}

unsigned Numbers::get_M() const{
    return m;
}

void Numbers::init(unsigned n, unsigned m){
    numbers.clear();
    for(unsigned i=1; i <= m; i++){
        numbers.insert((num)i, N(n));
    }
}

Nmap Numbers::get_numbers() const{
    return this->numbers;
}
Nmap Numbers::get_pocetnost() const{
    return this->pocetnost;
}

void Numbers::set_numbers(Nmap numbers){
    this->numbers = numbers;
}
void Numbers::set_pocetnost(Nmap pocetnost){
    this->pocetnost = pocetnost;
}

QDataStream &operator<<(QDataStream &out, const Numbers &n){

    out << n.get_N() << n.get_M();
    out << n.get_numbers() << n.get_pocetnost();

    return out;
}
QDataStream &operator>>(QDataStream &in, Numbers &n){
    unsigned n1, m;
    Nmap numbers, pocetnost;

    in >> n1 >> m;
    in >> numbers >> pocetnost;

    n.set_N(n1);
    n.set_M(m);
    n.set_numbers(numbers);
    n.set_pocetnost(pocetnost);

    return in;
}

//Numbers end

#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "generator.h"

#include <limits>
#include<QFileDialog>
#include<QThread>
#include<QDir>

QString fname(QString path){
    return path.split(QDir::separator()).last();
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    generator_running = false;
    Archivtab = NULL;
    result = NULL;
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::get_M(){
    return ui->spinBoxM->text().toInt();
}

int MainWindow::get_N(){
    return ui->spinBoxN->text().toInt();
}

void MainWindow::info(QString s){
    ui->Info->setText(s);
}

void MainWindow::running(bool state){
    generator_running = state;
    if(generator_running){
        info("Hladam kombinacie");
        ui->generateButton->setText("Stop");
    }
    else{
        info("Hladanie dokoncene");
        ui->generateButton->setText("Generuj");
    }
}

void MainWindow::on_read_file_clicked()
{
    path_file = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_file.isEmpty()){

        Archivtab = NULL;

        Archiv *a = new Archiv(get_N(), get_M(), path_file);
        this->archiv = a;
        QThread* archiv_thread = new QThread;

        a->moveToThread(archiv_thread);

        connect(archiv_thread, SIGNAL(started()), a, SLOT(process()));
        connect(a, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(a, SIGNAL(finished()), archiv_thread, SLOT(quit()));
        connect(a, SIGNAL(finished()), this, SLOT(show_btns()));
//        connect(a, SIGNAL(finished()), a, SLOT(deleteLater()));
        connect(archiv_thread, SIGNAL(finished()), archiv_thread, SLOT(deleteLater()));

        archiv_thread->start();

        info(QString("Subor ").append(fname(path_file)).append(" uspesne nacitany"));
        return;
    }
    info(QString("Nepodarilo sa nacitat subor ").append(fname(path_file)));
}

void MainWindow::on_show_db2_clicked()
{
    if(path_file.isEmpty()){
        info(QString("Subor").append(" nebol nacitany"));
        return;
    }
    if(Archivtab == NULL){
        Archivtab = new Table();
        Archivtab->create_archiv(archiv);
    }
    if(!Archivtab->isVisible())
        Archivtab->show();
}

void MainWindow::set_limits(Glimits &g){
    if(ui->r1od->text() != "")
        g.set_r1od(ui->r1od->text().toDouble());
    if(ui->r1do->text() != "")
        g.set_r1do(ui->r1do->text().toDouble());
    if(ui->r2od->text() != "")
        g.set_r2od(ui->r2od->text().toDouble());
    if(ui->r2do->text() != "")
        g.set_r2do(ui->r2do->text().toDouble());
    if(ui->stl1od->text() != "")
        g.set_stl1od(ui->stl1od->text().toDouble());
    if(ui->stl1do->text() != "")
        g.set_stl1do(ui->stl1do->text().toDouble());
    if(ui->stl2od->text() != "")
        g.set_stl2od(ui->stl2od->text().toDouble());
    if(ui->stl2do->text() != "")
        g.set_stl2do(ui->stl2do->text().toDouble());

    if(ui->P->text() != "")
        g.set_P(ui->P->text().toUInt(), ui->pgl->isChecked());
    if(ui->N->text() != "")
        g.set_N(ui->N->text().toUInt(), ui->ngl->isChecked());
    if(ui->PR->text() != "")
        g.set_PR(ui->PR->text().toUInt(), ui->prgl->isChecked());
    if(ui->Mc->text() != "")
        g.set_Mc(ui->Mc->text().toUInt(), ui->mcgl->isChecked());
    if(ui->Vc->text() != "")
        g.set_Vc(ui->Vc->text().toUInt(), ui->vcgl->isChecked());
    if(ui->ZH->text() != "")
        g.set_ZH(ui->ZH->text().toUInt(), ui->zhgl->isChecked());
    if(ui->c1_c9->text() != "")
        g.set_c19(ui->c1_c9->text().toUInt(), ui->c1c9gl->isChecked());
    if(ui->C0->text() != "")
        g.set_c0(ui->C0->text().toUInt(), ui->c0gl->isChecked());
    if(ui->cC->text() != "")
        g.set_cC(ui->cC->text().toUInt(), ui->cCgl->isChecked());
    if(ui->Cc->text() != "")
        g.set_Cc(ui->Cc->text().toUInt(), ui->Ccgl->isChecked());
    if(ui->CC->text() != "")
        g.set_CC(ui->CC->text().toUInt(), ui->CCgl->isChecked());
//    if(ui->P->text() != "")
//        g.set_P(ui->P->text().toUInt(), ui->pgl->isChecked());
}

void MainWindow::on_generateButton_clicked()
{
    if(path_file.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(!min2()){
        info("Musia byt zadane aspon 2 kriteria pre vyhladavanie");
        return;
    }

    if(!generator_running){

        running(true);

        if(result != NULL)
            delete result;
        result = new Result(archiv);

        Glimits g(archiv);
        set_limits(g);

        QThread* generator_thread = new QThread;
        Generator* worker = new Generator(result ,archiv->get_1DO(), archiv->get_ODDO(), g);

        worker->moveToThread(generator_thread);

        connect(generator_thread, SIGNAL(started()), worker, SLOT(process()));
        connect(this, SIGNAL(stop_generator()), worker, SLOT(stop()));
        connect(worker, SIGNAL(generator_state(bool)), this, SLOT(running(bool)));
        connect(worker, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(worker, SIGNAL(finished()), this, SLOT(create_export()));
        connect(worker, SIGNAL(finished()), generator_thread, SLOT(quit()));
        connect(worker, SIGNAL(finished()), worker, SLOT(deleteLater()));
        connect(generator_thread, SIGNAL(finished()), generator_thread, SLOT(deleteLater()));

        generator_thread->start();
    }
    else{
        emit stop_generator();
    }
}

void MainWindow::create_export()
{
    if(result->empty()){
        return;
    }
    QThread * e_thread = new QThread;
    Export * exp = new Export(archiv, result);

    exp->moveToThread(e_thread);

    connect(e_thread, SIGNAL(started()), exp, SLOT(process()));

//    connect(exp, SIGNAL(finished(QString)), e_thread, SLOT(quit()));
//    connect(exp, SIGNAL(finished(QString)), e_thread, SLOT(deleteLater()));
//    connect(e_thread, SIGNAL(finished()), e_thread, SLOT(deleteLater()));

    e_thread->start();
}

void MainWindow::on_del_r1_clicked(){
    ui->r1od->clear();
    ui->r1do->clear();
}

void MainWindow::on_del_stl1_clicked(){
    ui->stl1do->clear();
    ui->stl1od->clear();
}

void MainWindow::on_del_sum_komb_clicked(){
    ui->kombdo->clear();
    ui->kombod->clear();
}

void MainWindow::on_del_rod_clicked() {
    ui->r2do->clear();
    ui->r2od->clear();
}

void MainWindow::on_del_stlod_clicked() {
    ui->stl2do->clear();
    ui->stl2od->clear();
}

void MainWindow::on_del_all_clicked(){
    on_del_r1_clicked();
    on_del_rod_clicked();
    on_del_stl1_clicked();
    on_del_stlod_clicked();
    on_del_sum_komb_clicked();
    ui->P->clear();
    ui->N->clear();
    ui->PR->clear();
    ui->Mc->clear();
    ui->Vc->clear();
    ui->ZH->clear();
    ui->c1_c9->clear();
    ui->C0->clear();
    ui->cC->clear();
    ui->Cc->clear();
    ui->CC->clear();
    ui->n_tice->clear();
}

void MainWindow::show_btns(){
    ui->show_limits->setEnabled(true);
    ui->r1gl->setEnabled(true);
    ui->stl1gl->setEnabled(true);
    ui->kombgl->setEnabled(true);
    ui->r2gl->setEnabled(true);
    ui->stl2gl->setEnabled(true);
}

void MainWindow::on_show_limits_clicked()
{
    qvect v = archiv->get_last_numberings();
    on_r1gl_clicked(ui->r1gl->isChecked());
    on_stl1gl_clicked(ui->stl1gl->isChecked());
    on_kombgl_clicked(ui->kombgl->isChecked());
    on_r2gl_clicked(ui->r2gl->isChecked());
    on_stl2gl_clicked(ui->stl2gl->isChecked());
    ui->P->setText(QString::number(v[0]));
    ui->N->setText(QString::number(v[1]));
    ui->PR->setText(QString::number(v[2]));
    ui->Mc->setText(QString::number(v[3]));
    ui->Vc->setText(QString::number(v[4]));
    ui->ZH->setText(QString::number(v[5]));
    ui->c1_c9->setText(QString::number(v[6]));
    ui->C0->setText(QString::number(v[7]));
    ui->cC->setText(QString::number(v[8]));
    ui->Cc->setText(QString::number(v[9]));
    ui->CC->setText(QString::number(v[10]));
//    ui->n_tice->setText(QString::number(v[11]));
}

bool MainWindow::min2(){
    int c=0;
    if (ui->r1do->text().size() > 0)
        c++;
    if (ui->r1od->text().size() > 0)
        c++;
    if (ui->stl1do->text().size() > 0)
        c++;
    if (ui->stl1od->text().size() > 0)
        c++;
    if (ui->kombdo->text().size() > 0)
        c++;
    if (ui->kombod->text().size() > 0)
        c++;
    if (ui->r2do->text().size() > 0)
        c++;
    if (ui->r2od->text().size() > 0)
        c++;
    if (ui->stl2do->text().size() > 0)
        c++;
    if (ui->stl2od->text().size() > 0)
        c++;


    return (c > 1);
}

void MainWindow::on_r1gl_clicked(bool checked)
{
    if(checked){
        ui->r1gl->setText("≥");
        ui->r1od->setText(QString::number(archiv->get_1DO().sum_R_min()));
        ui->r1do->setText(QString::number(archiv->get_1DO().sum_R(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
    else{
        ui->r1gl->setText("≤");
        ui->r1do->setText(QString::number(archiv->get_1DO().sum_R_max()));
        ui->r1od->setText(QString::number(archiv->get_1DO().sum_R(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
}

void MainWindow::on_stl1gl_clicked(bool checked)
{
    if(checked){
        ui->stl1gl->setText("≥");
        ui->stl1od->setText(QString::number(archiv->get_1DO().sum_STL_min()));
        ui->stl1do->setText(QString::number(archiv->get_1DO().sum_STL(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
    else{
        ui->stl1gl->setText("≤");
        ui->stl1do->setText(QString::number(archiv->get_1DO().sum_STL_max()));
        ui->stl1od->setText(QString::number(archiv->get_1DO().sum_STL(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
}

void MainWindow::on_kombgl_clicked(bool checked)
{
    if(checked){
        ui->kombgl->setText("≥");
        ui->kombod->setText(QString::number(archiv->get_1DO().sum_komb_min()));
        ui->kombdo->setText(QString::number(archiv->get_1DO().sum_komb(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
    else{
        ui->kombgl->setText("≤");
        ui->kombdo->setText(QString::number(archiv->get_1DO().sum_komb_max()));
        ui->kombod->setText(QString::number(archiv->get_1DO().sum_komb(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
}

void MainWindow::on_r2gl_clicked(bool checked)
{
    if(checked){
        ui->r2gl->setText("≥");
        ui->r2od->setText(QString::number(archiv->get_ODDO().sum_R_min()));
        ui->r2do->setText(QString::number(archiv->get_ODDO().sum_R(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
    else{
        ui->r2gl->setText("≤");
        ui->r2do->setText(QString::number(archiv->get_ODDO().sum_R_max()));
        ui->r2od->setText(QString::number(archiv->get_ODDO().sum_R(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
}

void MainWindow::on_stl2gl_clicked(bool checked)
{
    if(checked){
        ui->stl2gl->setText("≥");
        ui->stl2od->setText(QString::number(archiv->get_ODDO().sum_STL_min()));
        ui->stl2do->setText(QString::number(archiv->get_ODDO().sum_STL(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
    else{
        ui->stl2gl->setText("≤");
        ui->stl2do->setText(QString::number(archiv->get_ODDO().sum_STL_max()));
        ui->stl2od->setText(QString::number(archiv->get_ODDO().sum_STL(archiv->get_last_comb().begin(), archiv->get_last_comb().end())));
    }
}

void MainWindow::on_pgl_clicked(bool checked)
{
    if(checked){
        ui->pgl->setText("≥");
    }
    else{
        ui->pgl->setText("≤");
    }
}

void MainWindow::on_ngl_clicked(bool checked)
{
    if(checked){
        ui->ngl->setText("≥");
    }
    else{
        ui->ngl->setText("≤");
    }
}

void MainWindow::on_prgl_clicked(bool checked)
{
    if(checked){
        ui->prgl->setText("≥");
    }
    else{
        ui->prgl->setText("≤");
    }
}

void MainWindow::on_mcgl_clicked(bool checked)
{
    if(checked){
        ui->mcgl->setText("≥");
    }
    else{
        ui->mcgl->setText("≤");
    }
}

void MainWindow::on_vcgl_clicked(bool checked)
{
    if(checked){
        ui->vcgl->setText("≥");
    }
    else{
        ui->vcgl->setText("≤");
    }
}

void MainWindow::on_zhgl_clicked(bool checked)
{
    if(checked){
        ui->zhgl->setText("≥");
    }
    else{
        ui->zhgl->setText("≤");
    }
}

void MainWindow::on_c1c9gl_clicked(bool checked)
{
    if(checked){
        ui->c1c9gl->setText("≥");
    }
    else{
        ui->c1c9gl->setText("≤");
    }
}

void MainWindow::on_c0gl_clicked(bool checked)
{
    if(checked){
        ui->c0gl->setText("≥");
    }
    else{
        ui->c0gl->setText("≤");
    }
}

void MainWindow::on_cCgl_clicked(bool checked)
{
    if(checked){
        ui->cCgl->setText("≥");
    }
    else{
        ui->cCgl->setText("≤");
    }
}

void MainWindow::on_Ccgl_clicked(bool checked)
{
    if(checked){
        ui->Ccgl->setText("≥");
    }
    else{
        ui->Ccgl->setText("≤");
    }
}

void MainWindow::on_CCgl_clicked(bool checked)
{
    if(checked){
        ui->CCgl->setText("≥");
    }
    else{
        ui->CCgl->setText("≤");
    }
}

void MainWindow::on_nticegl_clicked(bool checked)
{
    if(checked){
        ui->nticegl->setText("≥");
    }
    else{
        ui->nticegl->setText("≤");
    }
}

#ifndef TYPES_H
#define TYPES_H

#include<QtGlobal>
#include<QVector>
#include<QMap>

class N;

typedef quint8 num;
typedef QMap<num, N> Nmap;
typedef QMap<unsigned, double> stl_map;

typedef QVector<num> qvect;
typedef QVector< qvect > qvect2d;
typedef QVector< QVector<double> > qvect2double;

#endif // TYPES_H

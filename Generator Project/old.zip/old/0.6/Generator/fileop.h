#ifndef FILEOP_H
#define FILEOP_H

#include "numbers.h"

#include <QString>
#include <QFile>
#include <QTextStream>
#include <QStringList>

class Reader;
class Reader
{
public:
    Reader(QString filename);
    ~Reader();

    bool opened();
    bool next_line(QStringList &list);
    void open();
    void close();
    void reset();

private:
    bool is_open;
    unsigned line_readed;

    QString filename;
    QFile *file;
    QTextStream *in;
};

void write_protocol(QString filename, QString text);

#endif // FILEOP_H

#ifndef GLIMITS_H
#define GLIMITS_H

#include "archiv.h"
#include "numbers.h"

class Glimits
{
public:
    Glimits();
    Glimits(Archiv *archiv);

    void set_r1od(double r1);
    void set_r1do(double r1);
    void set_r2od(double r2);
    void set_r2do(double r2);
    void set_stl1od(double s);
    void set_stl1do(double s);
    void set_stl2od(double s);
    void set_stl2do(double s);

    void set_kombod(unsigned u);
    void set_kombdo(unsigned u);

    void set_N(unsigned u,bool b);
    void set_P(unsigned u, bool b);
    void set_PR(unsigned u, bool b);
    void set_Mc(unsigned u, bool b);
    void set_Vc(unsigned u, bool b);
    void set_ZH(unsigned u, bool b);
    void set_c19(unsigned u, bool b);
    void set_c0(unsigned u, bool b);
    void set_cC(unsigned u, bool b);
    void set_Cc(unsigned u, bool b);
    void set_CC(unsigned u, bool b);
    void set_ntice(unsigned u, bool b);

    bool check(qvect &v);

private:
    qvect last;
    Numberings n;
    Numbers num1_R, numOD_R;
    double r1od,r1do,r2od,r2do,stl1od,stl1do,stl2od,stl2do;
    unsigned Nod, Ndo, Pod, Pdo, PRod, PRdo, Mcod, Mcdo, Vcod, Vcdo, ZHod, ZHdo, c19od, c19do, c0od, c0do, cCod, cCdo, Ccod, Ccdo, CCod, CCdo, nticeod, nticedo, kombod,kombdo;
};

#endif // GLIMITS_H

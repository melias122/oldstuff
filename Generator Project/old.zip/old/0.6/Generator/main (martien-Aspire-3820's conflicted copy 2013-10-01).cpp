#include "mainwindow.h"
#include <QApplication>

//int main(int argc, char *argv[])
//{
//    QApplication a(argc, argv);
//    MainWindow w;
//    w.show();

//    qRegisterMetaType<qvect>("qvect");
//    qRegisterMetaType<qvect2d>("qvect2d");
    
//    return a.exec();
//}



#include"lib/FindCombByIdx.h"
#include <iostream>

using namespace std;
using namespace stdcomb;

class G
{
public:
    
    G(int n, int m){
        for(num i=1; i<=n; i++){
            qvect v;
            for(num j=i;j<=m-n+i;j++){
                v.push_back(j);
            }
            combs.push_back(v);
            pos.push_back(0);
            end.push_back(m-n+i);
        }
        this->n = (num)n;
        this->m = (num)m;
        level = 0;
    }
    
    ~G(){
        combs.clear();
        pos.clear();
    }
    
    void up(){
        if(level < n)
            level++;
    }

    void down(){
        if(level > 0)
            level--;
    }

    void next(){

    }

    bool has_next(){
        
        if(pos == end)
            return false;
        else
            return true;
    }

    void print(){
        foreach (num i, result) {
            std::cout << (int)i << " ";
        }
        std::cout << std::endl;
    }
    
    void process(){
        // cykl
        // vlozenie prvku
        // kontrola
        // if ok
        //  up() o dalsi level vyssie
        //  continue
        // else
        //  next na leveli
        while(pos != end){

            if(true){ //check num
//                result.push_back();
            }
        }
    }
    
private:
    num level, n, m;
    qvect2d combs;
    qvect result, pos, end;
};

#include<boost/multiprecision/cpp_int.hpp>
using namespace boost::multiprecision;
#include<QDebug>

int main(int argc, char *argv[])
{
    const int n=30, m=90;

    QVector<int> qv;

    qv.push_back(1);
    qv.push_back(2);
    qv.push_back(3);

    while(!qv.isEmpty()){
        QVectorIterator<int> qvi(qv);
        while(qvi.hasNext()){
            int i = qvi.next();
            cout << i;
        }
        qv.pop_front();
    }


//    cpp_int i = cpp_int("699999000000000000000000");
////    BigInteger bi;

////    bi = "123";

//    CFindCombByIdx< CFindTotalComb<cpp_int>, cpp_int> findcomb;

//    vector<unsigned int> nums(n);

//    findcomb.FindCombByIdx(m, n, i, nums );

//    for(unsigned u=0; u < nums.size(); u++){
//        cout << nums[u] + 1 << " ";
////        cb.push_back(nums[u] + 1);
//    }

    return 0;
}



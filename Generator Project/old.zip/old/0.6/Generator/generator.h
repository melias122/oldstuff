#ifndef GENERATOR_H
#define GENERATOR_H

#include <QObject>
#include <QMutex>
#include <QVector>

#include "lib/FindCombByIdx.h"
#include "lib/FindTotalComb.h"
#include "numbers.h"
#include "result.h"
#include "glimits.h"

class GeneratorThread : public QObject
{
    Q_OBJECT
public:
    GeneratorThread(BigInteger from, BigInteger limit, Numbers &n1, Numbers &n2, Glimits g);

signals:
    void comb(qvect c);
    void finished();

public slots:
    void generate();
    void stop();

private:

    volatile bool state;
    Glimits g;
    BigInteger limit;
    qvect ca, cb;
//    QVector<unsigned> ca, cb;
    stdcomb::CFindCombByIdx< CFindTotalComb<BigInteger>, BigInteger > findcomb;
    Numbers num1_R, numOD_R;
    qvect2double limits;
    QMutex mutex;
};

class Generator : public QObject
{
    Q_OBJECT
public:
    Generator(Result *result, const Numbers n1, const Numbers n2, Glimits &g);

signals:
    void info(QString);
    void finished();
    void generator_state(bool state);

public slots:
//    void time_left();
    void process();
    void stop();
    void finish();
    void results(qvect v);

private:

    Result *result;
    Glimits g;
    quint64 total_ticks, ticks;
    int threads_count, Set, Comb, progress_bar_value, threads_finished;
    QVector<BigInteger> from, limit;
    BigInteger total_comb_count;
    CFindTotalComb<BigInteger> tc;
    Numbers num1_R, numOD_R;
//    qvect2double limits;
    QVector<GeneratorThread*> workers;
};

#endif // GENERATOR_H

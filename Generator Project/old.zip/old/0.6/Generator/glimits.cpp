#include "glimits.h"

#include <QVector>

Glimits::Glimits(){
    r1od = r2od = stl1od = stl2od = 0;
    r1do = r2do = stl1do = stl2do = 999999999;
    Nod = Pod = PRod = Mcod = Vcod = ZHod = c19od = c0od = cCod = Ccod = CCod =kombod = 0;
    Ndo = Pdo = PRdo = Mcdo = Vcdo = ZHdo = c19do = c0do = cCdo = Ccdo = CCdo = kombdo = 99999999;
}

Glimits::Glimits(Archiv *archiv)
{
    this->num1_R = archiv->get_1DO();
    this->numOD_R = archiv->get_ODDO();
    this->last = archiv->get_last_comb();

    r1od = r2od = stl1od = stl2od = 0;
    r1do = r2do = stl1do = stl2do = 999999999;
    Nod = Pod = PRod = Mcod = Vcod = ZHod = c19od = c0od = cCod = Ccod = CCod =kombod = 0;
    Ndo = Pdo = PRdo = Mcdo = Vcdo = ZHdo = c19do = c0do = cCdo = Ccdo = CCdo = kombdo = 99999999;
}

void Glimits::set_r1od(double r1){
    r1od = r1;
}
void Glimits::set_r1do(double r1){
    r1do = r1;
}
void Glimits::set_r2od(double r2){
    r2od = r2;
}
void Glimits::set_r2do(double r2){
    r2do = r2;
}
void Glimits::set_stl1od(double s){
    stl1od = s;
}
void Glimits::set_stl1do(double s){
    stl1do = s;
}
void Glimits::set_stl2od(double s){
    stl2od = s;
}
void Glimits::set_stl2do(double s){
    stl2do = s;
}

void Glimits::set_kombod(unsigned u){
    kombod = u;
}
void Glimits::set_kombdo(unsigned u){
    kombdo = u;
}

void Glimits::set_N(unsigned u,bool b){
    if(b)
        Nod = u;
    else
        Ndo = u;
}
void Glimits::set_P(unsigned u, bool b){
    if(b)
        Pod = u;
    else
        Pdo = u;
}
void Glimits::set_PR(unsigned u, bool b){
    if(b)
        PRod = u;
    else
        PRdo = u;
}
void Glimits::set_Mc(unsigned u, bool b){
    if(b)
        Mcod = u;
    else
        Mcdo = u;
}
void Glimits::set_Vc(unsigned u, bool b){
    if(b)
        Vcod = u;
    else
        Vcdo = u;
}
void Glimits::set_ZH(unsigned u, bool b){
    if(b)
        ZHod = u;
    else
        ZHdo = u;
}
void Glimits::set_c19(unsigned u, bool b){
    if(b)
        c19od = u;
    else
        c19do = u;
}
void Glimits::set_c0(unsigned u, bool b){
    if(b)
        c0od = u;
    else
        c0do = u;
}
void Glimits::set_cC(unsigned u, bool b){
    if(b)
        cCod = u;
    else
        cCdo = u;
}
void Glimits::set_Cc(unsigned u, bool b){
    if(b)
        Ccod = u;
    else
        Ccdo = u;
}
void Glimits::set_CC(unsigned u, bool b){
    if(b)
        CCod = u;
    else
        CCdo = u;
}

bool Glimits::check(qvect &v){

    qvect qv;

    qv = n.result2(v,last);

//    double  sumr1   = num1_R.sum_R(v.begin(), v.end()),
//            sumr2   = numOD_R.sum_R(v.begin(),v.end()),
//            sumstl1 = num1_R.sum_STL(v.begin(),v.end()),
//            sumstl2 = numOD_R.sum_STL(v.begin(), v.end()),
//            sumcomb = num1_R.sum_komb(v.begin(), v.end());

//    if(!(sumr1 >= r1od && sumr1 <= r1do))
//        return false;
//    if(!(sumr2 >= r2od  && sumr2 <= r2do))
//        return false;
//    if(!(sumstl1 >= stl1od  && sumstl1 <= stl1do ))
//        return false;
//    if(!(sumstl2 >= stl2od && sumstl2 <= stl2do))
//        return false;
//    if(!(sumcomb >= kombod  && sumcomb <= kombdo))
//        return false;

    if(!(qv[0] >= Pod && qv[0] <= Pdo))
        return false;
    if(!(qv[1] >= Nod && qv[1] <= Ndo))
        return false;
    if(!(qv[2] >= PRod && qv[2] <= PRdo))
        return false;
    if(!(qv[3] >= Mcod && qv[3] <= Mcdo))
        return false;
    if(!(qv[4] >= Vcod && qv[4] <= Vcdo))
        return false;
    if(!(qv[5] >= c19od && qv[5] <= c19do))
        return false;
    if(!(qv[6] >= c0od && qv[6] <= c0do))
        return false;
    if(!(qv[7] >= cCod && qv[7] <= cCdo))
        return false;
    if(!(qv[8] >= Ccod && qv[8] <= Ccdo))
        return false;
    if(!(qv[9] >= CCod && qv[9] <= CCdo))
        return false;
    if(!(qv[10] >= ZHod && qv[10] <= ZHdo))
        return false;

    return true;
}

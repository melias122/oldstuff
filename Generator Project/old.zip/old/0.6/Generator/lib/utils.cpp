#include "utils.h"

#include "FindCombByIdx.h"
#include "FindTotalComb.h"
#include "IndexCombination.h"
#include "BigIntegerLibrary.hh"

using namespace std;
using namespace stdcomb;

void find_comb(unsigned nComb, unsigned nSet, long unsigned int c, vector<unsigned> &vec){

//    CFindCombByIdx< CFindTotalComb<BigInteger>, BigInteger > findcomb;

//    // Intialize the vector with size nComb
//    vector<unsigned> combs(nComb);

//    // vector returned by FindCombByIdx
//    findcomb.FindCombByIdx( nSet, nComb, c, combs );

//    vec.clear();
//    for(vector<unsigned>::iterator it = combs.begin(); it != combs.end(); ++it){
//        vec.push_back(*it + 1);
//    }
}

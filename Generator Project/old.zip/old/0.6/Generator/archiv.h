#ifndef ARCHIV_H
#define ARCHIV_H

#include <QObject>
#include <QLinkedList>

#include <boost/multiprecision/cpp_int.hpp>
#include <boost/math/special_functions/binomial.hpp>

#include "fileop.h"
#include "numbers.h"


using namespace boost::multiprecision;
using namespace boost::math;

class Archiv : public QObject
{
    Q_OBJECT
//    Q_PROPERTY(unsigned n READ get_n WRITE set_n)
public:

    //
    QLinkedList< QStringList > lines, archiv;

    Archiv();
    Archiv(unsigned n, unsigned m, QString &filename);

    Numbers get_1DO() const;
    Numbers get_ODDO() const;
    qvect get_last_comb() const;
    qvect get_last_numberings() const;
    unsigned get_n() const;
    unsigned get_m() const;
    QLinkedList< qvect > get_qvnums() const;

    cpp_int get_stlcc(int c, int stl);

    void set_n(unsigned n);
    void set_m(unsigned m);
    void set_1DO(Numbers n);
    void set_ODDO(Numbers n);
    void set_qvnums(QLinkedList< qvect > qvn);
    void set_lastcomb(qvect qv);

signals:
    void finished();
    void info(QString);
    
public slots:
    void process();
    
private:
    //
    unsigned n, m;
    Numbers n_1DO, n_ODDO;
    Reader *r;

    QLinkedList< qvect > qvnums;
    qvect last_comb;
    //

    void parse();
    void n1DO(int to);
    void nODDO(int from);
    Numbers make_numbers(Nmap &pocetnost);

};

QDataStream &operator<<(QDataStream &out, const Archiv &ar);
QDataStream &operator>>(QDataStream &in, Archiv &ar);

void save_archiv(const Archiv &a);
void load_archiv(Archiv &a);

#endif // ARCHIV_H

#include "generator.h"

#include "lib/combination.h"

#include <QThread>
//#include <QDebug>
#include <vector>

template<class T>
void print(T begin, T end){
    for(T i=begin; i!=end; i++){
        std::cout << *i << " ";
    }
    std::cout << std::endl;
}

// GeneratorThread
GeneratorThread::GeneratorThread(BigInteger from, BigInteger limit, Numbers &n1, Numbers &n2, Glimits g)
{
    this->limit = limit;
    this->num1_R = n1;
    this->numOD_R = n2;
    this->g =  g;

    state = true;

    for(quint8 i=1;i<=(quint8)num1_R.get_M();i++)
        ca.push_back(i);

    std::vector<unsigned> vc(num1_R.get_N());
    findcomb.FindCombByIdx(num1_R.get_M(), num1_R.get_N(), from, vc);

    for(unsigned i=0;i<vc.size();i++)
        cb.push_back((quint8)(vc[i]+1));
}

void GeneratorThread::generate(){

    using namespace stdcomb;

    BigInteger i = 0;
    do{
        if(g.check(cb)){
            emit comb(cb);
        }
        i++;
    } while(next_combination(ca.begin(), ca.end(), cb.begin(), cb.end()) && (i < limit) && state);

    emit finished();
}

void GeneratorThread::stop(){
    mutex.lock();
    state=false;
    mutex.unlock();
}


// Generator
Generator::Generator(Result *result, const Numbers n1, const Numbers n2, Glimits &g)
{
    this->result = result;
    this->Set = n1.get_M();
    this->Comb = n1.get_N();
    this->num1_R = n1;
    this->numOD_R = n2;
//    this->limits = limits;
    this->g = g;

    threads_finished = 0;
    ticks = 0;
    progress_bar_value = 1;

    threads_count = QThread::idealThreadCount();
    total_comb_count = tc.FindTotalComb(Set, Comb).GetResult();
    total_ticks = total_comb_count.toUnsignedLong();



    BigInteger row, lim;

    row = 0;
    lim = total_comb_count/threads_count;

    for(int i=0;i<threads_count;i++){
        from.push_back(row);
        if(i == threads_count - 1){
            lim += (total_comb_count % threads_count);
            limit.push_back(lim);
        }
        else{
            limit.push_back(lim);
        }
        row += lim;
    }
}

void Generator::process() {

    for(int i = 0; i < threads_count; i++){

        QThread* thread = new QThread;
        GeneratorThread* worker = new GeneratorThread(from[i], limit[i], num1_R, numOD_R, g);
        workers.push_back(worker);

        worker->moveToThread(thread);

        connect(thread, SIGNAL(started()), worker, SLOT(generate()));
//        connect(worker, SIGNAL(tick()), this, SLOT(time_left()), Qt::QueuedConnection);
        connect(worker, SIGNAL(comb(qvect)), this, SLOT(results(qvect)), Qt::QueuedConnection);
        connect(worker, SIGNAL(finished()), this, SLOT(finish()));
        connect(worker, SIGNAL(finished()), thread, SLOT(quit()));
        connect(worker, SIGNAL(finished()), worker, SLOT(deleteLater()));
        connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));

        thread->start();
    }
}

void Generator::stop(){
    for(int i = 0; i < threads_count; i++){
        workers[i]->stop();
    }
}

void Generator::finish(){
    threads_finished++;

    if(threads_finished == threads_count){
        emit generator_state(false);
        emit info(QString("Najdenych ").append(QString::number(result->size())).append(" kombinacii"));
        emit finished();
    }
}

void Generator::results(qvect v){
    result->insert(v);
}

//void Generator::time_left(){

//}


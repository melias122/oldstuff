#ifndef RESULT_H
#define RESULT_H

#include "types.h"
#include "archiv.h"
#include "QStringList"

class Result
{
public:
    Result(Archiv *archiv);
    ~Result();

    QStringList header();
    bool next_comb_str(QStringList &strList);
    int size();
    bool empty();
    void set_begin(){
        result_iterator = result.begin();
    }

    template<class T>
    QString combs_to_str( T begin, T end){
        QString s;
        for(T i=begin; i!=end; i++){
            s.append(QString::number(*i));
            s.append(" ");
        }
        return s;
    }

    template<class T>
    int sum_comb(T begin, T end){
        int sum = 0;
        for(T it = begin; it != end; ++it){
            int i = (int)*it;
            sum += i;
        }
        return sum;
    }

//public slots:
    void insert(qvect v);

private:
    Numbers num1_R, numOD_R;
    Numberings numberings;
    qvect2d::Iterator result_iterator;
    qvect2d result;
    qvect last_comb;

    void strl_insert(QStringList &list, double d);
};

#endif // RESULT_H

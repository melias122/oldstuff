#include "export.h"

#include <QDateTime>
#include <QDir>
#include <QFile>

#include <QDebug>

Export::Export(Archiv *archiv, Result *result)
{
    this->archiv = archiv;
    this->result = result;
}

void Export::process(){

//    if(result->empty()){
//        emit finished("");
//        return;
//    }

    QFile *f = NULL;
    QTextStream *data = NULL;
    QDateTime dt = QDateTime::currentDateTime();
    QString dir_name, dir_date;

    dir_name.append(QString::number(archiv->get_1DO().get_N())).append(QString::number(archiv->get_1DO().get_M()));
    dir_date.append(dt.toString("yyyy-MM-dd-hh-mm-ss"));

    QDir dir(dir_name.append("/").append(dir_date));

    if(!dir.exists()){
        dir.mkpath(".");
    }

    unsigned exp_num=0, exp_size=0;
    result->set_begin();
    QStringList strList;

    while (result->next_comb_str(strList)) {

        if(exp_size == 0){
            exp_num++;

            f = new QFile(dir.path().append("/").append(QString::number(exp_num).append(".csv")));
            f->open(QFile::WriteOnly);
            data = new QTextStream(f);

            *data << result->header().join(";") << "\n";
        }
        *data << strList.join(";") << "\n";
        exp_size++;

        if(exp_size > 500000){
            f->close();
            exp_size = 0;
        }

        strList.clear();
    }
    if(f->isOpen())
        f->close();

    if(f != NULL)
        delete f;
    if(data !=NULL)
        delete data;

    emit finished("Exportovanie uspesne dokoncene");
}

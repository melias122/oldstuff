#include "result.h"

#include "archiv.h"

Result::Result(Archiv *archiv)
{
    result_iterator = result.begin();
    last_comb = archiv->get_last_comb();
    num1_R = archiv->get_1DO();
    numOD_R = archiv->get_ODDO();
}

Result::~Result()
{
    result.clear();
}

QStringList Result::header()
{
    QStringList header;
    header  << "Kombinacie"
            <<"P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH"
            << "ƩR1-DO"<< "ƩSTL1-DO"
            << "ƩR OD-DO"<< "ƩSTL OD-DO"
            << "ƩKombinacie";
    return header;
}

bool Result::next_comb_str(QStringList &strList)
{
    if(result_iterator == result.end())
        return false;

    strList.clear();

    strList << combs_to_str((*result_iterator).begin(),(*result_iterator).end());
    strList << numberings.result(*result_iterator, last_comb);
    strl_insert(strList,num1_R.sum_R((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList, num1_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));

    strl_insert(strList, numOD_R.sum_R((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList, numOD_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));

    strList << QString::number(sum_comb((*result_iterator).begin(),(*result_iterator).end()));

    int stl = 1;
    for(qvect::Iterator iq=(*result_iterator).begin();iq!=(*result_iterator).end();iq++){

        strList << QString::number(*iq);

        strl_insert(strList, num1_R.get_R((unsigned)*iq));
        strl_insert(strList, num1_R.get_STL((unsigned)*iq,stl));

        strl_insert(strList, numOD_R.get_R((unsigned)*iq));
        strl_insert(strList, numOD_R.get_STL((unsigned)*iq,stl));

        stl++;
    }


    result_iterator++;
    return true;
}
int Result::size()
{
    return result.size();
}

bool Result::empty()
{
    return result.empty();
}
void Result::insert(qvect v)
{
    this->result.push_back(v);
}

void Result::strl_insert(QStringList &list, double d)
{
    list << QString::number(d, 'g', 10).replace(QString("."), QString(","));
}

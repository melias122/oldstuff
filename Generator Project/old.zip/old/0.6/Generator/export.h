#ifndef EXPORT_H
#define EXPORT_H

#include "archiv.h"
#include "result.h"

class Export : public QObject
{
    Q_OBJECT
public:

    Export(Archiv *archiv, Result *result);

signals:
    void finished(QString);

public slots:
    void process();

private:
    Archiv *archiv;
    Result *result;
};

#endif // EXPORT_H

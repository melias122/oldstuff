#include "table.h"
#include "ui_table.h"

#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QStringList>

Table::Table(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Table)
{
    ui->setupUi(this);
}

Table::~Table()
{
    ui->tableWidget->clearContents();
    delete ui;
}

void Table::size(int size){
    ui->tableWidget->setColumnCount(size);
}

void Table::insert_row(){
    ui->tableWidget->insertRow(ui->tableWidget->rowCount());
}

void Table::insert_item(int row, int col, int i){
    insert_item(row, col, QString::number(i));
}

void Table::insert_item(int row, int col, double d){
    insert_item(row, col, QString::number(d, 'g', 8));
}

void Table::insert_item(int row, int col, QString s){
    ui->tableWidget->setItem(row ,col, new QTableWidgetItem(s));
}

template<class T>
int Table::sum_comb(T begin, T end){
    int sum = 0;
    for(T it = begin; it != end; ++it){
        int i = (int)*it;
        sum += i;
    }
    return sum;
}

template<class T>
QString Table::comb_to_str(T begin, T end){
    QString s;
    for(T i=begin; i!=end; i++){
        s.append(QString::number(*i));
        s.append(" ");
    }
    return s;
}

template<class T>
void Table::insert_sums(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2){

    insert_item(row, col++, n1.sum_R(begin, end));
    insert_item(row, col++, n1.sum_STL(begin, end));
    insert_item(row, col++, n2.sum_R(begin, end));
    insert_item(row, col++, n2.sum_STL(begin, end));
    insert_item(row, col++, sum_comb(begin, end));
}

template<class T>
void Table::insert_csums2(T begin, T end, int row, int &col, Numbers &n1, Numbers &n2){

    int stl=1;
    for(T it = begin; it != end; it++ ){
        int c = (int)(*it);
        insert_item(row, col++, c);
        insert_item(row, col++, n1.get_R(c));
        insert_item(row, col++, n1.get_STL(c, stl));
        insert_item(row, col++, n2.get_R(c));
        insert_item(row, col++, n2.get_STL(c, stl));
        stl++;
    }

}

template<class T>
void Table::insert_numberings(T begin, T end, int row, int &col){
    for(T it = begin; it != end; it++ ){
        insert_item(row, col++, *it);
    }
}

void Table::header(int c){

    QStringList t_header;

    t_header << "Kombinacie" <<"P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH"<< "ƩR1-DO"<< "ƩSTL1-DO" << "ƩR OD-DO"<< "ƩSTL OD-DO" << "ƩKombinacie";

    for(int i=0; i < c; i++){
        t_header << "Cislo" << "R1-DO"<< "STL1-DO"<< "R OD-DO"<< "STL OD-DO";
    }

    ui->tableWidget->setHorizontalHeaderLabels(t_header);
    ui->tableWidget->horizontalHeader()->setVisible(true);

}

void Table::create_archiv(Archiv *archiv){

    int col=0, row=0;

    size(archiv->archiv.first().size());

    foreach (const QStringList &list, archiv->archiv) {
        insert_row();
        col=0;
        foreach (const QString &string, list) {
            insert_item(row,col++,string);
        }
        row++;
    }
    header(archiv->get_1DO().get_N());
}

void Table::create_result(qvect2d &result, Archiv *archiv){

    Numbers n1 = archiv->get_1DO(), n2 = archiv->get_ODDO();
    Numberings numberings;
    qvect first, prev = archiv->get_last_comb();
    int col = 0, row = 0;
    qvect::iterator begin, end;

    this->size((5*n1.get_N()) + 17);

    for(qvect2d::iterator it=result.begin(); it != result.end() && row < 25000; it++, row++){

        col = 0;
        first = *it;
        begin = (*it).begin();
        end = (*it).end();

        this->insert_row();
        insert_item(row, col++, comb_to_str(begin, end));
        QStringList strl = numberings.result(first, prev);
        insert_numberings(strl.begin(), strl.end(),row,col);
        insert_sums(begin, end, row, col, n1, n2);
        insert_csums2(begin, end, row, col, n1, n2);

//        prev = first;
    }
    header(n1.get_N());
}

void Table::on_Export_clicked()
{
    QString filename;
    if((filename = QFileDialog::getSaveFileName(this, tr("Ulozit subor"), "", tr("Export (*.csv)"))) == "")
        return;
    filename.append(".csv");
    QFile f( filename );

    if (f.open(QFile::WriteOnly)) {

        QTextStream data( &f );
        QStringList strList;
        strList.clear();

        for( int c = 0; c < ui->tableWidget->columnCount(); ++c ) {
            strList << ui->tableWidget->horizontalHeaderItem(c)->data(Qt::DisplayRole).toString();
        }

        data << strList.join( ";" )+"\n";
        for( int r = 0; r < ui->tableWidget->rowCount(); ++r ) {

            strList.clear();
            for( int c = 0; c < ui->tableWidget->columnCount(); ++c ) {
                strList << ui->tableWidget->item( r, c )->text().replace(QString("."), QString(","));
            }

            data << strList.join( ";" )+"\n";
        }
        f.close();
    }
}

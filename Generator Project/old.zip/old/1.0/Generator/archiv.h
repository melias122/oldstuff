#ifndef ARCHIV_H
#define ARCHIV_H

#include <QObject>
#include <QString>

#include "types.h"
#include "phcisla.h"
#include "hrx.h"

class Archiv {
private:
    enum class val  {Sm=0,dt_Sm, Kk, dt_Kk,
                     R1,dt_R1,Rplus1,STL1,dt_STL1, STLplus1,dt_R1STL1,
                     HHRX,dt_HHRX,
                     R2,dt_R2,STL2,dt_STL2, dt_R2STL2,
                     HRX, dt_HRX,
                     Sucet, dt_Sucet,
                     SIZE};

    QVector<double> values = QVector<double>((uint)val::SIZE, 0.f);

    Kombinacia m_kombinacia;
    Cislovacky m_cislovacky;
//    double m_Sm{0.f}, m_SmDelta{0.f}, m_Kk{0.f}, m_KkDelta{0.f};
    Ntica m_Ntica;
    Xtica m_Xtica;
//    double m_R1{0.f}, m_R1Delta{0.f};                                       //ƩR1-DO            ΔƩR1-DO     ƩR1-DO "r+1"
//    double m_Rplus1{0.f};
//    double m_STL1{0.f}, m_STL1Delta{0.f};                                   //ƩSTL1-DO          ΔƩSTL1-DO   ƩSTL1-DO "r+1"
//    double m_STLplus1{0.f};
//    double m_R1STL1Delta{0.f};                                              //Δ(ƩR1-DO-ƩSTL1-DO)
//    double m_HHRX{0.f}, m_HHRXDelta{0.f};
//    double m_ROD{0.f}, m_RODDelta{0.f};                                     //ƩR OD-DO          ΔƩR OD-DO
//    double m_STLOD{0.f}, m_STLODDelta{0.f};                                 //ƩSTL OD-DO        ΔƩSTL OD-DO
//    double m_RODSTLODDelta{0.f};                                            //Δ(ƩROD-DO-ƩSTLOD-DO)
//    double m_HRX{0.f}, m_HRXDelta{0.f};
//    int m_KombinaciaSucet{0};
//    int m_KombinaciaSucetDelta{0};

protected:
    double getVal(val v) const{
        return values[(uint)v];
    }
    void setVal(val v, double d){
        values[(uint)v] = d;
    }
public:
    Archiv();
    Archiv(uint n, uint m, const Kombinacia &aktualna, const PHCisla &od1, const PHCisla &odDo);
    Archiv(uint n, uint m, const Kombinacia &aktualna, const PHCisla &od1, const PHCisla &odDo, const Archiv &predchadzajuciRiadok);

    void setArchiv(Archiv &archiv);

    Kombinacia kombinacia() const;
    double Sm() const;
    double Kk() const;
    double R1() const;
    double STL1() const;
    double HHRX() const;
    double ROD() const;
    double STLOD() const;
    double HRX() const;
    double Rplus1() const;
    double STLplus1() const;
    double dtROD() const;
    uint P() const;
    uint N() const;
    uint PR() const;
    uint Mc() const;
    uint Vc() const;
    uint C19() const;
    uint C0() const;
    uint cC() const;
    uint Cc() const;
    uint CC() const;
    uint ZH() const;
    Cislovacky getCislovacky() const;
    Xtica getXtica() const;
    Ntica getNtica() const;
    double dtSTLOD() const;
    double dtR1() const;
    double dtSTL1() const;
    double dtR1STL1() const;
    double dtRODSTLOD() const;
    double dtHHRX() const;
    double dtHRX() const;
    int dtKombinaciaSucet() const;
    double dtSm() const;
    double dtKk() const;
    int KombinaciaSucet() const;
    QStringList toQStringList() const;
};

QDataStream &operator<<(QDataStream &out, const Archiv &archiv);
QDataStream &operator>>(QDataStream &in, Archiv &archiv);


class ArchivWrap : public QObject
{
    Q_OBJECT
public:
    ArchivWrap(uint n, uint m, QString suborCesta): n{n}, m{m}, suborCesta{suborCesta} {}
signals:
    void msg(QString msg);
    void setUCcisloRiadok(QPair<uint, uint>);
    void setLastLine(QStringList riadok);
    void setArchiv(Archiv archiv);
    void setHrxHHrx(HrxHHrx &hrx);
    void setPhcisla(QPair<PHCisla, PHCisla>);
    void finished();
public slots:
    void process2();
private:
    uint n, m;
    QString suborCesta;

    void processArchiv(Kombinacie &kombinacie, PHCisla &phc1do, PHCisla &phcoddo, Archiv &ArchAkt, uint &UCcislo, uint &UCriadok);
};

#endif // ARCHIV_H

#ifndef TYPES_H
#define TYPES_H

#include <QVector>
#include <QStringList>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>

using bigInt = boost::multiprecision::cpp_int;
using bigFloat = boost::multiprecision::cpp_dec_float_50;

using gNum = quint8;

using Kombinacia = QVector<gNum>;
using Kombinacie = QVector<Kombinacia>;

using Cislovacky = QVector<gNum>;
using Kombinacia = QVector<gNum>;
using Ntica = QVector<gNum>;
using Xtica = QVector<gNum>;

using CSV = QVector<QStringList>;

#endif // TYPES_H

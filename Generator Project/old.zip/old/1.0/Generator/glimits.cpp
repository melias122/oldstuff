#include "glimits.h"

#include <QDebug>
#include <QtAlgorithms>

#include "cislovacky.h"

GLimits::GLimits(){
    this->count = QVector<double>(28,0);
    this->max = QVector<double>(28, std::numeric_limits<double>::max());
    this->min = QVector<double>(28, std::numeric_limits<double>::lowest());

    max[(uint)Fn::Kk] = 1;
}

GLimits::GLimits(uint n, uint m){

    this->level = n;
    this->m = m;
    this->count = QVector<double>(28,0);
    this->max = QVector<double>(28, std::numeric_limits<double>::max());
    this->min = QVector<double>(28, std::numeric_limits<double>::lowest());

    max[(uint)Fn::Kk] = 1;                                     //KK max
    max[(uint)Fn::Hrx] = 100;
    max[(uint)Fn::HHrx] = 100;
}

void GLimits::setFn_Od(Fn fn, double d){
    func_od.insert((uint)fn);
    func_using.insert((uint)fn);
    min[(uint)fn] = d;

    qDebug() << "GLimits::setFn_Od " << "Fn: " << (uint)fn << "double: " << d;
    qDebug() << "func_od: " << func_od;
    qDebug() << "func_using: " << func_using;
    qDebug() << "min[" << (uint)fn << "] = " << min[(uint)fn];
}

void GLimits::unsetFn_Od(Fn fn){
    if(!func_do.contains((uint)fn))
        func_using.remove((uint)fn);
    func_od.remove((uint)fn);

    switch ((uint)fn) {
        default: min[(uint)fn] = std::numeric_limits<double>::lowest(); break;
    }

    qDebug() << "GLimits::unsetFn_Od " << "Fn: " << (uint)fn;
    qDebug() << "func_do: " << func_do;
    qDebug() << "func_od: " << func_od;
    qDebug() << "func_using: " << func_using;
//    ////qDebug() << "min[" << fn << "]" = min[fn];
}

void GLimits::setFn_Do(Fn fn, double d){
    func_do.insert((uint)fn);
    func_using.insert((uint)fn);
    max[(uint)fn] = d;

    qDebug() << "GLimits::setFn_Do " << "Fn: " << (uint)fn << "double: " << d;
    qDebug() << "func_do: " << func_do;
    qDebug() << "func_using: " << func_using;
    qDebug() << "max[" << (uint)fn << "] = " << max[(uint)fn];
}

void GLimits::unsetFn_Do(Fn fn){
    if(!func_od.contains((uint)fn))
        func_using.remove((uint)fn);
    func_do.remove((uint)fn);

    switch (fn) {
        case Fn::Kk: max[(uint)Fn::Kk] = 1; break;
        case Fn::Hrx: max[(uint)Fn::Hrx] = 100; break;
        case Fn::HHrx: max[(uint)Fn::HHrx] = 100; break;
        default: max[(uint)fn] = std::numeric_limits<double>::max(); break;
    }

    qDebug() << "GLimits::unsetFn_Do " << "Fn: " << (uint)fn;
    qDebug() << "func_od: " << func_od;
    qDebug() << "func_do: " << func_do;
    qDebug() << "func_using: " << func_using;
//    ////qDebug() << "min[" << fn << "]" = min[fn];
}

bool GLimits::getFn_Od(Fn fn, double &d){

    qDebug() << "GLimits::getFn_Od " << "Fn: " << (uint)fn;
    qDebug() << "func_od: " << func_od;
    qDebug() << "min[" << (uint)fn << "] = " << min[(uint)fn];

    if(func_od.contains((uint)fn)){
        d = min[(uint)fn];
        return true;
    }
    return false;
}

bool GLimits::getFn_Do(Fn fn, double &d){

    qDebug() << "GLimits::getFn_Do " << "Fn: " << (uint)fn;
    qDebug() << "func_do: " << func_do;
    qDebug() << "max[" << (uint)fn << "] = " << max[(uint)fn];

    if(func_do.contains((uint)fn)){
        d = max[(uint)fn];
        return true;
    }
    return false;
}

void GLimits::setNticeStl(QVector<uint> &ntice_stl){
    for(uint i=0; i < level; i++){
        this->ntice_stl.push_back(ntice_stl[i]);
    }
    qDebug() << "GLimits::setNticeStl";
    qDebug() << "ntice_stl: " << this->ntice_stl;
//        ntice_stl = ntice_stl;
}

void GLimits::unsetNticeStl(){
    ntice_stl.clear();
//    ntice_stl_pos.clear();
}

void GLimits::setHrxPair(const HrxPair &hrxPair){
    auto skupiny = hrxPair.first;
//    ktoraKolko = hrxPair.second;
    for(auto &c : *hrxPair.second)
        ktoraKolko.push_back((int)c);

    for(int i{0}; i < skupiny.size(); ++i){
        for(auto& cislo : *skupiny[i]){
            cisloKolko.insert((int)cislo, &ktoraKolko[i]);
        }
    }
}

void GLimits::setPHCisla(PHCisla phc1R, PHCisla phcODR){
    phcisla1R.setPHCisla(phc1R);
    phcislaODR.setPHCisla(phcODR);
}

void GLimits::setLL(const Kombinacia last){
    this->last = last;
}

Kombinacia GLimits::getLL() const {
    return last;
}

void GLimits::setDelty(double R1, double S1, double R2, double S2){
    deltaVec = QVector<double>(4,0);
    deltaVec[0] = R1;
    deltaVec[1] = S1;
    deltaVec[2] = R2;
    deltaVec[3] = S2;
    qDebug() << deltaVec;
}

void GLimits::setNtice(QVector<uint> &ntice){
    ntice_vect = QVector<uint>(level,0);

    for(int i=0;i<ntice.size();i++)
        ntice_vect[i]=ntice[i];

    bool found = false;
    for(int pos = ntice.size()-1; pos >= 0; pos--){
        if(ntice[pos] == 0 && !found)
            continue;
        else{
            found = true;
            this->ntice.insert(pos,ntice[pos]);
        }
    }
    qDebug() << "GLimits::setNtice";
    qDebug() << "ntice_vect: " << this->ntice_vect;
    qDebug() << "ntice: " << this->ntice;
}

void GLimits::unsetNtice(){
    ntice_vect.clear();
    ntice.clear();
}

void GLimits::setXtice(QString xstr){

    xtice_str = xstr;

    foreach (const QString &qs, xstr.split("|")) {
        QSet<uint> stl{};
//        stl.clear();
        foreach (const QString &qsp, qs.split(",")) {
            if(qsp.contains("-")){
                QStringList a = qsp.split("-");
                for(int i=a[0].toInt(); i<=a[1].toInt(); i++){
                    stl.insert(i);
                }
            }

            else
                stl.insert(qsp.toUInt());
        }
        xtice_vect.push_back(stl);
    }

//    if(xtice_vect.size() < n)

    while(xtice_vect.size() < level){
        QSet<uint> qs{0};
        xtice_vect.push_back(qs);
    }
    while(xtice_vect.size() > level)
        xtice_vect.pop_back();

    qDebug() << "GLimits::setXtice";
    qDebug() << "xtice_str: " << xtice_str;
    qDebug() << "xtice_vect: " << xtice_vect;
}

void GLimits::unsetXtice(){
    xtice_str.clear();
    xtice_vect.clear();
}

void GLimits::setZakazane(QSet<uint> &zakazane){
    this->zakazane = zakazane;
    qDebug() << "GLimits::setZakazane";
    qDebug() << "zakazane: " << this->zakazane;
}

void GLimits::unsetZakazane(){
    zakazane.clear();
}

void GLimits::setPovinneSTL(QMultiHash<uint, uint> &pov){
    povinneSTL = pov;
    qDebug() << "GLimits::setPovinneSTL";
    qDebug() << "povinneSTL: " << this->povinneSTL;
}

void GLimits::unsetPovinneSTL(){
    povinneSTL.clear();
}

void GLimits::setZakazaneSTL(QMultiHash<uint, uint> &zak){
    zakazaneSTL = zak;
    qDebug() << "GLimits::setZakazaneSTL";
    qDebug() << "zakazaneSTL: " << this->zakazaneSTL;
}

void GLimits::unsetZakazaneSTL(){
    zakazaneSTL.clear();
}

void GLimits::setPovinne(QSet<uint> &povinne){
    this->povinne = povinne.toList().toVector();
    qSort(this->povinne);
    qDebug() << "GLimits::setPovinne";
    qDebug() << "povinne: " << this->povinne;
}

void GLimits::unsetPovinne(){
    povinne.clear();
}

void GLimits::addZakazane(QSet<uint> &zakazane){
    foreach (const uint &zak, zakazane) {
        zakazane << zak;
    }
}

void GLimits::addPovinne(QSet<uint> &povinne){
    foreach (const uint &pov, povinne) {
        this->povinne.push_back(pov);
    }
    qSort(this->povinne);
}


void GLimits::append(uint c){

    //qDebug() << "GLimits::append";

    result.append(c);
    foreach (const uint &pos, func_using) {
        switch (pos) {

        case (uint)Fn::N: if(N(c)) count[pos]++; break;
        case (uint)Fn::P: if(P(c)) count[pos]++; break;
        case (uint)Fn::PR: if(PR(c)) count[pos]++; break;
        case (uint)Fn::Mc: if(Mc(c)) count[pos]++; break;
        case (uint)Fn::Vc: if(Vc(c)) count[pos]++; break;
        case (uint)Fn::ZH: if(last.contains(c)) count[pos]++; break;
        case (uint)Fn::c19: if(C19(c)) count[pos]++; break;
        case (uint)Fn::c0: if(C0(c)) count[pos]++; break;
        case (uint)Fn::cC: if(cC(c)) count[pos]++; break;
        case (uint)Fn::Cc: if(Cc(c)) count[pos]++; break;
        case (uint)Fn::CC: if(CC(c)) count[pos]++; break;

        case (uint)Fn::R1: count[15] += phcisla1R.hodnotaRiadok(c); break;
        case (uint)Fn::R2: count[16] += phcislaODR.hodnotaRiadok(c); break;
        case (uint)Fn::STL1: count[17] += phcisla1R.hodnotaStlpec(c, result.size()); break;
        case (uint)Fn::STL2: count[18] += phcislaODR.hodnotaStlpec(c, result.size()); break;
        case (uint)Fn::Sucet: count[19] += (double)c; break;

        default: /*count[pos]++;*/ break;
        }
    }

    if(!cisloKolko.isEmpty()){
        int cislo = c;
        if(cisloKolko.contains(cislo))
            --(*cisloKolko[cislo]);
    }
}

void GLimits::removeLast(){

    //qDebug() << "GLimits::removeLast";

    if(result.isEmpty()){
        //qDebug() << "empty Result" << result;
        return;
    }

    uint c = result.last();

    foreach (const uint &pos, func_using) {
        switch (pos) {

        case (uint)Fn::N: if(N(c)) count[pos]--; break;
        case (uint)Fn::P: if(P(c)) count[pos]--; break;
        case (uint)Fn::PR: if(PR(c)) count[pos]--; break;
        case (uint)Fn::Mc: if(Mc(c)) count[pos]--; break;
        case (uint)Fn::Vc: if(Vc(c)) count[pos]--; break;
        case (uint)Fn::ZH: if(last.contains(c)) count[pos]--; break;
        case (uint)Fn::c19: if(C19(c)) count[pos]--; break;
        case (uint)Fn::c0: if(C0(c)) count[pos]--; break;
        case (uint)Fn::cC: if(cC(c)) count[pos]--; break;
        case (uint)Fn::Cc: if(Cc(c)) count[pos]--; break;
        case (uint)Fn::CC: if(CC(c)) count[pos]--; break;

        case (uint)Fn::R1: count[15] -= phcisla1R.hodnotaRiadok(c); break;
        case (uint)Fn::R2: count[16] -= phcislaODR.hodnotaRiadok(c); break;
        case (uint)Fn::STL1: count[17] -= phcisla1R.hodnotaStlpec(c, result.size()); break;
        case (uint)Fn::STL2: count[18] -= phcislaODR.hodnotaStlpec(c, result.size()); break;
        case (uint)Fn::Sucet: count[19] -= (double)c; break;

        default: /*count[pos]--;*/ break;
        }
    }

    if(!cisloKolko.isEmpty()){
//        uint cislo = c;
        if(cisloKolko.contains(c))
            ++(*cisloKolko[c]);
    }

//    result.pop_back();
    result.removeLast();
}

bool GLimits::checkXtice(){
    //qDebug() << "GLimits::checkXtice";

    if(xtice_vect.isEmpty())
        return true;

    QVector<int> vysl;

    foreach (const uint &qvn, result) {
        int pos = 0;
        for(uint i=10; i <= 90; i+=10, ++pos){

            if(pos >= vysl.size())
                vysl.push_back(0);

            if(qvn <= i){
                vysl[pos]++;
                break;
            }
        }
    }

    uint sum=0;
    for(int i=0; i<vysl.size() && i < xtice_vect.size(); i++){
//        auto l = xtice_vect[i].toList();
//        qSort(l);
//        int max=(i+1)*10, xmin=l.first(), xmax=l.last();

        // ak neobsahuje, pozriem sa ci mozeme dosiahnut, alebo sme presiahli xticu
//        if(!xtice_vect[i].contains(vysl[i])){
//            if(vysl[i] > xmax)
//                return false;
//            if(max-(int)result.last() < xmin)
//                return false;
//        }
        sum += vysl[i];
    }

    if(result.size() == (int)level && sum == level){
        //        if(sum == level){
        for(int i=0; i<vysl.size() && i < xtice_vect.size(); ++i){
            if(!xtice_vect[i].contains(vysl[i]))
                return false;
        }
        //        }
    }

    return true;
}

bool GLimits::checkStlNtice(){

    //qDebug() << "GLimits::checkStlNtice";

    if(ntice_stl.isEmpty())
        return true;

    for(int i=0; i< ntice_stl_pos.size(); i++){
        if(ntice_stl[i] != ntice_stl_pos[i])
            return false;
    }

    return true;
}

bool GLimits::checkNtice(){

    //qDebug() << "GLimits::checkNtice";

    if(ntice.isEmpty())
        return true;
    if(result.size() < 2)
        return true;

    // hladame ntcie/volne
    QVector<uint> tice(level,0);
    ntice_stl_pos.clear();
//    ntice_stl_pos = QVector<uint>(level,0);

    int tica=0;
    result.push_back(0);
    for(int i = 0; i < result.size(); i++){

        ntice_stl_pos.push_back(0);

        if((i == result.size()-2) && ((int)level == result.size()-1)){ // posledny je volny
            if(tica > 0){
                tice[tica]++;
                ntice_stl_pos[i]=1;
            }
            else
                tice[0]++;
            break;
        }

        int c = (int)(result[i] - result[i+1]);
        if(c == (int)result[i]){
            if(tica > 0){
                tice[tica]++;
                ntice_stl_pos[i]=1;
            }
            else
                ntice_stl_pos.pop_back();
            break;
        }
        if(c < -1){
            if(tica==0){
                tice[0]++;
            }
            else{
                ntice_stl_pos[i]=1;
                tice[tica]++;
                tica=0;
            }
        }
        else{
            ntice_stl_pos[i]=1;
            tica++;
        }
    }
    result.pop_back();

    // kontrola volnych
    // ak sme nasli volne a nemali sme tak je zle..
    if(result.size() < (int)level){

        if(tice[0] > ntice.find(0).value())
            return false;

        uint _size = tice.size();
        for(uint pos=1; pos < _size; ++pos){
            if(tice[pos] != 0 && ntice.find(pos) == ntice.end()){
                return false;
            }
        }
    }
    else{
        uint _size = tice.size();
        for(uint pos = 0; pos < _size; ++pos){
            if(ntice_vect[pos] != tice[pos])
                return false;
        }
    }

    return true;
}

bool GLimits::checkPovinne(){

    //qDebug() << "GLimits::checkPovinne";

    if(povinne.isEmpty())
        return true;

    uint p_size = povinne.size();
    uint r_size = result.size();
    for(uint lev=0; lev < p_size && lev < r_size; ++lev){
        if(result[lev] > povinne[lev])
            return false;
    }

    if(level == r_size){
        foreach (const uint &pov, povinne) {
            if(!result.contains(pov))
                return false;
        }
    }
    return true;
}

bool GLimits::checkSm(){

    //qDebug() << "GLimits::checkSm";

    if(!func_using.contains((uint)Fn::Sm))
        return true;


    if((uint)result.size() == level){

        double sm = smernica(result, level, m);

        if((sm >= min[2]) && (sm <= max[2]))
            return true;
        else
            return false;
    }

    return true;
}

bool GLimits::checkKk(){

    //qDebug() << "GLimits::checkKk";

    if(!func_using.contains(3))
        return true;

    if((uint)result.size() == level){

        double kk = korelacia(result, last, level, m);

        if((kk >= min[3]) && (kk <= max[3]))
            return true;
        else
            return false;
    }

    return true;
}

bool GLimits::checkFn(GLimits::Fn fn, double val){
    uint cf = (uint)fn;
    bool _od = func_od.contains(cf);
    bool _do = func_do.contains(cf);
    if(_od && _do)
        return val >= min[cf] && val <= max[cf] ? true : false;
    else if(_od)
        return val >= min[cf];
    else if(_do)
        return val <= max[cf];
    else
        return true;
}

bool GLimits::checkRange(GLimits::Fn fn, double from, double to){
    uint cf = (uint)fn;
    bool _od = func_od.contains(cf);
    bool _do = func_do.contains(cf);

    if(_od && _do)
        return from >= min[cf] && to <= max[cf] ? true : false;
    else if(_od)
        return from >= min[cf];
    else if(_do)
        return to <= max[cf];
    else
        return true;
}

bool GLimits::checkHrx(double _hrx){
    uint cf = (uint)Fn::Hrx;
    return _hrx >= min[cf] && _hrx <= max[cf] ? true : false;
}

uint GLimits::size(){
    uint size=0;
    if(!ntice.isEmpty())
        size++;
    if(!povinne.isEmpty())
        size++;
    if(!zakazane.isEmpty())
        size++;
    if(!xtice_vect.isEmpty())
        size++;
    return size + func_od.size() + func_do.size();
}

void GLimits::nastav(QString &nastavenie, uint pos){
    if(func_od.contains(pos))
        nastavenie.append(QString::number(min[pos],'g',12)).append(" ");
    else
        nastavenie.append("- ");
    if(func_do.contains(pos))
        nastavenie.append(QString::number(max[pos],'g',12)).append(" ");
    else
        nastavenie.append("- ");
}

QString GLimits::getSettings(){
    QString nastavenie;

    if(!povinne.empty()){
        nastavenie.append("Povinne: ");
        foreach (const uint zak, povinne) {
            nastavenie.append(QString::number(zak)).append(" ");
        }
    }
    if(!zakazane.empty()){
        nastavenie.append("Zakazane: ");
        foreach (const uint zak, zakazane) {
            nastavenie.append(QString::number(zak)).append(" ");
        }
    }
    if(!ntice.empty()){
        nastavenie.append("N-tice: ");
        for(int i=0;i<ntice_vect.size();i++)
            nastavenie.append(QString::number(ntice_vect[i])).append(" ");
    }
    if(!xtice_vect.empty()){
        nastavenie.append("X-tice: ").append(xtice_str);
//        for(int i=0;i<xtice_vect.size();i++)
//            nastavenie.append(QString::number(xtice_vect[i])).append(" ");
    }

    foreach (const uint &pos, func_using) {
        switch (pos) {

        case 2: nastavenie.append("Sm: "); nastav(nastavenie,pos); break;
        case 3: nastavenie.append("Kk: "); nastav(nastavenie,pos); break;
        case (uint)Fn::N: nastavenie.append("N: "); nastav(nastavenie,pos); break;
        case (uint)Fn::P: nastavenie.append("P: "); nastav(nastavenie,pos); break;
        case 6: nastavenie.append("PR: "); nastav(nastavenie,pos); break;
        case 7: nastavenie.append("Mc: "); nastav(nastavenie,pos); break;
        case 8: nastavenie.append("Vc: "); nastav(nastavenie,pos); break;
        case 9: nastavenie.append("ZH: "); nastav(nastavenie,pos); break;
        case 10: nastavenie.append("c19: "); nastav(nastavenie,pos); break;
        case 11: nastavenie.append("c0: "); nastav(nastavenie,pos); break;
        case 12: nastavenie.append("cC: "); nastav(nastavenie,pos); break;
        case 13: nastavenie.append("Cc: "); nastav(nastavenie,pos); break;
        case 14: nastavenie.append("CC: "); nastav(nastavenie,pos); break;

        case 15: nastavenie.append("R1-DO: "); nastav(nastavenie,pos); break;
        case 16: nastavenie.append("ROD-DO: "); nastav(nastavenie,pos); break;
        case 17: nastavenie.append("STL1-DO: "); nastav(nastavenie,pos); break;
        case 18: nastavenie.append("STLOD-DO: "); nastav(nastavenie,pos); break;
        case 19: nastavenie.append("Kombinacie: "); nastav(nastavenie,pos); break;
        case 20: nastavenie.append("ΔR1-DO: "); nastav(nastavenie,pos); break;
        case 21: nastavenie.append("ΔSTL1-DO: "); nastav(nastavenie,pos); break;
        case 22: nastavenie.append("Δ(R1DO-STL1DO): "); nastav(nastavenie,pos); break;
        case 23: nastavenie.append("ΔROD-DO: "); nastav(nastavenie,pos); break;
        case 24: nastavenie.append("ΔSTLOD-DO: "); nastav(nastavenie,pos); break;
        case 25: nastavenie.append("Δ(RODDO-STLODDO): "); nastav(nastavenie,pos); break;
        case 26: nastavenie.append("HHRX: "); nastav(nastavenie,pos); break;
        case 27: nastavenie.append("HRX: "); nastav(nastavenie,pos); break;

        default: break;
        }
    }
    return nastavenie;
}

bool GLimits::check(){

    ////qDebug() << "GLimits::check";

    uint r_size = result.size();

    //skupiny
    if(!cisloKolko.isEmpty()){
        if(cisloKolko.contains(result.last())){
            int kolko = (*cisloKolko[result.last()]);
            if(kolko < 0)
                return false;
        }
    }

    // zakazane
    if(zakazane.contains(result.last()))
        return false;

    //zakazaneSTL
    if(zakazaneSTL.keys().contains(r_size)){
        if(zakazaneSTL.find(r_size, result.last()) != zakazaneSTL.end())
            return false;
    }

    //povinneSTL
    if(povinneSTL.keys().contains(r_size)){
        if(povinneSTL.find(r_size, result.last()) == povinneSTL.end())
            return false;
    }

    // povinne
    if(!checkPovinne())
        return false;

    // N-tice
    if(!checkNtice())
        return false;

    // Stl N-tice
    if(!checkStlNtice())
        return false;

    if(!checkXtice())
        return false;



    // vector cisel funkcii
    // kontrola ci sme nepresiahli maximum
    foreach (const uint &cf, func_do) {
        switch (cf) {
        case (uint)Fn::Hrx:
        case (uint)Fn::HHrx:
        case (uint)Fn::Kk:
        case (uint)Fn::Sm:
        case (uint)Fn::dtR1:
        case (uint)Fn::dtR2:
        case (uint)Fn::dtSTL1:
        case (uint)Fn::dtSTL2:
        case (uint)Fn::dtRSTL1:
        case (uint)Fn::dtRSTL2: break;

        default:
            if(count[cf] > max[cf])
                return false;
            break;
        }
    }

    // vector cisel funkcii
    // kontrola ci dosiahneme minimum
    foreach (const uint &cf, func_od) {

        switch (cf) {
        case (uint)Fn::Hrx:
        case (uint)Fn::HHrx:
        case (uint)Fn::Kk:
        case (uint)Fn::Sm:
        case (uint)Fn::dtR1:
        case (uint)Fn::dtR2:
        case (uint)Fn::dtSTL1:
        case (uint)Fn::dtSTL2:
        case (uint)Fn::dtRSTL1:
        case (uint)Fn::dtRSTL2: break;

        case (uint)Fn::R1:
        case (uint)Fn::R2:
        case (uint)Fn::STL1:
        case (uint)Fn::STL2:
        case (uint)Fn::Sucet:
            if(level == r_size)
                if(count[cf] < min[cf]) return false;
            break;

        default:
            if(((int)level - (int)r_size) < ((int)min[cf] - (int)count[cf])) return false;
            break;
        }
    }

    if(func_using.contains((uint)Fn::HHrx) && level == r_size){
        if(!checkFn(Fn::HHrx, hrxRplus1(result, phcisla1R, m)))
            return false;
    }

    if(level == r_size){

        QList<uint> fns{
                                (uint)Fn::dtR1,
                                (uint)Fn::dtR2,
                                (uint)Fn::dtSTL1,
                                (uint)Fn::dtSTL2,
                                (uint)Fn::dtRSTL1,
                                (uint)Fn::dtRSTL2 };
        QList<double> delty{    phcisla1R.hodnotaRiadokKombinacia(result) - deltaVec[0],
                                phcislaODR.hodnotaRiadokKombinacia(result) - deltaVec[2],
                                phcisla1R.hodnotaStlpecKombinacia(result) - deltaVec[1],
                                phcislaODR.hodnotaStlpecKombinacia(result) - deltaVec[3],
                                phcisla1R.hodnotaRiadokKombinacia(result) - phcisla1R.hodnotaStlpecKombinacia(result),
                                phcislaODR.hodnotaRiadokKombinacia(result) - phcislaODR.hodnotaStlpecKombinacia(result)};

        for(uint &fn : fns){
            double dt = delty.takeFirst();
            if(func_using.contains(fn) && !checkFn((Fn)fn, dt))
                return false;
        }
    }

    // Kk
    if(!checkKk())
        return false;

    // Sm
    if(!checkSm())
        return false;

    return true;
}

#include "archiv.h"

#include <qdebug.h>

#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QSet>
#include <QMutableVectorIterator>

#include "cislovacky.h"
#include "utility.h"

Archiv::Archiv(){}

Archiv::Archiv(uint n,
        uint m,
        const Kombinacia &aktualna,
        const PHCisla &od1,
        const PHCisla &odDo
        ){

    m_kombinacia = aktualna;
    m_cislovacky = cislovacky(aktualna, {});
    values[(uint)val::Sm] = smernica(aktualna, n, m);
    m_Ntica = ntica(aktualna);
    m_Xtica = xtica(aktualna, m);
    double m_R1 = values[(uint)val::R1] = od1.hodnotaRiadokKombinacia(aktualna);
    double m_STL1 = values[(uint)val::STL1] = od1.hodnotaStlpecKombinacia(aktualna);
//    values[(uint)val::HHRX] = hrxRplus1(aktualna, od1, m);
    values[(uint)val::HHRX] = 100.f;
    double m_ROD = values[(uint)val::R2] = odDo.hodnotaRiadokKombinacia(aktualna);
    double m_STLOD = values[(uint)val::STL2] = odDo.hodnotaStlpecKombinacia(aktualna);
    values[(uint)val::HRX] = hrxR(aktualna, odDo, m);
    values[(uint)val::Sucet] = (int)sucet(aktualna);
    values[(uint)val::dt_R1STL1] = m_R1 - m_STL1;
    values[(uint)val::dt_R2STL2] = m_ROD - m_STLOD;

    values[(uint)val::Rplus1] = od1.Rplus1(aktualna);
    values[(uint)val::STLplus1] = od1.STLplus1(aktualna);
}

Archiv::Archiv(uint n,
        uint m,
        const Kombinacia &aktualna,
        const PHCisla &od1,
        const PHCisla &odDo,
        const Archiv &predchadzajuciRiadok){

    auto predchadzajuca = predchadzajuciRiadok.kombinacia();

    m_kombinacia = aktualna;
    m_cislovacky = cislovacky(aktualna, predchadzajuca);
    double m_Sm = values[(uint)val::Sm] = smernica(aktualna, n, m);
    double m_Kk = values[(uint)val::Kk] = korelacia(aktualna, predchadzajuca, n, m);
    m_Ntica = ntica(aktualna);
    m_Xtica = xtica(aktualna, m);
    double m_R1 = values[(uint)val::R1] = od1.hodnotaRiadokKombinacia(aktualna);
    double m_STL1 = values[(uint)val::STL1] = od1.hodnotaStlpecKombinacia(aktualna);
    double m_HHRX = values[(uint)val::HHRX] = hrxRplus1(aktualna, od1, m);
    double m_ROD = values[(uint)val::R2] = odDo.hodnotaRiadokKombinacia(aktualna);
    double m_STLOD = values[(uint)val::STL2] = odDo.hodnotaStlpecKombinacia(aktualna);
    double m_HRX = values[(uint)val::HRX] = hrxR(aktualna, odDo, m);
    double m_Sucet = values[(uint)val::Sucet] = (int)sucet(aktualna);

    values[(uint)val::dt_R1STL1] = m_R1 - m_STL1;
    values[(uint)val::dt_R2STL2] = m_ROD - m_STLOD;

    values[(uint)val::Rplus1] = od1.Rplus1(aktualna);
    values[(uint)val::STLplus1] = od1.STLplus1(aktualna);

    values[(uint)val::dt_Sm] = m_Sm - predchadzajuciRiadok.Sm();
    values[(uint)val::dt_Kk] = m_Kk - predchadzajuciRiadok.Kk();
    values[(uint)val::dt_R1] = m_R1 - predchadzajuciRiadok.R1();
    values[(uint)val::dt_STL1] = m_STL1 - predchadzajuciRiadok.STL1();
    values[(uint)val::dt_HHRX] = m_HHRX - predchadzajuciRiadok.HHRX();
    values[(uint)val::dt_R2] = m_ROD - predchadzajuciRiadok.ROD();
    values[(uint)val::dt_STL2] = m_STLOD - predchadzajuciRiadok.STLOD();
    values[(uint)val::dt_HRX] = m_HRX - predchadzajuciRiadok.HRX();
    values[(uint)val::dt_Sucet] = m_Sucet - predchadzajuciRiadok.KombinaciaSucet();
}

void Archiv::setArchiv(Archiv &archiv){

    m_kombinacia = archiv.kombinacia();
    m_cislovacky = archiv.getCislovacky();
    m_Ntica = archiv.getNtica();
    m_Xtica = archiv.getXtica();

    for(uint v{0}; v < (uint)val::SIZE; ++v)
        values[v] = archiv.getVal((val)v);
}

Kombinacia Archiv::kombinacia() const {return m_kombinacia;}
double Archiv::Sm() const {return getVal(val::Sm);}
double Archiv::Kk() const {return getVal(val::Kk);}
double Archiv::R1() const {return getVal(val::R1);}
double Archiv::STL1() const {return getVal(val::STL1);}
double Archiv::HHRX() const {return getVal(val::HHRX);}
double Archiv::ROD() const {return getVal(val::R2);}
double Archiv::STLOD() const {return getVal(val::STL2);}
double Archiv::HRX() const {return getVal(val::HRX);}
double Archiv::Rplus1() const {return getVal(val::Rplus1);}
double Archiv::STLplus1() const {return getVal(val::STLplus1);}
int Archiv::KombinaciaSucet() const {return (int)getVal(val::Sucet);}
double Archiv::dtROD() const {return getVal(val::dt_R2);}
uint Archiv::P() const{return m_cislovacky[0];}
uint Archiv::N() const{return m_cislovacky[1];}
uint Archiv::PR() const{return m_cislovacky[2];}
uint Archiv::Mc() const{return m_cislovacky[3];}
uint Archiv::Vc() const{return m_cislovacky[4];}
uint Archiv::C19() const{return m_cislovacky[5];}
uint Archiv::C0() const{return m_cislovacky[6];}
uint Archiv::cC() const{return m_cislovacky[7];}
uint Archiv::Cc() const{return m_cislovacky[8];}
uint Archiv::CC() const{return m_cislovacky[9];}
uint Archiv::ZH() const{return m_cislovacky[10];}
Cislovacky Archiv::getCislovacky() const{return m_cislovacky;}
Xtica Archiv::getXtica() const{return m_Xtica;}
Ntica Archiv::getNtica() const{return m_Ntica;}
double Archiv::dtSTLOD() const{return getVal(val::dt_STL2);}
double Archiv::dtR1() const{return getVal(val::dt_R1);}
double Archiv::dtSTL1() const{return getVal(val::dt_STL1);}
double Archiv::dtR1STL1() const{return getVal(val::dt_R1STL1);}
double Archiv::dtRODSTLOD() const{return getVal(val::dt_R2STL2);}
double Archiv::dtHHRX() const{return getVal(val::dt_HHRX);}
double Archiv::dtHRX() const{return getVal(val::dt_HRX);}
double Archiv::dtSm() const {return getVal(val::dt_Sm);}
double Archiv::dtKk() const {return getVal(val::dt_Kk);}
int Archiv::dtKombinaciaSucet() const{return (int)getVal(val::dt_Sucet);}

QStringList Archiv::toQStringList() const{
    QStringList riadok{};

    riadok += kombinaciaToQString(m_kombinacia);
    riadok += cislovackyToQStringList(m_cislovacky);
    riadok += doubleToQString(Sm());
    riadok += doubleToQString(dtSm());
    riadok += doubleToQString(Kk());
    riadok += doubleToQString(dtKk());
    riadok += nticaToQString(getNtica());
    riadok += xticaToQString(getXtica());

    riadok += doubleToQString(R1());
    riadok += doubleToQString(dtR1());
    riadok += doubleToQString(Rplus1());
    riadok += doubleToQString(STL1());
    riadok += doubleToQString(dtSTL1());
    riadok += doubleToQString(STLplus1());
    riadok += doubleToQString(dtR1STL1());
    riadok += doubleToQString(HHRX());
    riadok += doubleToQString(dtHHRX());

    riadok += doubleToQString(ROD());
    riadok += doubleToQString(dtROD());
    riadok += doubleToQString(STLOD());
    riadok += doubleToQString(dtSTLOD());
    riadok += doubleToQString(dtRODSTLOD());
    riadok += doubleToQString(HRX());
    riadok += doubleToQString(dtHRX());
    riadok += uintToQString(KombinaciaSucet());
    riadok += QString::number(dtKombinaciaSucet());

    return riadok;
}

QPair<bool, QStringList> CSVtoKombinacie(CSV &csv, Kombinacie &kombinacie, uint n, uint m){

//    qDebug() << "CSVtoKombinacie";

    auto dlzka = n + 3;

    for(auto &riadok : csv){

        if(riadok.size() < dlzka)
            return QPair<bool, QStringList>(false, riadok);

//        qDebug() << riadok;
        Kombinacia kombinacia;
        kombinacia.reserve(n);
        for(uint i{3}; i < dlzka; ++i){
            auto cislo = riadok[i].toUInt();

            // Zle zadane hodnoty n, m alebo zly subor
            if(cislo < 1 || cislo > m)
                return QPair<bool, QStringList>(false, riadok);

            kombinacia.push_back(cislo);
        }

        // Nespravny pocet stlpcov na riadku
        if(kombinacia.size() != n)
            return QPair<bool, QStringList>(false, riadok);

        kombinacie.push_back(kombinacia);
    }
    return QPair<bool, QStringList>(true, {});
}

CSV LinearnaPredikcia(QVector<QVector<double>> &data , uint CsvSize, uint UCRiadok){

    /****** LINEARNA PREDIKCIA BEGIN ******/
    //    {
    // CREATE DATA TO APPROXIMATE
    //        QVector<QVector<double>> data(33,{});
    //        for(auto& riadok : archiv){
    //            int i = 0;
    //            for(int j{2}; j <= 36; ++j){
    //                if(j == 17)continue;
    //                if(j == 18)continue;
    //                QString str = riadok[j];
    //                str.replace(",",".");
    //                data[i].push_back(str.toDouble());
    //                ++i;
    //            }
    //        }

    CSV archiv;
    QStringList line;
    line << "" << "Linearna predikcia";

    int i=0;
    for(auto &d : data){

        std::vector<double> original = d.toStdVector();

        // GET FORWARD LINEAR PREDICTION COEFFICIENTS
        std::vector<double> coeffs( 4, 0.0f );
        ForwardLinearPrediction( coeffs, original );

        // PREDICT DATA LINEARLY
        QVector<double> predicted(QVector<double>::fromStdVector(original));
        QVector<double>::fromStdVector(original);
        size_t m = coeffs.size();
        for ( size_t i = m; i < predicted.size(); i++ )
        {
            predicted[ i ] = 0.0f;
            for ( size_t j = 0; j < m; j++ )
            {
                predicted[ i ] -= coeffs[ j ] * original[ i - 1 - j ];
            }
        }
        if(i <= 10 || i == 31 || i == 32){
            line << doubleToQString(round(predicted.last()));
        }
        else
            line << doubleToQString(predicted.last());
        ++i;
    }
    archiv.push_back({});
    line.insert(17,"");
    line.insert(18,"");
    archiv.push_back(line);


    // predikcia podla uc
    line.clear();
    line << "" << "UC Linearna predikcia";
    uint dlzka = CsvSize - UCRiadok;

    i=0;
    for(auto &d : data){
        while(d.size() > dlzka)
            d.removeFirst();

        std::vector<double> original = d.toStdVector();

        // GET FORWARD LINEAR PREDICTION COEFFICIENTS
        std::vector<double> coeffs( 4, 0.0f );
        ForwardLinearPrediction( coeffs, original );

        // PREDICT DATA LINEARLY
        QVector<double> predicted(QVector<double>::fromStdVector(original));
        QVector<double>::fromStdVector(original);
        size_t m = coeffs.size();
        for ( size_t i = m; i < predicted.size(); i++ )
        {
            predicted[ i ] = 0.0f;
            for ( size_t j = 0; j < m; j++ )
            {
                predicted[ i ] -= coeffs[ j ] * original[ i - 1 - j ];
            }
        }

        if(i <= 10 || i == 31 || i == 32){
            line << doubleToQString(round(predicted.last()));
        }
        else
            line << doubleToQString(predicted.last());
        ++i;
    }
    //        archiv.push_back({});
    line.insert(17,"");
    line.insert(18,"");
    archiv.push_back(line);
    //    }
    /****** LINEARNA PREDIKCIA END ******/

    //    archiv.prepend(hlavicka);
    //    return std::make_tuple(archiv, predchadzajuci);
    return archiv;
}

void phCislaODDO2(uint n, uint m, QMutableVectorIterator<Kombinacia> ittKombinacieOD, PHCisla &phcisla, uint &UCcislo, uint &UCriadok, uint &CSVriadok){

    if(UCcislo != 0){
        Kombinacia kombinacia = ittKombinacieOD.value();
        if(!kombinacia.contains(UCcislo)){
            phcisla.increment(kombinacia);
            return;
        }
    }

    QSet<uint> vyskytCisiel{};
    bool hasUC{false};

    vyskytCisiel.reserve(m);
    for(uint i{1}; i<=m; ++i)
        vyskytCisiel.insert(i);

    UCriadok = CSVriadok;

//    phcisla.clear();
//    swap(phcisla, PHCisla(n, m));
//    phcisla = PHCisla(n, m);
    PHCisla p(n, m);
    phcisla.swap(p);
    while(ittKombinacieOD.hasPrevious() && !hasUC){

        auto kombinacia = ittKombinacieOD.previous();
        //            qDebug() << CSVriadok << kombinacia;

        phcisla.increment(kombinacia);
        for(auto &cislo : kombinacia){
            vyskytCisiel.remove(cislo);
            if(vyskytCisiel.size() == 0){
                UCcislo = cislo;
                hasUC = true;
                break;
            }
        }
        if(!hasUC)
            --UCriadok;
    }

    if(!vyskytCisiel.isEmpty()){
//        phcisla = PHCisla(n, m);
        PHCisla p(n, m);
        phcisla.swap(p);
    }

}



void ArchivWrap::processArchiv(Kombinacie &kombinacie, PHCisla &phc1do, PHCisla &phcoddo, Archiv &ArchAkt, uint &UCcislo, uint &UCriadok){

    QStringList ArchivHlavicka{
        "Poradove cislo" , "Kombinacie",
        "P","N","PR","Mc","Vc","c1-c9","C0","cC","Cc","CC","ZH",
        "Sm", "ΔSm",
        "Kk", "ΔKk",
        "N-tice","X-tice",
        "ƩR1-DO", "ΔƩR1-DO" , "ƩR1-DO \"r+1\"",
        "ƩSTL1-DO" , "ΔƩSTL1-DO" , "ƩSTL1-DO \"r+1\"" , "Δ(ƩR1-DO-ƩSTL1-DO)",
        "HHRX" , "ΔHHRX",
        "ƩR OD-DO" , "ΔƩR OD-DO",
        "ƩSTL OD-DO", "ΔƩSTL OD-DO" , "Δ(ƩROD-DO-ƩSTLOD-DO)",
        "HRX" , "ΔHRX",
        "ƩKombinacie" , "ΔƩKombinacie"};

    for(uint i=0; i < n; ++i){
        ArchivHlavicka << "Cislo"
                       << "R1-DO" << "ΔR1-DO"
                       << "STL1-DO"<< "ΔSTL1-DO"
                       << "R OD-DO"<< "ΔR OD-DO"
                       << "STL OD-DO"<< "ΔSTL OD-DO";
    }

    QStringList archivCsv;
    QFile subor(pwd() + "Archiv_" + filenameFromPath(suborCesta) + ".csv");
    if(subor.exists())
        subor.remove();
    subor.open(QFile::WriteOnly | QFile::Append);
    QTextStream csvOutStream(&subor);
    csvOutStream.setCodec("UTF-8");
    csvOutStream.setGenerateByteOrderMark(true);



//    Kombinacia kombinacia;
    uint CSVriadok{1};
    Archiv ArchPred;
    QMutableVectorIterator<Kombinacia> ittKombinacie(kombinacie);
    QVector<QVector<double>> ArchData(33,{});


    csvOutStream << ArchivHlavicka.join(";") << "\n";
    while(ittKombinacie.hasNext()){

        archivCsv.clear();

        emit msg("Vytvaram Archiv: riadok " + QString::number(CSVriadok) + "/" + QString::number(kombinacie.size()));

        auto kombinacia = ittKombinacie.next();
        phCislaODDO2(n,m, ittKombinacie, phcoddo, UCcislo, UCriadok, CSVriadok );

        if(CSVriadok > 1){
            auto _ArchAkt = Archiv(n, m, kombinacia, phc1do, phcoddo, ArchPred);
            ArchAkt.setArchiv(_ArchAkt);
        }
        else{
            auto _ArchAkt = Archiv(n, m, kombinacia, phc1do, phcoddo);
            ArchAkt.setArchiv(_ArchAkt);
        }

        archivCsv.append(ArchAkt.toQStringList());
        archivCsv.prepend(uintToQString(CSVriadok));

        auto DataStr = archivCsv;

        for(auto &cislo : kombinacia){
            uint stl=1;
            archivCsv.append(uintToQString(cislo));
            archivCsv.append(doubleToQString(phc1do.hodnotaRiadok(cislo)));
            archivCsv.append(doubleToQString(phc1do.hodnotaRiadok(cislo) - phc1do.hodnotaRiadok(cislo)));
            archivCsv.append(doubleToQString(phc1do.hodnotaStlpec(cislo, stl)));
            archivCsv.append(doubleToQString(phc1do.hodnotaStlpec(cislo, stl) - phc1do.hodnotaStlpec(cislo, stl)));
            archivCsv.append(doubleToQString(phcoddo.hodnotaRiadok(cislo)));
            archivCsv.append(doubleToQString(phcoddo.hodnotaRiadok(cislo) - phcoddo.hodnotaRiadok(cislo)));
            archivCsv.append(doubleToQString(phcoddo.hodnotaStlpec(cislo, stl)));
            archivCsv.append(doubleToQString(phcoddo.hodnotaStlpec(cislo, stl) - phcoddo.hodnotaStlpec(cislo, stl)));
            ++stl;
        }

        DataStr.pop_front();
        DataStr.pop_front();
        DataStr.removeAt(15);
        DataStr.removeAt(15);

        int i = 0;
        foreach (QString cisloStr, DataStr){
            cisloStr.replace(",",".");
            ArchData[i].push_back(cisloStr.toDouble());
            ++i;
        }

        csvOutStream << archivCsv.join(";") << "\n";

        ArchPred = ArchAkt;
        ++CSVriadok;
        phc1do.increment(kombinacia);
    }
    auto lp = LinearnaPredikcia(ArchData, kombinacie.size(), UCriadok);

    for(auto &riadok : lp)
        csvOutStream << riadok.join(";") << "\n";
}


void ArchivWrap::process2(){

    cp(suborCesta, pwd());

    emit msg("Nacitanie suboru");
    auto csv = nacitajCsv(suborCesta);
    if(csv.empty()){
        emit msg("Subor nebol uspesne nacitany");
        emit finished();
        return;
    }

    //Odstranenie hlavicky
    auto csv_header = csv.takeFirst();


    Kombinacie kombinacie{};
    kombinacie.reserve(csv.size());
    auto ok = CSVtoKombinacie(csv, kombinacie, n, m);
    if(ok.first == false){
        emit msg("CHYBA na riadku " + ok.second.join(";"));
        emit finished();
        return;
    }

    // archiv
    Archiv ArchAkt;
    PHCisla phcoddo(n, m), phc1do(n, m);
    uint UCcislo{0}, UCriadok{0};
    processArchiv(kombinacie, phc1do, phcoddo, ArchAkt, UCcislo, UCriadok);

    emit msg("Vytvaram Hrx");
    HrxHHrx hrxAll;
    makeHrxHHrx_v2(n, m, phc1do, phcoddo, hrxAll, suborCesta);

    emit msg("Vytvaram Statistiky");
    pocetnostR(phc1do, phcoddo, ArchAkt.kombinacia(),n, m);
    pocetnostSTL(phc1do, phcoddo, ArchAkt.kombinacia(), n, m);
    statArchiv(n, m, kombinacie);


    csv.prepend(csv_header);
    mapaNtice(csv, n);
    mapaZhoda(csv, n);

    csv.removeFirst();
    statistikaNtice(n, m, csv.size());
    statistikaZhoda(n, m, csv.size());

    emit setArchiv(ArchAkt);
    emit setHrxHHrx(hrxAll);
    emit setPhcisla({phc1do, phcoddo});
    emit setUCcisloRiadok({UCcislo, UCriadok});
    emit setLastLine(csv.last());
    emit msg("Subor bol uspesne nacitany");

    hrxAll.clear();
    kombinacie.clear();
    csv.clear();

    emit finished();
}

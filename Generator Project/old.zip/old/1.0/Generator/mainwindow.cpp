#include "mainwindow.h"
#include "ui_mainwindow.h"

//#include <QDebug>
#include <QFileDialog>
#include <QThread>
#include <QDir>
//#include <QtConcurrent>
#include <QDateTime>
#include <QFile>
#include <QTextStream>

#include <combination.h>
#include <generator.h>
#include <utility.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->resize(0,0);
    this->path = QDir::currentPath().append("/");

    setLines(lines);
    setStlNtice(stlNtice);

    this->glimits = GLimits(getN(), getM());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setLines(QVector< QVector<QLineEdit*> > &lines){

    if(!lines.isEmpty())
        lines.clear();

    //    //1-do
    lines.push_back({ui->r1od, ui->r1R, ui->r1do});                 //sum R     --0--
    lines.push_back({ui->stl1od, ui->stl1R, ui->stl1do});           //sum STL   --1--
    lines.push_back({ui->dtr1od, ui->dtr1, ui->dtr1do});            //dt R      --2--
    lines.push_back({ui->dtstl1od, ui->dtstl1, ui->dtstl1do});      //dt STL    --3--
    lines.push_back({ui->dtRSTL1od, ui->dtRSTL1, ui->dtRSTL1do});   //dt R-STL  --4--
    lines.push_back({ui->HHRXod, ui->HHRXr, ui->HHRXdo});           //hhrx      --5--
    lines.push_back({ui->kombod, ui->kombR, ui->kombdo});           //Komb      --6--

    //od-do
    lines.push_back({ui->r2od, ui->r2R, ui->r2do});                 //sum R     --7--
    lines.push_back({ui->stl2od, ui->stl2R, ui->stl2do});           //sum STL   --8--
    lines.push_back({ui->dtr2od, ui->dtr2, ui->dtr2do});            //dt R      --9--
    lines.push_back({ui->dtstl2od, ui->dtstl2, ui->dtstl2do});      //dt STL    --10--
    lines.push_back({ui->dtRSTL2od, ui->dtRSTL2, ui->dtRSTL2do});   //dt R-STL  --11--
    lines.push_back({ui->HRXod, ui->HRXr, ui->HRXdo});              //hrx       --12--
    lines.push_back({ui->oddo_rozpetie});                           //rozpatie  --13--

    //cislovacky
    lines.push_back({ui->Pod, ui->P, ui->Pdo});                     //P         --14--
    lines.push_back({ui->Nod, ui->N, ui->Ndo});                     //N         --15--
    lines.push_back({ui->PRod, ui->PR, ui->PRdo});                  //PR        --16--
    lines.push_back({ui->Mcod, ui->Mc, ui->Mcdo});                  //MC        --17--
    lines.push_back({ui->Vcod, ui->Vc, ui->Vcdo});                  //VC        --18--
    lines.push_back({ui->c1_c9od, ui->c1_c9, ui->c1_c9do});         //c19       --19--
    lines.push_back({ui->C0od, ui->C0, ui->C0do});                  //c0        --20--
    lines.push_back({ui->cCod, ui->cC, ui->cCdo});                  //cC        --21--
    lines.push_back({ui->Ccod, ui->Cc, ui->Ccdo});                  //Cc        --22--
    lines.push_back({ui->CCod, ui->CC, ui->CCdo});                  //CC        --23--
    lines.push_back({ui->ZHod, ui->ZH, ui->ZHdo});                  //ZH        --24--
    lines.push_back({ui->mix_r, ui->mix_r1});                       //ZH "r"    --25--

    //sm, kk
    lines.push_back({ui->Smod, ui->Sm, ui->Smdo});                  //Sm        --26--
    lines.push_back({ui->Korod, ui->Kor, ui->Kordo});               //Kk        --27--

    //xtice
    lines.push_back({ui->x_tice1, ui->x_tice2, ui->x_tice3, ui->x_tice4, ui->x_tice5, ui->x_tice6, ui->x_tice7, ui->x_tice8, ui->x_tice9}); // --28--

    //pov, zak, ...
//    lines.push_back({});
//    lines.push_back({});
//    lines.push_back({});
//    lines.push_back({});
//    lines.push_back({});
}

void MainWindow::setStlNtice(QVector< QCheckBox* > &stlNtice){

    if(!stlNtice.isEmpty())
        stlNtice.clear();

    stlNtice.push_back({ui->n1});
    stlNtice.push_back({ui->n2});
    stlNtice.push_back({ui->n3});
    stlNtice.push_back({ui->n4});
    stlNtice.push_back({ui->n5});
    stlNtice.push_back({ui->n6});
    stlNtice.push_back({ui->n7});
    stlNtice.push_back({ui->n8});
    stlNtice.push_back({ui->n9});
    stlNtice.push_back({ui->n10});
    stlNtice.push_back({ui->n11});
    stlNtice.push_back({ui->n12});
    stlNtice.push_back({ui->n13});
    stlNtice.push_back({ui->n14});
    stlNtice.push_back({ui->n15});
    stlNtice.push_back({ui->n16});
    stlNtice.push_back({ui->n17});
    stlNtice.push_back({ui->n18});
    stlNtice.push_back({ui->n19});
    stlNtice.push_back({ui->n20});
    stlNtice.push_back({ui->n21});
    stlNtice.push_back({ui->n22});
    stlNtice.push_back({ui->n23});
    stlNtice.push_back({ui->n24});
    stlNtice.push_back({ui->n25});
    stlNtice.push_back({ui->n26});
    stlNtice.push_back({ui->n27});
    stlNtice.push_back({ui->n28});
    stlNtice.push_back({ui->n29});
    stlNtice.push_back({ui->n30});

}

uint MainWindow::getM(){
    return ui->spinBoxM->text().toUInt();
}

uint MainWindow::getN(){
    return ui->spinBoxN->text().toUInt();
}

void MainWindow::info(QString s){
    ui->Info->setText(s);
}

void MainWindow::last_line(){
}

void MainWindow::setLastLine(QStringList riadok){
    ui->datc_R->setText(riadok.join(" "));
}

void MainWindow::setUCcisloRiadok(QPair<unsigned, unsigned> UC){
    ui->UC->setText(QString::number(UC.first) + "(" + QString::number(UC.second) + ")");
}

void MainWindow::setArchiv(Archiv archiv){
    this->archiv.setArchiv(archiv);
}

void MainWindow::setHrxHHrx(HrxHHrx &hrxHHrx){
    if(!this->hrxHHrx.isEmpty())
        this->hrxHHrx.clear();
    this->hrxHHrx.swap(hrxHHrx);
}

void MainWindow::setHrxHHrxFiltrovane(HrxHHrx &hrxHHrx){
    if(!hrxHHrx_Filtrovane.isEmpty())
        hrxHHrx_Filtrovane.clear();
//    hrxHHrx_Filtrovane = hrxHHrx;
    hrxHHrx_Filtrovane.swap(hrxHHrx);

//    CSV csv;
//    QStringList header{"ZH \"r\"/\"r+1\"",
//                       "HRX pre r+1",
//                       "ΔHRX s \"r\"",
//                       "X-cisla \"r\"",
//                       "Pocet Kombi",
//                       "ƩROD-DO",
//                       "Pocet ƩROD-DO",
//                       "N-tice od-do",
//                       "Pocet N-tic",
//                       "X-tice od-do",
//                       "Pocet X-tic",
//                       "ƩSTLOD-DO od-do",
//                       "Pocet ƩSTLOD-DO",
//                       "ƩKombi od-do",
//                       "Pocet ƩKombi",
//                       "HHRX pre \"r+1\"",
//                       "ΔHHRX",
//                       "Pocet HHRX",
//                       "ƩR1-DO od-do",
//                       "Pocet ƩR1-DO",
//                       "ƩSTL1-DO od-do",
//                       "Pocet ƩSTL1-DO"
//                      };
//    csv += header;
//    for(auto &_hrx : hrxHHrx_Filtrovane.values()){
////        csv += _hrx.filtered();

//    }
//    QString path = pwd() + QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss") + "_Filter" + "/";
//    mkdir(path);
//    exportCsv(csv, path + "HrxHHrx_" + QTime::currentTime().toString("hms") +  + ".csv");
}

void MainWindow::setPhcisla(QPair<PHCisla, PHCisla> phcisla){
    phcisla1DO.setPHCisla(phcisla.first);
    phcislaODDO.setPHCisla(phcisla.second);
}

void MainWindow::initUI(){
    glimits = GLimits(getN(), getM());
    glimits.setLL(archiv.kombinacia());
    glimits.setDelty(archiv.dtR1(), archiv.dtSTL1(), archiv.dtROD(), archiv.dtSTLOD());
    glimits.setPHCisla(phcisla1DO, phcislaODDO);

    //unlock
    ui->lim_r->setEnabled(true);
    ui->lim_r1->setEnabled(true);
    ui->generate_mix->setEnabled(true);
    ui->show_limits->setEnabled(true);
    ui->generate_rplus1->setEnabled(true);
    ui->filter->setEnabled(true);
    ui->KolkoKombi->setEnabled(true);

    for(int i{0}; i < getN(); ++i)
        stlNtice[i]->setEnabled(true);
}

void MainWindow::running(bool state){

}

void MainWindow::on_read_file_clicked(){
    suborPath = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));

    if(suborPath.isEmpty()){
        info(QString("Nepodarilo sa nacitat subor ").append(filenameFromPath(suborPath)));
        return;
    }

    auto curentPath = path + filenameFromPath(suborPath) + "/";
    mkdir(curentPath);
    QDir::setCurrent(curentPath);
    setSuborName(suborPath);

//    qDebug() << pwd();

    QThread *t = new QThread;
    ArchivWrap *aw = new ArchivWrap(getN(), getM(), suborPath);

    connect(t, &QThread::started, aw, &ArchivWrap::process2);
    connect(t, &QThread::finished, t, &QThread::deleteLater);

    connect(aw, &ArchivWrap::finished, t, &QThread::quit);
    connect(aw, &ArchivWrap::finished, aw, &ArchivWrap::deleteLater);

    connect(aw, &ArchivWrap::finished, this, &MainWindow::initUI);
    connect(aw, &ArchivWrap::msg, this, &MainWindow::info);
    connect(aw, &ArchivWrap::setUCcisloRiadok, this, &MainWindow::setUCcisloRiadok);
    connect(aw, &ArchivWrap::setArchiv, this, &MainWindow::setArchiv);
    connect(aw, &ArchivWrap::setPhcisla, this, &MainWindow::setPhcisla);
    connect(aw, &ArchivWrap::setHrxHHrx, this, &MainWindow::setHrxHHrx);
    connect(aw, &ArchivWrap::setLastLine, this, &MainWindow::setLastLine);

    aw->moveToThread(t);
    t->start();
}

void MainWindow::on_filter_clicked(){

    if(suborPath.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(hrxHHrx_Filtrovane.isEmpty())
        hrxHHrx_Filtrovane = hrxHHrx;

    set_limits();
    auto settings = glimits.getSettings();
    write_protocol(pwd() + "prokol_Filter.txt", settings);



    auto phcislaODDO1 = plus1(phcislaODDO, getN(), getM());
    auto glimitsCP = glimits;
    glimitsCP.setPHCisla(phcisla1DO, phcislaODDO1);

    QThread *t = new QThread;
    Vystup *v = new Vystup();
    Generator *gw = new Generator(getN(), getM(), hrxHHrx_Filtrovane, glimitsCP, v, 2);
    gw->setPhcisla({phcisla1DO, phcislaODDO1});
    gw->setPhcislaFilter(phcislaODDO);

    connect(t, &QThread::started, gw, &Generator::start);
    connect(t, &QThread::finished, t, &QThread::deleteLater);

    connect(gw, &Generator::setHrxHHrx, this, &MainWindow::setHrxHHrxFiltrovane);
    connect(gw, &Generator::finished, t, &QThread::quit);
    connect(gw, &Generator::finished, gw, &Generator::deleteLater);
    connect(gw, &Generator::finished, v, &Vystup::deleteLater);
    connect(gw, &Generator::msg, this, &MainWindow::info);

    gw->moveToThread(t);
    t->start();
}

void MainWindow::on_generate_mix_clicked(){

    if(suborPath.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(hrxHHrx_Filtrovane.isEmpty())
        hrxHHrx_Filtrovane = hrxHHrx;

    set_limits();
    auto settings = glimits.getSettings();
    write_protocol(pwd() + "prokol_ZH.txt", settings);

    QThread *t = new QThread;
    QThread *t2 = new QThread;

    auto glimitsCP = glimits;
    glimitsCP.setPHCisla(phcisla1DO, plus1(phcislaODDO, getN(), getM()));
    Vystup *v = new Vystup(getN(), getM(), phcisla1DO, phcislaODDO, archiv);
    Generator *gw = new Generator(getN(), getM(), hrxHHrx_Filtrovane, glimitsCP, v, 1);

    connect(t2, &QThread::finished, t2, &QThread::deleteLater);
    connect(v, &Vystup::msg, this, &MainWindow::info);
    connect(gw, &Generator::finished, t2, &QThread::quit);
    connect(gw, &Generator::finished, v, &Vystup::deleteLater);

    connect(t, &QThread::started, gw, &Generator::start);
    connect(t, &QThread::finished, t, &QThread::deleteLater);

    connect(gw, &Generator::finished, t, &QThread::quit);
    connect(gw, &Generator::finished, gw, &Generator::deleteLater);
    connect(gw, &Generator::msg, this, &MainWindow::info);

    gw->moveToThread(t);
    v->moveToThread(t2);
    t->start();
    t2->start();
}

void MainWindow::on_generate_rplus1_clicked(){

    if(suborPath.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(hrxHHrx_Filtrovane.isEmpty())
        hrxHHrx_Filtrovane = hrxHHrx;

    set_limits();
    auto settings = glimits.getSettings();
    write_protocol(pwd() + "prokol_Rplus1.txt", settings);

    QThread *t = new QThread;
    QThread *t2 = new QThread;

    auto glimitsCP = glimits;
    glimitsCP.setPHCisla(phcisla1DO, plus1(phcislaODDO, getN(), getM()));
    Vystup *v = new Vystup(getN(), getM(), phcisla1DO, phcislaODDO, archiv);
    Generator *gw = new Generator(getN(), getM(), hrxHHrx_Filtrovane, glimitsCP, v);

//    connect(t2, &QThread::started, gw, &Generator::start);

    connect(t2, &QThread::finished, t2, &QThread::deleteLater);
    connect(v, &Vystup::msg, this, &MainWindow::info);
    connect(gw, &Generator::finished, t2, &QThread::quit);
    connect(gw, &Generator::finished, v, &Vystup::deleteLater);

    connect(t, &QThread::started, gw, &Generator::start);
    connect(t, &QThread::finished, t, &QThread::deleteLater);

    connect(gw, &Generator::finished, t, &QThread::quit);
    connect(gw, &Generator::finished, gw, &Generator::deleteLater);
    connect(gw, &Generator::msg, this, &MainWindow::info);

    gw->moveToThread(t);
    v->moveToThread(t2);
    t->start();
    t2->start();
}

void MainWindow::show_btns(){
}

void MainWindow::on_show_limits_clicked(){
    ui->r1R->setText(doubleToQString(archiv.R1()));
    ui->stl1R->setText(doubleToQString(archiv.STL1()));
    ui->r2R->setText(doubleToQString(archiv.ROD()));
    ui->stl2R->setText(doubleToQString(archiv.STLOD()));
    ui->HHRXr->setText(doubleToQString(archiv.HHRX()));
    ui->HRXr->setText(doubleToQString(archiv.HRX()));
    ui->kombR->setText(doubleToQString(archiv.KombinaciaSucet()));

    ui->dtr1->setText(doubleToQString(archiv.dtR1()));
    ui->dtstl1->setText(doubleToQString(archiv.dtSTL1()));
    ui->dtRSTL1->setText(doubleToQString(archiv.dtR1STL1()));

    ui->dtr2->setText(doubleToQString(archiv.dtROD()));
    ui->dtstl2->setText(doubleToQString(archiv.dtSTLOD()));
    ui->dtRSTL2->setText(doubleToQString(archiv.dtRODSTLOD()));

    ui->P->setText(uintToQString(archiv.P()));
    ui->N->setText(uintToQString(archiv.N()));
    ui->PR->setText(uintToQString(archiv.PR()));

    ui->Mc->setText(uintToQString(archiv.Mc()));
    ui->Vc->setText(uintToQString(archiv.Vc()));
    ui->c1_c9->setText(uintToQString(archiv.C19()));

    ui->C0->setText(uintToQString(archiv.C0()));
    ui->cC->setText(uintToQString(archiv.cC()));
    ui->Cc->setText(uintToQString(archiv.Cc()));

    ui->CC->setText(uintToQString(archiv.CC()));
    ui->ZH->setText(uintToQString(archiv.ZH()));

    ui->Sm->setText(doubleToQString(archiv.Sm()));
    ui->Kor->setText(doubleToQString(archiv.Kk()));

    ui->n_tice->setText(nticaToQString(archiv.getNtica()));

    QStringList xtice = xticaToQString(archiv.getXtica()).split(" ");

    if(xtice.size() < 9){
        while(xtice.size() != 9)
            xtice.append("");
    }
    ui->x_tice1->setText(xtice[0]);
    ui->x_tice2->setText(xtice[1]);
    ui->x_tice3->setText(xtice[2]);
    ui->x_tice4->setText(xtice[3]);
    ui->x_tice5->setText(xtice[4]);
    ui->x_tice6->setText(xtice[5]);
    ui->x_tice7->setText(xtice[6]);
    ui->x_tice8->setText(xtice[7]);
    ui->x_tice9->setText(xtice[8]);

}

void MainWindow::on_lim_r_clicked(){

    ui->r1od->setText(doubleToQString(phcisla1DO.minHodnotaVRiadku(), 12));
    ui->r1do->setText(doubleToQString(phcisla1DO.maxHodnotaVRiadku(), 12));
    ui->stl1od->setText(doubleToQString(phcisla1DO.minHodnotaVStlpci(), 12));
    ui->stl1do->setText(doubleToQString(phcisla1DO.maxHodnotaVStlpci(), 12));
    ui->kombod->setText(uintToQString(sucetMin(getN())));
    ui->kombdo->setText(uintToQString(sucetMax(getN(), getM())));
    ui->r2od->setText(doubleToQString(phcislaODDO.minHodnotaVRiadku(), 12));
    ui->r2do->setText(doubleToQString(phcislaODDO.maxHodnotaVRiadku(), 12));
    ui->stl2od->setText(doubleToQString(phcislaODDO.minHodnotaVStlpci(), 12));
    ui->stl2do->setText(doubleToQString(phcislaODDO.maxHodnotaVStlpci(), 12));
}

void MainWindow::on_lim_r1_clicked(){

    auto phcisla1DO1 = plus1(phcisla1DO, getN(), getM());
    auto phcislaODDO1 = plus1(phcislaODDO, getN(), getM());

    ui->r1od->setText(doubleToQString(phcisla1DO1.minHodnotaVRiadku(), 12));
    ui->r1do->setText(doubleToQString(phcisla1DO1.maxHodnotaVRiadku(), 12));
    ui->stl1od->setText(doubleToQString(phcisla1DO1.minHodnotaVStlpci(), 12));
    ui->stl1do->setText(doubleToQString(phcisla1DO1.maxHodnotaVStlpci(), 12));
    ui->kombod->setText(uintToQString(sucetMin(getN())));
    ui->kombdo->setText(uintToQString(sucetMax(getN(), getM())));
    ui->r2od->setText(doubleToQString(phcislaODDO1.minHodnotaVRiadku(), 12));
    ui->r2do->setText(doubleToQString(phcislaODDO1.maxHodnotaVRiadku(), 12));
    ui->stl2od->setText(doubleToQString(phcislaODDO1.minHodnotaVStlpci(), 12));
    ui->stl2do->setText(doubleToQString(phcislaODDO1.maxHodnotaVStlpci(), 12));
}

//#include "QDesktopServices"

void MainWindow::on_lim_zh_clicked(){
//    QDesktopServices::openUrl(QUrl("file://" + pwd() + "Archiv_" + filenameFromPath(suborPath) + ".csv"));
}

bool MainWindow::min2(){
    return true;
}

bool MainWindow::set_limits(){

    QStringList settings;

    for(auto &l : lines){
        for(auto &setting : l)
            settings += setting->text();
    }
    settings += ui->Povinne->text();
    settings += ui->PovinneSTL->text();
    settings += ui->Zakazane->text();
    settings += ui->ZakazaneSTL->text();
    settings += ui->n_tice->text();

    on_del_all_clicked(1);

    for(auto &l : lines){
        for(auto &setting : l){
            if(!settings.front().isEmpty())
                setting->setText(settings.takeFirst());
            else
                settings.takeFirst();
        }
    }
    if(!settings.front().isEmpty())
        ui->Povinne->setText(settings.takeFirst());
    else
        settings.takeFirst();

    if(!settings.front().isEmpty())
        ui->PovinneSTL->setText(settings.takeFirst());
    else
        settings.takeFirst();

    if(!settings.front().isEmpty())
        ui->Zakazane->setText(settings.takeFirst());
    else
        settings.takeFirst();

    if(!settings.front().isEmpty())
        ui->ZakazaneSTL->setText(settings.takeFirst());
    else
        settings.takeFirst();

    if(!settings.front().isEmpty())
        ui->n_tice->setText(settings.takeFirst());
    else
        settings.takeFirst();



    if(!ui->x_tice1->text().isEmpty()){
        QString xstr;

        xstr.append(ui->x_tice1->text()).append("|");

        if(!ui->x_tice2->text().isEmpty())
            xstr.append(ui->x_tice2->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice3->text().isEmpty())
            xstr.append(ui->x_tice3->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice4->text().isEmpty())
            xstr.append(ui->x_tice4->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice5->text().isEmpty())
            xstr.append(ui->x_tice5->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice6->text().isEmpty())
            xstr.append(ui->x_tice6->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice7->text().isEmpty())
            xstr.append(ui->x_tice7->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice8->text().isEmpty())
            xstr.append(ui->x_tice8->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice9->text().isEmpty())
            xstr.append(ui->x_tice9->text()).append("|");
        else
            xstr.append("0 ");

        glimits.setXtice(xstr);

    }



//    // nticeStl
    if(!ui->n_tice->text().isEmpty()){
        QVector<uint> ntice_stl;

        for(int i{0}; i<getN() && i<30; ++i){
            if(stlNtice[i]->isChecked()) ntice_stl.push_back(1);
            else ntice_stl.push_back(0);
        }

        QStringList l = ui->n_tice->text().split(" ");
        unsigned sum = 0, sum2=0;

        for(int i=1; i<l.size() && i<=getN(); i++){
            sum += l[i].toUInt()*(i+1);
//            ntice.push_back((num)l[i-1].toUInt());
        }

        foreach (const int &i, ntice_stl) {
            if(i == 1)
                sum2 += 1;
        }
        if(sum != sum2){
            // zadane zle
        }
        else{
            glimits.setNticeStl(ntice_stl);
        }
    }

    return true;
}



void MainWindow::on_mix_r_textChanged(const QString &arg1)
{
    if(arg1.isEmpty()){
        ui->mix_r1->clear();
        glimits.unsetFn_Od(GLimits::Fn::ZH);
        glimits.unsetFn_Do(GLimits::Fn::ZH);
        return;
    }

    if(arg1.toInt() >= getN()){
        glimits.setFn_Od(GLimits::Fn::ZH, getN() - 1);
        glimits.setFn_Do(GLimits::Fn::ZH, getN() - 1);
        ui->mix_r->setText(QString::number(getN() - 1));
        ui->mix_r1->setText(QString::number(1));
    }
    else{
        glimits.setFn_Od(GLimits::Fn::ZH, arg1.toInt());
        glimits.setFn_Do(GLimits::Fn::ZH, arg1.toInt());
        ui->mix_r1->setText(QString::number(getN() - arg1.toInt()));
    }
}
//sum R     --0--
//sum STL   --1--
//dt R      --2--
//dt STL    --3--
//dt R-STL  --4--
//hhrx      --5--
//Komb      --6--
//sum R     --7--
//sum STL   --8--
//dt R      --9--
//dt STL    --10--
//dt R-STL  --11--
//hrx       --12--
//rozpatie  --13--
//P         --14--
//N         --15--
//PR        --16--
//MC        --17--
//VC        --18--
//c19       --19--
//c0        --20--
//cC        --21--
//Cc        --22--
//CC        --23--
//ZH        --24--
//ZH "r"    --25--
//Sm        --26--
//Kk        --27--
void MainWindow::swapEnabled(QLineEdit* a, QLineEdit *stred, QLineEdit* b){
    if(!a->isEnabled()){
        b->setEnabled(false);
        a->setEnabled(true);

        auto text = a->text();
        a->clear();
        a->setText(text);

        auto textStred = stred->text();
        stred->clear();
        stred->setText(textStred);
    }
}

void MainWindow::on_r1gl_clicked(){ swapEnabled(lines[0][0], lines[0][1], lines[0][2]); }
void MainWindow::on_r1gl_2_clicked(){ swapEnabled(lines[0][2], lines[0][1], lines[0][0]); }
void MainWindow::on_stl1gl_clicked(){swapEnabled(lines[1][0], lines[1][1], lines[1][2]);}
void MainWindow::on_stl1gl_2_clicked(){swapEnabled(lines[1][2], lines[1][1], lines[1][0]);}
void MainWindow::on_dtr1gl_clicked(){swapEnabled(lines[2][0], lines[2][1], lines[2][2]);}
void MainWindow::on_dtr1gl2_clicked(){swapEnabled(lines[2][2], lines[2][1], lines[2][0]);}
void MainWindow::on_dtslt1gl_clicked(){swapEnabled(lines[3][0], lines[3][1], lines[3][2]);}
void MainWindow::on_dtstl1gl2_clicked(){swapEnabled(lines[3][2], lines[3][1], lines[3][0]);}
void MainWindow::on_dtRSTL1gl_clicked(){swapEnabled(lines[4][0], lines[4][1], lines[4][2]);}
void MainWindow::on_dtRSTL1gl2_clicked(){swapEnabled(lines[4][2], lines[4][1], lines[4][0]);}
void MainWindow::on_HHRXgl_clicked(){swapEnabled(lines[5][0], lines[5][1], lines[5][2]);}
void MainWindow::on_HHRXgl2_clicked(){swapEnabled(lines[5][2], lines[5][1], lines[5][0]);}
void MainWindow::on_kombgl_clicked(){swapEnabled(lines[6][0], lines[6][1], lines[6][2]);}
void MainWindow::on_kombgl_2_clicked(){swapEnabled(lines[6][2], lines[6][1], lines[6][0]);}

void MainWindow::on_r2gl_clicked(){swapEnabled(lines[7][0], lines[7][1], lines[7][2]);}
void MainWindow::on_r2gl_2_clicked(){swapEnabled(lines[7][2], lines[7][1], lines[7][0]);}
void MainWindow::on_stl2gl_clicked(){swapEnabled(lines[8][0], lines[8][1], lines[8][2]);}
void MainWindow::on_stl2gl_2_clicked(){swapEnabled(lines[8][2], lines[8][1], lines[8][0]);}
void MainWindow::on_dtr2gl_clicked(){swapEnabled(lines[9][0], lines[9][1], lines[9][2]);}
void MainWindow::on_dtr2gl2_clicked(){swapEnabled(lines[9][2], lines[9][1], lines[9][0]);}
void MainWindow::on_dtstl2gl_clicked(){swapEnabled(lines[10][0], lines[10][1], lines[10][2]);}
void MainWindow::on_dtstl2gl2_clicked(){swapEnabled(lines[10][2], lines[10][1], lines[10][0]);}
void MainWindow::on_dtRSTL2gl_clicked(){swapEnabled(lines[11][0], lines[11][1], lines[11][2]);}
void MainWindow::on_dtRSTL2gl2_clicked(){swapEnabled(lines[11][2], lines[11][1], lines[11][0]);}
void MainWindow::on_HRXgl_clicked(){swapEnabled(lines[12][0], lines[12][1], lines[12][2]);}
void MainWindow::on_HRXgl2_clicked(){swapEnabled(lines[12][2], lines[12][1], lines[12][0]);}

void MainWindow::on_pgl_clicked(){swapEnabled(lines[14][0], lines[14][1], lines[14][2]);}
void MainWindow::on_pgl_2_clicked(){swapEnabled(lines[14][2], lines[14][1], lines[14][0]);}
void MainWindow::on_ngl_clicked(){swapEnabled(lines[15][0], lines[15][1], lines[15][2]);}
void MainWindow::on_ngl_2_clicked(){swapEnabled(lines[15][2], lines[15][1], lines[15][0]);}
void MainWindow::on_prgl_clicked(){swapEnabled(lines[16][0], lines[16][1], lines[16][2]);}
void MainWindow::on_prgl_2_clicked(){swapEnabled(lines[16][2], lines[16][1], lines[16][0]);}
void MainWindow::on_mcgl_clicked(){swapEnabled(lines[17][0], lines[17][1], lines[17][2]);}
void MainWindow::on_mcgl_2_clicked(){swapEnabled(lines[17][2], lines[17][1], lines[17][0]);}
void MainWindow::on_vcgl_clicked(){swapEnabled(lines[18][0], lines[18][1], lines[18][2]);}
void MainWindow::on_vcgl_2_clicked(){swapEnabled(lines[18][2], lines[18][1], lines[18][0]);}
void MainWindow::on_c1c9gl_clicked(){swapEnabled(lines[19][0], lines[19][1], lines[19][2]);}
void MainWindow::on_c1c9gl_2_clicked(){swapEnabled(lines[19][2], lines[19][1], lines[19][0]);}
void MainWindow::on_c0gl_clicked(){swapEnabled(lines[20][0], lines[20][1], lines[20][2]);}
void MainWindow::on_c0gl_2_clicked(){swapEnabled(lines[20][2], lines[20][1], lines[20][0]);}
void MainWindow::on_cCgl_clicked(){swapEnabled(lines[21][0], lines[21][1], lines[21][2]);}
void MainWindow::on_cCgl_2_clicked(){swapEnabled(lines[21][2], lines[21][1], lines[21][0]);}
void MainWindow::on_Ccgl_clicked(){swapEnabled(lines[22][0], lines[22][1], lines[22][2]);}
void MainWindow::on_Ccgl_2_clicked(){swapEnabled(lines[22][2], lines[22][1], lines[22][0]);}
void MainWindow::on_CCgl_clicked(){swapEnabled(lines[23][0], lines[23][1], lines[23][2]);}
void MainWindow::on_CCgl_2_clicked(){swapEnabled(lines[23][2], lines[23][1], lines[23][0]);}
void MainWindow::on_zhgl_clicked(){swapEnabled(lines[24][0], lines[24][1], lines[24][2]);}
void MainWindow::on_zhgl_2_clicked(){swapEnabled(lines[24][2], lines[24][1], lines[24][0]);}
void MainWindow::on_smgl_clicked(){swapEnabled(lines[26][0], lines[26][1], lines[26][2]);}
void MainWindow::on_smgl_2_clicked(){swapEnabled(lines[26][2], lines[26][1], lines[26][0]);}
void MainWindow::on_korgl_clicked(){swapEnabled(lines[27][0], lines[27][1], lines[27][2]);}
void MainWindow::on_korgl_2_clicked(){swapEnabled(lines[27][2], lines[27][1], lines[27][0]);}


void MainWindow::on_del_all_clicked(int arg){
    for(auto line : lines)
        for(auto i : line)
            i->clear();
    on_del_povinne_clicked();
    on_del_povinneSTL_clicked();
    on_del_zakazaneSTL_clicked();
    on_del_zakazane_clicked();
    on_del_Ntice_clicked();
    if (arg == 0)
        on_del_Ntice_2_clicked();

    for(uint i = (uint)GLimits::Fn::START + 1; i < (uint)GLimits::Fn::SIZE; ++i){
        glimits.unsetFn_Do((GLimits::Fn)i);
        glimits.unsetFn_Od((GLimits::Fn)i);
    }
    glimits.unsetNtice();
    glimits.unsetNticeStl();
    glimits.unsetPovinne();
    glimits.unsetPovinneSTL();
    glimits.unsetXtice();
    glimits.unsetZakazane();
    glimits.unsetZakazaneSTL();
}

void MainWindow::on_del_r1_clicked(){ for(auto i : lines[0]){ i->clear(); } }
void MainWindow::on_del_stl1_clicked(){ for(auto i : lines[1]){ i->clear(); } }
void MainWindow::on_del_sum_komb_clicked(){ for(auto i : lines[6]){ i->clear(); } }
void MainWindow::on_del_rod_clicked(){ for(auto i : lines[7]){ i->clear(); } }
void MainWindow::on_del_stlod_clicked(){ for(auto i : lines[8]){ i->clear(); } }
void MainWindow::on_del_dtr1_clicked(){for(auto i : lines[2]){ i->clear(); }}
void MainWindow::on_del_dtSTL1_clicked(){for(auto i : lines[3]){ i->clear(); }}
void MainWindow::on_del_dtRSTL1_clicked(){for(auto i : lines[4]){ i->clear(); }}
void MainWindow::on_del_dtr2_clicked(){for(auto i : lines[9]){ i->clear(); }}
void MainWindow::on_del_dtstl2_clicked(){for(auto i : lines[10]){ i->clear(); }}
void MainWindow::on_del_dtRSTL2_clicked(){for(auto i : lines[11]){ i->clear(); }}
void MainWindow::on_del_P_clicked(){ for(auto i : lines[14]){ i->clear(); } }
void MainWindow::on_del_Mc_clicked(){ for(auto i : lines[17]){ i->clear(); } }
void MainWindow::on_del_c1c9_clicked() { for(auto i : lines[19]){ i->clear(); } }
void MainWindow::on_del_N_clicked(){ for(auto i : lines[15]){ i->clear(); } }
void MainWindow::on_del_Cc_clicked() { for(auto i : lines[22]){ i->clear(); } }
void MainWindow::on_del_C0_clicked() { for(auto i : lines[20]){ i->clear(); } }
void MainWindow::on_del_PR_clicked(){ for(auto i : lines[16]){ i->clear(); } }
void MainWindow::on_del_Vc_clicked(){ for(auto i : lines[18]){ i->clear(); } }
void MainWindow::on_del_cC_clicked(){ for(auto i : lines[21]){ i->clear(); } }
void MainWindow::on_del_ZH_clicked(){ for(auto i : lines[24]){ i->clear(); } }
void MainWindow::on_del_CC_clicked(){for(auto i : lines[23]){ i->clear(); } }
void MainWindow::on_del_Sm_clicked(){for(auto i : lines[26]){ i->clear(); } }
void MainWindow::on_del_Kor_clicked(){for(auto i : lines[27]){ i->clear(); }}
void MainWindow::on_del_povinne_clicked(){ui->Povinne->clear();}
void MainWindow::on_del_zakazane_clicked(){ui->Zakazane->clear();}
void MainWindow::on_del_Ntice_clicked(){ui->n_tice->clear();}
void MainWindow::on_del_Xtice_clicked(){for(auto i : lines[28]){ i->clear(); }}
void MainWindow::on_del_Ntice_2_clicked(){for(auto i : stlNtice) i->setChecked(false); }
void MainWindow::on_del_povinneSTL_clicked(){ui->PovinneSTL->clear();}
void MainWindow::on_del_zakazaneSTL_clicked(){ui->ZakazaneSTL->clear();}
void MainWindow::on_del_HHRX_clicked(){ for(auto i : lines[5]){ i->clear(); }}
void MainWindow::on_del_HRX_clicked(){ for(auto i : lines[12]) i->clear(); }

void MainWindow::on_KolkoKombi_clicked(){
    if(!hrxHHrx_Filtrovane.isEmpty())
        hrxHHrx_Filtrovane.clear();
    hrxHHrx_Filtrovane = this->hrxHHrx;
    info("Reset ok");
}

void MainWindow::setLimit(GLimits::Fn fn, double d, OD_DO od_do){
    if(od_do == OD_DO::Od)
        glimits.setFn_Od(fn, d);
    else if(od_do == OD_DO::Do)
        glimits.setFn_Do(fn, d);
}

void MainWindow::unsetLimit(GLimits::Fn fn, OD_DO od_do){
    if(od_do == OD_DO::Od)
        glimits.unsetFn_Od(fn);
    else if(od_do == OD_DO::Do)
        glimits.unsetFn_Do(fn);
}

bool MainWindow::changeHelper(QLineEdit *kliknuty, QString arg, double &val, double min, double max){
    val = arg.replace(",",".").toDouble();
    if(!arg.isEmpty()){

        if(arg.size() < 2 && arg[0] == QChar('-'))
            return false;
        if(arg[arg.size() - 1] == '.')
            return false;
        if(arg[arg.size() - 1] == 'e')
            return false;
        if(arg[arg.size() - 1] == 'E')
            return false;
        if(arg[arg.size() - 1] == '-')
            return false;


        if(val > max)
            val = max;
        else if(val < min)
            val = min;
        if(kliknuty != nullptr)
            kliknuty->setText(QString::number(val).replace(".", ","));
    }
    else {
        return false;
    }
    return true;
}

int MainWindow::changeODDO(QLineEdit *kliknuty, const QString &arg, QLineEdit *p_od, QLineEdit *p_do, int n){
    double val;
    changeHelper(kliknuty, arg, val, 0, n);
    if(p_od->isEnabled()){
        if(arg.isEmpty()){
            p_od->clear();
//            val = -1;
        }
        else{
            p_od->setText(QString::number(n - val));
        }
    }
    else{
        if(arg.isEmpty()){
            p_do->clear();
//            val = -1;
        }
        else{
            p_do->setText(QString::number(n - val));
        }
    }
    return val;
}

void MainWindow::on_Pod_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Pod, arg1, ui->Ndo, ui->N, getN());
    if(ret >= 0)
        glimits.setFn_Od(GLimits::Fn::P, ret);
    else
        glimits.unsetFn_Od(GLimits::Fn::P);
}

void MainWindow::on_P_textChanged(const QString &arg1){
    if(ui->Pod->isEnabled()){
        int ret = changeODDO(ui->P, arg1, ui->Nod, ui->N, getN());
        if(ret >= 0)
            glimits.setFn_Do(GLimits::Fn::P, ret);
        else
            glimits.unsetFn_Do(GLimits::Fn::P);
    }
    else{
        int ret = changeODDO(ui->P, arg1, ui->Ndo, ui->N, getN());
        if(ret >= 0)
            glimits.setFn_Od(GLimits::Fn::P, ret);
        else
            glimits.unsetFn_Od(GLimits::Fn::P);
    }
}

void MainWindow::on_Pdo_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Pdo, arg1, ui->Nod, ui->N, getN());
    if(ret >= 0)
        glimits.setFn_Do(GLimits::Fn::P, ret);
    else
        glimits.unsetFn_Do(GLimits::Fn::P);
}

void MainWindow::on_Nod_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Nod, arg1, ui->Pdo, ui->P, getN());
    if(ret >= 0)
        glimits.setFn_Od(GLimits::Fn::N, ret);
    else
        glimits.unsetFn_Od(GLimits::Fn::N);
}

void MainWindow::on_N_textChanged(const QString &arg1){
    if(ui->Nod->isEnabled()){
        int ret = changeODDO(ui->N, arg1, ui->Pod, ui->P, getN());
        if(ret >= 0)
            glimits.setFn_Do(GLimits::Fn::N, ret);
        else
            glimits.unsetFn_Do(GLimits::Fn::N);
    }
    else{
        int ret = changeODDO(ui->N, arg1, ui->Pdo, ui->P, getN());
        if(ret >= 0)
            glimits.setFn_Od(GLimits::Fn::N, ret);
        else
            glimits.unsetFn_Od(GLimits::Fn::N);
    }
}

void MainWindow::on_Ndo_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Ndo, arg1, ui->Pod, ui->P, getN());
    if(ret >= 0)
        glimits.setFn_Do(GLimits::Fn::N, ret);
    else
        glimits.unsetFn_Do(GLimits::Fn::N);
}

void MainWindow::on_Mcod_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Mcod, arg1, ui->Vcdo, ui->Vc, getN());
    if(ret >= 0)
        glimits.setFn_Od(GLimits::Fn::Mc, ret);
    else
        glimits.unsetFn_Od(GLimits::Fn::Mc);
}

void MainWindow::on_Mc_textChanged(const QString &arg1){
    if(ui->Mcod->isEnabled()){
        int ret = changeODDO(ui->Mc, arg1, ui->Vcod, ui->Vc, getN());
        if(ret >= 0)
            glimits.setFn_Do(GLimits::Fn::Mc, ret);
        else
            glimits.unsetFn_Do(GLimits::Fn::Mc);
    }
    else{
        int ret = changeODDO(ui->Mc, arg1, ui->Vcdo, ui->Vc, getN());
        if(ret >= 0)
            glimits.setFn_Od(GLimits::Fn::Mc, ret);
        else
            glimits.unsetFn_Od(GLimits::Fn::Mc);
    }
}

void MainWindow::on_Mcdo_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Mcdo, arg1, ui->Vcod, ui->Vc, getN());
    if(ret >= 0)
        glimits.setFn_Do(GLimits::Fn::Mc, ret);
    else
        glimits.unsetFn_Do(GLimits::Fn::Mc);
}

void MainWindow::on_Vcod_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Vcod, arg1, ui->Mcdo, ui->Mc, getN());
    if(ret >= 0)
        glimits.setFn_Od(GLimits::Fn::Vc, ret);
    else
        glimits.unsetFn_Od(GLimits::Fn::Vc);
}

void MainWindow::on_Vc_textChanged(const QString &arg1){
    if(ui->Vcod->isEnabled()){
        int ret = changeODDO(ui->Vc, arg1, ui->Mcod, ui->Mc, getN());
        if(ret >= 0)
            glimits.setFn_Do(GLimits::Fn::Vc, ret);
        else
            glimits.unsetFn_Do(GLimits::Fn::Vc);
    }
    else{
        int ret = changeODDO(ui->Vc, arg1, ui->Mcdo, ui->Mc, getN());
        if(ret >= 0)
            glimits.setFn_Od(GLimits::Fn::Vc, ret);
        else
            glimits.unsetFn_Od(GLimits::Fn::Vc);
    }
}

void MainWindow::on_Vcdo_textChanged(const QString &arg1){
    int ret = changeODDO(ui->Vcdo, arg1, ui->Mcod, ui->Mc, getN());
    if(ret >= 0)
        glimits.setFn_Do(GLimits::Fn::Vc, ret);
    else
        glimits.unsetFn_Do(GLimits::Fn::Vc);
}

void MainWindow::changeOd(QLineEdit *Od, GLimits::Fn fn, const QString &arg, double min, double max){
    double ret;
    bool ok = changeHelper(Od, arg, ret, min, max);
    if(ok)
        glimits.setFn_Od(fn, ret);
    else
        glimits.unsetFn_Od(fn);
}

void MainWindow::changeDo(QLineEdit *Do, GLimits::Fn fn, const QString &arg, double min, double max){
    double ret;
    bool ok = changeHelper(Do, arg, ret, min, max);
    if(ok)
        glimits.setFn_Do(fn, ret);
    else
        glimits.unsetFn_Do(fn);
}

void MainWindow::changeStred(QLineEdit *s, QLineEdit *Od, GLimits::Fn fn, const QString &arg, double min, double max){
    double ret;
    bool ok = changeHelper(s, arg, ret, min, max);
    if(Od->isEnabled()){
        if(ok)
            glimits.setFn_Do(fn, ret);
        else
            glimits.unsetFn_Do(fn);
    }
    else{
        if(ok)
            glimits.setFn_Od(fn, ret);
        else
            glimits.unsetFn_Od(fn);
    }
}

void MainWindow::on_PRod_textChanged(const QString &arg1){
    changeOd(ui->PRod, GLimits::Fn::PR, arg1, 0, getN());
}

void MainWindow::on_PR_textChanged(const QString &arg1){
    changeStred(ui->PR, ui->PRod, GLimits::Fn::PR, arg1, 0, getN());
}

void MainWindow::on_PRdo_textChanged(const QString &arg1){
    changeDo(ui->PRdo, GLimits::Fn::PR, arg1, 0, getN());
}

void MainWindow::on_c1_c9od_textChanged(const QString &arg1){
    changeOd(ui->c1_c9od, GLimits::Fn::c19, arg1, 0, getN());
}

void MainWindow::on_c1_c9_textChanged(const QString &arg1){
    changeStred(ui->c1_c9, ui->c1_c9od, GLimits::Fn::c19, arg1, 0, getN());
}

void MainWindow::on_c1_c9do_textChanged(const QString &arg1){
    changeDo(ui->c1_c9do, GLimits::Fn::c19, arg1, 0, getN());
}

void MainWindow::on_C0od_textChanged(const QString &arg1){
    changeOd(ui->C0od, GLimits::Fn::c0, arg1, 0, getN());
}

void MainWindow::on_C0_textChanged(const QString &arg1){
    changeStred(ui->C0, ui->C0od, GLimits::Fn::c0, arg1, 0, getN());
}

void MainWindow::on_C0do_textChanged(const QString &arg1){
    changeDo(ui->C0do, GLimits::Fn::c0, arg1, 0, getN());
}

void MainWindow::on_cCod_textChanged(const QString &arg1){
    changeOd(ui->cCod, GLimits::Fn::cC, arg1, 0, getN());
}

void MainWindow::on_cC_textChanged(const QString &arg1){
    changeStred(ui->cC, ui->cCod, GLimits::Fn::cC, arg1, 0, getN());
}

void MainWindow::on_cCdo_textChanged(const QString &arg1){
    changeDo(ui->cCdo, GLimits::Fn::cC, arg1, 0, getN());
}

void MainWindow::on_Ccod_textChanged(const QString &arg1){
    changeOd(ui->Ccod, GLimits::Fn::Cc, arg1, 0, getN());
}

void MainWindow::on_Cc_textChanged(const QString &arg1){
    changeStred(ui->Cc, ui->Ccod, GLimits::Fn::Cc, arg1, 0, getN());
}

void MainWindow::on_Ccdo_textChanged(const QString &arg1){
    changeDo(ui->Ccdo, GLimits::Fn::Cc, arg1, 0, getN());
}

void MainWindow::on_CCod_textChanged(const QString &arg1){
    changeOd(ui->CCod, GLimits::Fn::CC, arg1, 0, getN());
}

void MainWindow::on_CC_textChanged(const QString &arg1){
    changeStred(ui->CC, ui->CCod, GLimits::Fn::CC, arg1, 0, getN());
}

void MainWindow::on_CCdo_textChanged(const QString &arg1){
    changeDo(ui->CCdo, GLimits::Fn::CC, arg1, 0, getN());
}

void MainWindow::on_ZHod_textChanged(const QString &arg1){
    changeOd(ui->ZHod, GLimits::Fn::ZH, arg1, 0, getN() - 1);
}

void MainWindow::on_ZH_textChanged(const QString &arg1){
    changeStred(ui->ZH, ui->ZHod, GLimits::Fn::ZH, arg1, 0, getN() - 1);
}

void MainWindow::on_ZHdo_textChanged(const QString &arg1){
    changeDo(ui->ZHdo, GLimits::Fn::ZH, arg1, 0, getN() - 1);
}
//===
void MainWindow::on_Smod_textChanged(const QString &arg1){
    changeOd(nullptr, GLimits::Fn::Sm, arg1);
}

void MainWindow::on_Sm_textChanged(const QString &arg1){
    changeStred(nullptr, ui->Smod, GLimits::Fn::Sm, arg1);
}

void MainWindow::on_Smdo_textChanged(const QString &arg1){
    changeDo(nullptr, GLimits::Fn::Sm, arg1);
}

void MainWindow::on_Korod_textChanged(const QString &arg1){
    changeOd(nullptr, GLimits::Fn::Kk, arg1);
}

void MainWindow::on_Kor_textChanged(const QString &arg1){
    changeStred(nullptr, ui->Korod, GLimits::Fn::Kk, arg1);
}

void MainWindow::on_Kordo_textChanged(const QString &arg1){
    changeDo(nullptr, GLimits::Fn::Kk, arg1);
}

void MainWindow::on_r1od_textChanged(const QString &arg1){
    changeOd(nullptr, GLimits::Fn::R1, arg1);
}

void MainWindow::on_r1R_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->r1od, GLimits::Fn::R1, arg1);
}

void MainWindow::on_r1do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::R1, arg1);
}

void MainWindow::on_stl1od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::STL1, arg1);
}

void MainWindow::on_stl1R_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->stl1od, GLimits::Fn::STL1, arg1);
}

void MainWindow::on_stl1do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::STL1, arg1);
}

void MainWindow::on_dtr1od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::dtR1, arg1);
}

void MainWindow::on_dtr1_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->dtr1od, GLimits::Fn::dtR1, arg1);
}

void MainWindow::on_dtr1do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::dtR1, arg1);
}

void MainWindow::on_dtstl1od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::dtSTL1, arg1);
}

void MainWindow::on_dtstl1_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->dtstl1od, GLimits::Fn::dtSTL1, arg1);
}

void MainWindow::on_dtstl1do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::dtSTL1, arg1);
}

void MainWindow::on_dtRSTL1od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::dtRSTL1, arg1);
}

void MainWindow::on_dtRSTL1_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->dtRSTL1od, GLimits::Fn::dtRSTL1, arg1);
}

void MainWindow::on_dtRSTL1do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::dtRSTL1, arg1);
}

void MainWindow::on_HHRXod_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::HHrx, arg1);
}

void MainWindow::on_HHRXr_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->HHRXod, GLimits::Fn::HHrx, arg1);
}

void MainWindow::on_HHRXdo_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::HHrx, arg1);
}

void MainWindow::on_kombod_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::Sucet, arg1, sucetMin(getN()), sucetMax(getN(), getM()));
}

void MainWindow::on_kombR_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->kombod, GLimits::Fn::Sucet, arg1, sucetMin(getN()), sucetMax(getN(), getM()));
}

void MainWindow::on_kombdo_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::Sucet, arg1, sucetMin(getN()), sucetMax(getN(), getM()));
}

void MainWindow::on_r2od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::R2, arg1);
}

void MainWindow::on_r2R_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->r2od, GLimits::Fn::R2, arg1);
}

void MainWindow::on_r2do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::R2, arg1);
}

void MainWindow::on_stl2od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::STL2, arg1);
}

void MainWindow::on_stl2R_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->stl2od, GLimits::Fn::STL2, arg1);
}

void MainWindow::on_stl2do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::STL2, arg1);
}

void MainWindow::on_dtr2od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::dtR2, arg1);
}

void MainWindow::on_dtr2_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->dtr2od, GLimits::Fn::dtR2, arg1);
}

void MainWindow::on_dtr2do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::dtR2, arg1);
}

void MainWindow::on_dtstl2od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::dtSTL2, arg1);
}

void MainWindow::on_dtstl2_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->dtstl2od, GLimits::Fn::dtSTL2, arg1);
}

void MainWindow::on_dtstl2do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::dtSTL2, arg1);
}

void MainWindow::on_dtRSTL2od_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::dtRSTL2, arg1);
}

void MainWindow::on_dtRSTL2_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->dtRSTL2od, GLimits::Fn::dtRSTL2, arg1);
}

void MainWindow::on_dtRSTL2do_textChanged(const QString &arg1)
{
    changeDo(nullptr, GLimits::Fn::dtRSTL2, arg1);
}

void MainWindow::on_HRXod_textChanged(const QString &arg1)
{
    changeOd(nullptr, GLimits::Fn::Hrx, arg1);
}

void MainWindow::on_HRXr_textChanged(const QString &arg1)
{
    changeStred(nullptr, ui->HRXod, GLimits::Fn::Hrx, arg1);
}

void MainWindow::on_HRXdo_textChanged(const QString &arg1)
{
//    changeDo(ui->HRXdo, GLimits::Fn::Hrx, arg1);
    changeDo(nullptr, GLimits::Fn::Hrx, arg1);
}

void MainWindow::on_Povinne_textChanged(const QString &arg1){

    if(!arg1.isEmpty()){
        QSet<uint> povinne{};
        QStringList pov = arg1.split(",");
        foreach (const QString &str, pov) {
            if(str.contains("-")){
                QStringList range = str.split("-");
                for(int cislo = range[0].toInt(); cislo <= range[1].toInt(); cislo++){
                    if(cislo > 0)
                        povinne.insert((uint)cislo);
                }
            }
            else if(str.toInt() > 0)
                povinne.insert(str.toUInt());
        }
        if(povinne.size() > getN()){
            info("Povinnych je prilis vela");
            glimits.unsetPovinne();
        }
        else{
            info("");
            glimits.setPovinne(povinne);
        }
    }
    else{
        glimits.unsetPovinne();
    }

}

void MainWindow::on_PovinneSTL_textChanged(const QString &arg1){

    if(!arg1.isEmpty()){
        QMultiHash<uint, uint> povMM;
        QStringList pov = arg1.split(";");

//        if(pov.size() > 0){
        foreach (const QString& str, pov){
            if(str.split(":").size() > 1){
                QString stl = str.split(":")[0];
                QString args = str.split(":")[1];
                foreach (auto &i, args.split(",")){
                    if(i.contains("-") && i.split("-").size() == 2){
                        auto a = i.split("-")[0].toUInt();
                        auto b = i.split("-")[1].toUInt();
                        for(;a <= b; ++a){
                            if(a > 0)
                                povMM.insert(stl.toUInt(), a);
                        }
                    }
                    else if(i.toInt() > 0){
                        povMM.insert(stl.toUInt(), i.toUInt());
                    }
                }
            }
        }
        glimits.setPovinneSTL(povMM);
    }
    else
        glimits.unsetPovinneSTL();
}

void MainWindow::on_Zakazane_textChanged(const QString &arg1){

    if(!arg1.isEmpty()){
        QSet<uint> zakazane{};
        QStringList zak = arg1.split(",");
        foreach (const QString &str, zak) {
            if(str.contains("-")){
                QStringList args=str.split("-");
                for(uint cislo=args[0].toUInt(); cislo<=args[1].toUInt(); ++cislo){
                    zakazane.insert(cislo);
                }
            }
            else if(str.toInt() > 0)
                zakazane.insert(str.toUInt());
        }

        if(zakazane.size() > getM() - getN()){
            info("Zakazanych je prilis vela");
            glimits.unsetZakazane();
        }
        else{
            info("");
            glimits.setZakazane(zakazane);
        }
    }
    else
        glimits.unsetZakazane();
}

void MainWindow::on_ZakazaneSTL_textChanged(const QString &arg1){

    if(!arg1.isEmpty()){
        QMultiHash<uint, uint> zakMM;
        QStringList pov = arg1.split(";");

        foreach (const QString& str, pov){
            if(str.split(":").size() > 1){
                QString stl = str.split(":")[0];
                QString args = str.split(":")[1];
                foreach (auto& i, args.split(",")){
                    if(i.contains("-") && i.split("-").size() == 2){
                        auto a = i.split("-")[0].toUInt();
                        auto b = i.split("-")[1].toUInt();
                        for(;a <= b; ++a){
                            if(a > 0)
                                zakMM.insert(stl.toUInt(), a);
                        }
                    }
                    else if(i.toInt() > 0){
                        zakMM.insert(stl.toUInt(), i.toUInt());
                    }
                }
            }
        }
        glimits.setZakazaneSTL(zakMM);
    }
    else
        glimits.unsetZakazaneSTL();
}

void MainWindow::on_n_tice_textChanged(const QString &arg1)
{
    if(!arg1.isEmpty()){
        QVector<uint> ntice;
        QStringList nticaList = arg1.split(" ");
        uint sum = 0;

        for(int i=1; i <= nticaList.size() && i <= getN(); ++i){
            sum += nticaList[i-1].toUInt()*i;
            ntice.push_back(nticaList[i-1].toUInt());
        }
        if(sum != getN()){
            info("N-tice zle zadane");
            glimits.unsetNtice();
        }
        else{
            info("");
            glimits.setNtice(ntice);
        }
    }
    else
        glimits.unsetNtice();
}

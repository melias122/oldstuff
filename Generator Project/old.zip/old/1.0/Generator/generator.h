#ifndef GENERATOR_H
#define GENERATOR_H

#include <QObject>
#include <QFile>
//#include <QPointer>
#include <QMutex>

#include "types.h"
#include "phcisla.h"
#include "archiv.h"
#include "glimits.h"
#include "hrx.h"

using kIterators = QVector<Kombinacia::Iterator>;
using endIterator = Kombinacia::Iterator;
class Vystup;

class Generator : public QObject {
    Q_OBJECT
public:

    Generator(uint n, uint m, HrxHHrx hrx, GLimits glimits, Vystup *vystup, uint connectionType = 0);
    void setPhcisla(QPair<PHCisla, PHCisla> phcisla);
    void setPhcislaFilter(PHCisla &oddo){
        this->m_oddoFilter = oddo;
    }
signals:
    void finished();
    void setHrxHHrx(HrxHHrx &_hrxHHrx);
    void msg(QString message);
public slots:
    void start();
    void workerFinished();
    void setHrxHHrxFiltered(Hrx &hrx);
private:
    void createWorker();
    uint maxThreads{1}, threadsCount, n, m, hrxSize;
    GLimits glimits;
    QPair<PHCisla, PHCisla> m_PHCisla;
    PHCisla m_oddoFilter;
    HrxHHrx hrxHHrxFiltered;
    QVector<HrxPair> hrxHHrx;
    Vystup *vystup;
    QMutex mutex;
    uint connectionType{0}; // 0==proces, 1==processZHR, 2==filter
};

class GeneratorWrap : public QObject{
    Q_OBJECT
public:
    GeneratorWrap(uint n, uint m);
    GeneratorWrap(uint n, uint m, HrxPair hrxPair, GLimits glimits);
    void setPhcisla(QPair<PHCisla, PHCisla> phcisla);
    void setPhcislaODDO_orgi(PHCisla &oddoOrig){
        phcislaODDO_orig = oddoOrig;
    }
signals:
    void finished();
    void hrxFound(Hrx &hrx);
    void resultFound(const Kombinacia &k);
public slots:
    void process();
    void processZhodaR();
    void processHrxHHrx();
private:
    bool nextCombination(kIterators &mnozinaItt, endIterator &end, bool &ok);
    PHCisla phcisla1DO, phcislaODDO, phcislaODDO_orig;
    uint n, m;
    HrxPair hrxPair;
    GLimits glimits;
    Kombinacia vysledok;
};

class Vystup : public QObject {
    Q_OBJECT
public:
//    Vystup();
    Vystup(uint n, uint m, PHCisla &od1, PHCisla &odDo, Archiv archiv, uint max = 500000); // Kombinacie
    Vystup(uint max = 500000); // HRX Filter
//    Vystup(uint n, uint m, PHCisla &od1, PHCisla &odDo, Archiv archiv, GLimits &glimits, uint max = 500000);
    ~Vystup();
signals:
    void finished();
    void msg(QString message);
public slots:
    bool zapis(const Kombinacia &kombinacia);
    bool zapisFilter(Hrx &hrx);
private:
    bigInt pocetNajdenych{0};
    Kombinacia zR;
    PHCisla od1, odDo;
    Archiv archiv;
    uint cisloExportu{0}, maxFileSize, pocetZapisanych{0}, n{0}, m{0};
    QStringList header;
    QString path;
    QFile *file;
};

#endif // GENERATOR_H

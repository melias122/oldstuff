#include "hrx.h"

#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QLinkedList>
#include <QtAlgorithms>
#include <QtConcurrent/QtConcurrentRun>
#include <QFuture>
#include <QMutex>

#include <combination.h>
#include <utility.h>

QLinkedList<QVector<gNum>> HrxVECTORS{};
QVector<gNum> *HrxVECTORS_Find(QVector<gNum> &el){
    //    QVector<gNum> *ptr = nullptr;
    for(auto &v : HrxVECTORS)
        if(el == v)
            return &v;
    return nullptr;
}
//QVector<gNum> Hrx_ktoraKolko{};

QString presunStr(QHash<gNum, gNum> &presun){
    QString p;
    QVector<gNum> qi;

    for(auto &key : presun.keys()){
        while(qi.size() <= (key+1))
            qi.push_back(0);
        qi[key] = presun[key];
    }
    qi.removeLast();
    p = vectorToQString(qi.begin(), qi.end());
    return p;
}

double Hrx::getVal(val fn) const{
    return values[(uint)fn];
}

bigInt Hrx::getVal2(val2 fn) const {
    return sums[(uint)fn];
}

void Hrx::setVal(val fn, double value){
    values[(uint)fn] = value;
}

void Hrx::setVal2(val2 fn, bigInt value){
    sums[(uint)fn] = value;
}

Hrx::Hrx(){}

Hrx::Hrx(double hrx, double dhrx, QString presunString, HrxPair Hp)
    : Skupina_KtoraKolko{Hp},
      presunString{presunString}
{
    setVal(val::hrx, hrx);
    setVal(val::dhrx, dhrx);
}

Hrx::Hrx(double hrx, double dhrx, QHash<gNum, gNum> &presun){
    setVal(val::hrx, hrx);
    setVal(val::dhrx, dhrx);
    presunString = presunStr(presun);
}

Hrx::Hrx(double sumXR,
         double hrx,
         double hhrx,
         double dhrx,
         double dhhrx,
         uint sumMin,
         uint sumMax,
         bigInt pocetKombi,
         bigInt pocetTeorR1Max,
         double percStl1Min,
         double percStl1Max,
         double percStlOdMin,
         double percStlOdMax,
         double percR1Min,
         double percR1Max,
         QHash<gNum, gNum> presun,
         HrxPair Hp)
    : Skupina_KtoraKolko{Hp}
{
    setVal(val::R2Min, sumXR);
    setVal(val::hrx, hrx);
    setVal(val::HHRXMin, hhrx);
    setVal(val::dhrx, dhrx);
    setVal(val::dhhrx, dhhrx);
    setVal(val::sucetMin, (double)sumMin);
    setVal(val::sucetMax, (double)sumMax);
    setVal(val::S1Min, percStl1Min);
    setVal(val::S1Max, percStl1Max);
    setVal(val::S2Min, percStlOdMin);
    setVal(val::S2Max, percStlOdMax);
    setVal(val::R1Min, percR1Min);
    setVal(val::R1Max, percR1Max);

    setVal2(val2::pocetKombi, pocetKombi);
    setVal2(val2::pocetR1, pocetTeorR1Max);
    presunString = presunStr(presun);
}

QString Hrx::toQString(){
    return  doubleToQString(getHrx()) + ";" + doubleToQString(getdHrx()) + ";" +
            presunString + ";" +
            doubleToQString(getR2Min()) + ";" +
            doubleToQString(getS2Min()) + "-" + doubleToQString(getS2Max()) + ";" +
            QString::number(getSucetMin()) + "-" + QString::number(getSucetMax()) + ";" +
            bigIntToQString(getPocetKombi()) + ";" +
            doubleToQString(getHHRXMin()) + ";" + doubleToQString(getdHHrx()) + ";" +
            doubleToQString(getR1Min()) + "-" + doubleToQString(getR1Max()) + ";" +
            bigIntToQString(getPocetR1()) + ";" +
            doubleToQString(getS1Min()) + "-" + doubleToQString(getS1Max());
}

QStringList Hrx::toQStringList(){
    return toQString().split(";");
}

QStringList Hrx::filtered(){
    QStringList out{};

    //        out += uintToQString(poradoveCislo);
    QStringList ZHstr;
    qSort(ZH);
    for(auto &cislo : ZH){
        ZHstr += uintToQString(cislo);
    }

    out += ZHstr.join(",");
    out += doubleToQString(getHrx());
    out += doubleToQString(getdHrx());
    out += presunString;
    out += bigIntToQString(getPocetKombi());
    out += QString(doubleToQString(getR2Min()) + "-" +  doubleToQString(getR2Max()));
    out += bigIntToQString(getPocetR2());

    QStringList nticeStr{}, nticePocet{};
    for(auto &ntica : Ntice.keys()){
        nticeStr += ntica;
        nticePocet += QString(ntica + ":(" + bigIntToQString(Ntice[ntica]) + ")");
    }

    out += nticeStr.join(",");
    out += nticePocet.join(",");

    QStringList xticeStr, xticePocet;
    for(auto &xtica : Xtice.keys()){
        xticeStr += xtica;
        xticePocet += QString(xtica + ":(" + bigIntToQString(Xtice[xtica]) + ")");
    }

    out += xticeStr.join(",");
    out += xticePocet.join(",");

    out += QString(doubleToQString(getS2Min()) + "-" +  doubleToQString(getS2Max()));
    out += bigIntToQString(getPocetS2());

    out += QString(uintToQString(getSucetMin()) + "-" +  uintToQString(getSucetMax()));
    out += bigIntToQString(getPocetS2());

    out += QString(doubleToQString(getHHRXMin()) + "-" +  doubleToQString(getHHRXMax()));
    out += doubleToQString(getdHHrx());
    out += bigIntToQString(getPocetHHRX());

    out += QString(doubleToQString(getR1Min()) + "-" +  doubleToQString(getR1Max()));
    out += bigIntToQString(getPocetR1());

    out += QString(doubleToQString(getS1Min()) + "-" +  doubleToQString(getS1Max()));
    out += bigIntToQString(getPocetS1());

    return out;
}

uint Hrx::getSucetMin() const{
    return getVal(val::sucetMin);
}

uint Hrx::getSucetMax() const{
    return getVal(val::sucetMax);
}

double Hrx::getHrx() const {
    return getVal(val::hrx);
}

double Hrx::getdHrx() const{
    return getVal(val::dhrx);
}

double Hrx::getdHHrx() const{
    return getVal(val::dhhrx);
}

double Hrx::getR1Min() const{
    return getVal(val::R1Min);
}

double Hrx::getR1Max() const{
    return getVal(val::R1Max);
}

double Hrx::getS1Min() const{
    return getVal(val::S1Min);
}

double Hrx::getS1Max() const{
    return getVal(val::S1Max);
}

double Hrx::getR2Min() const{
    return getVal(val::R2Min);
}

double Hrx::getR2Max() const{
    return getVal(val::R2Max);
}

double Hrx::getS2Min() const{
    return getVal(val::S2Min);
}

double Hrx::getS2Max() const{
    return getVal(val::S2Max);
}

double Hrx::getHHRXMin() const{
    return getVal(val::HHRXMin);
}

double Hrx::getHHRXMax() const{
    return getVal(val::HHRXMax);
}

bigInt Hrx::getPocetR1() const{
    return getVal2(val2::pocetR1);
}

bigInt Hrx::getPocetR2() const{
    return getVal2(val2::pocetR2);
}

bigInt Hrx::getPocetS1() const{
    return getVal2(val2::pocetS1);
}

bigInt Hrx::getPocetS2() const{
    return getVal2(val2::pocetS2);
}

bigInt Hrx::getPocetHHRX() const{
    return getVal2(val2::pocetHHRX);
}

bigInt Hrx::getPocetKombi() const{
    return getVal2(val2::pocetKombi);
}

HrxPair Hrx::getHrxPair() const {
    return Skupina_KtoraKolko;
}

QString Hrx::getPresunString() const{
    return presunString;
}

void Hrx::setSucetMin(uint arg){
    setVal(val::sucetMin, (double)arg);
}

void Hrx::setSucetMax(uint arg){
    setVal(val::sucetMax, (double)arg);
}

void Hrx::setR1Min(double arg){
    setVal(val::R1Min, arg);
}

void Hrx::setR1Max(double arg){
    setVal(val::R1Max, arg);
}

void Hrx::setR2Min(double arg){
    setVal(val::R2Min, arg);
}

void Hrx::setR2Max(double arg){
    setVal(val::R2Max, arg);
}

void Hrx::setSTL1Min(double arg){
    setVal(val::S1Min, arg);
}

void Hrx::setSTL1Max(double arg){
    setVal(val::S1Max, arg);
}

void Hrx::setSTL2Min(double arg){
    setVal(val::S2Min, arg);
}

void Hrx::setSTL2Max(double arg){
    setVal(val::S2Max, arg);
}

void Hrx::setHHRXMin(double arg){
    setVal(val::HHRXMin, arg);
}

void Hrx::setHHRXMax(double arg){
    setVal(val::HHRXMax, arg);
}

void Hrx::setPocetKombi(bigInt arg){
    setVal2(val2::pocetKombi, arg);
}

void Hrx::setPocetKombiR1(bigInt arg){
    setVal2(val2::pocetR1, arg);
}

void Hrx::setPocetKombiR2(bigInt arg){
    setVal2(val2::pocetR2, arg);
}

void Hrx::setPocetKombiSTL1(bigInt arg){
    setVal2(val2::pocetS1, arg);
}

void Hrx::setPocetKombiSTL2(bigInt arg){
    setVal2(val2::pocetS2, arg);
}

void Hrx::setPocetKombiHHRX(bigInt arg){
    setVal2(val2::pocetHHRX, arg);
}

void Hrx::setNtice(QHash<QString, bigInt> &arg){
    Ntice = arg;
}

void Hrx::setXtice(QHash<QString, bigInt> &arg){
    Xtice = arg;
}

void Hrx::setZH(QVector<int> &arg){
    ZH = arg;
}

void Hrx::setHrxPair(HrxPair &hp){
    Skupina_KtoraKolko = hp;
}

QVector<double> Hrx::getValues() const{
    return values;
}

QVector<bigInt> Hrx::getSums() const{
    return sums;
}

HrxPair Hrx::getSkupina_KtoraKolko() const{
    return Skupina_KtoraKolko;
}

QHash<QString, bigInt> Hrx::getNtice() const{
    return Ntice;
}

QHash<QString, bigInt> Hrx::getXtice() const{
    return Xtice;
}

QVector<int> Hrx::getZH() const{
    return ZH;
}

//QString Hrx::getPresunString() const{
//    return presunString;
//}


void _hrx_stlodMinMax(int n, int m, PHCisla &phcODDOplus1, QVector<qint8> &cislaX, double &stlOdMin, double &stlOdMax){
    QVector<QVector<double>> stlOdPerc;
    for(int stl{1}; stl<=n; ++stl){
        int minCStl = stl;
        int maxCStl = m-n+stl;

        QVector<double> ql;
        for(int i{0}; i<cislaX.size(); ++i){
            auto c = cislaX[i];
            if(c >= minCStl && c <=maxCStl)
                ql.push_back(phcODDOplus1.hodnotaStlpec(c, stl));
        }
        qSort(ql);
        stlOdPerc.push_back(ql);
    }
    for(int i{0}; i<n; ++i){
        stlOdMin += stlOdPerc[i].front();
        stlOdMax += stlOdPerc[i].back();
    }
}

void _hrx_STL1_DOMinMax(int n, int m, PHCisla &phc1DOplus1, QVector<qint8> &cislaX,double &stl1Min, double &stl1Max){
    QVector<QVector<double>> stl1Perc;
    for(int stl{1}; stl<=n; ++stl){
        int minCStl = stl;
        int maxCStl = m-n+stl;

        QVector<double> ql;
        for(int i{0}; i<cislaX.size(); ++i){
            auto c = cislaX[i];
            if(c >= minCStl && c <=maxCStl)
                ql.push_back(phc1DOplus1.hodnotaStlpec(c, stl));
        }
        qSort(ql);
        stl1Perc.push_back(ql);
    }

    for(int i{0}; i<n; ++i){
        stl1Min += stl1Perc[i].front();
        stl1Max += stl1Perc[i].back();
    }
}

void _hrx_R1_DOMinMax(int n, PHCisla &phc1DOplus1, QVector<qint8> &cislaX,double &r1Min, double &r1Max){

    QVector<double> r1Perc;
    for(auto& c: cislaX){
        //                        r1Perc.push_back(n_1DO_1.get_R(c));
        r1Perc.push_back(phc1DOplus1.R(c));
    }

    if(r1Perc.size() >= n){
        qSort(r1Perc);
        int endIdx = r1Perc.size() - 1;
        for(int i{0}; i<n; ++i){
            r1Min += r1Perc[i];
            r1Max += r1Perc[endIdx - i];
        }
    }
}

void _hrx_R1_DOTeorPMax(QVector<gNum> *qi, PHCisla &phc1DOplus1, QVector< QVector<gNum>*> &skupinyPocetKombi, bigInt &r1PMax){

    QVector<QVector<double>> r1TeorPMax;
    for(auto &sk: skupinyPocetKombi){
        QVector<double> qs;
        for(auto &c: *sk){
            if(!qs.contains(phc1DOplus1.hodnotaRiadok(c)))
                qs.push_back(phc1DOplus1.hodnotaRiadok(c));
        }
        r1TeorPMax.push_back(qs);
    }
    for(int i{0}; i < r1TeorPMax.size(); ++i){
        auto val = nCm(qi->at(i), r1TeorPMax[i].size());
        if(!val.is_zero())
            r1PMax *= val;
    }
}

//struct skupinyPK{

//};

QList<QList<gNum> > run(QList<gNum> perm, QList<gNum> skupiny, QHash<gNum, QVector<gNum>> ss){

    QList<QList<gNum>> moznost;

    do{
        bool ok = true;
        int i{0};
        for(auto &s : skupiny){
            if(perm[i] > ss[s].size()){
                ok = false;
                break;
            }
            ++i;
        }
        if(ok){
            moznost.append(perm);
        }
    }while(std::next_permutation(std::begin(perm), std::end(perm)));

    return moznost;
}

//struct run2_res{
//    double d;
//    HrxPair hp;
//};

//#include <QReadWriteLock>
//#include <QMutexLocker>

QMutex mutex;
QPair<double, HrxPair> run2(PHCisla &phcODDO, QList<gNum > &moznost, QHash< gNum, QVector< gNum > > &ss, QList<gNum> &skupiny, QHash<QString, QVector<gNum> *> *vecPrts){

    //    qDebug() << vecPrts;
    //    qDebug() << HrxVECTORS;
    //    for(auto &v : HrxVECTORS)
    //        qDebug() << v;

    Kombinacia comb;
    QVector<QVector<gNum>> sk;
    QVector<gNum> kk;
    uint m = phcODDO.getM();
    //    QReadWriteLock locker;

    for(int i{0}; i<moznost.size(); ++i){
        if(moznost[i] == 0)
            continue;

        mutex.lock();
        sk.append(ss[skupiny[i]]);
        mutex.unlock();
        kk.append(moznost[i]);
    }
    int i{0};
    for(auto &s : sk){
        for(int j{0}; j<kk[i];++j){
            comb.append(s[j]);
        }
        ++i;
    }

    QVector<QVector<gNum>*> p1;
    QVector<gNum>* p2;

    auto s1 = vectorToQString(kk.begin(), kk.end());
    mutex.lock();
    if(!HrxVECTORS.contains(kk)){
        HrxVECTORS.append(kk);
        vecPrts->insert(s1, &HrxVECTORS.last());
    }
    p2 = vecPrts->value(s1);
    mutex.unlock();

    for(auto &s : sk){
        auto s2 = vectorToQString(s.begin(), s.end());
        mutex.lock();
        if(!HrxVECTORS.contains(s)){
            HrxVECTORS.append(s);
            vecPrts->insert(s2, &HrxVECTORS.last());
        }
        p1.append(vecPrts->value(s2));
        mutex.unlock();
    }
    mutex.lock();
    double hrx = hrxRplus1(comb, phcODDO, m);
    mutex.unlock();
    //    qDebug() << hrx << p1 << p2;
    return QPair<double, HrxPair>(hrx, HrxPair{p1, p2});
}

HrxHHrx hrx_step2(PHCisla &phcODDO, QList<QList<gNum> > &vm, QHash<gNum, QVector<gNum>> &ss){

    QHash<QString, QVector<gNum> *> vecPrts;
    HrxHHrx hrxAll;
    QList<QFuture<QPair<double, HrxPair>>> futures;

    auto skupiny = ss.keys();
    qSort(skupiny);

    //    QThreadPool::setMaxThreadCount(1);
    //    QThreadPool::globalInstance()->setMaxThreadCount(1);
    for(auto &moznost : vm)
        futures.append(QtConcurrent::run(run2, phcODDO, moznost, ss, skupiny, &vecPrts));
    for(auto &future : futures){
        future.waitForFinished();
        hrxAll.insert(future.result().first, future.result().second);
    }
    return hrxAll;
}

QList<QList<gNum> > vsetkyMozne(QVector<QVector<gNum>> &mozne, QHash<gNum, QVector<gNum>> &ss){

    QList<QFuture<QList<QList<gNum>>>> futures;
    QList<QList<gNum>> moznosti;

    auto skupiny = ss.keys();
    qSort(skupiny);

    for(auto m : mozne){
        if(m.size() > ss.size())
            continue;
        auto perm = m.toList();

        while(perm.size() != ss.size())
            perm.prepend(0);

        futures.append(QtConcurrent::run(run, perm, skupiny, ss));
    }

    //    int total{0};
    for(auto &future : futures){
        future.waitForFinished();
        moznosti.append(future.result());
        //        total += future.result().size();
    }
    //    qDebug() << total;
    return moznosti;
}
struct phc{
    PHCisla a,b,c,d;
};
Hrx run3(HrxPair &h, PHCisla &phc1DO, PHCisla &phcODDO, QHash<gNum, QVector<gNum>> &ss){

    Kombinacia comb;
    QHash<gNum, gNum> presun;
    //        QVector<QVector<gNum>> skupinyPocetKombi;
    int min = 0, max = 0;

    uint n = phc1DO.getN();
    uint m = phc1DO.getM();

    auto phc1DOplus1 = plus1(phc1DO, n, m);
    auto phcODDOplus1 = plus1(phcODDO, n, m);

    int i{0};
    for(auto &s : h.first){
        int ktora = ss.key(*s);
        int kolko = (*h.second)[i];

        presun.insert(ktora, kolko);

        for(int j{0}; j<kolko;++j){
            min += s->at(j);
            max += s->at(s->size()-1-j);
            comb.append(s->at(j));
        }
        //            skupinyPocetKombi.append(*s);
        ++i;
    }

    // cisla zo skupin
    QVector<qint8> cislaX;
    for(auto &sk: h.first){
        for(auto &c: (*sk)){
            cislaX.push_back(c);
        }
    }
    //

    //∑% R1-DO min-max
    double r1Min=0, r1Max=0, stl1Min=0, stl1Max=0, stlOdMin=0, stlOdMax=0;
    bigInt r1PMax{1}, biPocet{1};
    _hrx_R1_DOMinMax(n, phc1DOplus1, cislaX, r1Min, r1Max);

    //∑% R1-DO teor. pocet max
    //        r1PMax = 1;
    _hrx_R1_DOTeorPMax(h.second, phc1DOplus1, h.first, r1PMax);

    //∑% STL1-DO min-max
    //                    stl1Min=0, stl1Max=0;
    _hrx_STL1_DOMinMax(n, m, phc1DOplus1, cislaX, stl1Min, stl1Max);
    //

    //∑% STL1-DO teor. pocet max
    //

    //∑% STLOD-DO min-max
    //                    stlOdMin=0, stlOdMax=0;
    _hrx_stlodMinMax(n, m, phcODDOplus1, cislaX, stlOdMin, stlOdMax);

    // Pocet kombi
    //                    biPocet = 1;
    for(int i{0}; i < h.first.size(); ++i){
        auto val = nCm(h.second->at(i), h.first.at(i)->size());
        if(!val.is_zero())
            biPocet *= val;
    }
    //

    double hrx = hrxRplus1(comb, phcODDO, m);
    double hhrx = hrxRplus1(comb, phc1DO, m);

    return Hrx(phcODDO.hodnotaRiadokKombinacia(comb),
               hrx, hhrx,
               hrx - hrxR(comb, phcODDO, m), hhrx - hrxR(comb, phc1DO, m),
               min, max,
               biPocet, r1PMax,
               stl1Min, stl1Max, stlOdMin, stlOdMax, r1Min, r1Max,
               presun, h);
}

QList<Hrx> hrx_step3(QHash<gNum, QVector<gNum>> &ss, HrxHHrx &hrxAll, PHCisla &phc1DO, PHCisla &phcODDO){

    QList<Hrx> AllHrxs;
    AllHrxs.reserve(hrxAll.size());

    QList<QFuture<Hrx>> futures;

    uint n = phc1DO.getN();
    uint m = phc1DO.getM();

//    auto phc1DOplus1 = plus1(phc1DO, n, m);
//    auto phcODDOplus1 = plus1(phcODDO, n, m);

    for(HrxPair &h : hrxAll.values()){
        futures.append(QtConcurrent::run(run3, h, phc1DO, phcODDO, ss));
    }
    for(auto &future : futures){
        future.waitForFinished();
        AllHrxs.append(future.result());
    }
    return AllHrxs;
}

void makeHrxHHrx_v2(uint n, uint m, PHCisla &phc1DO, PHCisla &phcODDO, HrxHHrx &hrxAll, QString &suborCesta){

    auto mozne = Ntice2(n);
    QHash<gNum, QVector<gNum>> ss; // skupina, cisla zo skupiny; skupina su pocetnosti ODDO

    //    auto phc1DOplus1 = plus1(phc1DO, n, m);
    //    auto phcODDOplus1 = plus1(phcODDO, n, m);

    for(uint i{1}; i<=m; ++i)
        ss[phcODDO.pocetnostRiadok(i)].append(i);
    for(auto &s : ss)
        qSort(s);

    qDebug() << "step1";
    auto vm = vsetkyMozne(mozne, ss);
    qDebug() << "step2";
    hrxAll = hrx_step2(phcODDO, vm, ss);
    qDebug() << "step3";
    auto AllHrxs = hrx_step3(ss, hrxAll, phc1DO, phcODDO);

    qDebug() << "sort";
    qSort(AllHrxs.begin(), AllHrxs.end(), [](const Hrx &a, const Hrx &b){
        return a.getHrx() < b.getHrx();
    });

    //OUT
    QFile *f = new QFile(pwd() + "HrxHHrx_" + filenameFromPath(suborCesta) + ".csv");
    f->open(QFile::WriteOnly);

    QTextStream *out = new QTextStream(f);
    out->setCodec("UTF-8");
    out->setGenerateByteOrderMark(true);

    // CSV
    auto skupiny = ss.keys();
    qSort(skupiny);
    for(auto &i : skupiny) {
        QStringList out_stringl;

        out_stringl << "Cislo";
        for(auto &cislo : ss[i])
            out_stringl << QString::number(cislo);
        *out << out_stringl.join(";") << "\n";

        out_stringl.clear();
        out_stringl << "Pocet R1-DO";
        for(auto &cislo : ss[i])
            out_stringl << QString::number(phc1DO.pocetnostRiadok(cislo));
        *out << out_stringl.join(";") << "\n";

        out_stringl.clear();
        out_stringl << "Pocet ROD-DO";
        for(auto _: ss[i])
            out_stringl << QString::number(i);
        *out << out_stringl.join(";") << "\n\n\n";
    }

    // header
    QStringList header;
    header << "p.c."<<"HRX pre r+1"<<"dHRX diferencia s \"r\""<<"presun z r do (r+1)cisla"<<"∑%ROD-DO"<<
                       "∑%STLOD-DO od do"<<"∑ kombi od do"<<"Pocet ∑ kombi"<<"HHRX pre r+1"<<"dHHRX diferencia s \"r\""<<
                       "∑%R1-DO od do"<<"Teor. max. pocet ∑%R1-DO"<<"∑%STL1-DO od do";
    *out << header.join(";") << "\n";

    ulong pc=1;
    uint en=1;
    for(auto &a : AllHrxs){
        if(pc%500000 == 0){
            ++en;
            if(f->isOpen())
                f->close();
            f->setFileName(pwd() + "HrxHHrx_" + filenameFromPath(suborCesta) + "-" + QString::number(en) + ".csv");
            f->open(QFile::WriteOnly);
            delete out;
            out = new QTextStream(f);
            out->setCodec("UTF-8");
            out->setGenerateByteOrderMark(true);
            *out << header.join(";") << "\n";
        }
        *out << QString::number(pc) << ";" << a.toQStringList().join(";") << "\n";
        ++pc;
    }
    if(out){
        out->flush();
        delete out;
    }
    if(f->isOpen()){
        f->flush();
        f->close();
        delete f;
    }
}

//void makeHrxHHrx(uint n, uint m, PHCisla &phc1DO, PHCisla &phcODDO, HrxHHrx &hrxAll, QString &suborCesta){

//    using namespace stdcomb;

//    CSV csv;
//    QStringList out_stringl;
//    QHash<qint8, QHash<gNum, gNum>> skupiny;
//    QVector<qint8> skupinyKeys;
//    QVector<QVector<gNum>> qvi;

////    Hrx_skupiny.clear();
////    Hrx_ktoraKolko.clear();

//    auto phcODDOplus1 = plus1(phcODDO, n, m);
//    auto phc1DOplus1 = plus1(phc1DO, n, m);

////    QVector<QPair<double, HrxPair>> hrxAll2;
////    QHash<double, Hrx> hrxAll{};

//    QFile f(pwd() + "HrxHHrx_" + filenameFromPath(suborCesta) + ".csv");
//    f.open(QFile::WriteOnly);

//    QTextStream out(&f);
//    out.setCodec("UTF-8");
//    out.setGenerateByteOrderMark(true);

//    foreach (const auto &i, Ntice(n).keys()) {
//        auto l = i.split(" ");
//        l.pop_back();

//        auto pos = 1;
//        QVector<gNum> qi;
//        foreach (const auto& s, l) {
//            int c = s.toInt();
//            if(c > 0){
//                for(int j{1}; j <= c; ++j){
//                    qi.push_back(pos);
//                }
//            }
//            ++pos;
//        }
//        qvi.push_back(qi);
//    }

//    for(uint i{1}; i <= m; ++i)
//        skupiny[phcODDO.pocetnostRiadok(i)].insert(i, phc1DO.pocetnostRiadok(i));

////    qDebug() << skupiny;

//    foreach (const auto &i, skupiny.keys())
//        skupinyKeys.push_back(i);
//    qSort(skupinyKeys);


//    // CSV
//    out_stringl.clear();
////    auto keys = skupiny.keys();
////    qSort(keys);
//    for(auto &i : skupinyKeys) {
//        out_stringl << "Cislo";
//        foreach (const auto &cislo, skupiny[i].keys()) {
//            out_stringl << QString::number(cislo);
//        }
//        csv += out_stringl;
//        out_stringl.clear();
//        out_stringl << "Pocet R1-DO";
//        foreach (const auto &pocet, skupiny[i].values()) {
//            out_stringl << QString::number(pocet);
//        }
//        csv += out_stringl;
//        out_stringl.clear();
//        out_stringl << "Pocet ROD-DO";
//        foreach (const auto &cislo, skupiny[i].keys()) {
//            out_stringl << QString::number(i);
//        }
//        csv += out_stringl;
//        csv += {";"};
//        csv += {";"};
//        out_stringl.clear();
//    }


//// header
//    out_stringl << "p.c."
//                << "HRX pre r+1" << "dHRX diferencia s \"r\""
//                << "presun z r do (r+1)cisla"
//                << "∑%ROD-DO"
//                << "∑%STLOD-DO od do"
////                << "pocet ∑%STLOD-DO"
//                << "∑ kombi od do"
//                << "Pocet ∑ kombi"
//                << "HHRX pre r+1"
//                << "dHHRX diferencia s \"r\""
//                << "∑%R1-DO od do"
//                << "Teor. max. pocet ∑%R1-DO"
//                << "∑%STL1-DO od do";
////                << "pocet ∑%STLOD-DO";
//    csv << out_stringl;

//    for(auto &r : csv)
//        out << r.join(";") << "\n";

//    csv.clear();

//    unsigned long pc{1};
//    // CSV END

////    qSort(qvi);
//    for(auto &qi : qvi) {
//        qSort(qi);
//        do
//        {
//            if(qi.size() > skupiny.size())
//                continue;

//            QVector<qint8> posSk;

//            for(int i{0}; i < qi.size(); ++i)
//                posSk.push_back(skupinyKeys[i]);

//            qDebug() << "qi: " << qi;
//            do
//            {
//                qDebug() << "possk: " << posSk << skupinyKeys;

//                QVector<QVector<gNum>> skupinyPocetKombi;
//                QHash<gNum, gNum> presun;
//                Kombinacia comb; comb.reserve(n);
//                int min = 0, max = 0;



//                for(int i{0}; i<qi.size(); ++i)
//                {
//                    int kolko = qi[i];
//                    int ktora = posSk[i];

//                    if(kolko > skupiny[ktora].size()){
//                        qDebug() << "break";
//                        break;
//                    }

//                    presun.insert(ktora, kolko);

//                    int j{0};
//                    auto skKeys = skupiny[ktora].keys();
//                    auto last = (skKeys.end() - 1);
//                    for(auto& cislo : skKeys)
//                    {
//                        if(j<kolko){
//                            max += *last;
//                            min += cislo;
//                            comb.push_back(cislo);
//                        }
//                        else
//                            break;
//                        ++j;
//                        --last;
//                    }
//                    skupinyPocetKombi.push_back(skKeys.toVector());
//                }

////                qDebug() << skupinyKeys;

//                if(comb.size() == n){

//                    // cisla zo skupin
//                    QVector<qint8> cislaX;
//                    for(auto& sk: skupinyPocetKombi){
//                        for(auto& c: sk){
//                            cislaX.push_back(c);
//                        }
//                    }
//                    //

//                    //∑% R1-DO min-max
//                    double r1Min=0, r1Max=0, stl1Min=0, stl1Max=0, stlOdMin=0, stlOdMax=0;
//                    bigInt r1PMax{1}, biPocet{1};
//                    _hrx_R1_DOMinMax(n, phc1DOplus1, cislaX, r1Min, r1Max);

//                    //∑% R1-DO teor. pocet max
////                    r1PMax = 1;
////                    _hrx_R1_DOTeorPMax(qi, phc1DOplus1, skupinyPocetKombi, r1PMax);

//                    //∑% STL1-DO min-max
////                    stl1Min=0, stl1Max=0;
//                    _hrx_STL1_DOMinMax(n, m, phc1DOplus1, cislaX, stl1Min, stl1Max);
//                    //

//                    //∑% STL1-DO teor. pocet max
//                    //

//                    //∑% STLOD-DO min-max
////                    stlOdMin=0, stlOdMax=0;
//                    _hrx_stlodMinMax(n, m, phcODDOplus1, cislaX, stlOdMin, stlOdMax);

//                    // Pocet kombi
////                    biPocet = 1;
//                    for(int i{0}; i < skupinyPocetKombi.size(); ++i){
//                        auto val = nCm(qi[i], skupinyPocetKombi[i].size());
//                        if(!val.is_zero())
//                            biPocet *= val;
//                    }
//                    //

//                    auto phcOdDoCopy = phcODDO;
//                    phcOdDoCopy.increment(comb);
//                    double hrx = hrxR(comb, phcOdDoCopy, m);
//                    double hhrx = hrxRplus1(comb, phc1DO, m);

////                    qDebug() << skupinyPocetKombi << qi;

//                    QVector<QVector<gNum>*> p1;
////                    QVector<gNum> *p2 = nullptr;
//                    for(auto &v : skupinyPocetKombi){
//                        if(!HrxVECTORS.contains(v)){
//                            HrxVECTORS.append(v);
//                        }
//                        p1.append(HrxVECTORS_Find(v));
//                    }
//                    if(!HrxVECTORS.contains(qi))
//                        HrxVECTORS.append(qi);
//                    QVector<gNum> *p2 = HrxVECTORS_Find(qi);

//                    hrxAll.insert(hrx, HrxPair{p1, p2});

//                    Hrx shrx(phcODDO.hodnotaRiadokKombinacia(comb),
//                             hrx, hhrx,
//                             hrx - hrxR(comb, phcODDO, m), hhrx - hrxR(comb, phc1DO, m),
//                             min, max,
//                             biPocet, r1PMax,
//                             stl1Min, stl1Max, stlOdMin, stlOdMax, r1Min, r1Max,
//                             presun,
//                             HrxPair{p1, p2}
//                             );

//                    out_stringl.clear();
//                    out_stringl << QString::number(pc) << shrx.toQStringList();
//                    out << out_stringl.join(";") << "\n";
//                    ++pc;
//                }
//            }while(next_combination(skupinyKeys.begin(), skupinyKeys.end(), posSk.begin(), posSk.end()));

//        } while(std::next_permutation(qi.begin(), qi.end()));
//    }
//}

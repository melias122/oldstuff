#ifndef HRX_H
#define HRX_H

//#include <QSet>
#include <QHash>
#include <QMap>

#include "phcisla.h"

//struct _hp{
//public:
//    _hp(QVector<QVector<gNum>> &first, QVector<gNum> &second){

//    }

//    ~_hp(){
////        for(auto begin = std::begin(first); begin != std::end(first); ++begin){
////            delete[] begin;
////        }
////        delete[] second;
//    }

////    QVector<QVector<gNum>> first(){}
////    QVector<gNum> second(){}
//private:
//    gNum **first;
//    gNum *second;
//};

class Hrx;
using HrxPair = QPair<QVector<QVector<gNum>*>, QVector<gNum>*>; // skupina, ktoraKolko
using HrxHHrx = QMap<double, HrxPair>;

enum class val{
    sucetMin = 0, sucetMax,
    hrx, dhrx, dhhrx,
    R1Min, R1Max, S1Min, S1Max, R2Min, R2Max, S2Min, S2Max, HHRXMin, HHRXMax,
    SIZE
};

enum class val2{
    pocetR1 = 0, pocetR2, pocetS1, pocetS2, pocetHHRX, pocetKombi,
    SIZE
};

// hrx pre vystup
class Hrx{
private:

    QVector<double> values = QVector<double>((uint)val::SIZE, 0.f);
    QVector<bigInt> sums = QVector<bigInt>((uint)val2::SIZE);
    HrxPair Skupina_KtoraKolko;
    QHash<QString, bigInt> Ntice, Xtice;
    QVector<int> ZH;
    QString presunString;


    double getVal(val fn) const;
    bigInt getVal2(val2 fn) const;
    void setVal(val fn, double value);
    void setVal2(val2 fn, bigInt value);

public:

    Hrx();
    Hrx(double hrx, double dhrx, QString presun, HrxPair Hp);
    Hrx(double hrx, double dhrx, QHash<gNum, gNum> &presun);
    Hrx(double sumXR, double hrx, double hhrx, double dhrx, double dhhrx, uint sumMin, uint sumMax,
        bigInt pocetKombi, bigInt pocetTeorR1Max, double percStl1Min, double percStl1Max, double percStlOdMin,
        double percStlOdMax, double percR1Min, double percR1Max, QHash<gNum, gNum> presun, HrxPair Hp);

    QString toQString();
    QStringList toQStringList();

    // Vystup pre filrovane .csv
    QStringList filtered();

    uint getSucetMin() const;
    uint getSucetMax() const;
    double getHrx() const;
    double getdHrx() const;
    double getdHHrx() const;
    double getR1Min() const;
    double getR1Max() const;
    double getS1Min() const;
    double getS1Max() const;
    double getR2Min() const;
    double getR2Max() const;
    double getS2Min() const;
    double getS2Max() const;
    double getHHRXMin() const;
    double getHHRXMax() const;
    bigInt getPocetR1() const;
    bigInt getPocetR2() const;
    bigInt getPocetS1() const;
    bigInt getPocetS2() const;
    bigInt getPocetHHRX() const;
    bigInt getPocetKombi() const;
    HrxPair getHrxPair() const;
//    double getNtice() const;
//    double getXtice() const;
//    double getZH() const;
    QString getPresunString() const;

    void setSucetMin(uint arg);
    void setSucetMax(uint arg);
    void setR1Min(double arg);
    void setR1Max(double arg);
    void setR2Min(double arg);
    void setR2Max(double arg);
    void setSTL1Min(double arg);
    void setSTL1Max(double arg);
    void setSTL2Min(double arg);
    void setSTL2Max(double arg);
    void setHHRXMin(double arg);
    void setHHRXMax(double arg);
    void setPocetKombi(bigInt arg);
    void setPocetKombiR1(bigInt arg);
    void setPocetKombiR2(bigInt arg);
    void setPocetKombiSTL1(bigInt arg);
    void setPocetKombiSTL2(bigInt arg);
    void setPocetKombiHHRX(bigInt arg);
    void setNtice(QHash<QString, bigInt> &arg);
    void setXtice(QHash<QString, bigInt> &arg);
    void setZH(QVector<int> &arg);
    void setHrxPair(HrxPair &hp);



    QVector<double> getValues() const;
    QVector<bigInt> getSums() const;
    HrxPair getSkupina_KtoraKolko() const;
    QHash<QString, bigInt> getNtice() const;
    QHash<QString, bigInt> getXtice() const;
    QVector<int> getZH() const;
//    QString getPresunString() const;
};

//QDataStream &operator<<(QDataStream &out, const Hrx &hrx){

//    out << hrx.getValues()
//        << hrx.getSums()
//        << hrx.getSkupina_KtoraKolko()
//        << hrx.getNtice()
//        << hrx.getXtice()
//        << hrx.getZH()
//        << hrx.getPresunString();

//    return out;
//}

//QDataStream &operator>>(QDataStream &in, Hrx &hrx){

//    QVector<double> values = QVector<double>((uint)val::SIZE, 0.f);
//    QVector<bigInt> sums = QVector<bigInt>((uint)val2::SIZE);
//    HrxPair Skupina_KtoraKolko;
//    QHash<QString, bigInt> Ntice, Xtice;
//    QVector<int> ZH;
//    QString presunString;

//    in >> values >> sums >> Skupina_KtoraKolko
//       >> Ntice >> Xtice >> ZH >> presunString;

////    hrx = Hrx();

//    return in;
//}

void makeHrxHHrx_v2(uint n, uint m, PHCisla &phc1DO, PHCisla &phcODDO, HrxHHrx &hrxAll, QString &suborCesta);
//void makeHrxHHrx(uint n, uint m, PHCisla &phc1DO, PHCisla &phcODDO, HrxHHrx &hrxAll, QString &suborCesta);

#endif // HRX_H

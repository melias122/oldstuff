#include "generator.h"

#include <QDebug>
#include <QThread>
#include <QDateTime>
#include <QTime>
#include <QtAlgorithms>
#include <QMutexLocker>
//#include <QSet>
#include <QTextStream>
#include <QMapIterator>
#include <QHash>

#include <utility.h>
#include <cislovacky.h>

Generator::Generator(uint n, uint m, HrxHHrx hrx, GLimits glimits, Vystup *vystup, uint connectionType)
    : n{n}, m{m}, glimits{glimits}, vystup{vystup}, connectionType{connectionType}
{
//    hrxHHrx = hrx.values().toVector();

//    QMutableVectorIterator<HrxPair> itt_hrxHHrx(hrxHHrx);

//    while(itt_hrxHHrx.hasNext()){
//        auto h = itt_hrxHHrx.next();
//        if(!glimits.checkHrx(h.getHrx()))
//            itt_hrxHHrx.remove();
//    }

    QMapIterator<double, HrxPair> itt_hrxHHrx(hrx);

    while(itt_hrxHHrx.hasNext()){
        auto el = itt_hrxHHrx.next();
//        HrxPair hp = el.value();
        if(glimits.checkHrx(el.key()))
            hrxHHrx.push_back(el.value());
    }

    hrxSize = hrx.size();
//    this->vystup = vystup;


    auto ithc = QThread::idealThreadCount();
    if(ithc > 1)
        maxThreads = ithc;
    threadsCount = maxThreads;

}

void Generator::setPhcisla(QPair<PHCisla, PHCisla> phcisla){
    m_PHCisla = phcisla;
}

void Generator::start(){
    while(threadsCount > 0 && !hrxHHrx.isEmpty()){
        createWorker();
    }
}

void Generator::setHrxHHrxFiltered(Hrx &hrx){
    hrxHHrxFiltered.insert(hrx.getHrx(), hrx.getHrxPair());
}

void Generator::workerFinished(){

    {
        QMutexLocker lock(&mutex);
        ++threadsCount;
    }

    start();

    if(threadsCount == maxThreads){
        if(connectionType == 2){
            emit msg("Odfiltrovanych: " + QString::number((int)hrxSize - hrxHHrxFiltered.size()) + " z " + QString::number(hrxSize));
            emit setHrxHHrx(hrxHHrxFiltered);
        }
        emit finished();
    }
}

void Generator::createWorker(){

    QMutexLocker lock(&mutex);

    if(hrxHHrx.isEmpty())
        return;

    // ak nesedi hrx pokracujeme kym nemame vhodne hrx
//    while(!glimits.checkHrx(hrxHHrx.first().getHrx())){
//        hrxHHrx.removeFirst();
//        emit msg("Este ostava prehladat HrxSkupin: " + QString::number(hrxHHrx.size()));

//        if(hrxHHrx.isEmpty())
//            return;
//    }



    QThread *t = new QThread;
    GeneratorWrap *gw = new GeneratorWrap(n, m, hrxHHrx.takeFirst(), glimits);

    if(connectionType == 2){
        gw->setPhcisla(m_PHCisla);
        gw->setPhcislaODDO_orgi(m_oddoFilter);
        connect(t, &QThread::started, gw, &GeneratorWrap::processHrxHHrx);
        connect(gw, &GeneratorWrap::hrxFound, this, &Generator::setHrxHHrxFiltered);
        connect(gw, &GeneratorWrap::hrxFound, vystup, &Vystup::zapisFilter, Qt::BlockingQueuedConnection);
    }
    else if(connectionType == 1){
        connect(t, &QThread::started, gw, &GeneratorWrap::processZhodaR);
        connect(gw, &GeneratorWrap::resultFound, vystup, &Vystup::zapis, Qt::BlockingQueuedConnection);
    }
    else{
        connect(t, &QThread::started, gw, &GeneratorWrap::process);
        connect(gw, &GeneratorWrap::resultFound, vystup, &Vystup::zapis, Qt::BlockingQueuedConnection);
    }

    connect(t, &QThread::finished, t, &QThread::deleteLater);
    connect(gw, &GeneratorWrap::finished, this, &Generator::workerFinished);
    connect(gw, &GeneratorWrap::finished, t, &QThread::quit);
    connect(gw, &GeneratorWrap::finished, gw, &GeneratorWrap::deleteLater);

    gw->moveToThread(t);
    t->start();

    emit msg("Este ostava prehladat HrxSkupin: " + QString::number(hrxHHrx.size()));
    --threadsCount;
}

GeneratorWrap::GeneratorWrap(uint n, uint m) : n{n}, m{m}
{}

GeneratorWrap::GeneratorWrap(uint n, uint m, HrxPair hrxPair, GLimits glimits)
    :n{n}, m{m},
      hrxPair{hrxPair},
      glimits{glimits}
{
}

void GeneratorWrap::setPhcisla(QPair<PHCisla, PHCisla> phcisla){
    phcisla1DO.setPHCisla(phcisla.first);
    phcislaODDO.setPHCisla(phcisla.second);
}

bool GeneratorWrap::nextCombination(kIterators &mnozinaItt, endIterator &end, bool &ok){

    Kombinacia::Iterator nextItt;

    //up
    if(ok && vysledok.size() < n){
        nextItt = mnozinaItt.last() + 1;
        if(nextItt != end){
            mnozinaItt.append(nextItt);
            vysledok.append(*nextItt);
            glimits.append(*nextItt);
            return true;
        }
    }

next:
    if(mnozinaItt.isEmpty())
        return false;

    nextItt = mnozinaItt.last() + 1;
    if(nextItt == end){
        mnozinaItt.removeLast();
        vysledok.removeLast();
        glimits.removeLast();
        goto next;
    }

    mnozinaItt.last() = nextItt;
    vysledok.last() = *nextItt;
    glimits.removeLast();
    glimits.append(*nextItt);

    return true;
}

void GeneratorWrap::process(){

    bool ok;
    auto mnoziny = hrxPair.first;

    Kombinacia mnozina;
    kIterators mnozinaItt;
    endIterator end;


    for(auto m : mnoziny)
        for(auto cislo : *m)
            mnozina.append(cislo);
    qSort(mnozina);

    mnozinaItt.append(mnozina.begin());
    end = mnozina.end();

    vysledok.append(mnozina.first());

    glimits.setHrxPair(hrxPair);
    glimits.append(mnozina.first());

    do{
        ok = glimits.check();
        if(ok && vysledok.size() == n){
            emit resultFound(vysledok);
        }
    }while(nextCombination(mnozinaItt, end, ok));

    emit finished();
}

void GeneratorWrap::processZhodaR(){

    bool ok;
    auto mnoziny = hrxPair.first;

    Kombinacia mnozina;
    kIterators mnozinaItt;
    endIterator end;


    for(auto &m : mnoziny)
        for(auto &cislo : *m)
            mnozina.append(cislo);
    qSort(mnozina);

    mnozinaItt.append(mnozina.begin());
    end = mnozina.end();

    vysledok.append(mnozina.first());

    glimits.setHrxPair(hrxPair);
    glimits.append(mnozina.first());

    do{
        ok = glimits.check();
        if(ok && vysledok.size() == n){
            emit resultFound(vysledok);
        }
    }while(nextCombination(mnozinaItt, end, ok));

    emit finished();
}

void GeneratorWrap::processHrxHHrx(){

    //FILTER

    bool ok;
    auto mnoziny = hrxPair.first;

    Kombinacia mnozina;
    kIterators mnozinaItt;
    endIterator end;


    for(auto &m : mnoziny)
        for(auto &cislo : *m)
            mnozina.append(cislo);
    qSort(mnozina);

    mnozinaItt.append(mnozina.begin());
    end = mnozina.end();

    vysledok.append(mnozina.first());

    glimits.setHrxPair(hrxPair);
    glimits.append(mnozina.first());

    // pre HRX
    bigInt pocetKombi{0};
    QHash<QString, bigInt> ntice_pocty, xtice_pocty;
    QMap<double, int> pocetR1, pocetSTL1, pocetR2, pocetSTL2, pocetHHRX;
    QVector<int> pocetZH;
    uint Sucet_min{std::numeric_limits<unsigned>::max()}, Sucet_max{0};
    Kombinacia lastL = glimits.getLL();
    //
    do{
        ok = glimits.check();
        if(ok && vysledok.size() == n){
            ++pocetKombi;

            uint _sucet = sucet(vysledok);
            if(_sucet < Sucet_min)
                Sucet_min = _sucet;
            if(_sucet > Sucet_max)
                Sucet_max = _sucet;

            auto _ntica = nticaToQString(ntica(vysledok));
            if(ntice_pocty.contains(_ntica))
                ntice_pocty[_ntica]++;
            else
                ntice_pocty[_ntica] = 1;

            auto _xtica = xticaToQString(xtica(vysledok, m));
            if(xtice_pocty.contains(_xtica))
                xtice_pocty[_xtica]++;
            else
                xtice_pocty[_xtica] = 1;

            uint ZH{0};
            for(auto &cislo : vysledok){
                if(lastL.contains(cislo))
                    ++ZH;
            }
//            pocetZH.insert(ZH);
            if(!pocetZH.contains(ZH))
                pocetZH.push_back(ZH);

            double R1 = phcisla1DO.hodnotaRiadokKombinacia(vysledok);
            auto R2 = phcislaODDO.hodnotaRiadokKombinacia(vysledok);
            auto STL1 = phcisla1DO.hodnotaStlpecKombinacia(vysledok);
            auto STL2 = phcislaODDO.hodnotaStlpecKombinacia(vysledok);
            auto HHRX = hrxRplus1(vysledok, phcisla1DO, m);

            pocetR1.insert(R1, 0);
            pocetR2.insert(R2, 0);
            pocetSTL1.insert(STL1, 0);
            pocetSTL2.insert(STL2, 0);
            pocetHHRX.insert(HHRX, 0);
        }
    }while(nextCombination(mnozinaItt, end, ok));

    if(!pocetKombi.is_zero()){

        Kombinacia comb;
        comb.reserve(n);
        QHash<quint8, QVector<quint8>> skupiny{};
        QHash<gNum, gNum> presun;

        for(quint8 i{1}; i <= (quint8)m; ++i){
            quint8 key = phcislaODDO_orig.pocetnostRiadok(i);
            skupiny[key].append(i);
        }

        for(uint i = 0; i < mnoziny.size(); ++i){
            qSort(*mnoziny[i]);
            auto ktora = skupiny.key(*mnoziny[i]);
            auto kolko = hrxPair.second->at(i);
            presun.insert(ktora, kolko);

//            qDebug() << "ktora: " << ktora << "kolko: " << kolko << "presun: " << presun;

            for(quint8 j = 0; j < kolko; ++j){
                comb.push_back(skupiny[ktora][j]);
            }
        }


        double hrx = hrxRplus1(comb, lastL, phcislaODDO_orig, m);
        double dhrx = hrx - hrxR(comb, phcislaODDO_orig, m);

        Hrx hrxx(hrx, dhrx, presun);
        hrxx.setZH(pocetZH);
        hrxx.setNtice(ntice_pocty);
        hrxx.setXtice(xtice_pocty);
        hrxx.setPocetKombi(pocetKombi);
        hrxx.setPocetKombiHHRX({pocetHHRX.size()});
        hrxx.setPocetKombiR1({pocetR1.size()});
        hrxx.setPocetKombiR2({pocetR2.size()});
        hrxx.setPocetKombiSTL1({pocetSTL1.size()});
        hrxx.setPocetKombiSTL2({pocetSTL2.size()});
        hrxx.setR1Min(pocetR1.keys().first());
        hrxx.setR1Max(pocetR1.keys().last());
        hrxx.setR2Max(pocetR2.keys().last());
        hrxx.setR2Min(pocetR2.keys().first());
        hrxx.setSTL1Max(pocetSTL1.keys().last());
        hrxx.setSTL1Min(pocetSTL1.keys().first());
        hrxx.setSTL2Max(pocetSTL2.keys().last());
        hrxx.setSTL2Min(pocetSTL2.keys().first());
        hrxx.setHHRXMin(pocetHHRX.keys().first());
        hrxx.setHHRXMax(pocetHHRX.keys().last());
        hrxx.setSucetMax(Sucet_max);
        hrxx.setSucetMin(Sucet_min);
        hrxx.setHrxPair(hrxPair);

        emit hrxFound(hrxx);
    }

    emit finished();
}

Vystup::Vystup(uint n, uint m, PHCisla &od1, PHCisla &odDo, Archiv archiv, uint max)
    : n{n},
      m{m},
      od1{od1},
      odDo{odDo},
      archiv{archiv},
      maxFileSize{max}
{
    zR = archiv.kombinacia();
    file = new QFile;
//    this->odDo = plus1(odDo, n, m);

    path = pwd() + QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss") + "/";
    mkdir(path);

    for(uint i{1}; i<=n; ++i)
        header << QString::number(i);
    header  << "P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH"<<"Sm"<<"Kk"<<"N-tice"<<"X-tice"
            << "ƩR1-DO"<< "ΔƩR1-DO" << "ƩSTL1-DO" << "ΔƩSTL1-DO" << "Δ(ƩR1-DO-ƩSTL1-DO)"
            << "HHRX" << "ΔHHRX"
            << "ƩR OD-DO" << "ΔƩR OD-DO" << "ƩSTL OD-DO"<< "ΔƩSTL OD-DO" << "Δ(ƩROD-DO-ƩSTLOD-DO)"
            << "HRX" <<	"ΔHRX"
            << "ƩKombinacie";
}

Vystup::Vystup(uint max)
    : maxFileSize{max}
{
    file = new QFile;
    path = pwd() + QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss") + "_Filter" + "/";
    mkdir(path);

    header << "ZH \"r\"/\"r+1\""<< "HRX pre r+1" << "ΔHRX s \"r\"" << "X-cisla \"r\""
           << "Pocet Kombi" << "ƩROD-DO" << "Pocet ƩROD-DO" << "N-tice od-do"
           << "Pocet N-tic" << "X-tice od-do" << "Pocet X-tic" << "ƩSTLOD-DO od-do"
           << "Pocet ƩSTLOD-DO" << "ƩKombi od-do" << "Pocet ƩKombi" << "HHRX pre \"r+1\""
           << "ΔHHRX" << "Pocet HHRX" << "ƩR1-DO od-do"<< "Pocet ƩR1-DO"
           << "ƩSTL1-DO od-do" << "Pocet ƩSTL1-DO";
}


Vystup::~Vystup(){
    if(file->isOpen())
        file->close();
    delete file;

    if(n != 0 && m != 0)
        emit msg("Kombinacii najdenych: " + bigIntToQString(pocetNajdenych));
}

bool Vystup::zapis(const Kombinacia &kombinacia){

    if(cisloExportu == 0 || pocetZapisanych > maxFileSize){
        if(file->isOpen()){
            file->close();
        }
        ++cisloExportu;
        pocetZapisanych = 0;
        file->setFileName(path + QString::number(cisloExportu) + "_" + QTime::currentTime().toString("hms") + ".csv");
        if(file->open(QFile::WriteOnly | QFile::Append) == false)
            return false;

        QTextStream out(file);
        out.setCodec("UTF-8");
        out.setGenerateByteOrderMark(true);
        out << header.join(";").append("\n");
    }

    QTextStream out(file);
    QStringList outList;

    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    outList += kombinaciaToQStringList(kombinacia);
    outList += cislovackyToQStringList(cislovacky(kombinacia, zR));
    outList += doubleToQString(smernica(kombinacia, n, m), 7);
    outList += doubleToQString(korelacia(kombinacia, zR, n, m), 7);
    outList += nticaToQString(ntica(kombinacia));
    outList += xticaToQString(xtica(kombinacia, m));

    outList += doubleToQString(od1.hodnotaRiadokKombinacia(kombinacia));
    outList += doubleToQString(od1.hodnotaRiadokKombinacia(kombinacia) - archiv.R1());
    outList += doubleToQString(od1.hodnotaStlpecKombinacia(kombinacia));
    outList += doubleToQString(od1.hodnotaStlpecKombinacia(kombinacia) - archiv.STL1());
    outList += doubleToQString(od1.hodnotaRiadokKombinacia(kombinacia) - od1.hodnotaStlpecKombinacia(kombinacia));

    double hhrx = hrxRplus1(kombinacia, od1, m);
    double dhhrx = hhrx - archiv.HHRX();
    outList += doubleToQString(hhrx);
    outList += doubleToQString(dhhrx);

    PHCisla odDo2;
    odDo2.setPHCisla(odDo);
    odDo2.increment(kombinacia);
    outList += doubleToQString(odDo2.hodnotaRiadokKombinacia(kombinacia));
    outList += doubleToQString(odDo2.hodnotaRiadokKombinacia(kombinacia) - archiv.ROD());
    outList += doubleToQString(odDo2.hodnotaStlpecKombinacia(kombinacia));
    outList += doubleToQString(odDo2.hodnotaStlpecKombinacia(kombinacia) - archiv.STLOD());
    outList += doubleToQString(odDo2.hodnotaRiadokKombinacia(kombinacia) - odDo2.hodnotaStlpecKombinacia(kombinacia));

    double hrx = hrxR(kombinacia, odDo2, m);
    double dhrx = hrx - archiv.HRX();
    outList += doubleToQString(hrx);
    outList += doubleToQString(dhrx);

    outList += uintToQString(sucet(kombinacia));

    out << outList.join(";").append("\n");

    ++pocetZapisanych;
    ++pocetNajdenych;

    return true;
}

bool Vystup::zapisFilter(Hrx &hrx){
    if(cisloExportu == 0 || pocetZapisanych > maxFileSize){
        if(file->isOpen()){
            file->close();
        }
        ++cisloExportu;
        pocetZapisanych = 0;
        file->setFileName(path + QString::number(cisloExportu) + "_" + QTime::currentTime().toString("hms") + ".csv");
        if(file->open(QFile::WriteOnly | QFile::Append) == false)
            return false;

        QTextStream out(file);
        out.setCodec("UTF-8");
        out.setGenerateByteOrderMark(true);
        out << header.join(";").append("\n");
    }

    QTextStream out(file);

    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    out << hrx.filtered().join(";") << "\n";

    return true;

}

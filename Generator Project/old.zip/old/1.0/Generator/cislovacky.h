#ifndef CISLOVACKY_H
#define CISLOVACKY_H

#include "types.h"

bool P(const uint c);
bool N(const uint c);
bool PR(const uint c);
bool Mc(const uint c);
bool Vc(const uint c);
bool C19(const uint c);
bool C0(const uint c);
bool cC(const uint c);
bool Cc(const uint c);
bool CC(const uint c);

double korelacia(const Kombinacia &aktualna, const Kombinacia &predchadzajuca, uint n, uint m);
double smernica(const Kombinacia &a, uint n, uint m);

Ntica ntica(const Kombinacia &vect);
Xtica xtica(const Kombinacia &vect, uint max_size);

Cislovacky cislovacky(const Kombinacia &aktualnyRiadok, const Kombinacia &predchadzajuciRiadok);

#endif // CISLOVACKY_H

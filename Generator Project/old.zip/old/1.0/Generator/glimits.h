#ifndef GLIMITS_H
#define GLIMITS_H

#include <QSet>
#include <QMultiHash>

#include "phcisla.h"
#include "hrx.h"

class GLimits
{
public:

    enum class Fn : uint {
        START=1,
        Sm=2, Kk=3, P=4, N=5, PR=6, Mc=7, Vc=8, ZH=9, c19=10, c0=11, cC=12, Cc=13, CC=14,
        R1=15, R2=16, STL1=17, STL2=18, Sucet=19,
        dtR1=20, dtSTL1=21, dtRSTL1=22, dtR2=23, dtSTL2=24, dtRSTL2=25,
        HHrx=26, Hrx=27,
        SIZE
    };

    GLimits();
    GLimits(uint n, uint m);

    void setFn_Od(Fn fn, double d);
    void unsetFn_Od(Fn fn);
    bool getFn_Od(Fn fn, double &d);

    void setFn_Do(Fn fn, double d);
    void unsetFn_Do(Fn fn);
    bool getFn_Do(Fn fn, double &d);

    void setHrxPair(const HrxPair &HrxPair);
    void setPHCisla(PHCisla phc1R, PHCisla phcODR);
    void setLL(const Kombinacia last);
    Kombinacia getLL() const;
    void setDelty(double R1, double S1, double R2, double S2);

    void setZakazane(QSet<uint> &zakazane);
    void unsetZakazane();
    void addZakazane(QSet<uint> &zakazane);

    void setZakazaneSTL(QMultiHash<uint, uint> &zak);
    void unsetZakazaneSTL();

    void setPovinne(QSet<uint> &povinne);
    void unsetPovinne();
    void addPovinne(QSet<uint> &povinne);

    void setPovinneSTL(QMultiHash<uint, uint> &pov);
    void unsetPovinneSTL();

    void setXtice(QString xstr);
    void unsetXtice();
    void setNtice(QVector<uint> &ntice);
    void unsetNtice();
    void setNticeStl(QVector<uint> &ntice_stl);
    void unsetNticeStl();

    void append(uint c);
    void removeLast();
    uint size();


    void nastav(QString &nastavenie, uint pos); // pre protokol
    QString getSettings(); // pre protokol


    bool check();
    bool checkNtice();
    bool checkStlNtice();
    bool checkXtice();
    bool checkPovinne();
    bool checkSm();
    bool checkKk();
    bool checkFn(GLimits::Fn fn, double val);
    bool checkRange(GLimits::Fn fn, double from, double to);
    bool checkHrx(double _hrx);

    QVector<uint> povinne;

private:
    uint m, level;  // level == n
    Kombinacia last, result;
    QVector<uint> ntice_vect, ntice_stl_pos, ntice_stl;
    QVector<double> count, max, min, deltaVec;
    PHCisla phcisla1R, phcislaODR;
    QSet<uint> zakazane, func_using, func_od, func_do;
    QHash<uint, uint> ntice;
    QMultiHash<uint, uint> povinneSTL, zakazaneSTL;
    QVector< QSet<uint> > xtice_vect;
    QString xtice_str;
    QHash<int, int*> cisloKolko;   // <cislo, skupina>
    QVector<int> ktoraKolko;       // skupina,kolko este
};

QDataStream &operator<<(QDataStream &out, const GLimits &glimits);
QDataStream &operator>>(QDataStream &in, GLimits &glimits);

#endif // GLIMITS_H

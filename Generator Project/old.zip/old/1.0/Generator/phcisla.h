#ifndef PHCISLA_H
#define PHCISLA_H

#include "types.h"

using Pocetnost = QVector<uint>;
using Pocetnost2D = QVector<Pocetnost>;
using Hodnota = QVector<double>;
using Hodnota2D = QVector<Hodnota>;

/*
 * Pocetnost a Hodnota cisla v stlpci/riadku
*/
class PHCisla {
private:

    uint n, m;

    Pocetnost m_pocetnostRiadok;
    Pocetnost2D m_pocetnostStlpec;

    Hodnota m_hodnotaRiadok;
    Hodnota2D m_hodnotaStlpec;

public:

    PHCisla();
    PHCisla(uint pocetStlpcov, uint pocetRiadkov);
    PHCisla(uint &n, uint &m, Pocetnost &pR, Pocetnost2D &pSTL, Hodnota &hR, Hodnota2D &hSTL);

    void setPHCisla(const PHCisla &phcisla);
    void setPHCisla_ptr(const PHCisla *phcisla);

    uint getN() const;
    uint getM() const;
    Pocetnost getPocetnost() const;
    Pocetnost2D getPocetnost2D() const;
    Hodnota getHodnota() const;
    Hodnota2D getHodnota2D() const;

    void clear();
    void swap(PHCisla &other);

    void incrementRiadok(uint cislo);
    void incrementStlpec(uint cislo, uint stlpec);

//    void decrementRiadok(uint cislo);
//    void decrementStlpec(uint cislo, uint stlpec);

    void increment(const Kombinacia &kombinacia);
    void increment(uint cislo, uint stlpec);

//    void decrement(const Kombinacia &kombinacia);
//    void decrement(uint cislo, uint stlpec);

    double R(uint cislo) const;
    double STL(uint cislo, uint stlpec) const;

    double R(const Kombinacia &kombinacia) const;
    double STL(const Kombinacia &kombinacia) const;

    double Rplus1(const Kombinacia &kombinacia) const;
    double STLplus1(const Kombinacia &kombinacia) const;

    double hodnotaRiadok(uint cislo) const;
    double hodnotaStlpec(uint cislo, uint stlpec) const;

    double hodnotaRiadokKombinacia(const Kombinacia &kombinacia) const;
    double hodnotaStlpecKombinacia(const Kombinacia &kombinacia) const;

    uint pocetnostRiadok(uint cislo) const;
    uint pocetnostStlpec(uint cislo, uint stlpec) const;

    double minHodnotaVRiadku() const;
    double maxHodnotaVRiadku() const;

    double minHodnotaVStlpci() const;
    double maxHodnotaVStlpci() const;
};

QDataStream &operator<<(QDataStream &out, const PHCisla &phcisla);
QDataStream &operator>>(QDataStream &in, PHCisla &phcisla);

PHCisla plus1(PHCisla phcisla, uint n, uint m);

/*
*/
double hrxR(const Kombinacia &kombinacia, const PHCisla &phcisla, uint m);
double hrxRplus1(const Kombinacia &kombinacia, PHCisla phcisla, uint m);
double hrxRplus1(const Kombinacia &kombinacia, const Kombinacia &predchadzajuca, PHCisla phcisla, uint m);


/*
 * Funkcia vypocita pocetnost cisla v stlpci
 * Vypocet : C(pocetStlpcov - AktualnyStlpec, pocetRiadkov - Cislo) * C(aktualnyStlpec - 1, Cislo - 1)
 * Priklad(5/50)
 * r/stl    1                           2                       3       4       5
 * 1:       C(5-1, 50-1) * C(0, 0)      0                       0       0       0
 * 2:       C(5-1, 50-2) * C(0, 0)      C(5-1, 50-2) * C(1, 1)
 * 3:       ...                         ...                     ...     ...     ...
 * ...      ...                         ...                     ...     ...     ...
 * ...      ...                         ...                     ...     ...     ...
 * 49:      0                           0                       0       C(...)  C(...)
 * 50:      0                           0                       0       0       C(0,0) * C(4,49)
*/
bigInt stlCC(int cislo, int stlpec, int n, int m);

/*
 * - Funkcia pre vypocet kombinacneho cisla
 * - Kombinacne cislo C(5,50) == (50 nad 5)
 * - Musi platit ze n <= m
 */
bigInt nCm(uint n, uint m);

#endif // PHCISLA_H

#include "phcisla.h"

#include <QHash>

#include <boost/math/special_functions/binomial.hpp>

double hrx(const Kombinacia &kombinacia, const PHCisla &phcisla, uint m);

PHCisla::PHCisla(){}

PHCisla::PHCisla(uint pocetStlpcov, uint pocetRiadkov) :
    n{pocetStlpcov},
    m{pocetRiadkov},
    m_pocetnostRiadok{Pocetnost(pocetRiadkov, 0)},
    m_pocetnostStlpec{Pocetnost2D(pocetRiadkov,Pocetnost(pocetStlpcov, 0))},
    m_hodnotaRiadok{Hodnota(pocetRiadkov, 0.f)},
    m_hodnotaStlpec{Hodnota2D(pocetRiadkov, Hodnota(pocetStlpcov, 0.f))}
{}

PHCisla::PHCisla(uint &n, uint &m, Pocetnost &pR, Pocetnost2D &pSTL, Hodnota &hR, Hodnota2D &hSTL) :
    n{n}, m{m},
    m_pocetnostRiadok{pR}, m_pocetnostStlpec{pSTL},
    m_hodnotaRiadok{hR}, m_hodnotaStlpec{hSTL}
{}

void PHCisla::setPHCisla(const PHCisla &phcisla){
    n = phcisla.getN();
    m = phcisla.getM();
    m_pocetnostRiadok = phcisla.getPocetnost();
    m_pocetnostStlpec = phcisla.getPocetnost2D();
    m_hodnotaRiadok = phcisla.getHodnota();
    m_hodnotaStlpec = phcisla.getHodnota2D();
}

void PHCisla::setPHCisla_ptr(const PHCisla *phcisla){
    n = phcisla->getN();
    m = phcisla->getM();
    m_pocetnostRiadok = phcisla->getPocetnost();
    m_pocetnostStlpec = phcisla->getPocetnost2D();
    m_hodnotaRiadok = phcisla->getHodnota();
    m_hodnotaStlpec = phcisla->getHodnota2D();
}

uint PHCisla::getN() const{
    return n;
}

uint PHCisla::getM() const{
    return m;
}

Pocetnost PHCisla::getPocetnost() const{
    return m_pocetnostRiadok;
}

Pocetnost2D PHCisla::getPocetnost2D() const{
    return m_pocetnostStlpec;
}

Hodnota PHCisla::getHodnota() const{
    return m_hodnotaRiadok;
}

Hodnota2D PHCisla::getHodnota2D() const{
    return m_hodnotaStlpec;
}

void PHCisla::clear(){

    for(uint r{0}; r<m; ++r){
        m_pocetnostRiadok[r] = 0;
        m_hodnotaRiadok[r] = 0.f;
        for(uint s{0}; s<n; ++s){
            m_pocetnostStlpec[r][s] = 0;
            m_hodnotaStlpec[r][s] = 0.f;
        }
    }
}

void PHCisla::swap(PHCisla &other){
    qSwap(n, other.n);
    qSwap(m, other.m);
    qSwap(m_pocetnostRiadok, other.m_pocetnostRiadok);
    qSwap(m_pocetnostStlpec, other.m_pocetnostStlpec);
    qSwap(m_hodnotaRiadok, other.m_hodnotaRiadok);
    qSwap(m_hodnotaStlpec, other.m_hodnotaStlpec);
}

void PHCisla::incrementRiadok(uint cislo){

    auto pocRiadok = ++m_pocetnostRiadok[cislo-1];

    //    if(pocRiadok > 0){
    bigFloat f{pocRiadok};
    bigInt i{stlCC(1, 1, n, m)};
    f /= i.convert_to<bigFloat>();
    m_hodnotaRiadok[cislo-1] = f.convert_to<double>();
    //    }
}

void PHCisla::incrementStlpec(uint cislo, uint stlpec){

    auto pocStlpec = ++m_pocetnostStlpec[cislo-1][stlpec-1];

//    if(pocStlpec > 0){
    bigFloat f(pocStlpec);
    bigInt i(stlCC(cislo, stlpec, n, m));
    f /= i.convert_to<bigFloat>();
    m_hodnotaStlpec[cislo-1][stlpec-1] = f.convert_to<double>();
//    }
}

void PHCisla::increment(const Kombinacia &kombinacia){
    uint end = kombinacia.size();
    for(uint i{1}; i <= end; ++i){
        increment(kombinacia[i-1], i);
    }
}

void PHCisla::increment(uint cislo, uint stlpec){
    incrementRiadok(cislo);
    incrementStlpec(cislo, stlpec);
}

double PHCisla::R(uint cislo) const{
    return hodnotaRiadok(cislo);
}

double PHCisla::STL(uint cislo, uint stlpec) const{
    return hodnotaStlpec(cislo, stlpec);
}

double PHCisla::R(const Kombinacia &kombinacia) const{
    return hodnotaRiadokKombinacia(kombinacia);
}

double PHCisla::STL(const Kombinacia &kombinacia) const{
    return hodnotaStlpecKombinacia(kombinacia);
}

double PHCisla::Rplus1(const Kombinacia &kombinacia) const{
    PHCisla tmp(n, m);
    tmp.setPHCisla_ptr(this);
    tmp.increment(kombinacia);
    return tmp.R(kombinacia);
}

double PHCisla::STLplus1(const Kombinacia &kombinacia) const{
    PHCisla tmp(n, m);
    tmp.setPHCisla_ptr(this);
    tmp.increment(kombinacia);
    return tmp.STL(kombinacia);
}

double PHCisla::hodnotaRiadok(uint cislo) const{
    return m_hodnotaRiadok[cislo-1];
}

double PHCisla::hodnotaStlpec(uint cislo, uint stlpec) const{
    return m_hodnotaStlpec[cislo-1][stlpec-1];
}

double
PHCisla::hodnotaRiadokKombinacia(const Kombinacia &kombinacia) const{
    double hodnota{0.f};
    for(auto &cislo : kombinacia){
        hodnota += hodnotaRiadok(cislo);
    }
    return hodnota;
}

double
PHCisla::hodnotaStlpecKombinacia(const Kombinacia &kombinacia) const{
    double hodnota{0.f};
    uint pocetStlpcov = kombinacia.size();
    for(uint stlpec{1}; stlpec <= pocetStlpcov; ++stlpec){
        hodnota += hodnotaStlpec(kombinacia[stlpec-1], stlpec);
    }
    return hodnota;
}

uint PHCisla::pocetnostRiadok(uint cislo) const{
    return m_pocetnostRiadok[cislo-1];
}

uint PHCisla::pocetnostStlpec(uint cislo, uint stlpec) const{
    return m_pocetnostStlpec[cislo-1][stlpec-1];
}

double PHCisla::minHodnotaVRiadku() const{
    double min{0};
    auto hodnoty = m_hodnotaRiadok;
    qSort(hodnoty);

    for(uint i{0}; i < n; ++i)
        min += hodnoty[i];

    return min;
}

double PHCisla::maxHodnotaVRiadku() const{
    double max{0};
    auto hodnoty = m_hodnotaRiadok;
    qSort(hodnoty);

    for(uint i{0}; i < n; ++i)
        max += hodnoty[hodnoty.size() - 1 - i];

    return max;
}

double PHCisla::minHodnotaVStlpci() const{
    double min{0};
    auto hodnoty = m_hodnotaStlpec;
    for(auto &stl : hodnoty){
        qSort(stl);
        min += stl[0];
    }
    return min;
}

double PHCisla::maxHodnotaVStlpci() const{
    double max{0};
    auto hodnoty = m_hodnotaStlpec;
    for(auto &stl : hodnoty){
        qSort(stl);
        max += stl[stl.size() - 1];
    }
    return max;
}

QDataStream &operator<<(QDataStream &out, const PHCisla &phcisla){

    out << phcisla.getN() << phcisla.getM()
        << phcisla.getPocetnost() << phcisla.getPocetnost2D()
        << phcisla.getHodnota() << phcisla.getHodnota2D();

    return out;
}

QDataStream &operator>>(QDataStream &in, PHCisla &phcisla){

    uint n, m;
    Pocetnost pocetnostRiadok;
    Pocetnost2D pocetnostStlpec;
    Hodnota hodnotaRiadok;
    Hodnota2D hodnotaStlpec;

    in >> n >> m
       >> pocetnostRiadok >> pocetnostStlpec
       >> hodnotaRiadok >> hodnotaStlpec;

    phcisla = PHCisla(n, m, pocetnostRiadok, pocetnostStlpec, hodnotaRiadok, hodnotaStlpec);

    return in;
}

PHCisla plus1(PHCisla phcisla, uint n, uint m){

    for(uint i{1}; i <= m; ++i)
        phcisla.incrementRiadok(i);

    for(uint stl{1}; stl <= n; ++stl)
        for(uint cislo = stl; cislo <= m-n+1; ++cislo)
            phcisla.incrementStlpec(cislo, stl);

    return phcisla;
}

double hrxR(const Kombinacia &kombinacia, const PHCisla &phcisla, uint m){
    double m_hrx{0.f};

    m_hrx = hrx({}, phcisla, m);

    return m_hrx;
}

double hrxRplus1(const Kombinacia &kombinacia, PHCisla phcisla, uint m){
    double m_hrx{0.f};

    if(kombinacia.isEmpty())
        return m_hrx;

    phcisla.increment(kombinacia);

    m_hrx = hrx(kombinacia, phcisla, m);
    return m_hrx;
}

double hrxRplus1(const Kombinacia &kombinacia, const Kombinacia &predchadzajuca, PHCisla phcisla, uint m){
    double m_hrx{0.f};

    if(kombinacia.isEmpty())
        return m_hrx;

//    phcisla.increment(kombinacia);
    uint stl = 1;
    for(auto &c : kombinacia){
        if(!predchadzajuca.contains(c))
            phcisla.increment(c, stl);
        ++stl;
    }

    m_hrx = hrx(kombinacia, phcisla, m);
    return m_hrx;
}

double hrx(const Kombinacia &kombinacia, const PHCisla &phcisla, uint m){

    double maxCisla{0.f};
    double m_hrx{0.f};
    double M = (double)m;
    QHash<int, int> niCisla;

    for(uint cislo{1}; cislo <= m; ++cislo){
        if(phcisla.pocetnostRiadok(cislo) > maxCisla)
            maxCisla = phcisla.pocetnostRiadok(cislo);
    }

    if(maxCisla == 0)
        return 100.0f;

    for(uint i{1}; i <= m; ++i){
//        int cislo = pocetnostTmp[i].get_R();
        uint cislo = phcisla.pocetnostRiadok(i);

        if(niCisla.contains(cislo))
            ++niCisla[cislo];
        else
            niCisla[cislo] = 1;
    }

    foreach (const int &kluc, niCisla.keys()) {
//        qDebug() << "ni-cisla:" << niCisla[kluc] << "m:" << m << "maxCisla:" << maxCisla << "pocetNi:" << kluc;
        double _hrx1 = niCisla[kluc]/M;                            // prvy zlomok
        double _hrx2 = pow((maxCisla - kluc)/maxCisla, 16.0f);     // druhy
        m_hrx += (_hrx1 * _hrx2);
    }
    m_hrx = pow(m_hrx, 0.25f);
    m_hrx *= 100;

    return m_hrx;
}

bigInt stlCC(int cislo, int stlpec, int n, int m){
    if((cislo - stlpec) < 0 ) return bigInt{0};
    else if((cislo - stlpec) > (m - n)) return bigInt{0};
    else return (nCm(n-stlpec, m-cislo) * nCm(stlpec-1, cislo-1));
}

bigInt nCm(uint n, uint m){
    if(n > m)
        return {0};
    return bigInt{boost::math::binomial_coefficient<double>(m, n)};
}

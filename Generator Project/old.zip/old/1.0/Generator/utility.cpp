#include "utility.h"

#include <QDebug>
#include <QDateTime>
#include <QDir>
#include <vector>

#include <cislovacky.h>

QHash<QString, int> ntice_pocet;
QHash<int, int> zhoda_pocet;
QHash<int ,QHash<QString, int>> zhoda_typ_pocet;
QHash<QString, QHash<QString, int>> ntice_typ_pocet;
QString _suborName;

QString kombinaciaToQString(const Kombinacia &kombinacia){
    return vectorToQString(kombinacia.begin(), kombinacia.end());
}

QStringList kombinaciaToQStringList(const Kombinacia &kombinacia){
    QStringList qStrList{};
    for(auto &cislo : kombinacia)
        qStrList += QString::number(cislo);
    return qStrList;
}

QStringList cislovackyToQStringList(const Cislovacky &cislovacky){
    QStringList qStrList{};

    for(auto &cislo : cislovacky)
        qStrList += QString::number(cislo);

    return qStrList;
}

QString nticaToQString(const Ntica &ntica){
    return vectorToQString(ntica.begin(), ntica.end());
}

QString xticaToQString(const Xtica &xtica){
    return vectorToQString(xtica.begin(), xtica.end());
}

QString bigIntToQString(bigInt bInt){
    return QString(bInt.str().c_str());
}

QString doubleToQString(double d, int prec){
    return QString::number(d, 'g', prec).replace(".", ",");
}

QString uintToQString(uint u){
    return QString::number(u);
}

QString intToQString(int i){
    return QString::number(i);
}

QString pwd(){

//#ifdef __APPLE__
//    auto p = QDir::currentPath().split(QDir::separator());

//    p.removeFirst();
//    for(int i=0; i < 3; ++i)
//        p.removeLast();

//    QString path;
//    for(auto &arg : p)
//        path += QDir::separator() + arg;
//    path += QDir::separator();

//    return path;
//#else
//    return QDir::currentPath().append("/");
//#endif

    return QDir::currentPath().append("/");
}

QString filenameFromPath(const QString path){
    return path.split("/").last().split(".").first();
}

bool mkdir(QString path){
    return QDir().mkpath(path);
}

bool cp(QString filePathFrom, QString pathTo){

    //ak nie je zadany nazov suboru
    //tak nazov suboru ostava povodny
    if(pathTo.split("/").last().isEmpty()){
        auto filename = filePathFrom.split("/").last();
        pathTo += filename;
    }

    if(filePathFrom == pathTo)
        return true;

    QFile destination(pathTo);
    if(destination.exists())
        destination.remove();

    return QFile().copy(filePathFrom, pathTo);
}

uint sucetMin(uint n){
    uint sucet{0};
    for(uint i{1}; i<=n; ++i)
        sucet += i;
    return sucet;
}

uint sucetMax(uint n, uint m){
    uint sucet{0};
    for(uint i{1}; i <=n; ++i, --m)
        sucet += m;
    return sucet;
}

uint sucet(const Kombinacia &kombinacia){
    uint spolu{0};
    for(auto &cislo : kombinacia)
        spolu += cislo;
    return spolu;
}

void ForwardLinearPrediction( std::vector<double> &coeffs, const std::vector<double> &x ) {
    // GET SIZE FROM INPUT VECTORS
    size_t N = x.size() - 1;
    size_t m = coeffs.size();

    // INITIALIZE R WITH AUTOCORRELATION COEFFICIENTS
    std::vector<double> R( m + 1, 0.0f );
    for ( size_t i = 0; i <= m; i++ ){
        for ( size_t j = 0; j <= N - i; j++ ){
            R[ i ] += x[ j ] * x[ j + i ];
        }
    }

    // INITIALIZE Ak
    std::vector<double> Ak( m + 1, 0.0 );
    Ak[ 0 ] = 1.0;

    // INITIALIZE Ek
    double Ek = R[ 0 ];

    // LEVINSON-DURBIN RECURSION
    for ( size_t k = 0; k < m; k++ ){
        // COMPUTE LAMBDA
        double lambda = 0.0;
        for ( size_t j = 0; j <= k; j++ ){
            lambda -= Ak[ j ] * R[ k + 1 - j ];  //7
        }
        lambda /= Ek;

        // UPDATE Ak
        for ( size_t n = 0; n <= ( k + 1 ) / 2; n++ ){
            double temp = Ak[ k + 1 - n ] + lambda * Ak[ n ];
            Ak[ n ] = Ak[ n ] + lambda * Ak[ k + 1 - n ];
            Ak[ k + 1 - n ] = temp;
        }

        // UPDATE Ek
        Ek *= 1.0 - lambda * lambda;
    }

    // ASSIGN COEFFICIENTS
    coeffs.assign( ++Ak.begin(), Ak.end() );
}

QHash<QString, int> Ntice(int n){

    int idx=0, ntice_pos_idx=0;
    QHash<QString, int> ntice;
    QVector<int> nt(n,0), nt_end(n,0);

    // Ntice
    nt[0] = n;
    nt_end[n-1] = 1;

    while(nt != nt_end){
        uint sum=0;

        for(int j=1; j <=nt.size(); ++j)
            sum += nt[j-1]*j;

        if(sum == n){
            ntice.insert(vectorToQString(nt.begin(), nt.end()),ntice_pos_idx);
            ++ntice_pos_idx;

            --nt[idx];
            ++idx;
        } else if(sum < n){
            ++nt[idx];
        } else {
            --nt[idx];
            ++idx;
        }

        if(idx == nt.size()){
            --idx;
            while(nt[idx] == 0)
                --idx;
            --nt[idx];
            ++idx;
        }
    }
    ntice.insert(vectorToQString(nt.begin(), nt.end()), ntice_pos_idx);

    return ntice;
}

QVector< QVector<gNum> > Ntice2(int n){
    QVector<QVector<gNum>> qvi;
    auto ntice = Ntice(n);
    auto values = ntice.values();
    qSort(values);
    for(auto &val : values){
        auto ntica = ntice.key(val);
        auto pos = 1;
        QVector<gNum> qi;
        for(auto &s : ntica.split(" ")){
            auto c = s.toInt();
            if(c > 0){
                for(int j{1}; j <= c; ++j){
                    qi.push_back(pos);
                }
            }
            ++pos;
        }
        qvi.push_back(qi);
    }
//    qvi.squeeze();
    return qvi;
}

void statistikaZhoda(uint n, uint m, uint csvLength){

    CSV statZH;
    QStringList out_stringl;
    bigFloat cr;

    // header
    out_stringl << "Zhoda" << "Pocetnost teor." << "Teoreticka moznost v %" << "Pocetnost" << "Realne dosiahnute %";
    statZH.append(out_stringl);

    for(int i = n; i >= 0; --i){

        out_stringl.clear();

        cr = nCm(i,n).convert_to<bigFloat>() * nCm(m-n-(n-i),m-n).convert_to<bigFloat>();
        out_stringl << QString::number(i)                       // ZH
                    << doubleToQString(cr.convert_to<double>()); // pocet teor

        cr /= nCm(n, m).convert_to<bigFloat>();
        out_stringl << doubleToQString(cr.convert_to<double>()*100)         // teor %
                    << QString::number(zhoda_pocet[i]);    // pocet

        out_stringl << doubleToQString(((double)zhoda_pocet[i]/csvLength)*100);     // real %

        statZH.append(out_stringl);
    }
    statZH.append({";"});

    for(uint i=1; i<=n; i++){

        out_stringl.clear();

        QString zhs = QString::number(i);

        // header
        out_stringl << QString("Zhoda ").append(zhs) << "Pocetnost" << QString("Realne %");
        statZH.append(out_stringl);
        out_stringl.clear();
        //

        // vsetky
        out_stringl << QString("Zhoda ").append(zhs) << QString::number(zhoda_pocet[i]) << doubleToQString(((double)zhoda_pocet[i]/csvLength)*100);
        statZH.append(out_stringl);
        //

        foreach (const QString &poz, zhoda_typ_pocet[i].keys()) {
            out_stringl.clear();
            out_stringl << poz // poz
                        << QString::number(zhoda_typ_pocet[i][poz]) // pocet
                        << doubleToQString(((double)zhoda_typ_pocet[i][poz]/csvLength)*100);
            statZH.append(out_stringl);
        }
        statZH.append({";"});
    }

    zhoda_pocet.clear();
    zhoda_typ_pocet.clear();

    zhoda_pocet.squeeze();
    zhoda_typ_pocet.squeeze();

    exportCsv(statZH, pwd() + "StatistikaZhoda_" + suborName() + ".csv");
}

void statistikaNtice(uint n, uint m, uint csvLength){

    CSV statNtice;
    QStringList out_stringl;
    QHash<QString, int> ntice_pos;
    QHash<QString, bigInt> ntice_poc_teor;

    const QStringList header{"N-tica","Pocetnost teor.", "Teoreticka moznost v %", "Realne dosiahnute %"};
    statNtice.append(header);

    // ntice
    ntice_pos = Ntice(n);

    foreach (const QString &ntica, ntice_pos.keys()) {

        int tica, k = m-n+1;
        bigInt poc_real{1};
        QVector<QString> qs = ntica.split(" ").toVector();

        for(int i=0; i<qs.size(); i++){
            if(qs[i].toInt() == 0)
                continue;
            tica = qs[i].toInt();
            poc_real *= nCm(k-tica,k);
            k -= tica;
        }
        ntice_poc_teor.insert(ntica, poc_real);
    }

    for(int i=ntice_pos.size()-1; i>=0; i--){

        QString tica = ntice_pos.key(i);
        bigFloat cr;

        out_stringl << tica << ntice_poc_teor.value(tica).str().c_str();

        //tero moznost
        cr.assign(ntice_poc_teor.value(tica).convert_to<bigFloat>()/nCm(n,m).convert_to<bigFloat>());
        out_stringl << doubleToQString(cr.convert_to<double>()*100);

        //real dosiah
        out_stringl << doubleToQString((ntice_pocet[tica]/(double)csvLength)*100);

        statNtice.append(out_stringl);
        out_stringl.clear();
    }

    statNtice.append({";"});
    out_stringl.clear();
    out_stringl << "N-tica;" << "Sucin pozicie a stlpca;" << "Pocet vyskytov;" << "%" << "\n";
    statNtice.append(out_stringl);

    for(int i=ntice_pos.size()-1; i>=0; i--){
        QString tica = ntice_pos.key(i);
        QHash<QString, int> qmi = ntice_typ_pocet.value(tica);

        out_stringl.clear();
        out_stringl << tica << "vsetky" << QString::number(ntice_pocet.value(tica)) << doubleToQString(ntice_pocet[tica]/(double)csvLength*100);
        statNtice.append(out_stringl);

        foreach (const QString &p, qmi.keys()) {
            out_stringl.clear();
            out_stringl << tica << p << QString::number(qmi.value(p)) << doubleToQString((qmi.value(p)/(double)csvLength)*100);
            statNtice.append(out_stringl);
        }
    }

    ntice_pocet.clear();
    ntice_typ_pocet.clear();

    exportCsv(statNtice, pwd() + "StatistikaNtice_" + suborName() + ".csv");
}

void mapaNtice(CSV csv, uint n){

    CSV mapaNtice;
    QStringList out_stringl, header, ntica_anl;
    Kombinacia akt;
    QHash<QString, int> ntice_pos, ntice_krok;

    // ntice
    ntice_pos = Ntice(n);
    ntice_krok = QHash<QString, int>(ntice_pos);
    ntice_pocet = QHash<QString, int>(ntice_pos);
    foreach (const QString &strp, ntice_krok.keys()) {
        ntice_krok[strp] = -1;
        ntice_pocet[strp] = 0;
    }

    // header
    header << "N-tica";
    for(uint i=1; i <= n; i++)
        header << QString::number(i);
    header << "Sucet N-tic" << "Sucin pozicie a stlpca";

    for(int i=0; i < ntice_pos.size(); i++)
        header << QString(ntice_pos.key(i)).prepend("Krok ");

    out_stringl << csv.front() << header;
    mapaNtice.append(out_stringl);

    csv.pop_front();

    // analyza
    int pos=0;
    foreach (const QStringList &akt_r, csv) {
        pos++;

        if(!akt.isEmpty())
            akt.clear();

        for(uint i=3; i < n+3;i++)
            akt.push_back(akt_r[i].toInt());

        if(!ntica_anl.empty())
            ntica_anl.clear();

        for(uint i=0; i < n+3+ntice_pos.size(); i++){
            ntica_anl << "";
        }
        ntica_anl[0] = nticaToQString(ntica(akt));

        if(ntica_anl[0] != ntice_pos.key(0)){ // ak neni n 0 0 0 ...

            int start=-1, end=-1;
            for(int i=0; i<akt.size()-1;i++){

                for(int j=i; j <akt.size()-1;j++){
                    if((akt[j+1] - akt[j]) == 1){
                        if(start==-1)
                            start=j;
                        end=j+1;
                        i=j;
                    }
                    else
                        break;
                }
                if(start != end) {
                    int sum=0,sum_stl=1;
                    for(int j=start; j <= end; j++){
                        sum += (int)akt[j];
                        sum_stl *= (j+1);
                        // cislo v stl
                        ntica_anl[j+1] = QString::number(akt[j]);
                    }

                    // sucet ntic
                    if(ntica_anl[n+1].size() > 0)
                        ntica_anl[n+1].append(QString::number(sum).prepend(", "));
                    else
                        ntica_anl[n+1] = QString::number(sum);

                    // sucin stlpcov
                    if(ntica_anl[n+2].size() > 0)
                        ntica_anl[n+2].append(QString::number(sum_stl).prepend(", "));
                    else
                        ntica_anl[n+2] = QString::number(sum_stl);

                    start=end=-1;
                }
            }
        }

        // ntice stat
        QString tica = ntica_anl[0], sucin_stl = ntica_anl[n+2];
        ntice_pocet[tica]++;
        if(!sucin_stl.isEmpty()){
            if(ntice_typ_pocet[tica].value(sucin_stl) > 0){
                int p = ntice_typ_pocet[tica].value(sucin_stl);
                ntice_typ_pocet[tica].insert(sucin_stl, p + 1);
            }
            else{
                ntice_typ_pocet[ntica_anl[0]].insert(ntica_anl[n+2], 1);
            }
        }
        //

        foreach (const QString &strp, ntice_krok.keys()) {
            if(ntice_krok[strp] != -1)
                ntice_krok[strp]++;
        }

        if(ntice_krok[ntica_anl[0]] == -1){
            ntica_anl[n+3+ntice_pos[ntica_anl[0]]] = QString::number(0);
        }
        else{
            ntica_anl[n+3+ntice_pos[ntica_anl[0]]] = QString::number(ntice_krok[ntica_anl[0]]);
        }
        ntice_krok[ntica_anl[0]] = 0;


        out_stringl.clear();
        out_stringl << akt_r << ntica_anl;

        mapaNtice.append(out_stringl);
    }
    exportCsv(mapaNtice, pwd() + "MapaNtice_" + suborName() + ".csv");
}

void mapaZhoda(CSV csv, uint n){

    CSV mapaZhoda;
    int zhoda{0}, l_len{0}, krok{-1};
    QStringList out_stringl, header, zh_anl;
    QVector<int> prd ,akt;
    QHash<int, int> zh_pos;

    // dlzka riadku
    if(csv.size() > 0)
        l_len = csv[1].length();
    else
        l_len = csv.front().length();

    // header
    header << "Zhoda";
    for(uint i{1}; i <= n; ++i)
        header << QString::number(i);
    header << "Pozicia ZH" << "Krok";
    for(uint i{1}; i <= n; ++i)
        header << QString::number(i).append(" Stl r-1/r");

    out_stringl << csv.front() << header;
    mapaZhoda.append(out_stringl);
    // header end

    //header pop
    csv.pop_front();

    for(uint i{0}; i <= n; ++i)
        zhoda_pocet.insert(i, 0);

    foreach (const QStringList &akt_r, csv){

        if(!akt.isEmpty())
            akt.clear();

        for(uint i=3; i < n+3;i++)
            akt.push_back(akt_r[i].toInt());

        zhoda=0;
        zh_anl.clear();
        zh_pos.clear();

        for(uint i=0; i < 2*n+3;i++){
            zh_anl << "";
        }

        for(int i=0; i<akt.size() && !prd.empty(); i++){
            for(int j=0; j <prd.size();j++){
                if(akt[i] == prd[j]){
                    zhoda++;
                    zh_pos.insert(i,j);
                }
            }
        }

        // Zhoda
        zh_anl[0] = QString::number(zhoda);

        // Krok
        if(zhoda > 0){
            if(krok == -1)
                zh_anl[n+2] = QString::number(0);
            else
                zh_anl[n+2] = QString::number(krok);
            krok=1;
        }
        else if(krok >= 0)
            krok++;

        QString pos_zh{""};

        auto zhPosKeys = zh_pos.keys();
        if(!zhPosKeys.isEmpty())
            qSort(zhPosKeys);

        for(int &i : zhPosKeys){
            // 1-n
            mapaZhoda.back()[l_len+1+zh_pos[i]] = QString::number(prd[zh_pos[i]]);
            zh_anl[i+1] = QString::number(akt[i]);

            // Pozicia zhoda
            pos_zh = QString::number(zh_pos[i]+1).append("|").append(QString::number(i+1));
            if(zh_anl[n+1].size() > 0){
//                pos_zh += ", " + QString::number(zh_pos[i]+1).append("|").append(QString::number(i+1));
                zh_anl[n+1].append(", ").append(pos_zh);
            }
            else{
//                pos_zh = QString::number(zh_pos[i]+1).append("|").append(QString::number(i+1));
                zh_anl[n+1].append(pos_zh);
            }

            // nstl r-1/r
            zh_anl[n+3+i] = pos_zh;
        }

        //stat aln
//        auto headerTmp = mapaZhoda.takeFirst();
//        for(auto &riadok : mapaZhoda){

//            QString zhs = riadok[2*n+4];
        QString zhs = zh_anl[n+1];

//        qDebug() << zhs << zh_anl;

        int zhoda_kolko;
        if(!zhs.isEmpty())
            zhoda_kolko = zhs.split(",").size();
        else
            zhoda_kolko = 0;
//        qDebug() << zhoda_kolko << zhs;
        zhoda_pocet[zhoda_kolko]++;

        if(zhoda_kolko > 0){  // len zhoda 1,2,3,..
            if(!zhoda_typ_pocet[zhoda_kolko].contains(zhs))
                zhoda_typ_pocet[zhoda_kolko].insert(zhs,1);
            else
                zhoda_typ_pocet[zhoda_kolko][zhs]++;
        }
//        }
//        mapaZhoda.prepend(headerTmp);
        //

        out_stringl.clear();
        out_stringl << akt_r << zh_anl;

        mapaZhoda.push_back(QStringList(out_stringl));

        prd = akt;
    }

//    //stat aln
//    auto headerTmp = mapaZhoda.takeFirst();
//    for(auto &riadok : mapaZhoda){

//        QString zhs = riadok[2*n+4];
//        int zhoda_kolko;
//        if(!zhs.isEmpty())
//            zhoda_kolko = zhs.split(",").size();
//        else
//            zhoda_kolko = 0;
//        qDebug() << zhoda_kolko << zhs;
//        zhoda_pocet[zhoda_kolko]++;

//        if(zhoda_kolko > 0){  // len zhoda 1,2,3,..
//            if(!zhoda_typ_pocet[zhoda_kolko].contains(zhs))
//                zhoda_typ_pocet[zhoda_kolko].insert(zhs,1);
//            else
//                zhoda_typ_pocet[zhoda_kolko][zhs]++;
//        }
//    }
//    mapaZhoda.prepend(headerTmp);
//    //

    exportCsv(mapaZhoda, pwd() + "MapaZhoda_" + suborName() + ".csv");
}

void pocetnostR(const PHCisla &phcisla1DO, const PHCisla &phcislaODDO, const Kombinacia &poslednyRiadok, uint n, uint m){

    const QStringList hlavicka{
        "Cislo" , "ZH \"r\"" , "P" , "N" ,	"PR" ,	"Mc" ,	"Vc" , "c1-c9" , "C0" ,	"cC" ,	"Cc" ,	"CC" , "Cislo",
        "Teor. pocet" , "Teor. %",
        "Pocet R1-DO" , "% R1-DO",
        "Pocet R1-DO (r+1)" , "% R1-DO (r+1)",
        "Pocet ROD-DO" , "% ROD-DO",
        "Pocet ROD-DO (r+1)" , "% ROD-DO (r+1)"};

    CSV csv{};
    auto phcisla1DOplus1 = plus1(phcisla1DO, n, m);
    auto phcislaODDOplus1 = plus1(phcislaODDO, n, m);

    csv.append(hlavicka);

    // cisla v riadkoch
    for(uint cislo=1; cislo <= m; ++cislo){
        QStringList riadok{}; 
        bigInt teorPocet = 0;
        double teorPerc = 0.f;

        for(uint stl = 1; stl <= n; ++stl)
            teorPocet += stlCC(cislo, stl, n, m);

//        teorPerc = (double)m / teorPocet.convert_to<double>() * 100;

        auto cisl = cislovacky({(gNum)cislo}, poslednyRiadok);

        riadok.append(uintToQString(cislo));
        riadok.append(uintToQString(cisl[10])); //ZH

        //P..CC
        for(int i{0}; i<cisl.size()-1; ++i){
            if(cisl[i] == 0)
                riadok.append("");
            else
                riadok.append(uintToQString(cislo));
        }
        riadok += uintToQString(cislo);
        riadok += bigIntToQString(teorPocet);
        riadok += uintToQString(teorPerc);
        riadok += uintToQString(phcisla1DO.pocetnostRiadok(cislo));
        riadok += doubleToQString(phcisla1DO.hodnotaRiadok(cislo));
        riadok += uintToQString(phcisla1DOplus1.pocetnostRiadok(cislo));
        riadok += doubleToQString(phcisla1DOplus1.hodnotaRiadok(cislo));
        riadok += uintToQString(phcislaODDO.pocetnostRiadok(cislo));
        riadok += doubleToQString(phcislaODDO.hodnotaRiadok(cislo));
        riadok += uintToQString(phcislaODDOplus1.pocetnostRiadok(cislo));
        riadok += doubleToQString(phcislaODDOplus1.hodnotaRiadok(cislo));

        csv.append(riadok);
    }
    exportCsv(csv, pwd() + "PocetnostR_" + suborName() + ".csv");
}

void pocetnostSTL(const PHCisla &phcisla1DO, const PHCisla &phcislaODDO, const Kombinacia &poslednyRiadok, uint n, uint m){

    const QStringList hlavicka{
        "Cislo", "ZH \"r\"" , "P" , "N" ,	"PR" ,	"Mc" ,	"Vc" , "c1-c9" , "C0" ,	"cC" ,	"Cc" ,	"CC", "Stlpec/Cislo",
        "Teor. pocet" , "Teor. %", "Pocet STL1-DO" , "% STL1-DO" , "Pocet STL1-DO (r+1)" , "% STL1-DO (r+1)",
        "Pocet STLOD-DO" , "% STLOD-DO", "Pocet STLOD-DO (r+1)" , "% STLOD-DO (r+1)"};

    CSV csv{};

    auto phcisla1DOplus1 = plus1(phcisla1DO, n, m);
    auto phcislaODDOplus1 = plus1(phcislaODDO, n, m);
    uint poradoveCislo{0};

    csv.append(hlavicka);

    for(uint cislo{1}; cislo <= m; ++cislo){
        for(uint stlpec{1}; stlpec <= n; ++stlpec){

            uint teorPerc{1};
            auto cisl = cislovacky({(gNum)cislo}, poslednyRiadok);
            QStringList riadok{};

            if(stlCC(cislo, stlpec, n, m).is_zero())
                teorPerc = 0;

            riadok.append(uintToQString(poradoveCislo++));
            riadok.append(uintToQString(cisl[10])); //ZH

            //P..CC
            for(int i{0}; i < cisl.size()-1; ++i){
                if(cisl[i] == 0)
                    riadok.append("");
                else
                    riadok.append(uintToQString(cislo));
            }

            riadok += "stlchce(" + uintToQString(stlpec) + "):" + uintToQString(cislo);
            bigInt bi = stlCC(cislo, stlpec, n, m);

            riadok += bigIntToQString(bi);
            riadok += uintToQString(teorPerc);

            riadok += uintToQString(phcisla1DO.pocetnostStlpec(cislo, stlpec));
            riadok += doubleToQString(phcisla1DO.hodnotaStlpec(cislo, stlpec));
            riadok += uintToQString(phcisla1DOplus1.pocetnostStlpec(cislo, stlpec));
            riadok += doubleToQString(phcisla1DOplus1.hodnotaStlpec(cislo, stlpec));
            riadok += uintToQString(phcislaODDO.pocetnostStlpec(cislo, stlpec));
            riadok += doubleToQString(phcislaODDO.hodnotaStlpec(cislo, stlpec));
            riadok += uintToQString(phcislaODDOplus1.pocetnostStlpec(cislo, stlpec));
            riadok += doubleToQString(phcislaODDOplus1.hodnotaStlpec(cislo, stlpec));

            csv.append(riadok);
        }
    }
    exportCsv(csv, pwd() + "PocetnostSTL_" + suborName() + ".csv");
}

void statArchiv(uint n,uint m, const Kombinacie &kombinacie){

    CSV csv;
    QStringList line;
    QVector<Cislovacky> _cislovacky;

    Kombinacia pred{};
    for(auto &akt : kombinacie){
        _cislovacky.append(cislovacky(akt, pred));
        pred = akt;
    }

    //    Počet možných
    line << "" << "Pocet moznych";
    QVector<uint> pm(11,0);
    for(uint cislo{1}; cislo <= m; ++cislo){
        if(P(cislo)) ++pm[0];
        if(N(cislo)) ++pm[1];
        if(PR(cislo)) ++pm[2];
        if(Mc(cislo)) ++pm[3];
        if(Vc(cislo)) ++pm[4];
        if(C19(cislo)) ++pm[5];
        if(C0(cislo)) ++pm[6];
        if(cC(cislo)) ++pm[7];
        if(Cc(cislo)) ++pm[8];
        if(CC(cislo)) ++pm[9];
    }
    pm[10] = n - 1;

    for(auto el : pm){
        line << uintToQString(el);
    }
    csv.append(line);

    //    teoret možné
    line.clear();
    line << "" << "Teor mozne";
    for(auto el : pm){
        QString tm("0-");
        if(el >= n)
            tm += uintToQString(n);
        else
            tm += uintToQString(el);
        line << tm;
    }
    csv.append(line);

    QVector<QVector<double>> ap(11,{}), hp(11,{}), vp(11,{});

    for(unsigned i{0}; i <= n; ++i){
        csv.push_back({});
        line.clear();

        QVector<int> pu(11,0), krok(11,0), vyskyt(11,0), sums(11,0);
        QVector<QVector<int>> krok_pocet(11,{});             // krok, pocet pre N,P,PR...


        int riadok = 1;
        for (auto &qv : _cislovacky) {
            for(int poz{0}; poz < 11; ++poz){
                if(qv[poz] == i){
                    ++pu[poz];                          // pocet udalost i
                    vyskyt[poz] = riadok;
                    if(krok[poz] > 0){
                        krok_pocet[poz].push_back(krok[poz]);
                        sums[poz] += krok[poz];
                    }
                    krok[poz] = 0;
                }
                else{
                    krok[poz]++;
                }
            }
            ++riadok;
        }

        line << "" << "Pocet udalost " + uintToQString(i) ;
        for(auto c : pu){
            line << uintToQString(c);
        }
        csv.append(line);

        //    Súčet diferencií krok udalosť i
        line.clear();
        line << "" << "Sucet diferencii krok udalost " + uintToQString(i);
        for(int j{0}; j< 11; ++j){
            line << uintToQString(sums[j]);
        }
        csv.append(line);

        //    Krok aritmetický priemer krok udalosť  i
        line.clear();
        line << "" << "Krok aritmeticky priemer udalost " + uintToQString(i);
        QVector<double> aritmeticky_priemer(11, 0.f);
        for(int j{0}; j< 11; ++j){
            if(krok_pocet[j].size() > 0)
                aritmeticky_priemer[j] = static_cast<double>(sums[j])/krok_pocet[j].size();
            line << uintToQString(round(aritmeticky_priemer[j]));
        }

        csv.append(line);

        //    Krok harmonický priemer krok udalosť i
        line.clear();
        line << "" << "Krok harmonicky priemer udalost " + uintToQString(i);
        QVector<double> harmonicky_priemer(11, 0.f);
        for(int j{0}; j< 11; ++j){
            double hp = 0.f;

            for(auto &c : krok_pocet[j]){
                hp += 1.0f/c;
            }
            if(hp > 0)
                harmonicky_priemer[j] = krok_pocet[j].size()/hp;
            line << uintToQString(round(harmonicky_priemer[j]));
        }

        csv.append(line);

        //    Krok vážený priemer krok udalosť i
        QSet<int> set;
        line.clear();
        line << "" << "Krok vazeny priemer udalost " + uintToQString(i);
        QVector<double> vazeny_priemer(11, 0.f);
        for(int j{0}; j< 11; ++j){
            double sum = 0.f;

            for(auto el : krok_pocet[j])
                set.insert(el);
            for(auto el : set)
                sum += el;

            if(sum > 0)
                vazeny_priemer[j] = sums[j]/sum;
            line << uintToQString(round(vazeny_priemer[j]));
        }

        csv.append(line);

        //    Riadok posedný výskyt udalosť i
        line.clear();
        line << "" << "Riadok posledny vyskyt udalost " + uintToQString(i);
        for(int j{0}; j< 11; ++j){
            line << uintToQString(vyskyt[j]);
        }
        csv.append(line);

        //    Riadokposedný výskyt i + Krok aritmetický priemer
        line.clear();
        line << "" << "Krok aritmeticky priemer + riadok posledny vyskyt " + uintToQString(i);
        for(int j{0}; j< 11; ++j){
            line << uintToQString(round(vyskyt[j] + aritmeticky_priemer[j]));
            ap[j].push_back(round(vyskyt[j] + aritmeticky_priemer[j]));
        }

        csv.append(line);

        //    Riadok posedný výskyt i + Krok harmonický priemer
        line.clear();
        line << "" << "Krok harmonicky priemer + riadok posledny vyskyt " + uintToQString(i);
        for(int j{0}; j< 11; ++j){
            line << uintToQString(round(vyskyt[j] + harmonicky_priemer[j]));
            hp[j].push_back(round(vyskyt[j] + harmonicky_priemer[j]));
        }

        csv.append(line);

        //    Riadok posedný výskyt i + Krok vážený priemer
        line.clear();
        line << "" << "Krok vazeny priemer + riadok posledny vyskyt " + uintToQString(i);
        for(int j{0}; j< 11; ++j){
            line << uintToQString(round(vyskyt[j] + vazeny_priemer[j]));
            vp[j].push_back(vyskyt[j] + vazeny_priemer[j]);
        }

        csv.append(line);
    }

    auto najblizsia = [](QVector<double> &vec, unsigned dlzka){
        double naj = dlzka + 1;
        int i = 0, ret = -1;

        for(auto c : vec){
            auto val = abs(dlzka - c);
            if(val < naj){
                naj = val;
                ret = i;
            }
            ++i;
        }
        return ret;
    };

//    csv.append({});
    csv.push_back({});
    line.clear();
    line << "" << "Riadok posedny vyskyt + Krok aritmeticky priemer";
    for(int i{0}; i < 11; ++i){
        line << QString::number(najblizsia(ap[i], _cislovacky.size()));
    }
    csv.append(line);

    line.clear();
    line << "" << "Riadok posedny vyskyt + Krok harmonicky priemer";
    for(int i{0}; i < 11; ++i){
        line << QString::number(najblizsia(hp[i], _cislovacky.size()));
    }
    csv.append(line);

    line.clear();
    line << "" << "Riadok posedny vyskyt + Krok vazeny priemer";
    for(int i{0}; i < 11; ++i){
        line << QString::number(najblizsia(vp[i], _cislovacky.size()));
    }
    csv.append(line);


    line.clear();
    line << "" << "Riadok posedný výskyt - Kriterium v  r+1 (riadku)";
    //    for(int i{0}; i < 11; ++i){
    //        auto naj = najblizsia(najblizsia(hp[i], _cislovacky.size()));
    //        if()
    //    }
    csv.append(line);

    exportCsv(csv, pwd() + "StatistikaCislovacky_" + suborName() + ".csv");
}

CSV nacitajCsv(QString cestaCsv){

//    qDebug() << "nacitajCsv";

    CSV csv{};

    QFile subor(cestaCsv);
    if(!subor.open(QFile::ReadOnly)){
        qDebug() << "nacitajCsv: Nepodarilo sa otvorit subor" << cestaCsv;
        return CSV{};
    }

    QTextStream csvStream(&subor);

    //TODO: prazdny, kratky riadok
    while(!csvStream.atEnd()){
        QStringList riadok = csvStream.readLine().split(";");
        csv.push_back(riadok);
    }
//    csv.squeeze();
    return csv;
}

void exportCsv(CSV &csv, QString nazovSuboru){

    QFile subor(nazovSuboru);
    if(!subor.open(QFile::WriteOnly)){
        qDebug() << "exportCsv: Nepodarilo sa vytvorit subor" << nazovSuboru;
        return;
    }

    QTextStream csvOutStream(&subor);

    csvOutStream.setCodec("UTF-8");
    csvOutStream.setGenerateByteOrderMark(true);

    for(auto &riadok : csv){
        csvOutStream << riadok.join(";") << "\n";
    }
//    csvOutStream.flush();
//    subor.flush();
//    subor.close();
}

void write_protocol(QString filename, QString text){

    if(filename.isEmpty() || text.isEmpty())
        return;

    QFile file(filename);

    if(!file.open(QFile::WriteOnly | QFile::Append)){
        qDebug() << "write_protocol: Nepodarilo sa otvorit subor " << filename;
        return;
    }

    QTextStream out(&file);
    out.setCodec("UTF-8");
    out.setGenerateByteOrderMark(true);

    QDateTime t = QDateTime::currentDateTime();
    out << t.toString("dd/MM/yyyy hh.mm.ss: ") << text << "\n";
}

void setSuborName(QString suborName){
//    qDebug() << "setSuborName: " << suborName;
    _suborName = suborName;
}

QString suborName(){
//    qDebug() << "suborName: " << filenameFromPath(_suborName);
    return filenameFromPath(_suborName);
}


#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    qRegisterMetaType<Archiv>("Archiv");
    qRegisterMetaType<Hrx>("Hrx");
    qRegisterMetaType<HrxHHrx>("HrxHHrx");
    qRegisterMetaType<Hrx>("Hrx&");
    qRegisterMetaType<HrxHHrx>("HrxHHrx&");
    qRegisterMetaType<QPair<uint,uint>>("QPair<uint,uint>");
    qRegisterMetaType<QPair<PHCisla, PHCisla>>("QPair<PHCisla, PHCisla>");

    MainWindow w;
    w.show();
    
    return a.exec();
}


//#include <QDebug>
//#include <qvector.h>

//int main(int argc, char *argv[]){

//    QVector<QVector<quint8>> qv2d{{12,3,4}, {4,5,6}};

//    QVector<quint8> qv{1, 2, 3};

//    QVector<QVector<quint8>*> qv2d_ptrs{&qv2d[0], &qv2d[1]};


//    qDebug() << sizeof(qv2d_ptrs) + sizeof(quint8) * qv.capacity();

//    return 0;
//}

//const int C4095 = 4095;

//QVector<int> aPocet_xCISLA(C4095), aFor(C4095), aPresun(C4095);
//int i, j, bLosuj, bVsetky, pocetCisel;

//double xHRX;

//int i101perioda, max101perioda;



//  fHRX, fVystup: TextFile;

//  i101perioda, max101perioda: Integer;

//  TMP_DIR, TMP_DIR_INT: String;
//  sProtokol, sHRX: String;

//procedure ZapisProtokol(coco: String);
//var
//  fProtokol: TextFile;
//begin
//if FileExists(sProtokol) then
//  begin
//      AssignFile(fProtokol,sProtokol);
//      Append(fProtokol);
//      if coco = 'kedy' then
//      Writeln(fProtokol,DateToStr(Date),' ',TimeToStr(Time))
//      else
//      Writeln(fProtokol,coco);
//      CloseFile(fProtokol);
//  end;
//end;

//void rekurzia(int xCISLA){
//    int iFor, jFor;
//    QString sTMP;
//    double dHRX;

//    if(pocetCisel == bLosuj){
//        dHRX = 0.f;
//        if(aPresun[max101perioda] > 0){
//            for(jFor = 1; jFor < max101perioda+1; ++jFor){
//                if(jFor <= C4095)
//                    dHRX += sqrt(sqrt(sqrt(sqrt((max101perioda+1 - jFor)/(max101perioda+1))))) * (aPocet_xCISLA[jFor] / bVsetky);
//            }
//        }
//        else{
//            for(jFor = 1; jFor < max101perioda; ++jFor){
//                if(jFor <= C4095)
//                    dHRX += sqrt(sqrt(sqrt(sqrt((max101perioda - jFor)/(max101perioda))))) * (aPocet_xCISLA[jFor] / bVsetky);
//            }
//        }
//        dHRX = sqrt(sqrt(dHRX));
//    }
//    else if(pocetCisel < bLosuj){
//        if(xCISLA <= max101perioda){
//            for(iFor = 0; iFor < aFor[xCISLA]; ++iFor){
//                pocetCisel += iFor;
//                aPocet_xCISLA[xCISLA] -= iFor;
//                aPocet_xCISLA[xCISLA + 1] += iFor;
//                aPresun[xCISLA] = iFor;
//                rekurzia(xCISLA + 1);
//                pocetCisel -= iFor;
//                aPocet_xCISLA[xCISLA] += iFor;
//                aPocet_xCISLA[xCISLA + 1] -= iFor;
//                aPresun[xCISLA] = 0;
//            }
//        }
//    }
//}

//procedure Rekurzia(xCISLA: Integer);
//var
//  iFor, jFor: Integer;
//  sTMP: String;
//  dHRX: Double;
//begin
//  if pocetCisel = bLosuj then

//  begin
//    dHRX := 0.0;
//{
//    if aPresun[max101perioda] > 0 then
//      begin
//      for jFor := 1 to max101perioda+1 do
//      if jFor <= C4095 then
//      dHRX := dHRX + Sqr(Sqr(Sqr(Sqr((max101perioda+1 - jFor)/(max101perioda+1))))) * (aPocet_xCISLA[jFor] / bVsetky);
//      end

//    else
//}
//      begin
//      for jFor := 1 to max101perioda do
//      if jFor <= C4095 then
//      dHRX := dHRX + Sqr(Sqr(Sqr(Sqr((max101perioda - jFor)/max101perioda)))) * (aPocet_xCISLA[jFor] / bVsetky);
//      end;

//    dHRX := Sqrt(Sqrt(dHRX));
//    Write( fVystup, FloatToStr(100 * dHRX - xHRX));
//    Write( fVystup, ListSeparator, FloatToStr(100 * dHRX));

//    sTMP := '';
//    for jFor := 0 to max101perioda+1 do
//    sTMP := sTMP + ' ' + IntToStr(aPocet_xCISLA[jFor]);
//    Write( fVystup, ListSeparator, sTMP);

//    sTMP := '';
//    for jFor := 0 to max101perioda do
//    sTMP := sTMP + ' ' + IntToStr(aPresun[jFor]);
//    Write( fVystup, ListSeparator, sTMP);

//    Writeln( fVystup);
//    Writeln( sTMP);
//  end

//  else if pocetCisel < bLosuj then

//  if xCISLA <= max101perioda then
//  for iFor := 0 to aFor[xCISLA] do
//  begin
//    pocetCisel := pocetCisel + iFor;
//    aPocet_xCISLA[xCISLA] := aPocet_xCISLA[xCISLA] - iFor;
//    aPocet_xCISLA[xCISLA+1] := aPocet_xCISLA[xCISLA+1] + iFor;
//    aPresun[xCISLA] := iFor;
//    Rekurzia(xCISLA+1);
//    pocetCisel := pocetCisel - iFor;
//    aPocet_xCISLA[xCISLA] := aPocet_xCISLA[xCISLA] + iFor;
//    aPocet_xCISLA[xCISLA+1] := aPocet_xCISLA[xCISLA+1] - iFor;
//    aPresun[xCISLA] := 0;
//  end;

//end;

////begin HRX
//begin

//  TMP_DIR_INT := ParamStr(1);
//  TMP_DIR := '';
//  while TMP_DIR_INT <> '' do
//  begin
//    TMP_DIR := TMP_DIR + Chr(StrToInt(Copy(TMP_DIR_INT,1,Pos('_',TMP_DIR_INT)-1)));
//    Delete(TMP_DIR_INT,1,Pos('_',TMP_DIR_INT));
//  end;

//  AssignFile( fHRX, TMP_DIR);

//  Reset( fHRX);

//  Readln( fHRX, sHRX);
//  bLosuj := StrToInt(sHRX);
//  Readln( fHRX, sHRX);
//  bVsetky := StrToInt(sHRX);

//  Readln( fHRX, sHRX);
//  xHRX := StrToFloat(sHRX);

//  Readln( fHRX, sHRX);
//  AssignFile( fVystup, sHRX);
//  Rewrite( fVystup);
//  Writeln( fVystup, ' dHRX', ListSeparator, ' HRX+1', ListSeparator, 'pocet x-cisla', ListSeparator, 'presun x-(x+1)-cisla');

//  Readln( fHRX, sHRX);
//  max101perioda := StrToInt(sHRX);
//  for i101perioda := 0 to max101perioda do
//  if i101perioda <= C4095 then
//  begin
//  Readln( fHRX, sHRX);
//  aPocet_xCISLA[i101perioda] := StrToInt(sHRX);
//  end;

//  CloseFile(fHRX);
//  DeleteFile(TMP_DIR);

//  //koniec nacitania kriterii
//  aPocet_xCISLA[max101perioda+1] := 0;

//  for i101perioda := 0 to max101perioda do
//  if i101perioda <= C4095 then
//  begin
//    aPresun[i101perioda] := 0;
//    if i101perioda = 1 then
//    begin
//      if aPocet_xCISLA[i101perioda]-1 > bLosuj
//      then aFor[i101perioda] := bLosuj
//      else aFor[i101perioda] := aPocet_xCISLA[i101perioda]-1;
//    end
//    else
//    begin
//      if aPocet_xCISLA[i101perioda] > bLosuj
//      then aFor[i101perioda] := bLosuj
//      else aFor[i101perioda] := aPocet_xCISLA[i101perioda];
//    end;
//  end;

//  pocetCisel := 0;
//  Rekurzia(1);

//  CloseFile( fVystup);
//  // Insert user code here
//end.

////HRX
//{
//if aPocet_xCISLA[0] = bVsetky - bLosuj then dHRX := 1.0
//else
//begin
//  dHRX := 0.0;
//      for i101perioda := 0 to max101perioda do
//      if i101perioda <= C4095 then
//        dHRX := dHRX + Sqr(Sqr(Sqr(Sqr((max101perioda - i101perioda)/max101perioda)))) * (aPocet_xCISLA[i101perioda] / (bVsetky));// / max101perioda;
//end;
//dHRX := Sqrt(Sqrt(dHRX));

//sS := sS + ListSeparator + FloatToStr(100 * dHRX);
//}


#include "utility.h"

#include <QDir>

QString kombinaciaToQString(const Kombinacia &kombinacia){
    return vectorToQString(kombinacia.begin(), kombinacia.end());
}

QStringList kombinaciaToQStringList(const Kombinacia &kombinacia){
    QStringList qStrList{};
    for(auto &cislo : kombinacia)
        qStrList += QString::number(cislo);
    return qStrList;
}

QStringList cislovackyToQStringList(const Cislovacky &cislovacky){
    QStringList qStrList{};

    for(auto &cislo : cislovacky)
        qStrList += QString::number(cislo);

    return qStrList;
}

QString nticaToQString(const Ntica &ntica){
    return vectorToQString(ntica.begin(), ntica.end());
}

QString xticaToQString(const Xtica &xtica){
    return vectorToQString(xtica.begin(), xtica.end());
}

QString bigIntToQString(bigInt &bInt){
    return QString(bInt.str().c_str());
}

QString doubleToQString(double d, int prec){
    return QString::number(d, 'g', prec).replace(".", ",");
}

QString uintToQString(uint u){
    return QString::number(u);
}

QString intToQString(int i){
    return QString::number(i);
}

QString pwd(){

//#ifdef __APPLE__
//    auto p = QDir::currentPath().split(QDir::separator());

//    p.removeFirst();
//    for(int i=0; i < 3; ++i)
//        p.removeLast();

//    QString path;
//    for(auto &arg : p)
//        path += QDir::separator() + arg;
//    path += QDir::separator();

//    return path;
//#else
    return QDir::currentPath() + "/";
//#endif
}

QString filenameFromPath(const QString path){
    return path.split(QDir::separator()).last().split(".").first();
}

bool mkdir(QString path){
    return QDir().mkpath(path);
}

bool cp(QString filePathFrom, QString pathTo){

    //ak nie je zadany nazov suboru
    //tak nazov suboru ostava povodny
    if(pathTo.split(QDir::separator()).last().isEmpty()){
        auto filename = filePathFrom.split(QDir::separator()).last();
        pathTo += filename;
    }

    if(filePathFrom == pathTo)
        return true;

    QFile destination(pathTo);
    if(destination.exists())
        destination.remove();

    return QFile().copy(filePathFrom, pathTo);
}

uint sucetMin(uint n){
    uint sucet{0};
    for(uint i{1}; i<=n; ++i)
        sucet += i;
    return sucet;
}

uint sucetMax(uint n, uint m){
    uint sucet{0};
    for(uint i{1}; i <=n; ++i, --m)
        sucet += m;
    return sucet;
}

void ForwardLinearPrediction( std::vector<double> &coeffs, const std::vector<double> &x ) {
    // GET SIZE FROM INPUT VECTORS
    size_t N = x.size() - 1;
    size_t m = coeffs.size();

    // INITIALIZE R WITH AUTOCORRELATION COEFFICIENTS
    std::vector<double> R( m + 1, 0.0f );
    for ( size_t i = 0; i <= m; i++ ){
        for ( size_t j = 0; j <= N - i; j++ ){
            R[ i ] += x[ j ] * x[ j + i ];
        }
    }

    // INITIALIZE Ak
    std::vector<double> Ak( m + 1, 0.0 );
    Ak[ 0 ] = 1.0;

    // INITIALIZE Ek
    double Ek = R[ 0 ];

    // LEVINSON-DURBIN RECURSION
    for ( size_t k = 0; k < m; k++ ){
        // COMPUTE LAMBDA
        double lambda = 0.0;
        for ( size_t j = 0; j <= k; j++ ){
            lambda -= Ak[ j ] * R[ k + 1 - j ];  //7
        }
        lambda /= Ek;

        // UPDATE Ak
        for ( size_t n = 0; n <= ( k + 1 ) / 2; n++ ){
            double temp = Ak[ k + 1 - n ] + lambda * Ak[ n ];
            Ak[ n ] = Ak[ n ] + lambda * Ak[ k + 1 - n ];
            Ak[ k + 1 - n ] = temp;
        }

        // UPDATE Ek
        Ek *= 1.0 - lambda * lambda;
    }

    // ASSIGN COEFFICIENTS
    coeffs.assign( ++Ak.begin(), Ak.end() );
}

//bool nextCombination(Kombinacia &vysledok, kIterators &mnozinaItt, endIterator &end, uint &N, bool &ok ){

//    Kombinacia::Iterator nextItt;

//    //up
//    if(ok && vysledok.size() < N){
//        nextItt = mnozinaItt.last() + 1;
//        if(nextItt != end){
//            mnozinaItt.append(nextItt);
//            vysledok.append(*nextItt);
//            return true;
//        }
//    }

//next:
//    if(mnozinaItt.isEmpty())
//        return false;

//    nextItt = mnozinaItt.last() + 1;
//    if(nextItt == end){
//        mnozinaItt.removeLast();
//        vysledok.removeLast();
//        goto next;
//    }

//    mnozinaItt.last() = nextItt;
//    vysledok.last() = *nextItt;

//    return true;
//}

//uint sucetMin(uint n){
//    uint sucet{0};
//    for(uint i{1}; i<=n; ++i)
//        sucet += i;
//    return sucet;
//}

//uint sucetMax(uint n, uint m){
//    uint sucet{0};
//    for(uint i{1}; i <=n; ++i, --m)
//        sucet += m;
//    return sucet;
//}

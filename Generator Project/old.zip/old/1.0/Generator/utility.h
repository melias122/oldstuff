#ifndef UTILITY_H
#define UTILITY_H

#include "types.h"
#include "phcisla.h"

template<class T>
QString vectorToQString(T begin, T end){
    QString qStr;

    for(; begin != end; ++begin){
        qStr.append(QString::number(*begin));
        if(begin < end - 1)
            qStr.append(" ");
    }

    return qStr;
}

QString kombinaciaToQString(const Kombinacia &kombinacia);
QStringList kombinaciaToQStringList(const Kombinacia &kombinacia);
QStringList cislovackyToQStringList(const Cislovacky &cislovacky);
QString nticaToQString(const Ntica &ntica);
QString xticaToQString(const Xtica &xtica);
QString bigIntToQString(bigInt bInt);
QString doubleToQString(double d, int prec = 14);
QString uintToQString(uint u);
QString intToQString(int i);
QString pwd();
QString filenameFromPath(const QString path);
bool mkdir(QString path);
bool cp(QString filePathFrom, QString pathTo);
uint sucetMin(uint n);
uint sucetMax(uint n, uint m);
uint sucet(const Kombinacia &kombinacia);

// Returns in vector linear prediction coefficients calculated using Levinson Durbin
void ForwardLinearPrediction(std::vector<double> &coeffs, const std::vector<double> &x);

// vrati vsetky ntice   n 0 0 0 0..
//                      ..0 0 0 0 n
QHash<QString, int> Ntice(int n);
QVector<QVector<gNum> > Ntice2(int n);

void statistikaZhoda(uint n, uint m, uint csvLength);
void statistikaNtice(uint n, uint m, uint csvLength);
void mapaNtice(CSV csv, uint n);
void mapaZhoda(CSV csv, uint n);
void pocetnostR(const PHCisla &phcisla1DO, const PHCisla &phcislaODDO, const Kombinacia &poslednyRiadok, uint n, uint m);
void pocetnostSTL(const PHCisla &phcisla1DO, const PHCisla &phcislaODDO, const Kombinacia &poslednyRiadok, uint n, uint m);
void statArchiv(uint n, uint m, const Kombinacie &kombinacie);

CSV nacitajCsv(QString cestaCsv);
void exportCsv(CSV &csv, QString nazovSuboru);
void write_protocol(QString filename, QString text);
void setSuborName(QString suborName);
QString suborName();

#endif // UTILITY_H

#include "cislovacky.h"

#include <QSet>
#include <cmath>

const QSet<uint> Prvocisla{2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89};

bool P(const uint c){
    return (c%2) == 0;
}

bool N(const uint c){
    return !P(c);
}

bool PR(const uint c){
    return Prvocisla.contains(c);
}

bool Mc(const uint c){
    if(C0(c))
        return false;
    QString s = QString::number(c);
    return (s[s.size()-1] < QChar('6'));
}

bool Vc(const uint c){
    return !Mc(c);
}

bool C19(const uint c){
    return (c < 10);
}

bool C0(const uint c){
   QString s = QString::number(c);
   if(s.size() < 2)
       return false;
   return (s[s.length() -1] == QChar('0'));
}

bool cC(const uint c){
    QString s = QString::number(c);
    if(s.size() < 2)
        return false;
    return (s[0] < s[1]);
}

bool Cc(const uint c){
    QString s = QString::number(c);
    if(s.size() < 2)
        return false;
    if(C0(c))
        return false;
    return (s[0] > s[1]);
}

bool CC(const uint c){
    QString s = QString::number(c);
    if(s.size() < 2)
        return false;
    return (s[0] == s[1]);
}

double korelacia(const Kombinacia &aktualna, const Kombinacia &predchadzajuca, uint n, uint m) {

    double dKorelacia = 0.0f;
    if(predchadzajuca.isEmpty())
        return dKorelacia;

    for(uint i=0; i < n; i++){
        int akt = aktualna[i];
        int pred = predchadzajuca[i];
        dKorelacia += pow((akt-pred)/(double)m,4)/(double)n;
    }

    dKorelacia = pow(1.0 - sqrt(dKorelacia),8);

    return dKorelacia;

//    double dKorelacia = 0.0f;

//    if(predchadzajuca.isEmpty())
//        return dKorelacia;

//    double M = static_cast<double>(m);
//    double N = static_cast<double>(n);

//    for(uint i{0}; i < n; ++i){
//        double p = aktualna[i] - predchadzajuca[i];
//        p /= M;
//        dKorelacia += pow(p,4)/N;
//    }

//    dKorelacia = pow(1.0 - sqrt(dKorelacia),8);

//    return dKorelacia;
}

double smernica(const Kombinacia &a, uint n, uint m){

    int pocetSmernic = 0;
    double dSmernica = 0.0f;

    double M = (double)(m - 1);
    double N = (double)(n - 1);

    for(uint i{0}; i < n-1; ++i) {
        for(uint j{i+1}; j < n; ++j){

            double p1 = (double)(a[j] - a[i]);
            double p2 = (double)(j - i);

            p1 /= M;
            p2 /= N;

            p1 /= p2;

            dSmernica += p1;
            pocetSmernic++;
        }
    }

    if(pocetSmernic > 0)
        dSmernica /= pocetSmernic;

    return dSmernica;
}

Ntica ntica(const Kombinacia &vect){

    Ntica tice(vect.size(),0), result(vect);

    int tica=0;
    result.push_back(0);
    for(int i = 0; i < result.size(); i++){

        if(i == result.size()-2){
            if(tica > 0) tice[tica]++;
            else tice[0]++;
            break;
        }

        int c = static_cast<int>(result[i] - result[i+1]);
        if(c == result[i]){
            if(tica > 0) tice[tica]++;
            break;
        }
        if(c < -1){
            if(tica==0){ tice[0]++; }
            else{
                tice[tica]++;
                tica=0;
            }
        }
        else{ tica++; }
    }
    return tice;
}

Xtica xtica(const Kombinacia &vect, uint max_size){

    Xtica vysl(((max_size+9)/10),0);

    foreach (const uint &qvn, vect) {
        uint pos = 0;
        for(uint i=10; i <= 90; i+=10, pos++){
            if(qvn <= i){
                vysl[pos]++;
                break;
            }
        }
    }
    return vysl;
}

Cislovacky cislovacky(const Kombinacia &aktualnyRiadok, const Kombinacia &predchadzajuciRiadok){

    Cislovacky cislovacky(11,0);

    foreach (const uint &cislo, aktualnyRiadok) {

        if(P(cislo))
            cislovacky[0]++;
        else
            cislovacky[1]++;

        if(PR(cislo))
            cislovacky[2]++;

        if(Mc(cislo))
            cislovacky[3]++;
        else
            cislovacky[4]++;

        if(C19(cislo))
            cislovacky[5]++;
        if(C0(cislo))
            cislovacky[6]++;
        if(cC(cislo))
            cislovacky[7]++;
        if(Cc(cislo))
            cislovacky[8]++;
        if(CC(cislo))
            cislovacky[9]++;

        if(    !predchadzajuciRiadok.isEmpty() &&
                predchadzajuciRiadok.contains(cislo))
            cislovacky[10]++;
    }
    return cislovacky;
}

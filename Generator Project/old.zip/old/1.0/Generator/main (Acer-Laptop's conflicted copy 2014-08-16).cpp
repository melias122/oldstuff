//#include "mainwindow.h"
//#include <QApplication>

//int main(int argc, char *argv[])
//{
//    QApplication a(argc, argv);

//    qRegisterMetaType<Archiv>("Archiv");
//    qRegisterMetaType<Hrx>("Hrx");
//    qRegisterMetaType<HrxHHrx>("HrxHHrx");
//    qRegisterMetaType<Hrx>("Hrx&");
//    qRegisterMetaType<HrxHHrx>("HrxHHrx&");
//    qRegisterMetaType<QPair<uint,uint>>("QPair<uint,uint>");
//    qRegisterMetaType<QPair<PHCisla, PHCisla>>("QPair<PHCisla, PHCisla>");

//    MainWindow w;
//    w.show();
    
//    return a.exec();
//}

//#include<QDebug>
//#include<QDir>
//#include<combination.h>

//#include <QFile>
//#include <QPointer>
//#include <QTextStream>

// zaoukruhlu na desatinee miesto s presnostou
// pres = desatinne miesto za ciarkou
//double gRound(double f, int pres)
//{
//    double tmp = 1;
//    for(int i{0}; i < pres; ++i)
//        tmp *= 0.1f;
//    return (double) (floor(f*(1.0f/tmp) + 0.5)/(1.0f/tmp));
//}

#include "qdir.h"
#include "qdebug.h"

int main(){


    qDebug() << QDir::currentPath().append("/");

    return 0;
}

//bool check(Kombinacia &kombinacia){
//    if(kombinacia.last() % 2 == 0)
//        return false;
//    return true;
//}



//using kIterators = QList<Kombinacia::Iterator>;
//using endIterator = Kombinacia::Iterator;

//inline bool
//nextCombination(Kombinacia &vysledok, kIterators &mnozinaItt, endIterator &end, uint &N, bool &ok ){

//    Kombinacia::Iterator nextItt;

//    //up
//    if(ok && vysledok.size() < N){
//        nextItt = mnozinaItt.last() + 1;
//        if(nextItt != end){
//            mnozinaItt.append(nextItt);
//            vysledok.append(*nextItt);
//            return true;
//        }
//    }

//next:
//    if(mnozinaItt.isEmpty())
//        return false;

//    nextItt = mnozinaItt.last() + 1;
//    if(nextItt == end){
//        mnozinaItt.removeLast();
//        vysledok.removeLast();
//        goto next;
//    }

//    mnozinaItt.last() = nextItt;
//    vysledok.last() = *nextItt;

//    return true;
//}

//int main(){
//    Kombinacia kombinacia{1}, mnozina{1,2,3,4,5,6,7,8,9,10};
//    QList<Kombinacia::Iterator> mnozinaItt;
//    mnozinaItt.push_back(mnozina.begin());
//    bool ok = true;
//    auto end = mnozina.end();
//    uint N = 4;

//    do{
//        ok = check(kombinacia);
//        if(ok && kombinacia.size() == 3)
//            qDebug() << kombinacia;
//    } while(nextCombination(kombinacia, mnozinaItt, end, N, ok));

//    return 0;
//}


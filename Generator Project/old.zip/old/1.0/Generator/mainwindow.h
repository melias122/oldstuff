#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QCheckBox>

#include <glimits.h>
#include <archiv.h>
#include <phcisla.h>
#include <hrx.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    enum class OD_DO{ Od=0, Do};

    uint getM();
    uint getN();
    bool min2();
    bool set_limits();
    void swapEnabled(QLineEdit* a, QLineEdit *stred, QLineEdit* b);

    void changeOd(QLineEdit *Od, GLimits::Fn fn, const QString &arg, double min = std::numeric_limits<double>::lowest(), double max = std::numeric_limits<double>::max());
    void changeDo(QLineEdit *Do, GLimits::Fn fn, const QString &arg, double min = std::numeric_limits<double>::lowest(), double max = std::numeric_limits<double>::max());
    void changeStred(QLineEdit *s, QLineEdit *Od, GLimits::Fn fn, const QString &arg , double min = std::numeric_limits<double>::lowest(), double max = std::numeric_limits<double>::max());
    bool changeHelper(QLineEdit *kliknuty, QString arg, double &val, double min, double max);
    int changeODDO(QLineEdit *kliknuty, const QString &arg, QLineEdit *p_od, QLineEdit *p_do, int n);
    void setLimit(GLimits::Fn fn, double d, OD_DO od_do);
    void unsetLimit(GLimits::Fn fn, OD_DO od_do);

    void setLines(QVector< QVector<QLineEdit*> > &lines);
    void setStlNtice(QVector< QCheckBox* > &stlNtice);

    void saveCurrentState(){

//        unsigned UCcislo;
//        Archiv archiv;
//        HrxHHrx hrxHHrx, hrxHHrx_Filtrovane;
//        PHCisla phcisla1DO, phcislaODDO;
//        GLimits glimits;
//        QString suborPath, suborName, path;
//        bool generator_running;

//        QDataStream out;

    }

    void loadCurrentState(){

    }

signals:
    void stop_generator();

public slots:
    void info(QString s);
    void running(bool state);
    void last_line();

    void setLastLine(QStringList riadok);
    void setUCcisloRiadok(QPair<unsigned, unsigned> UC);
    void setHrxHHrx(HrxHHrx &hrxHHrx);
    void setHrxHHrxFiltrovane(HrxHHrx &hrxHHrx);
    void setPhcisla(QPair<PHCisla, PHCisla> phcisla);
    void setArchiv(Archiv archiv);
    void initUI();

    
private slots:
    void on_read_file_clicked();
    void on_del_r1_clicked();
    void on_del_stl1_clicked();
    void on_del_sum_komb_clicked();
    void on_del_rod_clicked();
    void on_del_stlod_clicked();
    void on_del_all_clicked(int arg = 0);
    void on_show_limits_clicked();
    void show_btns();
//    void on_read_arch_clicked();
    void on_r1gl_clicked();
    void on_r1gl_2_clicked();
    void on_pgl_clicked();
    void on_pgl_2_clicked();
    void on_generate_rplus1_clicked();
    void on_mcgl_clicked();
    void on_mcgl_2_clicked();
    void on_c1c9gl_clicked();
    void on_c1c9gl_2_clicked();
    void on_c0gl_2_clicked();
    void on_ngl_clicked();
    void on_ngl_2_clicked();
    void on_Ccgl_clicked();
    void on_Ccgl_2_clicked();
    void on_c0gl_clicked();
    void on_prgl_clicked();
    void on_prgl_2_clicked();
    void on_vcgl_clicked();
    void on_vcgl_2_clicked();
    void on_cCgl_clicked();
    void on_cCgl_2_clicked();
    void on_zhgl_clicked();
    void on_zhgl_2_clicked();
    void on_CCgl_clicked();
    void on_CCgl_2_clicked();
    void on_stl1gl_clicked();
    void on_stl1gl_2_clicked();
    void on_kombgl_clicked();
    void on_kombgl_2_clicked();
    void on_r2gl_clicked();
    void on_r2gl_2_clicked();
    void on_stl2gl_clicked();
    void on_stl2gl_2_clicked();
    void on_del_P_clicked();
    void on_del_Mc_clicked();
    void on_del_c1c9_clicked();
    void on_del_N_clicked();
    void on_del_Cc_clicked();
    void on_del_C0_clicked();
    void on_del_PR_clicked();
    void on_del_Vc_clicked();
    void on_del_cC_clicked();
    void on_del_ZH_clicked();
    void on_del_CC_clicked();
    void on_del_povinne_clicked();
    void on_del_zakazane_clicked();
    void on_del_Ntice_clicked();
    void on_lim_r_clicked();
    void on_lim_r1_clicked();
    void on_del_Xtice_clicked();
    void on_del_Sm_clicked();
    void on_del_Kor_clicked();
    void on_smgl_clicked();
    void on_korgl_clicked();
    void on_smgl_2_clicked();
    void on_korgl_2_clicked();
    void on_lim_zh_clicked();
    void on_generate_mix_clicked();
    void on_mix_r_textChanged(const QString &arg1);
    void on_dtr1gl_clicked();
    void on_dtslt1gl_clicked();
    void on_dtRSTL1gl_clicked();
    void on_dtr1gl2_clicked();
    void on_dtstl1gl2_clicked();
    void on_dtRSTL1gl2_clicked();
    void on_dtr2gl_clicked();
    void on_dtRSTL2gl_clicked();
    void on_dtstl2gl_clicked();
    void on_dtr2gl2_clicked();
    void on_dtstl2gl2_clicked();
    void on_dtRSTL2gl2_clicked();
    void on_del_dtr1_clicked();
    void on_del_dtSTL1_clicked();
    void on_del_dtRSTL1_clicked();
    void on_del_dtr2_clicked();
    void on_del_dtstl2_clicked();
    void on_del_dtRSTL2_clicked();
    void on_del_Ntice_2_clicked();
    void on_del_povinneSTL_clicked();
    void on_del_zakazaneSTL_clicked();
    void on_del_HHRX_clicked();
    void on_HHRXgl_clicked();
    void on_HHRXgl2_clicked();
    void on_HRXgl_clicked();
    void on_HRXgl2_clicked();
    void on_del_HRX_clicked();
    void on_KolkoKombi_clicked();
    void on_filter_clicked();
    void on_Pod_textChanged(const QString &arg1);
    void on_P_textChanged(const QString &arg1);
    void on_Pdo_textChanged(const QString &arg1);
    void on_Nod_textChanged(const QString &arg1);
    void on_N_textChanged(const QString &arg1);
    void on_Ndo_textChanged(const QString &arg1);
    void on_Mcod_textChanged(const QString &arg1);
    void on_Mc_textChanged(const QString &arg1);
    void on_Mcdo_textChanged(const QString &arg1);
    void on_Vcod_textChanged(const QString &arg1);
    void on_Vc_textChanged(const QString &arg1);
    void on_Vcdo_textChanged(const QString &arg1);
    void on_PRod_textChanged(const QString &arg1);
    void on_PR_textChanged(const QString &arg1);
    void on_PRdo_textChanged(const QString &arg1);
    void on_c1_c9od_textChanged(const QString &arg1);
    void on_c1_c9_textChanged(const QString &arg1);
    void on_c1_c9do_textChanged(const QString &arg1);
    void on_C0od_textChanged(const QString &arg1);
    void on_C0_textChanged(const QString &arg1);
    void on_C0do_textChanged(const QString &arg1);
    void on_cCod_textChanged(const QString &arg1);
    void on_cC_textChanged(const QString &arg1);
    void on_cCdo_textChanged(const QString &arg1);
    void on_Ccod_textChanged(const QString &arg1);
    void on_Cc_textChanged(const QString &arg1);
    void on_Ccdo_textChanged(const QString &arg1);
    void on_CCod_textChanged(const QString &arg1);
    void on_CC_textChanged(const QString &arg1);
    void on_CCdo_textChanged(const QString &arg1);
    void on_ZHod_textChanged(const QString &arg1);
    void on_ZH_textChanged(const QString &arg1);
    void on_ZHdo_textChanged(const QString &arg1);
    void on_Smod_textChanged(const QString &arg1);
    void on_Sm_textChanged(const QString &arg1);
    void on_Smdo_textChanged(const QString &arg1);
    void on_Korod_textChanged(const QString &arg1);
    void on_Kor_textChanged(const QString &arg1);
    void on_Kordo_textChanged(const QString &arg1);
    void on_r1od_textChanged(const QString &arg1);
    void on_r1R_textChanged(const QString &arg1);
    void on_r1do_textChanged(const QString &arg1);
    void on_stl1od_textChanged(const QString &arg1);
    void on_stl1R_textChanged(const QString &arg1);
    void on_stl1do_textChanged(const QString &arg1);
    void on_dtr1od_textChanged(const QString &arg1);
    void on_dtr1_textChanged(const QString &arg1);
    void on_dtr1do_textChanged(const QString &arg1);
    void on_dtstl1od_textChanged(const QString &arg1);
    void on_dtstl1_textChanged(const QString &arg1);
    void on_dtstl1do_textChanged(const QString &arg1);
    void on_dtRSTL1od_textChanged(const QString &arg1);
    void on_dtRSTL1_textChanged(const QString &arg1);
    void on_dtRSTL1do_textChanged(const QString &arg1);
    void on_HHRXod_textChanged(const QString &arg1);
    void on_HHRXr_textChanged(const QString &arg1);
    void on_HHRXdo_textChanged(const QString &arg1);
    void on_kombod_textChanged(const QString &arg1);
    void on_kombR_textChanged(const QString &arg1);
    void on_kombdo_textChanged(const QString &arg1);
    void on_r2od_textChanged(const QString &arg1);
    void on_r2R_textChanged(const QString &arg1);
    void on_r2do_textChanged(const QString &arg1);
    void on_stl2od_textChanged(const QString &arg1);
    void on_stl2R_textChanged(const QString &arg1);
    void on_stl2do_textChanged(const QString &arg1);
    void on_dtr2od_textChanged(const QString &arg1);
    void on_dtr2_textChanged(const QString &arg1);
    void on_dtr2do_textChanged(const QString &arg1);
    void on_dtstl2od_textChanged(const QString &arg1);
    void on_dtstl2_textChanged(const QString &arg1);
    void on_dtstl2do_textChanged(const QString &arg1);
    void on_dtRSTL2od_textChanged(const QString &arg1);
    void on_dtRSTL2_textChanged(const QString &arg1);
    void on_dtRSTL2do_textChanged(const QString &arg1);
    void on_HRXod_textChanged(const QString &arg1);
    void on_HRXr_textChanged(const QString &arg1);
    void on_HRXdo_textChanged(const QString &arg1);
    void on_Povinne_textChanged(const QString &arg1);
    void on_PovinneSTL_textChanged(const QString &arg1);
    void on_Zakazane_textChanged(const QString &arg1);
    void on_ZakazaneSTL_textChanged(const QString &arg1);
    void on_n_tice_textChanged(const QString &arg1);

private:
    Ui::MainWindow *ui;

    QVector< QVector<QLineEdit*> > lines;
    QVector< QCheckBox* > stlNtice;

    unsigned UCcislo;
    Archiv archiv;
    HrxHHrx hrxHHrx, hrxHHrx_Filtrovane;
    PHCisla phcisla1DO, phcislaODDO;
    GLimits glimits;
    QString suborPath, suborName, path;

    bool generator_running;
};

#endif // MAINWINDOW_H

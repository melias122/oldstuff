#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QCheckBox>

#include <functional>


//#include "archiv.h"
#include "glimits.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int get_M();
    int get_N();
    bool min2();
    bool set_limits(Glimits &g);
    void swapEnabled(QLineEdit* a, QLineEdit* b);

signals:
    void stop_generator();

public slots:
    void info(QString s);
    void running(bool state);
    void last_line();

    void set_UC();

    
private slots:
    void on_read_file_clicked();
    void on_del_r1_clicked();
    void on_del_stl1_clicked();
    void on_del_sum_komb_clicked();
    void on_del_rod_clicked();
    void on_del_stlod_clicked();
    void on_del_all_clicked();
    void on_show_limits_clicked();
    void show_btns();
//    void on_read_arch_clicked();
    void on_r1gl_clicked();
    void on_r1gl_2_clicked();
    void on_pgl_clicked();
    void on_pgl_2_clicked();
    void on_generate_rplus1_clicked();
    void on_mcgl_clicked();
    void on_mcgl_2_clicked();
    void on_c1c9gl_clicked();
    void on_c1c9gl_2_clicked();
    void on_c0gl_2_clicked();
    void on_ngl_clicked();
    void on_ngl_2_clicked();
    void on_Ccgl_clicked();
    void on_Ccgl_2_clicked();
    void on_c0gl_clicked();
    void on_prgl_clicked();
    void on_prgl_2_clicked();
    void on_vcgl_clicked();
    void on_vcgl_2_clicked();
    void on_cCgl_clicked();
    void on_cCgl_2_clicked();
    void on_zhgl_clicked();
    void on_zhgl_2_clicked();
    void on_CCgl_clicked();
    void on_CCgl_2_clicked();
    void on_stl1gl_clicked();
    void on_stl1gl_2_clicked();
    void on_kombgl_clicked();
    void on_kombgl_2_clicked();
    void on_r2gl_clicked();
    void on_r2gl_2_clicked();
    void on_stl2gl_clicked();
    void on_stl2gl_2_clicked();
    void on_del_P_clicked();
    void on_del_Mc_clicked();
    void on_del_c1c9_clicked();
    void on_del_N_clicked();
    void on_del_Cc_clicked();
    void on_del_C0_clicked();
    void on_del_PR_clicked();
    void on_del_Vc_clicked();
    void on_del_cC_clicked();
    void on_del_ZH_clicked();
    void on_del_CC_clicked();
    void on_Pod_editingFinished();
    void on_Pdo_editingFinished();
    void on_P_editingFinished();
    void on_del_povinne_clicked();
    void on_del_zakazane_clicked();
    void on_del_Ntice_clicked();
    void on_Nod_editingFinished();
    void on_N_editingFinished();
    void on_Ndo_editingFinished();
    void on_Mcod_editingFinished();
    void on_Mcdo_editingFinished();
    void on_Mc_editingFinished();
    void on_Vcod_editingFinished();
    void on_Vcdo_editingFinished();
    void on_Vc_editingFinished();
    void on_lim_r_clicked();
    void on_lim_r1_clicked();
    void on_del_Xtice_clicked();
    void on_del_Sm_clicked();
    void on_del_Kor_clicked();
    void on_smgl_clicked();
    void on_korgl_clicked();
    void on_smgl_2_clicked();
    void on_korgl_2_clicked();
    void on_lim_zh_clicked();
    void on_generate_mix_clicked();
    void on_mix_r_textChanged(const QString &arg1);
    void on_dtr1gl_clicked();
    void on_dtslt1gl_clicked();
    void on_dtRSTL1gl_clicked();
    void on_dtr1gl2_clicked();
    void on_dtstl1gl2_clicked();
    void on_dtRSTL1gl2_clicked();
    void on_dtr2gl_clicked();
    void on_dtRSTL2gl_clicked();
    void on_dtstl2gl_clicked();
    void on_dtr2gl2_clicked();
    void on_dtstl2gl2_clicked();
    void on_dtRSTL2gl2_clicked();
    void on_del_dtr1_clicked();
    void on_del_dtSTL1_clicked();
    void on_del_dtRSTL1_clicked();
    void on_del_dtr2_clicked();
    void on_del_dtstl2_clicked();
    void on_del_dtRSTL2_clicked();
    void on_del_Ntice_2_clicked();
    void on_del_povinneSTL_clicked();
    void on_del_zakazaneSTL_clicked();
    void on_del_HHRX_clicked();
    void on_HHRXgl_clicked();
    void on_HHRXgl2_clicked();
    void on_HRXgl_clicked();
    void on_HRXgl2_clicked();
    void on_del_HRX_clicked();
    void on_KolkoKombi_clicked();

private:
    Ui::MainWindow *ui;

    QVector< QVector<std::function<void(Glimits&, double)>> > gfuntions;
    QVector< QVector<QLineEdit*> > lines;
    QVector< QCheckBox* > stlNtice;

//    Archiv *archiv;
    QString path_file;
    bool generator_running;
};

//bool HrxFilter(QMap<double, Hrx> &hrx, Glimits &g);

#endif // MAINWINDOW_H

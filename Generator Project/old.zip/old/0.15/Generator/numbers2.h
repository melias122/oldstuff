#ifndef PHCISLA_H
#define PHCISLA_H

#include <boost/multiprecision/cpp_int.hpp>
//#include <vector>

using bigInt = boost::multiprecision::cpp_int;

using Pocetnost = std::vector<unsigned>;
using Pocetnost2D = std::vector<Pocetnost>;

using Hodnota = std::vector<double>;
using Hodnota2D = std::vector<Hodnota>;

/*
 * Pocetnost a Hodnota cisla v stlpci/riadku
*/
class PHCisla {
private:

    unsigned n, m;

    Pocetnost m_pocetnostRiadok;
    Pocetnost2D m_pocetnostStlpec;

    Hodnota m_hodnotaRiadok;
    Hodnota2D m_hodnotaStlpec;

    void incrementRiadok(unsigned cislo);
    void incrementStlpec(unsigned cislo, unsigned stlpec);

public:

    PHCisla(unsigned pocetStlpcov, unsigned pocetRiadkov);

    void increment(const std::vector<unsigned> &nums);
    void increment(unsigned cislo, unsigned stlpec);

    double hodnotaRiadok(unsigned cislo) const;
    double hodnotaStlpec(unsigned cislo, unsigned stlpec) const;

    unsigned pocetnostRiadok(unsigned cislo) const;
    unsigned pocetnostStlpec(unsigned cislo, unsigned stlpec) const;

    double minHodnotaVRiadku();
    double maxHodnotaVRiadku();

    double minHodnotaVStlpci();
    double maxHodnotaVStlpci();
};

/*
*/
//double hrx(PHCisla phCisla, const std::vector<unsigned> &vector);

/*
 * Funkcia vypocita pocetnost cisla v stlpci
 * Vypocet : C(pocetStlpcov - AktualnyStlpec, pocetRiadkov - Cislo) * C(aktualnyStlpec - 1, Cislo - 1)
 * Priklad(5/50)
 * r/stl    1                           2                       3       4       5
 * 1:       C(5-1, 50-1) * C(0, 0)      0                       0       0       0
 * 2:       C(5-1, 50-2) * C(0, 0)      C(5-1, 50-2) * C(1, 1)
 * 3:       ...                         ...                     ...     ...     ...
 * ...      ...                         ...                     ...     ...     ...
 * ...      ...                         ...                     ...     ...     ...
 * 49:      0                           0                       0       C(...)  C(...)
 * 50:      0                           0                       0       0       C(0,0) * C(4,49)
*/
bigInt stlCC(int cislo, int stlpec, int n, int m);

/*
 * - Funkcia pre vypocet kombinacneho cisla
 * - Kombinacne cislo C(5,50) == (50 nad 5)
 * - Musi platit ze n <= m
 */
bigInt nCm(unsigned n, unsigned m);

#endif // PHCISLA_H

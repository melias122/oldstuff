#ifndef ARCHIV2_H
#define ARCHIV2_H

class Archiv2
{
private:
    unsigned n, m;
public:
    Archiv2();
};

bool readArhiv(){

    for(unsigned long i{0}; i < 10e7; ++i){
        ;
    }

    return true;
}

#endif // ARCHIV2_H

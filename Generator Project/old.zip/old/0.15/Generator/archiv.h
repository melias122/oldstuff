#ifndef ARCHIV_H
#define ARCHIV_H

#include <QObject>
#include <QLinkedList>


#include <boost/multiprecision/cpp_int.hpp>
//#include <boost/math/special_functions/binomial.hpp>
//#include <boost/multiprecision/cpp_dec_float.hpp>

//#include "utils.h"
#include "fileop.h"
#include "numbers.h"
#include "numbers2.h"

//struct HrxPair{
//private:
//    QVector<QVector<int>> group;
//    QVector<int> ktoraKolko;

////    void insert(QVector<int> &qi, int i){

////        auto cislo = qi.front();
////        for(int pos{0}; pos < skupiny.size(); ++pos){
////            if(cislo < skupiny[pos].front()){
////                skupiny.insert(pos, qi);
////                ktoraKolko.insert(pos, i);
////                return;
////            }
////        }
////        skupiny.push_back(qi);
////        ktoraKolko.push_back(i);
////    }

//public:
//    HrxPair(QVector<QVector<int>> &group, QVector<int> &ktoraKolko)
//        : group{group},
//          ktoraKolko{ktoraKolko}
//    {
////        for(int i{0}; i<skupiny.size(); ++i){
////            insert(skupiny[i], ktoraKolko[i]);
////        }
//    }

////    QVector<QVector<int>> getSkupiny(){
////        return group;
////    }

////    QVector<int> getKtoraKolko(){
////        return ktoraKolko;
////    }
//};

//struct HrxCislo{
//    int Cislo;
//    int Skupina;

//    HrxCislo(int cislo, int skupina) : Cislo{cislo}, Skupina{skupina} {}
//    bool operator <(HrxCislo hrxC) const { return Cislo < hrxC.Cislo; }
//};

//struct HrxSkupiny2{
//private:
//public:
//};

using HrxPair = QPair<QVector<QVector<int>>, QVector<int>>; // skupina, ktoraKolko

struct Hrx{
private:

    QString presunStr(){
        QString p;
        QVector<int> qi;

        foreach (const int& key, presun.keys()) {
            while(qi.size() <= (key+1))
                qi.push_back(0);
            qi[key] = presun[key];
        }
        foreach (const int& i, qi) {
            p += QString::number(i) + " ";
        }
        p.remove(p.size() - 1);
        return p;
    }

public:
    double sumXR;
    double hrx, hhrx;
    double dhrx, dhhrx;
    double percStl1Min, percStl1Max, percStlOdMin, percStlOdMax, percR1Min, percR1Max;
    int sumMin, sumMax;
    bigInt pocetKombi, pocetTeorR1Max;
    QMap<int, int> presun;
    HrxPair Hp;

    Hrx(){}
    Hrx(double sumXR,
        double hrx, double hhrx,
        double dhrx, double dhhrx,
        int sumMin, int sumMax,
        bigInt pocetKombi, bigInt pocetTeorR1Max,
        double percStl1Min, double percStl1Max, double percStlOdMin, double percStlOdMax, double percR1Min, double percR1Max,
        QMap<int, int> presun, HrxPair Hp)
        : sumXR{sumXR},
          hrx{hrx}, hhrx{hhrx},
          dhrx{dhrx}, dhhrx{dhhrx},
          sumMin{sumMin}, sumMax{sumMax},
          pocetKombi{pocetKombi}, pocetTeorR1Max{pocetTeorR1Max},
          percStl1Min{percStl1Min}, percStl1Max{percStl1Max}, percStlOdMin{percStlOdMin}, percStlOdMax{percStlOdMax}, percR1Min{percR1Min}, percR1Max{percR1Max},
          presun{presun},
          Hp{Hp}
    {}

    QString string(){
        return  double_to_qstr(hrx) + ";" + double_to_qstr(dhrx) + ";" +
                presunStr() + ";" +
                double_to_qstr(sumXR) + ";" +
                QString::number(percStlOdMin,'g',12) + "-" + QString::number(percStlOdMax,'g',12) + ";" +
                QString::number(sumMin) + "-" + QString::number(sumMax) + ";" +
                QString(pocetKombi.str().c_str()) + ";" +
                double_to_qstr(hhrx) + ";" + double_to_qstr(dhhrx) + ";" +
                QString::number(percR1Min,'g',12) + "-" + QString::number(percR1Max,'g',12) + ";" +
                QString(pocetTeorR1Max.str().c_str()) + ";" +
                QString::number(percStl1Min,'g',12) + "-" + QString::number(percStl1Max,'g',12);
    }

    QStringList stringList(){
        return string().split(";");
    }
};

class Archiv : public QObject
{
    Q_OBJECT
public:

    //
    QLinkedList< QStringList > lines, archiv;
    QVector<double> delta;
    double hrxLast, hhrxLast;
    QMap<double, Hrx> hrxAll;

    Archiv();
    Archiv(unsigned n, unsigned m, QString &filename);

    Numbers get_1DO() const;
    Numbers get_1DO1() const;
    Numbers get_ODDO() const;
    Numbers get_ODDO1() const;
    Numbers get_ODDO2() const;
    qvect get_last_comb() const;
    QStringList get_last_numberings() const;
    unsigned get_n() const;
    unsigned get_m() const;
    QLinkedList< qvect > get_qvnums() const;
    unsigned get_UC() const;
    unsigned get_UC_line_num() const;

//    double hrx();

    double get_delta(int dt);
    QVector<double> get_deltav(){return this->delta;}

    QString get_cwd() const;

    boost::multiprecision::cpp_int get_stlcc(int c, int stl);
    boost::multiprecision::cpp_int get_nCm(int n, int m);

    void set_n(unsigned n);
    void set_m(unsigned m);
    void set_1DO(Numbers n);
    void set_ODDO(Numbers n);
    void set_qvnums(QLinkedList< qvect > qvn);
    void set_lastcomb(qvect qv);
    void set_od_do(unsigned a, unsigned b);

    Numbers make_numbers(Nmap &pocetnost);

signals:
    void finished();
    void info(QString);
    
public slots:
    void process();
    void process_od_do();
    void save();
    void load(QString filename);
    
private:
    //
    unsigned n, m, a_od, a_do, UC, UC_line_num;
    Numbers n_1DO, n_ODDO, n_1DO_1, n_ODDO_1, nODDO_2;
    Reader *r;

    QStringList last_numberings;
    QString filepath, filename;
    QLinkedList< qvect > qvnums;
    qvect last_comb;
    QVector<double> deltar;

    QMap<QString, int> ntice_pocet, zhoda_pocet;
    QMap<QString, QMap<QString, int> > ntice_typ_pocet, zhoda_typ_pocet;
    //


    void poc_stl(QString od_do = "");
    void poc_R(QString od_do = "");
    QMap<QString, int> ntice_all();
    void stat_zh();
    void stat_ntice();
    void mapa_zh();
    void mapa_ntice();
    void hrx_hhrx();
//    void gen_sums();
    void copy_file();
    void export_arch();
    void make_rp1();
    void make_archiv();
    void parse();
    void n1DO(int to);
    void nODDO(int from);


};

QDataStream &operator<<(QDataStream &out, const Archiv &ar);
QDataStream &operator>>(QDataStream &in, Archiv &ar);

void save_archiv(const Archiv &a);
void load_archiv(Archiv &a, QString &filename);

void ForwardLinearPrediction( std::vector<double> &coeffs, const std::vector<double> &x );

#endif // ARCHIV_H

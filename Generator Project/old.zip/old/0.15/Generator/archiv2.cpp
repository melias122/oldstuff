#include "archiv2.h"

Archiv2::Archiv2()
{
}

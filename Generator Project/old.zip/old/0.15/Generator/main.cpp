//#include "mainwindow.h"
//#include <QApplication>

//int main(int argc, char *argv[])
//{
//    QApplication a(argc, argv);

//    qRegisterMetaType<qvect>("qvect");
//    qRegisterMetaType<qvect2d>("qvect2d");

//    MainWindow w;
//    w.show();
    
//    return a.exec();
//}

//#include <numbers2.h>
//#include <QVector>
//#include <QList>
//#include <QDebug>
//#include <functional>

//#include <QMap>

//int main(){

////    std::shared_ptr<int> ptr_i(new int);

//    QVector<int> kolko{1,2,3};

//    QMap<int, int*> cisloKolko{
//        {1, &kolko[0]},
//        {2, &kolko[0]},
//        {3, &kolko[0]}
//    };

////    qDebug() << cisloKolko;
//    QMutableMapIterator<int, int*> itt(cisloKolko);

//    while(itt.hasNext()){
//        itt.next();
//        qDebug() << itt.key() << *itt.value();
//    }

//    (*cisloKolko[1])--;
//    itt.toFront();
//    while(itt.hasNext()){
//        itt.next();
//        qDebug() << itt.key() << *itt.value();
//    }

//    return 0;
//}



int main(){

//    int **Pole = new int[5][50];

//    return 0;
}


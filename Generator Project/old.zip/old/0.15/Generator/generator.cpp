#include "generator.h"
#include "combination.h"

Generator::Generator(unsigned n, unsigned m, Glimits g){

    this->n = (num)n;
    this->m = (num)m;
    init(g);
}

Generator::Generator(Archiv *archiv, int r, Glimits g){

    this->n = (num)archiv->get_n();
    this->m = (num)archiv->get_m();
    this->archiv = archiv;
    this->r = r;
//    this->r1 = r1;

    init(g);
}

Generator::Generator(Archiv *archiv, int r, Glimits g, QMap<double, Hrx>& hrx){
    this->n = (num)archiv->get_n();
    this->m = (num)archiv->get_m();
    this->archiv = archiv;
    this->r = r;
    this->hrx = hrx;
//    this->r1 = r1;

    init(g);
}

Generator::Generator(unsigned n, unsigned m, Glimits g, QMap<double, Hrx>& hrx){
    this->n = (num)n;
    this->m = (num)m;
    this->hrx = hrx;
    init(g);
}

void Generator::init(Glimits g){

    this->limit = g;
    level = 0;
    result = qvect(n,0);
    stopped = false;

    pos.clear();
    for(num i=0; i<n; i++){
        pos.push_back(0);
    }

    combs.clear();
    for(num i=1; i <= n; i++){
        qvect lev;
        for(num j=i; j <= m-n+i; j++){
            lev.push_back(j);
        }
        combs.push_back(lev);
    }

    if(!g.povinne.isEmpty()){

        for(int i=0; i<g.povinne.size();i++){
            num min =g.povinne[i];
            for(int j=combs[i].size()-1;j>=0;j--){
                num akt = combs[i][j];
                if(akt > min)
                    combs[i].pop_back();
                else
                    break;
            }
        }
    }
}

Generator::~Generator(){
    combs.clear();
    pos.clear();
    result.clear();
}

void Generator::stop(){

    stopped = true;
    generator_state(false);
    emit ended();
    emit finished();
}

void Generator::process_mix(){

    generator_state(true);

    Glimits limit_orig = limit;

    qvect a, b;

    for(int i=0; i<n; ++i){
        a << i;
    }
    for(int i=0; i<r; ++i){
        b << i;
    }

    QSet<num> numbers;

    for(num i{1}; i<=m; ++i)
        numbers.insert(i);

    do{
//        foreach (const Hrx& h, hrx) {

            Nmap poc_1_do, poc_od_do;
            poc_1_do = archiv->get_1DO().get_pocetnost();
            poc_od_do = archiv->get_ODDO().get_pocetnost();

            for(unsigned i=0; i < b.size(); i++){

                int stl = b[i] + 1;
                int j= archiv->get_last_comb()[b[i]];

                poc_1_do[j].set_R(poc_1_do[j].get_R() + 1);
                poc_od_do[j].set_R(poc_od_do[j].get_R() + 1);

                poc_1_do[j].set_STL(stl, poc_1_do[j].get_STL(stl)+1);
                poc_od_do[j].set_STL(stl,poc_od_do[j].get_STL(stl)+1);
            }

            Numbers n1 = archiv->make_numbers(poc_1_do);
            Numbers n2 = archiv->make_numbers(poc_od_do);

            this->limit = limit_orig;

            QSet<num> pov,zak;

            for(int i=0; i<b.size(); i++)
                pov.insert((num)archiv->get_last_comb()[b[i]]);

            for(int i=0; i<archiv->get_last_comb().size(); i++)
                if(!pov.contains(archiv->get_last_comb()[i]))
                    zak.insert(archiv->get_last_comb()[i]);

            limit.add_zakazane(zak);
            limit.add_povinne(pov);

            //
//            auto numbersCp = numbers;

//            auto numbersGroup = h.Hp.first;

//            for(auto& v : numbersGroup){
//                for(auto& c : v){
//                    if(!pov.contains(c))
//                        numbersCp.remove(c);
//                }
//            }

//            limit.set_hrxPair(h.Hp);
//            limit.add_zakazane(numbersCp);
            //

            limit.set_1DO(n1);
            limit.set_ODDO(n2);

            init(limit);

            while (!combs.first().empty() && !stopped) {

                limit.add(combs[level][pos[level]]);

                // podmienka vlozenia
                if(limit.check()){
                    result[level] = combs[level][pos[level]];
                }

                // posuniem sa na leveli
                else{
                    next();
                    continue;
                }

                // up
                if(level < n-1){
                    level++;
                    continue;
                }

                emit send_result2(result,n1,n2);
                next();                 // hladame dalej
            }

//        }

    }while(stdcomb::next_combination(a.begin(),a.end(),b.begin(),b.end()));

    stop();
}

void Generator::process(){

    generator_state(true);

    Glimits limit_orig = limit;
    QSet<num> numbers;

    for(num i{1}; i<=m; ++i)
        numbers.insert(i);

    foreach (const Hrx& h, hrx) {

        this->limit = limit_orig;

        auto numbersCp = numbers;

        auto numbersGroup = h.Hp.first;

//        foreach (const int& i, numbersGroup) {
        for(auto& v : numbersGroup){
            for(auto& c : v){
                numbersCp.remove(c);
            }
        }

        limit.set_hrxPair(h.Hp);
        limit.add_zakazane(numbersCp);
        init(limit);
        while (!combs.first().empty() && !stopped) {

            limit.add(combs[level][pos[level]]);

            // podmienka vlozenia
            if(limit.check()){
                result[level] = combs[level][pos[level]];
            }

            // posuniem sa na leveli
            else{
                next();
                continue;
            }

            // up
            if(level < n-1){
                level++;
                continue;
            }

            //      print();                // nasli sme kombinaciu
            emit send_result(result);
            next();                 // hladame dalej
        }
    }

//  emit ended();
//  emit finished();
    stop();
}

//void Generator::print(){
//    foreach (num i, result) {
//        std::cout << (int)i << " ";
//    }
//    std::cout << std::endl;
//}

//private
void Generator::next(){

    limit.remove();
    if(level == 0){
        for(int i=0; i<n; i++){
            combs[i].pop_front();
            pos[i] = 0;
        }
        return;
    }

    if(pos[level] < combs[level].size()-1){

        pos[level]++;
        if(level < n){

            for(int i=level; i<n; i++){
                pos[i] = pos[level];
            }
        }
    }
    else{
        level--;
        next();
    }
}

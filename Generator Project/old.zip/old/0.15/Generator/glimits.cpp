#include "glimits.h"

//#include <QDebug>

#include <QtAlgorithms>

Glimits::Glimits(int n, int m){

    this->level = n;
    this->m = m;
//    this->num1_R = n1_r;
//    this->numOD_R = nod_r;
//    this->last = last_comb;
    this->count = QVector<double>(28,0);
    this->max = QVector<double>(28,0);
    this->min = QVector<double>(28,0);

//    this->deltaVec = delta;

    this->n = Numberings(n,m);

    max[2] = std::numeric_limits<double>::max();
    max[3] = 1;
}

Glimits::Glimits(int n, int m, Numbers n1_r, Numbers nod_r, qvect last_comb, QVector<double> delta)
{
    this->level = n;
    this->m = m;
    this->num1_R = n1_r;
    this->numOD_R = nod_r;
    this->last = last_comb;
    this->count = QVector<double>(28,0);
    this->max = QVector<double>(28,0);
    this->min = QVector<double>(28,0);

    this->deltaVec = delta;

    this->n = Numberings(n,m);

    max[2] = std::numeric_limits<double>::max();
    max[3] = 1;
}

void Glimits::set_r1od(double r1){
//    r1od = r1;
    func_od.push_back(15);
    func_using.insert(15);
    min[15] = r1;
}
void Glimits::set_r1do(double r1){
//    r1do = r1;
    func_do.push_back(15);
    func_using.insert(15);
    max[15] = r1;
}
void Glimits::set_r2od(double r2){
//    r2od = r2;
    func_od.push_back(16);
    func_using.insert(16);
    min[16] = r2;
}
void Glimits::set_r2do(double r2){
//    r2do = r2;
    func_do.push_back(16);
    func_using.insert(16);
    max[16] = r2;
}
void Glimits::set_stl1od(double s){
//    stl1od = s;
    func_od.push_back(17);
    func_using.insert(17);
    min[17] = s;
}
void Glimits::set_stl1do(double s){
//    stl1do = s;
    func_do.push_back(17);
    func_using.insert(17);
    max[17] = s;
}
void Glimits::set_stl2od(double s){
//    stl2od = s;
    func_od.push_back(18);
    func_using.insert(18);
    min[18] = s;
}
void Glimits::set_stl2do(double s){
//    stl2do = s;
    func_do.push_back(18);
    func_using.insert(18);
    max[18] = s;
}

void Glimits::set_kombod(unsigned u){
//    kombod = u;
    func_od.push_back(19);
    func_using.insert(19);
    min[19] = (double)u;
}
void Glimits::set_kombdo(unsigned u){
//    kombdo = u;
    func_do.push_back(19);
    func_using.insert(19);
    max[19] = (double)u;
}

void Glimits::set_Nod(unsigned u){
//    Nod = u;
    func_od.push_back(4);
    func_using.insert(4);
    min[4] = (double)u;
}
void Glimits::set_Ndo(unsigned u){
//    Ndo = u;
    func_do.push_back(4);
    func_using.insert(4);
    max[4] = (double)u;
}

void Glimits::set_Pod(unsigned u){
//    Pod = u;
    func_od.push_back(5);
    func_using.insert(5);
    min[5] = (double)u;
}
void Glimits::set_Pdo(unsigned u){
//    Pdo = u;
    func_do.push_back(5);
    func_using.insert(5);
    max[5] = (double)u;
}

void Glimits::set_PRod(unsigned u){
//    PRod = u;
    func_od.push_back(6);
    func_using.insert(6);
    min[6] = (double)u;
}
void Glimits::set_PRdo(unsigned u){
//    PRdo = u;
    func_do.push_back(6);
    func_using.insert(6);
    max[6] = (double)u;
}

void Glimits::set_Mcod(unsigned u){
//    Mcod = u;
    func_od.push_back(7);
    func_using.insert(7);
    min[7] = (double)u;
}
void Glimits::set_Mcdo(unsigned u){
//    Mcdo = u;
    func_do.push_back(7);
    func_using.insert(7);
    max[7] = (double)u;
}

void Glimits::set_Vcod(unsigned u){
//    Vcod = u;
    func_od.push_back(8);
    func_using.insert(8);
    min[8] = (double)u;
}
void Glimits::set_Vcdo(unsigned u){
//    Vcdo = u;
    func_do.push_back(8);
    func_using.insert(8);
    max[8] = (double)u;
}

void Glimits::set_ZHod(unsigned u){
//    ZHod = u;
    func_od.push_back(9);
    func_using.insert(9);
    min[9] = (double)u;
}
void Glimits::set_ZHdo(unsigned u){
//    ZHdo = u;
    func_do.push_back(9);
    func_using.insert(9);
    max[9] = (double)u;
}

void Glimits::set_c19od(unsigned u){
//    c19od = u;
    func_od.push_back(10);
    func_using.insert(10);
    min[10] = (double)u;
}
void Glimits::set_c19do(unsigned u){
//    c19do = u;
    func_do.push_back(10);
    func_using.insert(10);
    max[10] = (double)u;
}

void Glimits::set_c0od(unsigned u){
//    c0od = u;
    func_od.push_back(11);
    func_using.insert(11);
    min[11] = (double)u;
}
void Glimits::set_c0do(unsigned u){
//    c0do = u;
    func_do.push_back(11);
    func_using.insert(11);
    max[11] = (double)u;
}

void Glimits::set_cCod(unsigned u){
//    cCod = u;
    func_od.push_back(12);
    func_using.insert(12);
    min[12] = (double)u;
}
void Glimits::set_cCdo(unsigned u){
//    cCdo = u;
    func_do.push_back(12);
    func_using.insert(12);
    max[12] = (double)u;
}

void Glimits::set_Ccod(unsigned u){
//    Ccod = u;
    func_od.push_back(13);
    func_using.insert(13);
    min[13] = (double)u;
}
void Glimits::set_Ccdo(unsigned u){
//    Ccdo = u;
    func_do.push_back(13);
    func_using.insert(13);
    max[13] = (double)u;
}

void Glimits::set_CCod(unsigned u){
//    CCod = u;
    func_od.push_back(14);
    func_using.insert(14);
    min[14] = (double)u;
}
void Glimits::set_CCdo(unsigned u){
//    CCdo = u;
    func_do.push_back(14);
    func_using.insert(14);
    max[14] = (double)u;
}

void Glimits::set_Smod(double d){
    func_od.push_back(2);
    func_using.insert(2);
    min[2] = d;
}

void Glimits::set_Smdo(double d){
    func_do.push_back(2);
    func_using.insert(2);
    max[2] = d;
}

void Glimits::set_Kkod(double d){
    func_od.push_back(3);
    func_using.insert(3);
    min[3] = d;
}

void Glimits::set_Kkdo(double d){
    func_do.push_back(3);
    func_using.insert(3);
    max[3] = d;
}

void Glimits::set_ntice(qvect &ntice){
//    this->ntice_vect = ntice;
    this->ntice_vect = qvect(level,0);

    for(int i=0;i<ntice.size();i++)
        ntice_vect[i]=ntice[i];

    bool found = false;
    for(int pos=ntice.size()-1; pos >= 0; pos--){
        if(ntice[pos] == 0 && !found)
            continue;
        else{
            found = true;
            this->ntice.insert(pos,ntice[pos]);
        }
    }
}

void Glimits::set_xtice(QString xstr){

    this->xtice_str = xstr;

    foreach (const QString &qs, xstr.split("|")) {
        QSet<int> stl;
        stl.clear();
        foreach (const QString &qsp, qs.split(",")) {
            if(qsp.contains("-")){
                QStringList a = qsp.split("-");
                for(int i=a[0].toInt(); i<=a[1].toInt(); i++){
                    stl.insert(i);
                }
            }
            else
                stl.insert(qsp.toInt());
        }
        xtice_vect.push_back(stl);
    }
}

void Glimits::set_zakazane(QSet<num> &zakazane){
    this->zakazane = zakazane;
}

void Glimits::set_povinneSTL(QMultiHash<int, int> &pov){
    povinneSTL = pov;
}

void Glimits::set_zakazaneSTL(QMultiHash<int, int> &zak){
    zakazaneSTL = zak;
}

void Glimits::set_povinne(QSet<num> &povinne){
    this->povinne = povinne.toList();
    qSort(this->povinne);
}

void Glimits::add_zakazane(QSet<num> &zakazane){
    foreach (const num &zak, zakazane) {
        this->zakazane << zak;
    }
}

void Glimits::add_povinne(QSet<num> &povinne){
    foreach (const num &pov, povinne) {
        this->povinne.push_back(pov);
    }
    qSort(this->povinne);
}


void Glimits::add(num c){

    result.push_back(c);
    foreach (const num &pos, func_using) {
        switch (pos) {

        case 4: if(n.N(c)) count[pos]++; break;
        case 5: if(n.P(c)) count[pos]++; break;
        case 6: if(n.PR(c)) count[pos]++; break;
        case 7: if(n.Mc(c)) count[pos]++; break;
        case 8: if(n.Vc(c)) count[pos]++; break;
        case 9: if(last.contains(c)) count[pos]++; break;
        case 10: if(n.C19(c)) count[pos]++; break;
        case 11: if(n.C0(c)) count[pos]++; break;
        case 12: if(n.cC(c)) count[pos]++; break;
        case 13: if(n.Cc(c)) count[pos]++; break;
        case 14: if(n.CC(c)) count[pos]++; break;

        case 15: count[15] += num1_R.get_R(c); break;
        case 16: count[16] += numOD_R.get_R(c); break;
        case 17: count[17] += num1_R.get_STL(c,result.size()); break;
        case 18: count[18] += numOD_R.get_STL(c, result.size()); break;
        case 19: count[19] += (double)c; break;

        default: /*count[pos]++;*/ break;
        }
    }

    if(!cisloKolko.isEmpty()){
        int cislo = c;
        if(cisloKolko.contains(cislo))
            --(*cisloKolko[cislo]);
    }
}

void Glimits::remove(){

    const num c = result.last();

    foreach (const num &pos, func_using) {
        switch (pos) {

        case 4: if(n.N(c)) count[pos]--; break;
        case 5: if(n.P(c)) count[pos]--; break;
        case 6: if(n.PR(c)) count[pos]--; break;
        case 7: if(n.Mc(c)) count[pos]--; break;
        case 8: if(n.Vc(c)) count[pos]--; break;
        case 9: if(last.contains(c)) count[pos]--; break;
        case 10: if(n.C19(c)) count[pos]--; break;
        case 11: if(n.C0(c)) count[pos]--; break;
        case 12: if(n.cC(c)) count[pos]--; break;
        case 13: if(n.Cc(c)) count[pos]--; break;
        case 14: if(n.CC(c)) count[pos]--; break;

        case 15: count[15] -= num1_R.get_R(c); break;
        case 16: count[16] -= numOD_R.get_R(c); break;
        case 17: count[17] -= num1_R.get_STL(c,result.size()); break;
        case 18: count[18] -= numOD_R.get_STL(c, result.size()); break;
        case 19: count[19] -= (double)c; break;

        default: /*count[pos]--;*/ break;
        }
    }

    if(!cisloKolko.isEmpty()){
        int cislo = c;
        if(cisloKolko.contains(cislo))
            ++(*cisloKolko[cislo]);
    }

    result.pop_back();
}

bool Glimits::check_xtice(){

    if(xtice_vect.isEmpty())
        return true;

    qvect vysl;

    foreach (const num &qvn, result) {
        num pos = 0;
        for(num i=10; i <= 90; i+=10, pos++){

            if(pos >= vysl.size())
                vysl.push_back(0);

            if(qvn <= i){
                vysl[pos]++;
                break;
            }
        }
    }

    size_t sum=0;
    for(int i=0; i<vysl.size(); i++){
        QList<int> l = xtice_vect[i].toList();
        qSort(l);
        int max=(i+1)*10, xmin=l.first(), xmax=l.last();

        // ak neobsahuje, pozriem sa ci mozeme dosiahnut, alebo sme presiahli xticu
        if(!xtice_vect[i].contains(vysl[i])){
            if(vysl[i] > xmax)
                return false;
            if(max-(int)result.last() < xmin)
                return false;
        }
        sum += vysl[i];
    }

    if(result.size() == level){
        if(sum == (size_t)level){
            for(int i=0; i<vysl.size(); i++){
                if(!xtice_vect[i].contains(vysl[i]))
                    return false;
            }
        }
    }

    return true;
}

//#include <QDebug>

bool Glimits::check_stl_ntice(){

    if(ntice_stl.isEmpty())
        return true;

    for(int i=0; i< ntice_stl_pos.size(); i++){
        if(ntice_stl[i] != ntice_stl_pos[i])
            return false;
    }

    return true;
}

bool Glimits::check_ntice(){

    if(ntice.isEmpty())
        return true;
    if(result.size() < 2)
        return true;

    // hladame ntcie/volne
    qvect tice(level,0);
    ntice_stl_pos.clear();
//    this->ntice_stl_pos = qvect(level,0);

    int tica=0;
    result.push_back(0);
    for(int i = 0; i < result.size(); i++){

        ntice_stl_pos.push_back(0);

        if((i == result.size()-2) && (level == result.size()-1)){ // posledny je volny
            if(tica > 0){
                tice[tica]++;
                ntice_stl_pos[i]=1;
            }
            else
                tice[0]++;
            break;
        }

        int c = (int)(result[i] - result[i+1]);
        if(c == result[i]){
            if(tica > 0){
                tice[tica]++;
                ntice_stl_pos[i]=1;
            }
            else
                ntice_stl_pos.pop_back();
            break;
        }
        if(c < -1){
            if(tica==0){
                tice[0]++;
            }
            else{
                ntice_stl_pos[i]=1;
                tice[tica]++;
                tica=0;
            }
        }
        else{
            ntice_stl_pos[i]=1;
            tica++;
        }
    }
    result.pop_back();

    // kontrola volnych
    // ak sme nasli volne a nemali sme tak je zle..
    if(result.size() < level){

        if(tice[0] > ntice.find(0).value())
            return false;

        for(num pos=1; pos < tice.size(); pos++){
            if(tice[pos] != 0 && ntice.find(pos) == ntice.end()){
                return false;
            }
        }
    }
    else{
        for(num pos = 0; pos < tice.size(); pos++){
            if(ntice_vect[pos] != tice[pos])
                return false;
        }
    }

    return true;
}

bool Glimits::check_povinne(){

    if(povinne.isEmpty())
        return true;

    for(num lev=0; lev < povinne.size() && lev < result.size(); lev++){
        if(result[lev] > povinne[lev])
            return false;
    }

    if(level == result.size()){
        foreach (const num &pov, povinne) {
            if(!result.contains(pov))
                return false;
        }
    }
    return true;
}

bool Glimits::check_Sm(){

    if(!func_using.contains(2))
        return true;

    if(result.size() == level){

        double sm = n.smernica(result);

        if((sm >= min[2]) && (sm <= max[2]))
            return true;
        else
            return false;
    }

    return true;
}

bool Glimits::check_Kk(){
    if(!func_using.contains(3))
        return true;

    if(result.size() == level){

        double kk = n.korelacia(last,result);

        if((kk >= min[3]) && (kk <= max[3]))
            return true;
        else
            return false;
    }

    return true;
}

int Glimits::size(){
    int size=0;
    if(!ntice.isEmpty())
        size++;
    if(!povinne.isEmpty())
        size++;
    if(!zakazane.isEmpty())
        size++;
    if(!xtice_vect.isEmpty())
        size++;
    return size + func_od.size() + func_do.size();
}

void Glimits::nastav(QString &nastavenie, num pos){
    if(func_od.contains(pos))
        nastavenie.append(QString::number(min[pos],'g',12)).append(" ");
    else
        nastavenie.append("- ");
    if(func_do.contains(pos))
        nastavenie.append(QString::number(max[pos],'g',12)).append(" ");
    else
        nastavenie.append("- ");
}

QString Glimits::get_settings(){
    QString nastavenie;

    if(!povinne.empty()){
        nastavenie.append("Povinne: ");
        foreach (const num zak, povinne) {
            nastavenie.append(QString::number(zak)).append(" ");
        }
    }
    if(!zakazane.empty()){
        nastavenie.append("Zakazane: ");
        foreach (const num zak, zakazane) {
            nastavenie.append(QString::number(zak)).append(" ");
        }
    }
    if(!ntice.empty()){
        nastavenie.append("N-tice: ");
        for(int i=0;i<ntice_vect.size();i++)
            nastavenie.append(QString::number(ntice_vect[i])).append(" ");
    }
    if(!xtice_vect.empty()){
        nastavenie.append("X-tice: ").append(xtice_str);
//        for(int i=0;i<xtice_vect.size();i++)
//            nastavenie.append(QString::number(xtice_vect[i])).append(" ");
    }

    foreach (const num &pos, func_using) {
        switch (pos) {

        case 2: nastavenie.append("Sm: "); nastav(nastavenie,pos); break;
        case 3: nastavenie.append("Kk: "); nastav(nastavenie,pos); break;
        case 4: nastavenie.append("N: "); nastav(nastavenie,pos); break;
        case 5: nastavenie.append("P: "); nastav(nastavenie,pos); break;
        case 6: nastavenie.append("PR: "); nastav(nastavenie,pos); break;
        case 7: nastavenie.append("Mc: "); nastav(nastavenie,pos); break;
        case 8: nastavenie.append("Vc: "); nastav(nastavenie,pos); break;
        case 9: nastavenie.append("ZH: "); nastav(nastavenie,pos); break;
        case 10: nastavenie.append("c19: "); nastav(nastavenie,pos); break;
        case 11: nastavenie.append("c0: "); nastav(nastavenie,pos); break;
        case 12: nastavenie.append("cC: "); nastav(nastavenie,pos); break;
        case 13: nastavenie.append("Cc: "); nastav(nastavenie,pos); break;
        case 14: nastavenie.append("CC: "); nastav(nastavenie,pos); break;

        case 15: nastavenie.append("R1-DO: "); nastav(nastavenie,pos); break;
        case 16: nastavenie.append("ROD-DO: "); nastav(nastavenie,pos); break;
        case 17: nastavenie.append("STL1-DO: "); nastav(nastavenie,pos); break;
        case 18: nastavenie.append("STLOD-DO: "); nastav(nastavenie,pos); break;
        case 19: nastavenie.append("Kombinacie: "); nastav(nastavenie,pos); break;
        case 20: nastavenie.append("ΔR1-DO: "); nastav(nastavenie,pos); break;
        case 21: nastavenie.append("ΔSTL1-DO: "); nastav(nastavenie,pos); break;
        case 22: nastavenie.append("Δ(R1DO-STL1DO): "); nastav(nastavenie,pos); break;
        case 23: nastavenie.append("ΔROD-DO: "); nastav(nastavenie,pos); break;
        case 24: nastavenie.append("ΔSTLOD-DO: "); nastav(nastavenie,pos); break;
        case 25: nastavenie.append("Δ(RODDO-STLODDO): "); nastav(nastavenie,pos); break;
        case 26: nastavenie.append("HHRX: "); nastav(nastavenie,pos); break;
        case 27: nastavenie.append("HRX: "); nastav(nastavenie,pos); break;

        default: break;
        }
    }
    return nastavenie;
}

// 1: --
// 2: SM
// 3: KK
// 4: N
// 5: P
// 6: PR
// 7: Mc
// 8: Vc
// 9: ZH
//10: c19
//11: c0
//12: cC
//13: Cc
//14: CC
//15: r1-do
//16: rod-do
//17: stl1-do
//18: stlod-do
//19: kombinacie
//20: dt r1
//21: dt stl1
//22: dt (r1-stl1)
//23: dt r2
//24: dt stl2
//25: dt (r2-stl2)
//26: HHRX
//27: HRX
bool Glimits::check(){

    // zakazane
    if(zakazane.contains(result.last()))
        return false;

    //zakazaneSTL
    if(zakazaneSTL.keys().contains(result.size())){
        if(zakazaneSTL.find(result.size(), result.last()) != zakazaneSTL.end())
            return false;
    }

    //povinneSTL
    if(povinneSTL.keys().contains(result.size())){
        if(povinneSTL.find(result.size(), result.last()) == povinneSTL.end())
            return false;
    }

    // povinne
    if(!check_povinne())
        return false;

    //skupiny
    if(!cisloKolko.isEmpty()){
        if(cisloKolko.contains(result.last())){
            int kolko = (*cisloKolko[result.last()]);
            if(kolko < 0)
                return false;
        }
    }

    // N-tice
    if(!check_ntice())
        return false;

    // Stl N-tice
    if(!check_stl_ntice())
        return false;

    if(!check_xtice())
        return false;

    // vector cisel funkcii
    // kontrola ci sme nepresiahli maximum
    foreach (const num &cf, func_do) {
        if(count[cf] > max[cf])
            return false;

        if(level == result.size()){

        double delta;

        switch (cf) {
        case 20:
            delta = num1_R.sum_R(result.begin(),result.end()) - deltaVec[0];
            if(delta > max[cf])
                return false;
            break;

        case 21:
            delta = num1_R.sum_STL(result.begin(),result.end()) - deltaVec[1];
            if(delta > max[cf])
                return false;
            break;

        case 22:
            delta = num1_R.sum_R(result.begin(),result.end()) - num1_R.sum_STL(result.begin(),result.end());
            if(delta > max[cf])
                return false;
            break;

        case 23:
            delta = numOD_R.sum_R(result.begin(),result.end()) - deltaVec[2];
            if(delta > max[cf])
                return false;
            break;

        case 24:
            delta = numOD_R.sum_R(result.begin(),result.end()) - deltaVec[3];
            if(delta > max[cf])
                return false;
            break;

        case 25:
            delta = numOD_R.sum_R(result.begin(),result.end()) - numOD_R.sum_STL(result.begin(),result.end());
            if(delta > max[cf])
                return false;
            break;

        case 26:
        {
            double hhrx = hrxNumbers1.hrx(result);
            if(hhrx > max[cf])
                return false;
        }
            break;

        case 27:
//        {
//            double hrx = hrxNumbers2.hrx(result);
//            if(hrx > max[cf])
//                return false;
//        }
            break;

        default:
            break;
        }
        }
    }

    // vector cisel funkcii
    // kontrola ci dosiahneme minimum
    foreach (const num &cf, func_od) {

        double delta;

        switch (cf) {
        case 2: break;
        case 3: break;
        case 15:
        case 16:
        case 17:
        case 18:
        case 19:
            if(level == result.size())
                if(count[cf] < min[cf]) return false;
            break;

        case 20:
            if(level == result.size()){
            delta = num1_R.sum_R(result.begin(),result.end()) - deltaVec[0];
            if(delta < min[cf])
                return false;
            }
            break;

        case 21:
            if(level == result.size()){
            delta = num1_R.sum_STL(result.begin(),result.end()) - deltaVec[1];
            if(delta < min[cf])
                return false;
            }
            break;

        case 22:
            if(level == result.size()){
            delta = num1_R.sum_R(result.begin(),result.end()) - num1_R.sum_STL(result.begin(),result.end());
            if(delta < min[cf])
                return false;
            }
            break;

        case 23:
            if(level == result.size()){
            delta = numOD_R.sum_R(result.begin(),result.end()) - deltaVec[2];
            if(delta < min[cf])
                return false;
            }
            break;

        case 24:
            if(level == result.size()){
            delta = numOD_R.sum_STL(result.begin(),result.end()) - deltaVec[3];
            if(delta < min[cf])
                return false;
            }
            break;

        case 25:
            if(level == result.size()){
            delta = numOD_R.sum_R(result.begin(),result.end()) - numOD_R.sum_STL(result.begin(),result.end());
            if(delta < min[cf])
                return false;
            }
            break;
        case 26:
            if(level == result.size()){
                double hhrx = hrxNumbers1.hrx(result);
                if(hhrx < min[cf])
                    return false;
            }
            break;
        case 27:
//            if(level == result.size()){
//                double hrx = hrxNumbers2.hrx(result);
//                if(hrx < min[cf])
//                    return false;
//            }
            break;
        default:
            if((level - result.size()) < (min[cf] - count[cf])) return false;
            break;
        }
    }

    // Kk
    if(!check_Kk())
        return false;

    // Sm
    if(!check_Sm())
        return false;

    return true;
}

#include "result.h"

Result::Result(Numbers a, Numbers b, QVector<double> delta){
    last_comb = qvect();
    num1_R = a;
    numOD_R = b;
    f=NULL;
    data=NULL;
    this->numberings = Numberings(a.get_N(),a.get_M());
    this->delta = delta;
}

Result::Result(Archiv *archiv, int state1_r, int stateod_r)
{
    last_comb = archiv->get_last_comb();

    this->delta = archiv->get_deltav();

    if(state1_r==1)
        num1_R =archiv->get_1DO1();
    else
        num1_R =archiv->get_1DO();

    if(stateod_r==2)
        numOD_R = archiv->get_ODDO2();
    else if(stateod_r == 1)
        numOD_R = archiv->get_ODDO1();
    else
        numOD_R = archiv->get_ODDO();

    this->num1_Rr = archiv->get_1DO();
    this->numOD_Rr = archiv->get_ODDO();


    f=NULL;
    data=NULL;
    exp_num = 0;
    exp_size = 0;

    dt = QDateTime::currentDateTime();

//    dir_name.append(QString::number(archiv->get_1DO().get_N())).append(QString::number(archiv->get_1DO().get_M()));
    dir_name.append(archiv->get_cwd());
    dir_date.append(dt.toString("yyyy-MM-dd-hh-mm-ss"));

    dir = QDir(dir_name.append(dir_date));

    if(!dir.exists()){
        dir.mkpath(".");
    }
    this->numberings = Numberings(archiv->get_n(),archiv->get_m());
}

Result::~Result()
{
    result.clear();
}

QStringList Result::header()
{
    QStringList header;
//    header  << "Kombinacie"
    for(int i=1; i<=this->num1_R.get_N(); i++)
        header << QString::number(i);
    header  << "P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH"<<"Sm"<<"Kk"<<"N-tice"<<"X-tice"
            << "ƩR1-DO"<< "ΔƩR1-DO" << "ƩSTL1-DO" << "ΔƩSTL1-DO" << "Δ(ƩR1-DO-ƩSTL1-DO)"
            << "HHRX" << "ΔHHRX"
            << "ƩR OD-DO" << "ΔƩR OD-DO" << "ƩSTL OD-DO"<< "ΔƩSTL OD-DO" << "Δ(ƩROD-DO-ƩSTLOD-DO)"
            << "HRX" <<	"ΔHRX"
            << "ƩKombinacie";

//    for(int i=0; i < (int)num1_R.get_N(); i++){
//        header << "Cislo" << "R1-DO"<< "STL1-DO"<< "R OD-DO"<< "STL OD-DO";
//    }

    return header;
}

bool Result::next_comb_str(QByteArray &arr)
{
    if(result.isEmpty())
        return false;

    QStringList strList;
    result_iterator = result.begin();

    strList << combs_to_str((*result_iterator).begin(),(*result_iterator).end()).split(" ");
    strList << numberings.result(*result_iterator, last_comb);
    strList << numberings.ntice(*result_iterator);
    strList << numberings.xtice(*result_iterator, this->num1_R.get_M());

    strl_insert(strList,num1_R.sum_R((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList,num1_R.sum_R((*result_iterator).begin(),(*result_iterator).end()) - delta[0]);

    strl_insert(strList, num1_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList, num1_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()) - delta[1]);

    strl_insert(strList,num1_R.sum_R((*result_iterator).begin(),(*result_iterator).end()) - num1_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));

    //HHRX,dtHHRX
    double hhrx = num1_Rr.hrx(*result_iterator);
    strl_insert(strList, hhrx);
    strl_insert(strList, num1_Rr.hrx({}) - hhrx);


    strl_insert(strList, numOD_R.sum_R((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList, numOD_R.sum_R((*result_iterator).begin(),(*result_iterator).end()) - delta[2]);

    strl_insert(strList, numOD_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));
    strl_insert(strList, numOD_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()) - delta[3]);

    strl_insert(strList, numOD_R.sum_R((*result_iterator).begin(),(*result_iterator).end()) - numOD_R.sum_STL((*result_iterator).begin(),(*result_iterator).end()));

    //HRX, dtHRX
    double hrx = numOD_Rr.hrx(*result_iterator);
    strl_insert(strList, hrx);
    strl_insert(strList, numOD_Rr.hrx({}) - hrx);


    strList << QString::number(sum_comb((*result_iterator).begin(),(*result_iterator).end()));

//    int stl = 1;
//    for(qvect::Iterator iq=(*result_iterator).begin();iq!=(*result_iterator).end();iq++){

//        strList << QString::number(*iq);

//        strl_insert(strList, num1_R.get_R(*iq));
//        strl_insert(strList, num1_R.get_STL(*iq,stl));

//        strl_insert(strList, numOD_R.get_R(*iq));
//        strl_insert(strList, numOD_R.get_STL(*iq,stl));

//        stl++;
//    }

    arr.clear();
    arr.append(strList.join(";")).append("\n");
    result.pop_front();
    return true;
}
int Result::size()
{
    return result.size();
}

bool Result::empty()
{
    return result.empty();
}

void Result::insert(qvect v)
{
    this->result.push_back(v);
    if(result.size() > 500000)
        write_combs();
}

/*
 * Zapise do suboru ihned
*/
void Result::insert2(qvect v, Numbers n1, Numbers n2){
    this->num1_R = n1;
    this->numOD_R = n2;
    this->result.push_back(v);
    write_combs();
}

void Result::strl_insert(QStringList &list, double d)
{
    list << double_to_qstr(d);
}

void Result::stop(){

    if(f){
        if(f->isOpen())
            f->close();
        delete f;
        f=NULL;
    }
    emit finished();
}

void Result::end(){

    while(!result.isEmpty()){
        emit info(QString("Exportujem subory. Ostava ").append(QString::number(result.size())));
        write_combs();
    }

    //close
    if(f){

//        f->flush();
//        fsync(f->handle());

//        if(f->isOpen())
//            f->close();
        delete f;
        f=NULL;
    }
    emit info("Exportovanie dokoncene");
    emit finished();
}

void Result::write_combs(){

    if(f==NULL){
        exp_num++;
        exp_size = 0;
        f = new QFile(dir.path().append("/").append(QString::number(exp_num).append("_").append(QTime::currentTime().toString("hms")).append(".csv")));

        f->open(QFile::WriteOnly);
        data = new QTextStream(f);
        data->setCodec("UTF-8");
        data->setGenerateByteOrderMark(true);

        *data << header().join(";").append("\n").toUtf8();
//        f->write(header().join(";").append("\n").toUtf8());
    }

    QByteArray qbarray;

    while(next_comb_str(qbarray) && exp_size < 500000){
        *data << QString::fromUtf8(qbarray).toUtf8();
//        f->write(qbarray);
        exp_size++;
    }

    if(exp_size > 450000){

        // close
        if(f){
            if(f->isOpen())
                f->close();
            delete f;
            f = NULL;
        }
    }
}

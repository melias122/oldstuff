#include "numbers2.h"

#include <boost/math/special_functions/binomial.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>


using bigFloat = boost::multiprecision::cpp_dec_float_100;


PHCisla::PHCisla(unsigned pocetStlpcov, unsigned pocetRiadkov) :
    n{pocetStlpcov},
    m{pocetRiadkov},
    m_pocetnostRiadok{Pocetnost(pocetRiadkov, 0)},
    m_pocetnostStlpec{Pocetnost2D(pocetRiadkov,Pocetnost(pocetStlpcov, 0))},
    m_hodnotaRiadok{Hodnota(pocetRiadkov, 0.f)},
    m_hodnotaStlpec{Hodnota2D(pocetRiadkov, Hodnota(pocetStlpcov, 0.f))}
{}

void PHCisla::increment(const std::vector<unsigned> &nums){
    auto end = nums.size();
    for(unsigned i{1}; i <= end; ++i){
        increment(nums[i-1], i);
    }
}

void PHCisla::increment(unsigned cislo, unsigned stlpec){
    incrementRiadok(cislo);
    incrementStlpec(cislo, stlpec);
}

void PHCisla::incrementRiadok(unsigned cislo){

    auto pocRiadok = ++m_pocetnostRiadok[cislo-1];

    //    if(pocRiadok > 0){
    bigFloat f{pocRiadok};
    bigInt i{stlCC(1, 1, n, m)};
    f /= i.convert_to<bigFloat>();
    m_hodnotaRiadok[cislo-1] = f.convert_to<double>();
    //    }
}

void PHCisla::incrementStlpec(unsigned cislo, unsigned stlpec){

    auto pocStlpec = ++m_pocetnostStlpec[cislo-1][stlpec-1];

//    if(pocStlpec > 0){
    bigFloat f(pocStlpec);
    bigInt i(stlCC(cislo, stlpec, n, m));
    f /= i.convert_to<bigFloat>();
    m_hodnotaStlpec[cislo-1][stlpec-1] = f.convert_to<double>();
//    }
}

double PHCisla::hodnotaRiadok(unsigned cislo) const{
    return m_hodnotaRiadok[cislo-1];
}

double PHCisla::hodnotaStlpec(unsigned cislo, unsigned stlpec) const{
    return m_hodnotaStlpec[cislo-1][stlpec-1];
}

unsigned PHCisla::pocetnostRiadok(unsigned cislo) const{
    return m_pocetnostRiadok[cislo-1];
}

unsigned PHCisla::pocetnostStlpec(unsigned cislo, unsigned stlpec) const{
    return m_pocetnostStlpec[cislo-1][stlpec-1];
}

bigInt stlCC(int cislo, int stlpec, int n, int m){
    if((cislo - stlpec) < 0 ) return bigInt{0};
    else if((cislo - stlpec) > (m - n)) return bigInt{0};
    else return (nCm(n-stlpec, m-cislo) * nCm(stlpec-1, cislo-1));
}

bigInt nCm(unsigned n, unsigned m){
    return bigInt{boost::math::binomial_coefficient<double>(m, n)};
}

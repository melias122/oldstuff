#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "generator.h"
#include "numbers.h"
#include "tablewindow.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int get_N();
    int get_M();
    std::vector<std::vector<double> > limits();

    QString num_to_str(double num){
        return QString::number(num,'f',5);
    }

    bool min2();


signals:
    void stop_generator();

public slots:
    void info(QString s);
    void running(bool state);
    void result(qvect2d result);
    
private slots:
    void on_generateButton_clicked();

    void on_file_R1_clicked();

    void on_file_STL1_clicked();

    void on_file_ROD_clicked();

    void on_file_STLOD_clicked();

    void on_show_wlist_clicked();

    void on_export_wlist_clicked();

    void on_del_r1_clicked();

    void on_del_r1lpi_clicked();

    void on_del_komb_clicked();

    void on_del_stl1_clicked();

    void on_del_stl1pi_clicked();

    void on_del_rod_clicked();

    void on_del_rlpiod_clicked();

    void on_del_stlod_clicked();

    void on_del_stllpiod_clicked();

    void on_del_all_clicked();

    void on_show_limits_clicked();

private:
    Ui::MainWindow *ui;

    Numbers num1_R, numOD_R;

    QString path_protokol, path_R1, path_STL1, path_ROD, path_STLOD;

    bool generator_running;

    qvect2d combinations;

    TableWindow *Resultstab;
};



class Exp : public QObject
{
    Q_OBJECT
public:

    Exp(Numbers &n1, Numbers &n2, qvect2d &combinations, QString filename) {
        this->num1_R = n1;
        this->numOD_R = n2;
        this->combinations = combinations;
        this->filename = filename;
    }
//    virtual ~Exp() {}

    template<class T>
    QString combs_to_str( T begin, T end){
        QString s;
        for(T i=begin; i!=end; i++){
            s.append(QString::number(*i));
            s.append(" ");
        }
        return s;
    }

    template<class T>
    int sum_comb(T begin, T end){
        int sum = 0;
        for(T it = begin; it != end; ++it){
            int i = (int)*it;
            sum += i;
        }
        return sum;
    }

signals:
    void finished(QString="");

public slots:
    void process();

private:
    Numbers num1_R, numOD_R;
    QString filename;
    qvect2d combinations;
};

#endif // MAINWINDOW_H

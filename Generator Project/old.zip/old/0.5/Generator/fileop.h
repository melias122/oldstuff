#ifndef FILEOP_H
#define FILEOP_H

#include "numbers.h"
//#include "db.h"

#include <QString>

bool read_numbers_STL(Numbers &numbers, QString filename);
bool read_numbers_R(Numbers &numbers, QString filename);
void write_protocol(QString filename, QString text);


#endif // FILEOP_H

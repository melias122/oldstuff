#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "fileop.h"

#include<limits>

#include <QThread>
#include <QDebug>
#include <QFileDialog>


#include<QDir>
QString fname(QString path){
    return path.split(QDir::separator()).last();
}


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    generator_running = false;
    Resultstab = NULL;
}

MainWindow::~MainWindow()
{
    delete ui;
}

std::vector<std::vector<double> > MainWindow::limits(){

    using std::vector;

    std::vector<std::vector<double> > limits;

    std::vector<double> v1;
    v1.push_back(ui->r1od->text().replace(",",".").toDouble());
    v1.push_back(ui->r1do->text().replace(",",".").toDouble());
    v1.push_back(ui->r2od->text().replace(",",".").toDouble());
    v1.push_back(ui->r2do->text().replace(",",".").toDouble());

    std::vector<double> v2;
    v2.push_back(ui->r1lpiod->text().replace(",",".").toDouble());
    v2.push_back(ui->r1lpido->text().replace(",",".").toDouble());
    v2.push_back(ui->r2lpiod->text().replace(",",".").toDouble());
    v2.push_back(ui->r2lpido->text().replace(",",".").toDouble());

    std::vector<double> v3;
    v3.push_back(ui->stl1od->text().replace(",",".").toDouble());
    v3.push_back(ui->stl1do->text().replace(",",".").toDouble());
    v3.push_back(ui->stl2od->text().replace(",",".").toDouble());
    v3.push_back(ui->stl2do->text().replace(",",".").toDouble());

    std::vector<double> v4;
    v4.push_back(ui->stl1lpiod->text().replace(",",".").toDouble());
    v4.push_back(ui->stl1lpido->text().replace(",",".").toDouble());
    v4.push_back(ui->stl2lpiod->text().replace(",",".").toDouble());
    v4.push_back(ui->stl2lpido->text().replace(",",".").toDouble());

    std::vector<double> v5;
    v5.push_back(ui->kombod->text().toInt());
    v5.push_back(ui->kombdo->text().toInt());
    v5.push_back(0);
    v5.push_back(0);

    limits.push_back(v1);
    limits.push_back(v2);
    limits.push_back(v3);
    limits.push_back(v4);
    limits.push_back(v5);

    for(int i=0;i<limits.size();i++){
        if(limits[i][1] == 0)
            limits[i][1] = std::numeric_limits<double>::max();
        if(limits[i][3] == 0)
            limits[i][3] = std::numeric_limits<double>::max();
    }

    return limits;
}

void MainWindow::on_generateButton_clicked()
{
//    Form *f = new Form();
//    connect(this, SIGNAL(destroyed()), f, SLOT(deleteLater()));
//    f->show();

    if(path_R1.isEmpty() || path_ROD.isEmpty() || path_STL1.isEmpty() || path_STLOD.isEmpty()){
        info("Najprv treba nacitat subory");
        return;
    }

    if(!min2()){
        info("Musia byt zadane aspon 2 kriteria pre vyhladavanie");
        return;
    }

    if(!generator_running){

        running(true);
        combinations.clear();

        std::vector<std::vector<double> > l = limits();

        QThread* generator_thread = new QThread;
        Generator* worker = new Generator(num1_R, numOD_R, l);

        worker->moveToThread(generator_thread);

        connect(generator_thread, SIGNAL(started()), worker, SLOT(process()));
        connect(this, SIGNAL(stop_generator()), worker, SLOT(stop()));
        connect(worker, SIGNAL(generator_state(bool)), this, SLOT(running(bool)));
        connect(worker, SIGNAL(results_ready(qvect2d)), this, SLOT(result(qvect2d)));
        connect(worker, SIGNAL(finished()), generator_thread, SLOT(quit()));
        connect(worker, SIGNAL(finished()), worker, SLOT(deleteLater()));
        connect(generator_thread, SIGNAL(finished()), generator_thread, SLOT(deleteLater()));

        generator_thread->start();
    }
    else{
        emit stop_generator();
    }
}

int MainWindow::get_N(){
    return ui->spinBoxN->text().toInt();
}
int MainWindow::get_M(){
    return ui->spinBoxM->text().toInt();
}

void MainWindow::info(QString s){
    ui->Info->setText(s);
}

void MainWindow::running(bool state){
    generator_running = state;
    if(generator_running){
        info("Hladam kombinacie");
        ui->generateButton->setText("Stop");
    }
    else{
        info("Hladanie dokoncene");
        ui->generateButton->setText("Generuj");
    }
}

void MainWindow::result(qvect2d result){
    if(!combinations.empty())
        combinations.clear();
    combinations = result;
    info(QString("Najdenych ").append(QString::number(combinations.size())).append(" kombinacii"));
    if(Resultstab != NULL){
        delete Resultstab;
        Resultstab = NULL;
    }
}

void MainWindow::on_file_R1_clicked()
{
    if(get_M() == 0 || get_N() == 0){
        info("Nebol zadany rozmer N/M");
        return;
    }
    path_R1 = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_R1.isEmpty()){
        num1_R.set_M(get_M()); num1_R.set_N(get_N());
        if(read_numbers_R(num1_R, path_R1)){
            info(QString("Subor ").append(fname(path_R1)).append(" uspesne nacitany"));
            ui->file_STL1->setEnabled(true);
//            write_protocol(path_protokol, QString("Subor ").append(path_R1).append(" uspesne nacitany."));
        }
        else{
            info(QString("Nepodarilo sa nacitat subor ").append(fname(path_R1)));
        }
    }
}

void MainWindow::on_file_STL1_clicked()
{
    path_STL1 = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_STL1.isEmpty()){
        if(read_numbers_STL(num1_R, path_STL1)){
            num1_R.set_M(get_M()); num1_R.set_N(get_N());
            info(QString("Subor ").append(fname(path_STL1)).append(" uspesne nacitany"));
            ui->file_ROD->setEnabled(true);
//            write_protocol(path_protokol, QString("Subor ").append(path_STL1).append(" uspesne nacitany."));
        }
        else{
            info(QString("Nepodarilo sa nacitat subor ").append(fname(path_STL1)));
        }
    }
}

void MainWindow::on_file_ROD_clicked()
{
    path_ROD = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_ROD.isEmpty()){
        if(read_numbers_R(numOD_R, path_ROD)){
            numOD_R.set_M(get_M()); numOD_R.set_N(get_N());
            info(QString("Subor ").append(fname(path_ROD)).append(" uspesne nacitany"));
            ui->file_STLOD->setEnabled(true);
//            write_protocol(path_protokol, QString("Subor ").append(path_ROD).append(" uspesne nacitany."));
        }
        else{
            info(QString("Nepodarilo sa nacitat subor ").append(fname(path_ROD)));
        }
    }
}

void MainWindow::on_file_STLOD_clicked()
{
    path_STLOD = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_STLOD.isEmpty()){
        if(read_numbers_STL(numOD_R, path_STLOD)){
            numOD_R.set_M(get_M()); numOD_R.set_N(get_N());
            info(QString("Subor ").append(fname(path_STLOD)).append(" uspesne nacitany"));
            ui->generateButton->setEnabled(true);
            ui->show_limits->setEnabled(true);
            ui->show_wlist->setEnabled(true);
            ui->export_wlist->setEnabled(true);
//            write_protocol(path_protokol, QString("Subor ").append(path_STLOD).append(" uspesne nacitany."));
        }
        else{
            info(QString("Subor ").append(fname(path_STLOD)).append(" uspesne nacitany"));
        }
    }
}

void MainWindow::on_show_wlist_clicked()
{
    if(combinations.empty()){
        info("Kombinacie neboli vygenerovane alebo nevyhovoju kriteriam");
        return;
    }

    if(Resultstab == NULL){
        Resultstab = new TableWindow();
        Resultstab->create_worklist(combinations, num1_R, numOD_R);
    }
    if(!Resultstab->isVisible())
        Resultstab->show();
}

void Exp::process(){
//        QString filename;

    QFile f( filename );

    if (f.open(QFile::WriteOnly)) {

        Numberings numberings;
        QVector<num> first, prev;
        QTextStream data( &f );
        QStringList strList;

        strList << "Kombinacie" <<"P"<<"N"<<"PR"<<"Mc"<<"Vc"<<"c1-c9"<<"C0"<<"cC"<<"Cc"<<"CC"<<"ZH" << "ƩR1-DO"<< "ƩRLp-i1-DO"<< "ƩSTL1-DO"<< "ƩSTLLp-i1-DO"<< "ƩR OD-DO"<< "ƩRLp-i OD-DO"<< "ƩSTL OD-DO"<< "ƩSTLLp-i OD-DO" << "ƩKombinacie";
        for(int i=0; i < num1_R.get_N(); i++){
            strList << "Cislo" << "R1-DO"<< "RLp-i1-DO"<< "STL1-DO"<< "STLLp-i1-DO"<< "R OD-DO"<< "RLp-i OD-DO"<< "STL OD-DO"<< "STLLp-i OD-DO";
        }
        data << strList.join( ";" )+"\n";

//        for( int r = 0; r < ui->tableWidget->rowCount(); ++r ) {

        for(qvect2d::iterator it=combinations.begin(); it!=combinations.end();it++){
            strList.clear();
            first = *it;

            strList << combs_to_str((*it).begin(),(*it).end());
            strList << numberings.result(first, prev);
            strList << QString::number(num1_R.sum_R((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","))
                    << QString::number(num1_R.sum_R_Lpi((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","))
                    << QString::number(num1_R.sum_STL((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","))
                    << QString::number(num1_R.sum_STL_Lpi((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","));

            strList << QString::number(numOD_R.sum_R((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","))
                    << QString::number(numOD_R.sum_R_Lpi((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","))
                    << QString::number(numOD_R.sum_STL((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","))
                    << QString::number(numOD_R.sum_STL_Lpi((*it).begin(),(*it).end()),'g',10).replace(QString("."), QString(","));
            strList << QString::number(sum_comb((*it).begin(),(*it).end()));

            int stl = 1;
            for(qvect::iterator iq=(*it).begin();iq!=(*it).end();iq++){

                strList << QString::number(*iq);

                strList << QString::number(num1_R.get_R((unsigned)*iq),'g',10).replace(QString("."), QString(","));
                strList << QString::number(num1_R.get_R_Lpi((unsigned)*iq),'g',10).replace(QString("."), QString(","));
                strList << QString::number(num1_R.get_STL((unsigned)*iq,stl),'g',10).replace(QString("."), QString(","));
                strList << QString::number(num1_R.get_STL_Lpi((unsigned)*iq,stl),'g',10).replace(QString("."), QString(","));

                strList << QString::number(numOD_R.get_R((unsigned)*iq),'g',10).replace(QString("."), QString(","));
                strList << QString::number(numOD_R.get_R_Lpi((unsigned)*iq),'g',10).replace(QString("."), QString(","));
                strList << QString::number(numOD_R.get_STL((unsigned)*iq,stl),'g',10).replace(QString("."), QString(","));
                strList << QString::number(numOD_R.get_STL_Lpi((unsigned)*iq,stl),'g',10).replace(QString("."), QString(","));

                stl++;
            }
            data << strList.join( ";" )+"\n";
            prev = first;
        }
        f.close();
    }
    emit finished("Exportovanie uspesne dokoncene");
}

void MainWindow::on_export_wlist_clicked()
{
    if(combinations.empty()){
        return;
    }

    QString filename;
    if((filename = QFileDialog::getSaveFileName(this, tr("Ulozit subor"), "", tr("Export (*.csv)"))) == "")
        return;
    filename.append(".csv");

    QThread* thread = new QThread;
    Exp* worker = new Exp(num1_R, numOD_R, combinations, filename);

    worker->moveToThread(thread);

    connect(thread, SIGNAL(started()), worker, SLOT(process()));
    connect(worker, SIGNAL(finished(QString)), this, SLOT(info(QString)));
    connect(worker, SIGNAL(finished(QString)), thread, SLOT(quit()));
    connect(worker, SIGNAL(finished(QString)), worker, SLOT(deleteLater()));
    connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));

    thread->start();

    info(QString("Exportujem subor ").append(filename));
}

void MainWindow::on_del_r1_clicked()
{
    ui->r1od->clear();
    ui->r1do->clear();
}
void MainWindow::on_del_r1lpi_clicked()
{
    ui->r1lpiod->clear();
    ui->r1lpido->clear();
}
void MainWindow::on_del_stl1_clicked()
{
    ui->stl1od->clear();
    ui->stl1do->clear();
}
void MainWindow::on_del_stl1pi_clicked()
{
    ui->stl1lpiod->clear();
    ui->stl1lpido->clear();
}
void MainWindow::on_del_komb_clicked()
{
    ui->kombod->clear();
    ui->kombdo->clear();
}
void MainWindow::on_del_rod_clicked()
{
    ui->r2od->clear();
    ui->r2do->clear();
}
void MainWindow::on_del_rlpiod_clicked()
{
    ui->r2lpiod->clear();
    ui->r2lpido->clear();
}
void MainWindow::on_del_stlod_clicked()
{
    ui->stl2od->clear();
    ui->stl2do->clear();

}
void MainWindow::on_del_stllpiod_clicked()
{
    ui->stl2lpiod->clear();
    ui->stl2lpido->clear();
}
void MainWindow::on_del_all_clicked()
{
    on_del_r1_clicked();
    on_del_r1lpi_clicked();
    on_del_stl1_clicked();
    on_del_stl1pi_clicked();
    on_del_komb_clicked();
    on_del_rod_clicked();
    on_del_rlpiod_clicked();
    on_del_stlod_clicked();
    on_del_stllpiod_clicked();
}

void MainWindow::on_show_limits_clicked()
{
    ui->r1od->setText(num_to_str(num1_R.sum_R_min()));
    ui->r1do->setText(num_to_str(num1_R.sum_R_max()));
    ui->r1lpiod->setText(num_to_str(num1_R.sum_R_Lpi_min()));
    ui->r1lpido->setText(num_to_str(num1_R.sum_R_Lpi_max()));
    ui->stl1od->setText(num_to_str(num1_R.sum_STL_min()));
    ui->stl1do->setText(num_to_str(num1_R.sum_STL_max()));
    ui->stl1lpiod->setText(num_to_str(num1_R.sum_STL_Lpi_min()));
    ui->stl1lpido->setText(num_to_str(num1_R.sum_STL_Lpi_max()));

    ui->kombod;
    ui->kombdo;

    ui->r2od->setText(num_to_str(numOD_R.sum_R_min()));
    ui->r2do->setText(num_to_str(numOD_R.sum_R_max()));
    ui->r2lpiod->setText(num_to_str(numOD_R.sum_R_Lpi_min()));
    ui->r2lpido->setText(num_to_str(numOD_R.sum_R_Lpi_max()));
    ui->stl2od->setText(num_to_str(numOD_R.sum_STL_min()));
    ui->stl2do->setText(num_to_str(numOD_R.sum_STL_max()));
    ui->stl2lpiod->setText(num_to_str(numOD_R.sum_STL_Lpi_min()));
    ui->stl2lpido->setText(num_to_str(numOD_R.sum_STL_Lpi_max()));

}

bool MainWindow::min2(){
    int c=0;
    if (ui->r1do->text().size() > 0)
        c++;
    if (ui->r1od->text().size() > 0)
        c++;
    if (ui->r1lpiod->text().size() > 0)
        c++;
    if (ui->r1lpido->text().size() > 0)
        c++;
    if (ui->stl1do->text().size() > 0)
        c++;
    if (ui->stl1od->text().size() > 0)
        c++;
    if (ui->stl1lpiod->text().size() > 0)
        c++;
    if (ui->stl1lpido->text().size() > 0)
        c++;
    if (ui->kombdo->text().size() > 0)
        c++;
    if (ui->kombod->text().size() > 0)
        c++;
    if (ui->r2do->text().size() > 0)
        c++;
    if (ui->r2od->text().size() > 0)
        c++;
    if (ui->r2lpiod->text().size() > 0)
        c++;
    if (ui->r2lpido->text().size() > 0)
        c++;
    if (ui->stl2do->text().size() > 0)
        c++;
    if (ui->stl2od->text().size() > 0)
        c++;
    if (ui->stl2lpiod->text().size() > 0)
        c++;
    if (ui->stl2lpido->text().size() > 0)
        c++;

    return (c > 1);
}

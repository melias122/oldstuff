#ifndef NUMBERS_H
#define NUMBERS_H

#include <map>
#include <vector>
#include <deque>
#include <set>
#include <limits>
#include <qmath.h>
#include<QSet>
#include<QStringList>
#include <QVector>
#include <QtGlobal>

class N {
public:

    N(unsigned n);
    ~N();

    void set_R(double R);
    void set_R_Lpi(double R_Lpi);
    void set_STL(unsigned stl, double STL);
    void set_STL_Lpi(unsigned stl, double STL_Lpi);

    double get_R();
    double get_R_Lpi();
    double get_STL(unsigned stl);
    double get_STL_Lpi(unsigned stl);

private:

    double R, R_Lpi;
    std::map<unsigned, double> STL;
    std::map<unsigned, double> STL_Lpi;

};

class Numbers {
public:

    Numbers();
    Numbers(unsigned n, unsigned m);
    ~Numbers();

    void set_N(unsigned n);
    void set_M(unsigned m);

    template<class T>
    double sum_R(T begin, T end){
        double sum = 0;
        for(T it = begin; it != end; ++it){
            sum += get_R((int)*it);
        }
        return sum;
    }

    template<class T>
    double sum_STL(T begin, T end){
        double sum = 0;
        int stl = 1;
        for(T it = begin; it != end; ++it, ++stl){
            sum += get_STL((int)*it,stl);
        }
        return sum;
    }

    template<class T>
    double sum_R_Lpi(T begin, T end){
        double sum = 0;
        for(T it = begin; it != end; ++it){
            sum += get_R_Lpi((int)*it);
        }
        return sum;
    }

    template<class T>
    double sum_STL_Lpi(T begin, T end){
        double sum =0;
        int stl = 1;
        for(T it = begin; it != end; ++it, ++stl){
            sum += get_STL_Lpi((int)*it,stl);
        }
        return sum;
    }

    void set_R(unsigned c, double R);
    void set_R_Lpi(unsigned c, double R_Lpi);
    void set_STL(unsigned c, unsigned stl, double STL);
    void set_STL_Lpi(unsigned c, unsigned stl, double STL_Lpi);

    double get_R(unsigned c);
    double get_R_Lpi(unsigned c);
    double get_STL(unsigned c, unsigned stl);
    double get_STL_Lpi(unsigned c, unsigned stl);
    unsigned get_N();
    unsigned get_M();


    double sum_min(QVector<double> &qvd);
    double sum_max(QVector<double> &qvd);
    double sum_R_min();
    double sum_R_max();
    double sum_R_Lpi_min();
    double sum_R_Lpi_max();
    double sum_STL_min();
    double sum_STL_max();
    double sum_STL_Lpi_min();
    double sum_STL_Lpi_max();

private:
    unsigned n, m;
    std::map<unsigned, N> numbers;

    void init();
};

typedef quint8 num;

class Numberings{
public:
    Numberings(){
        pr <<2<<3<<5<<7<<11<<13<<17<<19<<23<<29<<31<<37<<41<<43<<47<<53<<59<<61<<67<<71<<73<<79<<83<<89;
    }

    bool P(num c){
        return ((c%2) == 0);
    }
    bool N(num c){
        return !P(c);
    }
    bool PR(num c){
        return pr.contains(c);
    }
    bool Mc(num c){
        if(C0(c))
            return false;
        QString s = QString::number(c);
        return (s[s.size()-1] < QChar('6'));
    }
    bool Vc(num c){
        return !Mc(c);
    }
    bool C19(num c){\
        return (c < 10);
    }
    bool C0(num c){
        QString s = QString::number(c);
        if(s.size() < 2)
            return false;
        return (s[s.length() -1] == QChar('0'));
    }
    bool cC(num c){
        QString s = QString::number(c);
        if(s.size() < 2)
            return false;
        return (s[0] < s[1]);
    }
    bool Cc(num c){
        QString s = QString::number(c);
        if(s.size() < 2)
            return false;
        return (s[0] > s[1]);
    }
    bool CC(num c){
       QString s = QString::number(c);
       if(s.size() < 2)
           return false;
       return (s[0] == s[1]);
    }

    QStringList result(const QVector<num> &first,const QVector<num> &prev){
        QStringList result;

        QVector<int> vi(11,0);

        foreach (const num &qvn, first) {
            if(P(qvn))      // Par
                vi[0]++;
            if(N(qvn))      // Nepar
                vi[1]++;
            if(PR(qvn))     //  Prvocislo
                vi[2]++;
            if(Mc(qvn))     // Male cifry
                vi[3]++;
            if(Vc(qvn))     // Velke cifry
                vi[4]++;
            if(C19(qvn))
                vi[5]++;
            if(C0(qvn))
                vi[6]++;
            if(cC(qvn))
                vi[7]++;
            if(Cc(qvn))
                vi[8]++;
            if(CC(qvn))
                vi[9]++;
            if(!prev.isEmpty() && prev.contains(qvn)) // Zhoda
                vi[10]++;
        }

        foreach (const int &i, vi) {
            result << QString::number(i);
        }

        return result;
    }

private:
    QSet<num> pr;
};

#endif // NUMBERS_H

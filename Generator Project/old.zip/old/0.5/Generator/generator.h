#ifndef GENERATOR_H
#define GENERATOR_H

#include <QObject>
#include <QMutex>
#include <QMutexLocker>
#include <QVector>

#include "lib/FindCombByIdx.h"
#include "lib/FindTotalComb.h"
#include "numbers.h"

typedef QVector<quint8> qvect;
typedef QVector< qvect > qvect2d;

class GeneratorThread : public QObject
{
    Q_OBJECT
public:
    GeneratorThread(BigInteger from, BigInteger limit, Numbers &n1, Numbers &n2, std::vector<std::vector<double> > &limits);

signals:
    void comb(qvect c);
//    void iter();
    void finished();

public slots:
    void generate();
    void stop();

private:

    template<class T>
    double sum_comb(T begin, T end){
        double sum = 0;
        for(T it=begin;it!=end;it++){
            sum += *it;
        }
        return sum;
    }

    template<class T>
    bool chceck(T begin, T end){
        mutex.lock();
        double  sumr1 = num1_R.sum_R(begin,end),
                sumrod = numOD_R.sum_R(begin,end),
                sumr1lpi = num1_R.sum_R_Lpi(begin,end),
                sumrodlpi = numOD_R.sum_R_Lpi(begin,end),
                sumstl1 = num1_R.sum_STL(begin,end),
                sumstl1lpi= num1_R.sum_STL_Lpi(begin, end),
                sumstlod=numOD_R.sum_STL(begin, end),
                sumstlodlpi=numOD_R.sum_STL_Lpi(begin,end),
                sumcomb = sum_comb(begin, end);
        mutex.unlock();

        if(!(sumr1 >= limits[0][0] && sumr1 <= limits[0][1]))
            return false;
        if(!(sumrod >= limits[0][2] && sumrod <= limits[0][3]))
            return false;
        if(!(sumr1lpi >= limits[1][0] && sumr1lpi <= limits[1][1]))
            return false;
        if(!(sumrodlpi >= limits[1][2] && sumrodlpi <= limits[1][3]))
            return false;
        if(!(sumstl1 >= limits[2][0] && sumstl1 <= limits[2][1]))
            return false;
        if(!(sumstlod >= limits[2][2] && sumstlod <= limits[2][3]))
            return false;
        if(!(sumstl1lpi >= limits[3][0] && sumstl1lpi <= limits[3][1]))
            return false;
        if(!(sumstlodlpi >= limits[3][2] && sumstlodlpi <= limits[3][3]))
            return false;
        if(!(sumcomb >= limits[4][0] && sumcomb <= limits[4][1]))
            return false;

        return true;
    }

    volatile bool state;
//    QMutexLocker mutexLocker;
    BigInteger limit;
    std::vector<unsigned> ca, cb;
    stdcomb::CFindCombByIdx< CFindTotalComb<BigInteger>, BigInteger > findcomb;
    Numbers num1_R, numOD_R;
    std::vector<std::vector<double> > limits;
    QMutex mutex;
};

class Generator : public QObject
{
    Q_OBJECT
public:
    Generator(Numbers &n1, Numbers &n2, std::vector<std::vector<double> > &limits);

signals:
//    void progress(int value);
    void results_ready(qvect2d r);
    void finished();
    void generator_state(bool state);
//    void error(QString err);

public slots:
    void process();
    void stop();
//    void counter();
    void finish();
    void results(qvect v);

private:

    int threads_count, Set, Comb, progress_bar_value, threads_finished;
    std::vector<BigInteger> from, limit;
    BigInteger total_comb_count, iterations;
    CFindTotalComb<BigInteger> tc;
    Numbers num1_R, numOD_R;
    std::vector<std::vector<double> > limits;
    qvect2d combinations;
    QMutex mutex;
    QVector<GeneratorThread*> workers;
};

#endif // GENERATOR_H

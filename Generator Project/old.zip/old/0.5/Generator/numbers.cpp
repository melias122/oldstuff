#include "numbers.h"
//#include "utils.h"
#include "fileop.h"

//#include <algorithm>
#include <QtAlgorithms>

using namespace std;

//N

N::N(unsigned n){
    R = R_Lpi = 0;
    for(unsigned i=1; i <=n; i++){
        STL.insert(std::pair<unsigned,double>(i,0));
        STL_Lpi.insert(std::pair<unsigned,double>(i,0));
    }
}

N::~N(){}

void N::set_R(double R){
    this->R = R;
}

void N::set_R_Lpi(double R_Lpi){
    this->R_Lpi = R_Lpi;
}

void N::set_STL(unsigned stl, double STL){
    if(stl > 0)
        this->STL.at(stl) = STL;
//        else
//            std::cerr << "Error: 'Nepodarilo sa vlozit hodnotu STL " << stl << ": " << STL << "'";
}

void N::set_STL_Lpi(unsigned stl, double STL_Lpi){
    if(stl > 0)
        this->STL_Lpi.at(stl) = STL_Lpi;
//        else
//            std::cerr << "Error: 'Nepodarilo sa vlozit hodnotu STL " << stl << ": " << STL << "'";
}

double N::get_R(){
    return R;
}

double N::get_R_Lpi(){
    return R_Lpi;
}

double N::get_STL(unsigned stl){
    return (stl>0) ? STL.at(stl) : 0;
}
double N::get_STL_Lpi(unsigned stl){
    return (stl>0) ? STL_Lpi.at(stl) : 0;
}

//N end


//Numbers

Numbers::Numbers(){
    init();
}

Numbers::Numbers(unsigned n, unsigned m){
    this->n = n;
    this->m = m;
    this->init();
}

Numbers::~Numbers(){}

void Numbers::set_N(unsigned n){ this->n = n;}

void Numbers::set_M(unsigned m){ this->m = m;}

void Numbers::set_R(unsigned c, double R){
    numbers.at(c).set_R(R);
}

void Numbers::set_R_Lpi(unsigned c, double R_Lpi){
    numbers.at(c).set_R_Lpi(R_Lpi);
}

void Numbers::set_STL(unsigned c, unsigned stl, double STL){
    numbers.at(c).set_STL(stl, STL);
}

void Numbers::set_STL_Lpi(unsigned c, unsigned stl, double STL_Lpi){
    numbers.at(c).set_STL_Lpi(stl, STL_Lpi);
}

double Numbers::get_R(unsigned c){
    return numbers.at(c).get_R();
}

double Numbers::get_R_Lpi(unsigned c){
    return numbers.at(c).get_R_Lpi();
}

double Numbers::get_STL(unsigned c, unsigned stl){
    return numbers.at(c).get_STL(stl);
}

double Numbers::get_STL_Lpi(unsigned c, unsigned stl){
    return numbers.at(c).get_STL_Lpi(stl);
}

unsigned Numbers::get_N(){
    return n;
}

unsigned Numbers::get_M(){
    return m;
}



double Numbers::sum_min(QVector<double> &qvd){
    double sum=0;
    qSort(qvd);

    for(int i=0;i<get_N();i++){
        sum += qvd[i];
    }
    return (sum > 0) ? sum - 0.000005 : 0;
}

double Numbers::sum_max(QVector<double> &qvd){
    double sum=0;
    qSort(qvd);

    for(int i=qvd.size()-1; i>qvd.size()-get_N()-1;i--){
        sum += qvd[i];
    }
    return (sum > 0) ? sum + 0.000005 : 0;
}

double Numbers::sum_R_min(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        qvd.push_back(get_R(i));
    }
    return sum_min(qvd);
}

double Numbers::sum_R_max(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        qvd.push_back(get_R(i));
    }
    return sum_max(qvd);
}

double Numbers::sum_R_Lpi_min(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        qvd.push_back(get_R_Lpi(i));
    }
    return sum_min(qvd);
}
double Numbers::sum_R_Lpi_max(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        qvd.push_back(get_R_Lpi(i));
    }
    return sum_max(qvd);
}
double Numbers::sum_STL_min(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        for(int j=1;j<=get_N();j++){
//            if(get_STL(i,j) > 0)
                qvd.push_back(get_STL(i,j));
        }
    }
    return sum_min(qvd);
}
double Numbers::sum_STL_max(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        for(int j=1;j<=get_N();j++){
//            if(get_STL(i,j) > 0)
                qvd.push_back(get_STL(i,j));
        }
    }
    return sum_max(qvd);
}
double Numbers::sum_STL_Lpi_min(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        for(int j=1;j<=get_N();j++){
//            if(get_STL_Lpi(i,j) > 0)
                qvd.push_back(get_STL_Lpi(i,j));
        }
    }
    return sum_min(qvd);
}
double Numbers::sum_STL_Lpi_max(){
    QVector<double> qvd;
    for(int i=1;i<=get_M();i++){
        for(int j=1;j<=get_N();j++){
//            if(get_STL_Lpi(i,j) > 0)
                qvd.push_back(get_STL_Lpi(i,j));
        }
    }
    return sum_max(qvd);
}



void Numbers::init(){
    numbers.clear();
    for(unsigned i=1; i <= 90; i++){
        numbers.insert(std::pair<unsigned, N>(i, N(30)));
    }
}

//Numbers end

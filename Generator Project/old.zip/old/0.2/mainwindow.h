#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "numbers.h"
#include "fileop.h"
#include "combination.h"
#include "utils.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
private slots:
    void on_actionKoniec_triggered();
    void on_pushButton_File_browser_clicked();

    void on_actionGeneruj_triggered();

    void on_spinBox_N_editingFinished();

    void on_spinBox_M_editingFinished();

    void on_actionNacitaj_subor_triggered();

    void on_actionSave_triggered();

private:
    bool file_readed_stl, file_readed_r;
    std::vector<unsigned> ca,cb;
    Ui::MainWindow *ui;
    Numbers n;
    QString file_path;
    QStringList t_header;
};

#endif // MAINWINDOW_H

#include<numbers.h>

#include<string>

#ifndef FILEOP_H
#define FILEOP_H

bool read_numbers_STL(Numbers &numbers, std::string filename);
bool read_numbers_R(Numbers &numbers, std::string filename);

#endif // FILEOP_H

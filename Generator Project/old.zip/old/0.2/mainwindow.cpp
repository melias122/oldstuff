#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<iostream>

#include<QFileDialog>
#include<QFile>
#include<QTextStream>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    n = Numbers(1,1);
    file_readed_stl = false;
    file_readed_r = false;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionKoniec_triggered()
{
    qApp->exit(0);
}

void MainWindow::on_pushButton_File_browser_clicked()
{
    file_path = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    ui->lineEdit_Path->setText(file_path);
}

template<class T>
QString comb_to_str(T begin, T end){
    QString s;
    for(T i=begin; i!=end; i++){
        s.append(QString::number(*i));
        s.append(" ");
    }
    return s;
}

template<class T>
unsigned comb_sum(T begin, T end, unsigned from, unsigned to){
    unsigned sum=0;
    for(T i=begin; i!=end; i++){
        sum += *i;
    }
    return ((sum >= from) && (sum <= to)) ? sum : 0;
}

void MainWindow::on_actionGeneruj_triggered()
{
    if(!((n.get_M() > 1) && (n.get_N() > 1))){ return;}
    if(!file_readed_r){return;}
    if(!file_readed_stl){return;}

    int i = 0, col = 0;
    double sum_R=0,sum_R_Lpi=0,sum_STL=0,sum_STL_Lpi=0,sum_comb=0;

    // najdenie riadku
//    cb.clear();
    find_comb(ui->spinBox_N->text().toInt(),ui->spinBox_M->text().toInt(),ui->rows_limit_OD->text().toLong() - 1,cb);
    //

    // vycistenie a sirka tabulky
//    ui->tableWidget->clear();
    while (ui->tableWidget->rowCount() > 0){ ui->tableWidget->removeRow(0); }
    ui->tableWidget->setColumnCount(((n.get_N()+1)*5)+1);
    //

    do {
        if(i == ui->tableWidget->rowCount()){ ui->tableWidget->insertRow(ui->tableWidget->rowCount()); }

        sum_R=n.sum_R(cb.begin(),cb.end(), ui->R_OD->text().toDouble(), ui->R_DO->text().toDouble());
        sum_R_Lpi=n.sum_R_Lpi(cb.begin(),cb.end(), ui->R_Lpi_OD->text().toDouble(), ui->R_Lpi_DO->text().toDouble());
        sum_STL=n.sum_STL(cb.begin(),cb.end(),1,ui->STL_OD->text().toDouble(),ui->STL_DO->text().toDouble());
        sum_STL_Lpi=n.sum_STL_Lpi(cb.begin(),cb.end(),1,ui->STL_Lpi_OD->text().toDouble(), ui->STL_Lpi_DO->text().toDouble());
        sum_comb=comb_sum(cb.begin(),cb.end(), ui->SUM_Komb_OD->text().toInt(), ui->SUM_Komb_DO->text().toInt());

        if( (sum_R == 0) || (sum_R_Lpi == 0) || (sum_STL == 0) || (sum_STL_Lpi == 0) || (sum_comb == 0))
            continue;

        col = 0;
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(comb_to_str(cb.begin(),cb.end())));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_R)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_R_Lpi)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_STL)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_STL_Lpi)));
        ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(sum_comb)));

        // ciastocne sucty
        for(unsigned cs = 0; cs < cb.size(); cs++){
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(cb[cs])));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_R( &cb[cs], &cb[cs+1] ))));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_R_Lpi( &cb[cs], &cb[cs+1] ))));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_STL( &cb[cs], &cb[cs+1], (cs+1) ))));
            ui->tableWidget->setItem(i,col++, new QTableWidgetItem(QString::number(n.sum_STL_Lpi( &cb[cs], &cb[cs+1], (cs+1) ))));
        }
        //

        i++;
    } while(stdcomb::next_combination(ca.begin (),ca.end (),cb.begin (),cb.end()) && (i < ui->rows_limit_DO->text().toLong()));

    // header
    t_header << "Kombinacie" << "R" << "R Lpi" << "STL" << "STL Lpi" << "SUM Komb";
    for(unsigned cs = 0; cs < cb.size(); cs++){
        t_header << "Cislo" << "R" << "R Lpi" << "STL" << "STL Lpi";
    }
    ui->tableWidget->setHorizontalHeaderLabels(t_header);
    ui->tableWidget->horizontalHeader()->setVisible(true);
    //
}


void MainWindow::on_spinBox_N_editingFinished()
{

    file_readed_r = file_readed_stl = false;
    n.set_N(ui->spinBox_N->text().toInt());
    cb.clear();
    for(unsigned i = 1; i <= n.get_N(); i++) cb.push_back(i);
}

void MainWindow::on_spinBox_M_editingFinished()
{
    file_readed_r = file_readed_stl = false;
    n.set_M(ui->spinBox_M->text().toInt());
    ca.clear();
    for(unsigned i = 1; i <= n.get_M(); i++) ca.push_back(i);
}

void MainWindow::on_actionNacitaj_subor_triggered()
{
    if(read_numbers_STL(n, ui->lineEdit_Path->text().toStdString())){ file_readed_stl = true;}
    if(read_numbers_R(n, ui->lineEdit_Path->text().toStdString())){ file_readed_r = true;}
}

void MainWindow::on_actionSave_triggered()
{
    QString filename;
    if((filename = QFileDialog::getSaveFileName(this, tr("Ulozit subor"), "", tr("Export (*.csv)"))) == "")
        return;
    QFile f( filename );

    if (f.open(QFile::WriteOnly)) {

        QTextStream data( &f );
        QStringList strList;
        strList.clear();

        for( int c = 0; c < ui->tableWidget->columnCount(); ++c ) {
            strList << ui->tableWidget->horizontalHeaderItem(c)->data(Qt::DisplayRole).toString();
        }

        data << strList.join( ";" )+"\n";

        for( int r = 0; r < ui->tableWidget->rowCount(); ++r ) {

            strList.clear();
            for( int c = 0; c < ui->tableWidget->columnCount(); ++c ) {
                strList << ui->tableWidget->item( r, c )->text().replace(QString("."), QString(","));
            }

            data << strList.join( ";" )+"\n";
        }
        f.close();
    }
}

#ifndef UTILS_H
#define UTILS_H

#include<vector>

void find_comb(unsigned nComb, unsigned nSet, long unsigned int c, std::vector<unsigned> &vec);

#endif // UTILS_H

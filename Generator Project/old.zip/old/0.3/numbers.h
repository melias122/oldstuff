#ifndef NUMBERS_H
#define NUMBERS_H

#include <map>
#include <vector>
#include <deque>
#include <limits>
#include <QtGlobal>

class N {
public:

    N(unsigned n);
    ~N();

    void set_R(double R);
    void set_R_Lpi(double R_Lpi);
    void set_STL(unsigned stl, double STL);
    void set_STL_Lpi(unsigned stl, double STL_Lpi);

    double get_R();
    double get_R_Lpi();
    double get_STL(unsigned stl);
    double get_STL_Lpi(unsigned stl);

private:

    double R, R_Lpi;
    std::map<unsigned, double> STL;
    std::map<unsigned, double> STL_Lpi;

};

class Numbers {
public:

    Numbers();
    Numbers(unsigned n, unsigned m);
    ~Numbers();

    void set_N(unsigned n);
    void set_M(unsigned m);

    template<class T>
    double sum_R(T begin, T end, double from = 0, double to = std::numeric_limits<double>::max());

    template<class T>
    double sum_STL(T begin, T end, int i = 1, double from = 0, double to = std::numeric_limits<double>::max());

    template<class T>
    double sum_R_Lpi(T begin, T end, double from = 0, double to = std::numeric_limits<double>::max());

    template<class T>
    double sum_STL_Lpi(T begin, T end, int i = 1, double from = 0, double to = std::numeric_limits<double>::max());

    void set_R(unsigned c, double R);
    void set_R_Lpi(unsigned c, double R_Lpi);
    void set_STL(unsigned c, unsigned stl, double STL);
    void set_STL_Lpi(unsigned c, unsigned stl, double STL_Lpi);

    double get_R(unsigned c);
    double get_R_Lpi(unsigned c);
    double get_STL(unsigned c, unsigned stl);
    double get_STL_Lpi(unsigned c, unsigned stl);
    unsigned get_N();
    unsigned get_M();

    std::deque<std::vector<quint8> > gen_R();
    std::vector< std::map<quint8, bool> > gen_STL();
    std::deque< std::vector<quint8> > get_RxSTL();

private:
    unsigned n, m;
    std::map<unsigned, N> numbers;

    void init();
    void check(std::vector<double> &perms, std::map<double, std::vector<int> > &m, std::deque< std::vector<quint8> > &cmp1);
};

#endif // NUMBERS_H

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "numbers.h"
#include "db.h"
//#include "form.h"
//#include "dialog.h"
#include "tablewindow.h"

#include <QMainWindow>
//#include <deque>
//#include <vector>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


    int get_N();
    int get_M();
    std::vector<std::vector<double> > limits();
    void wlist();
    void info(QString s);

private slots:
    void on_protokol_clicked();
    void on_filtruj_clicked();

    void on_file_R1_clicked();

    void on_file_STL1_clicked();

    void on_file_ROD_clicked();

    void on_file_STLOD_clicked();

    void on_gen_dbR1_clicked();

    void on_gen_dbODR_clicked();

//    void on_spinBoxN_editingFinished();

//    void on_spinBoxM_editingFinished();

    void on_db_R1_clicked();

    void on_arch_R1_clicked();

    void on_db_ROD_clicked();

    void on_arch_OD_R_clicked();

    void on_prac_list_clicked();

private:
    Ui::MainWindow *ui;
    TableWindow *arch1, *arch2, *list, *filt;

    QString path_protokol, path_R1, path_STL1, path_ROD, path_STLOD;

    Numbers num1_R, numOD_R;

    DB dbR1, dbROD;

    std::deque< std::vector<quint8> > worklist;
};

#endif // MAINWINDOW_H

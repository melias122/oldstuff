#ifndef UTILS_H
#define UTILS_H

#include <vector>
#include <deque>
#include <QtGlobal>
#include <QString>

std::deque< std::vector<quint8> > work_list(std::deque< std::vector<quint8> > cmp1, std::deque< std::vector<quint8> > cmp2);
QString fname(QString path);

#endif // UTILS_H

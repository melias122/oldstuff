#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "fileop.h"
#include "utils.h"

#include <vector>
#include <QDebug>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    arch1 = new TableWindow(this);
    arch2 = new TableWindow(this);
    list = new TableWindow(this);
    filt = new TableWindow(this);
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete arch1;
    delete arch2;
    delete list;
    delete filt;
    delete ui;
}

int MainWindow::get_N(){
    return ui->spinBoxN->text().toInt();
}
int MainWindow::get_M(){
    return ui->spinBoxM->text().toInt();
}

void MainWindow::info(QString s){
    ui->Info->setText(s);
}

void MainWindow::on_protokol_clicked()
{
    QString filename;
    if((filename = QFileDialog::getSaveFileName(this, tr("Ulozit subor"), "", tr("(*.txt)"))) == ""){
            return;
    }
    else {
        path_protokol = filename;
        path_protokol.append(".txt");
        info("Protokol vytvoreny");
        write_protocol(path_protokol, "Vytvoreny protokol.");
    }
}

void MainWindow::on_file_R1_clicked()
{
    path_R1 = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_R1.isEmpty()){
        num1_R.set_M(get_M()); num1_R.set_N(get_N());
        if(read_numbers_R(num1_R, path_R1)){
            info(QString("Subor ").append(fname(path_R1)).append(" uspesne nacitany"));
            write_protocol(path_protokol, QString("Subor ").append(path_R1).append(" uspesne nacitany."));
        }
        else{
            info(QString("Nepodarilo sa nacitat subor ").append(fname(path_R1)));
//            write_protocol(path_protokol, QString("Nepodarilo sa nacitat subor ").append(path_R1));
        }
    }
}

void MainWindow::on_file_STL1_clicked()
{
    path_STL1 = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_STL1.isEmpty()){
        if(read_numbers_STL(num1_R, path_STL1)){
            num1_R.set_M(get_M()); num1_R.set_N(get_N());
            info(QString("Subor ").append(fname(path_STL1)).append(" uspesne nacitany"));
            write_protocol(path_protokol, QString("Subor ").append(path_STL1).append(" uspesne nacitany."));
        }
        else{
            info(QString("Nepodarilo sa nacitat subor ").append(fname(path_STL1)));
//            write_protocol(path_protokol, QString("Nepodarilo sa nacitat subor ").append(path_STL1));
        }
    }
}

void MainWindow::on_file_ROD_clicked()
{
    path_ROD = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_ROD.isEmpty()){
        if(read_numbers_R(numOD_R, path_ROD)){
            numOD_R.set_M(get_M()); numOD_R.set_N(get_N());
            info(QString("Subor ").append(fname(path_ROD)).append(" uspesne nacitany"));
            write_protocol(path_protokol, QString("Subor ").append(path_ROD).append(" uspesne nacitany."));
        }
        else{
            info(QString("Nepodarilo sa nacitat subor ").append(fname(path_ROD)));
//            write_protocol(path_protokol, QString("Nepodarilo sa nacitat subor ").append(path_ROD));
        }
    }
}

void MainWindow::on_file_STLOD_clicked()
{
    path_STLOD = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_STLOD.isEmpty()){
        if(read_numbers_STL(numOD_R, path_STLOD)){
            numOD_R.set_M(get_M()); numOD_R.set_N(get_N());
            info(QString("Subor ").append(fname(path_STLOD)).append(" uspesne nacitany"));
            write_protocol(path_protokol, QString("Subor ").append(path_STLOD).append(" uspesne nacitany."));
        }
        else{
            info(QString("Subor ").append(fname(path_STLOD)).append(" uspesne nacitany"));
//            write_protocol(path_protokol, QString("Nepodarilo sa nacitat subor ").append(path_STLOD));
        }
    }
}

void MainWindow::on_gen_dbR1_clicked()
{
    if(!path_R1.isEmpty() && !path_STL1.isEmpty()){
        info("Vytvaram databazu 1-DO");
        write_protocol(path_protokol, QString("Vytvaram databazu 1-DO"));
        dbR1.clear();
        dbR1 = num1_R.get_RxSTL();
        dbR1 = num1_R;
        if(dbR1.save()){
            info("Databaza ulozena");
            write_protocol(path_protokol, QString("Databaza ulozena"));
        }
        else{
            info("Nepodarilo sa ulozit databazu, nebol zadany nazov");
            write_protocol(path_protokol, QString("Nepodarilo sa ulozit databazu, nebol zadany nazov alebo nastala chyba"));
        }
    }
    else{
        info("R a STL neboli nacitane");
//        write_protocol(path_protokol, QString("R a STL neboli nacitane"));
    }
}

void MainWindow::on_gen_dbODR_clicked()
{
    if(!path_ROD.isEmpty() && !path_STLOD.isEmpty()){
        info("Vytvaram databazu OD-DO");
        write_protocol(path_protokol, QString("Vytvaram databazu OD-R "));
        dbROD.clear();
        dbROD = numOD_R.get_RxSTL();
        dbROD = numOD_R;
        if(dbROD.save()){
            info("Databaza ulozena");
            write_protocol(path_protokol, QString("Databaza ulozena"));
        }
        else{
            info("Nepodarilo sa ulozit databazu, nebol zadany nazov");
            write_protocol(path_protokol, QString("Nepodarilo sa ulozit databazu, nebol zadany nazov alebo nastala chyba"));
        }
    }
    else{
        info("R a STL neboli nacitane");
//        write_protocol(path_protokol, QString("R a STL neboli nacitane"));
    }
}

void MainWindow::on_db_R1_clicked()
{
    QString dbpath;
    dbpath = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("DB (*.db)"));
    if(!dbpath.isEmpty()){
        worklist.clear();
        dbR1.load(dbpath);
        ui->spinBoxN->setValue(dbR1.get_N());
        ui->spinBoxM->setValue(dbR1.get_M());
        info(QString("Databaza " ).append(fname(dbpath)).append(" nacitana"));
        write_protocol(path_protokol, QString("Databaza " ).append(fname(dbpath)).append(" nacitana"));
    }
}

void MainWindow::on_db_ROD_clicked()
{
    QString dbpath;
    dbpath = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("DB (*.db)"));
    if(!dbpath.isEmpty()){
        worklist.clear();
        dbROD.load(dbpath);
        ui->spinBoxN->setValue(dbROD.get_N());
        ui->spinBoxM->setValue(dbROD.get_M());
        info(QString("Databaza " ).append(fname(dbpath)).append(" nacitana"));
        write_protocol(path_protokol, QString("Databaza ").append(fname(dbpath)).append(" nacitana"));
    }
}

void MainWindow::on_arch_R1_clicked()
{
    if(!dbR1.empty()){
        info("Nacitavam archiv");
        if(!arch1->isVisible()){
            delete arch1;
            arch1 = new TableWindow();
            arch1->create_arch(dbR1.get_nums(),dbR1.get_numbers());
            arch1->show();
        }
        info("Archiv nacitany");
    }
    else{
        info("Nebola nacitana databaza 1-DO");
    }
}

void MainWindow::on_arch_OD_R_clicked()
{
    if(!dbROD.empty()){
        info("Nacitavam archiv");
        if(!arch2->isVisible()){
            delete arch2;
            arch2=new TableWindow();
            arch2->create_arch(dbROD.get_nums(), dbROD.get_numbers());
            arch2->show();
        }
        info("Archiv nacitany");
    }
    else{
        info("Nebola nacitana databaza OD-DO");
    }

}

void MainWindow::wlist(){
    if(!dbR1.empty() && !dbROD.empty()){
        write_protocol(path_protokol, "Vytvaram pracovny list");
        worklist.clear();
        worklist = work_list(dbR1.get_nums(), dbROD.get_nums());
    }
    else{
        info("Neboli nacitane databazy");
    }
}

void MainWindow::on_prac_list_clicked()
{
    if(worklist.empty()){
        wlist();
    }
    if(!list->isVisible()){
        delete list;
        list = new TableWindow();
        list->create_worklist(worklist, dbR1.get_numbers(), dbROD.get_numbers());
        list->show();
    }
    info("Pracovny list vytvoreny");
}

std::vector<std::vector<double> > MainWindow::limits(){

    using std::vector;

    std::vector<std::vector<double> > limits;

    std::vector<double> v1;
    v1.push_back(ui->r1od->text().replace(",",".").toDouble());
    v1.push_back(ui->r1do->text().replace(",",".").toDouble());
    v1.push_back(ui->r2od->text().replace(",",".").toDouble());
    v1.push_back(ui->r2do->text().replace(",",".").toDouble());

    std::vector<double> v2;
    v2.push_back(ui->r1lpiod->text().replace(",",".").toDouble());
    v2.push_back(ui->r1lpido->text().replace(",",".").toDouble());
    v2.push_back(ui->r2lpiod->text().replace(",",".").toDouble());
    v2.push_back(ui->r2lpido->text().replace(",",".").toDouble());

    std::vector<double> v3;
    v3.push_back(ui->stl1od->text().replace(",",".").toDouble());
    v3.push_back(ui->stl1do->text().replace(",",".").toDouble());
    v3.push_back(ui->stl2od->text().replace(",",".").toDouble());
    v3.push_back(ui->stl2do->text().replace(",",".").toDouble());

    std::vector<double> v4;
    v4.push_back(ui->stl1lpiod->text().replace(",",".").toDouble());
    v4.push_back(ui->stl1lpido->text().replace(",",".").toDouble());
    v4.push_back(ui->stl2lpiod->text().replace(",",".").toDouble());
    v4.push_back(ui->stl2lpido->text().replace(",",".").toDouble());

    std::vector<double> v5;
    v5.push_back(ui->kombod->text().toInt());
    v5.push_back(ui->kombdo->text().toInt());

    limits.push_back(v1);
    limits.push_back(v2);
    limits.push_back(v3);
    limits.push_back(v4);
    limits.push_back(v5);

    return limits;
}

void MainWindow::on_filtruj_clicked()
{
    if(worklist.empty()){
        wlist();
    }
//    if(!filt->isVisible()){
    if(!worklist.empty()){
        info("Filtrujem");
//            delete filt;
        filt = new TableWindow();
        filt->create_filt(worklist, dbR1.get_numbers(), dbROD.get_numbers(),limits());
        filt->show();
        info("Filtrovanie dokoncene");
    }
    else
        info("Pracovny list je prazdny");
}

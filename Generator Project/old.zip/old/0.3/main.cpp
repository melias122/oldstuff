#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}

//#include <iostream>

//class A
//{
//public:
//    A() {}
//    A operator =(int a){
//        std::swap(*this, a);
//        return *this;
//    }
//    int geta(){
//        return a;
//    }
//private:
//    int a;
//};

//#include<iostream>
//#include<vector>

//int main(int argc, char *argv[])
//{
//    std::vector<int> a,b;
//    a.push_back(1);
//    b.push_back(1);

//    if(a == b)
//        std::cout << "ök";

//    return 0;
//}


//#include "numbers.h"
//#include "fileop.h"
//#include "utils.h"

//#include <vector>
//#include <deque>

//using namespace std;

//int main(int argc, char *argv[]){

//    deque< vector<quint8> > ret1, ret2;

//    int N = 5;
//    int M = 50;

//    Numbers n(N,M), n2(N,M);

//    read_numbers_R(n, "/home/melias122_elementary/550R.csv");
//    read_numbers_STL(n, "/home/melias122_elementary/550STL.csv");
//    ret1=n.get_RxSTL();

//    read_numbers_R(n2, "/home/melias122_elementary/550ROD.csv");
//    read_numbers_STL(n2, "/home/melias122_elementary/550STLOD.csv");
//    ret2=n2.get_RxSTL();

//    work_list(ret1,ret2);

//    return 0;
//}

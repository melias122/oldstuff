#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<QFileDialog>
#include<QThread>
#include<QDir>

#include"combination.h"
#include "generator.h"
#include "result.h"

//#ifdef QT_DEBUG
//    #include<QDebug>
//#endif

const QString colorErr{"#FF9999"};
const QString colorDefault{"white"};

QString fname(QString path){
    return path.split(QDir::separator()).last();
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    generator_running = false;

    gfuntions.push_back({&Glimits::set_r1od, &Glimits::set_r1do});
    gfuntions.push_back({&Glimits::set_stl1od, &Glimits::set_stl1do});
    gfuntions.push_back({&Glimits::set_dtR1od, &Glimits::set_dtR1do});
    gfuntions.push_back({&Glimits::set_dtSTL1od, &Glimits::set_dtSTL1do});
    gfuntions.push_back({&Glimits::set_dt_rs1od, &Glimits::set_dt_rs1do});
    gfuntions.push_back({&Glimits::set_hhrxod, &Glimits::set_hhrxdo}); //hhrx
    gfuntions.push_back({&Glimits::set_kombod, &Glimits::set_kombdo});

    gfuntions.push_back({&Glimits::set_r2od, &Glimits::set_r2do});
    gfuntions.push_back({&Glimits::set_stl2od, &Glimits::set_stl2do});
    gfuntions.push_back({&Glimits::set_dtR2od, &Glimits::set_dtR2do});
    gfuntions.push_back({&Glimits::set_dtSTL2od, &Glimits::set_dtSTL2do});
    gfuntions.push_back({&Glimits::set_dt_rs2od, &Glimits::set_dt_rs2do});
    gfuntions.push_back({&Glimits::set_hrxod, &Glimits::set_hrxdo}); //hrx
    gfuntions.push_back({});  //nepouziva sa...

    gfuntions.push_back({&Glimits::set_Pod, &Glimits::set_Pdo});
    gfuntions.push_back({&Glimits::set_Nod, &Glimits::set_Ndo});
    gfuntions.push_back({&Glimits::set_PRod, &Glimits::set_PRdo});
    gfuntions.push_back({&Glimits::set_Mcod, &Glimits::set_Mcdo});
    gfuntions.push_back({&Glimits::set_Vcod, &Glimits::set_Vcdo});
    gfuntions.push_back({&Glimits::set_c19od, &Glimits::set_c19do});
    gfuntions.push_back({&Glimits::set_c0od, &Glimits::set_c0do});
    gfuntions.push_back({&Glimits::set_cCod, &Glimits::set_cCdo});
    gfuntions.push_back({&Glimits::set_Ccod, &Glimits::set_Ccdo});
    gfuntions.push_back({&Glimits::set_CCod, &Glimits::set_CCdo});
    gfuntions.push_back({&Glimits::set_ZHod, &Glimits::set_ZHdo});
    gfuntions.push_back({}); //nepouziva sa...

    gfuntions.push_back({&Glimits::set_Smod, &Glimits::set_Smdo});
    gfuntions.push_back({&Glimits::set_Kkod, &Glimits::set_Kkdo});

    //1-do
    lines.push_back({ui->r1od, ui->r1R, ui->r1do});                 //sum R     --0--
    lines.push_back({ui->stl1od, ui->stl1R, ui->stl1do});           //sum STL   --1--
    lines.push_back({ui->dtr1od, ui->dtr1, ui->dtr1do});            //dt R      --2--
    lines.push_back({ui->dtstl1od, ui->dtstl1, ui->dtstl1do});      //dt STL    --3--
    lines.push_back({ui->dtRSTL1od, ui->dtRSTL1, ui->dtRSTL1do});   //dt R-STL  --4--
    lines.push_back({ui->HHRXod, ui->HHRXr, ui->HHRXdo});           //hhrx      --5--
    lines.push_back({ui->kombod, ui->kombR, ui->kombdo});           //Komb      --6--

    //od-do
    lines.push_back({ui->r2od, ui->r2R, ui->r2do});                 //sum R     --7--
    lines.push_back({ui->stl2od, ui->stl2R, ui->stl2do});           //sum STL   --8--
    lines.push_back({ui->dtr2od, ui->dtr2, ui->dtr2do});            //dt R      --9--
    lines.push_back({ui->dtstl2od, ui->dtstl2, ui->dtstl2do});      //dt STL    --10--
    lines.push_back({ui->dtRSTL2od, ui->dtRSTL2, ui->dtRSTL2do});   //dt R-STL  --11--
    lines.push_back({ui->HRXod, ui->HRXr, ui->HRXdo});              //hrx       --12--
    lines.push_back({ui->oddo_rozpetie});                           //rozpatie  --13--

    //cislovacky
    lines.push_back({ui->Pod, ui->P, ui->Pdo});                     //P         --14--
    lines.push_back({ui->Nod, ui->N, ui->Ndo});                     //N         --15--
    lines.push_back({ui->PRod, ui->PR, ui->PRdo});                  //PR        --16--
    lines.push_back({ui->Mcod, ui->Mc, ui->Mcdo});                  //MC        --17--
    lines.push_back({ui->Vcod, ui->Vc, ui->Vcdo});                  //VC        --18--
    lines.push_back({ui->c1_c9od, ui->c1_c9, ui->c1_c9do});         //c19       --19--
    lines.push_back({ui->C0od, ui->C0, ui->C0do});                  //c0        --20--
    lines.push_back({ui->cCod, ui->cC, ui->cCdo});                  //cC        --21--
    lines.push_back({ui->Ccod, ui->Cc, ui->Ccdo});                  //Cc        --22--
    lines.push_back({ui->CCod, ui->CC, ui->CCdo});                  //CC        --23--
    lines.push_back({ui->ZHod, ui->ZH, ui->ZHdo});                  //ZH        --24--
    lines.push_back({ui->mix_r, ui->mix_r1});                       //ZH "r"    --25--

    //sm, kk
    lines.push_back({ui->Smod, ui->Sm, ui->Smdo});                  //Sm        --26--
    lines.push_back({ui->Korod, ui->Kor, ui->Kordo});               //Kk        --27--

    //xtice
    lines.push_back({ui->x_tice1, ui->x_tice2, ui->x_tice3, ui->x_tice4, ui->x_tice5, ui->x_tice6, ui->x_tice7, ui->x_tice8, ui->x_tice9}); // --28--

    //pov, zak, ...
//    lines.push_back({});
//    lines.push_back({});
//    lines.push_back({});
//    lines.push_back({});
//    lines.push_back({});

    //stlNtice
    stlNtice.push_back({ui->n1});
    stlNtice.push_back({ui->n2});
    stlNtice.push_back({ui->n3});
    stlNtice.push_back({ui->n4});
    stlNtice.push_back({ui->n5});
    stlNtice.push_back({ui->n6});
    stlNtice.push_back({ui->n7});
    stlNtice.push_back({ui->n8});
    stlNtice.push_back({ui->n9});
    stlNtice.push_back({ui->n10});
    stlNtice.push_back({ui->n11});
    stlNtice.push_back({ui->n12});
    stlNtice.push_back({ui->n13});
    stlNtice.push_back({ui->n14});
    stlNtice.push_back({ui->n15});
    stlNtice.push_back({ui->n16});
    stlNtice.push_back({ui->n17});
    stlNtice.push_back({ui->n18});
    stlNtice.push_back({ui->n19});
    stlNtice.push_back({ui->n20});
    stlNtice.push_back({ui->n21});
    stlNtice.push_back({ui->n22});
    stlNtice.push_back({ui->n23});
    stlNtice.push_back({ui->n24});
    stlNtice.push_back({ui->n25});
    stlNtice.push_back({ui->n26});
    stlNtice.push_back({ui->n27});
    stlNtice.push_back({ui->n28});
    stlNtice.push_back({ui->n29});
    stlNtice.push_back({ui->n30});
}

MainWindow::~MainWindow()
{
    delete ui;
}

int MainWindow::get_M(){
    return ui->spinBoxM->text().toInt();
}

int MainWindow::get_N(){
    return ui->spinBoxN->text().toInt();
}

void MainWindow::info(QString s){
    ui->Info->setText(s);
}

void MainWindow::last_line(){
    QString pc, dat, cisla("");

//    line = archiv->lines.last();
    pc = archiv->lines.last()[0];
    dat = archiv->lines.last()[1];

    for(int i=0; i<archiv->get_n();i++){
        cisla.append(archiv->lines.last()[i+3]).append(" ");
    }
    ui->datc_R->setText(pc.append(": ").append(dat).append(" ").append(cisla));
}

void MainWindow::set_UC(){
    ui->UC->setText(QString::number(archiv->get_UC()).append("(").append(QString::number(archiv->get_UC_line_num())).append(")"));
}

void MainWindow::running(bool state){
    generator_running = state;
    if(generator_running){
        info("Hladam kombinacie");
//        ui->generateButton->setText("Stop");
//        ui->generate_rplus1->sett
    }
    else{
        info("Hladanie dokoncene");
        ui->generate_mix->setText("G");
//        ui->generateButton->setText("Gen r");
        ui->generate_rplus1->setText("Gen r+1");
    }
}

void MainWindow::on_read_file_clicked()
{
    path_file = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("CSV (*.csv)"));
    if(!path_file.isEmpty()){

//        Archivtab = NULL;

        Archiv *a = new Archiv(get_N(), get_M(), path_file);
        this->archiv = a;
        QThread* archiv_thread = new QThread;
//        QThread archiv_thread;

        a->moveToThread(archiv_thread);

        connect(archiv_thread, SIGNAL(started()), a, SLOT(process()));
        connect(a, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(a, SIGNAL(finished()), archiv_thread, SLOT(quit()));
        connect(a, SIGNAL(finished()), this, SLOT(show_btns()));
        connect(a, SIGNAL(finished()), this, SLOT(last_line()));
        connect(a, SIGNAL(finished()), this, SLOT(set_UC()));
//        connect(a, SIGNAL(finished()), a, SLOT(deleteLater()));
//        connect(a, SIGNAL(finished()), this, SLOT(save_arch()));
        connect(archiv_thread, SIGNAL(finished()), archiv_thread, SLOT(deleteLater()));

        archiv_thread->start();

        info(QString("Subor ").append(fname(path_file)).append(" uspesne nacitany"));
        return;
    }
    info(QString("Nepodarilo sa nacitat subor ").append(fname(path_file)));
}

void MainWindow::on_read_arch_clicked()
{
    QString path_db;
    path_db = QFileDialog::getOpenFileName(this, tr("Otvorit subor"), "", tr("DAT (*.dat)"));
    if(!path_db.isEmpty()){
        Archiv *a = new Archiv();
        a->load(path_db);
        this->archiv = a;
        ui->spinBoxN->setValue(archiv->get_n());
        ui->spinBoxM->setValue(archiv->get_m());
        path_file.append(".");
        show_btns();
        last_line();
        set_UC();
        info("Archiv uspesne nacitany");
    }
}

void MainWindow::on_generate_mix_clicked()
{
    if(path_file.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(!min2()){
        info("Musia byt zadane aspon 2 kriteria pre vyhladavanie");
        return;
    }

    if(ui->mix_r->text().toInt() == 0)
        return;

    if(!generator_running){

        ui->generate_mix->setText("X");

        Glimits lim(archiv->get_n(), archiv->get_m(), archiv->get_1DO(),archiv->get_ODDO(),archiv->get_last_comb(),archiv->get_deltav());
        set_limits(lim);

        auto hrx = archiv->hrxAll;

        if(HrxFilter(hrx, lim)){
            return;
        }

        write_protocol("protokol.txt",lim.get_settings());

        QThread *generator_thread, *result_thread;
        Result *res = new Result(archiv);
        Generator *gen = new Generator(archiv,ui->mix_r->text().toInt(),lim, hrx);

        generator_thread = new QThread;
        result_thread = new QThread;

        gen->moveToThread(generator_thread);
        res->moveToThread(result_thread);

        connect(generator_thread, SIGNAL(started()), gen, SLOT(process_mix()));
        connect(this, SIGNAL(stop_generator()), gen, SLOT(stop()),Qt::DirectConnection);
        connect(gen, SIGNAL(finished()), generator_thread, SLOT(quit()));
        connect(gen, SIGNAL(finished()), gen, SLOT(deleteLater()));
        connect(gen, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(generator_thread, SIGNAL(finished()), generator_thread, SLOT(deleteLater()));
        connect(gen, SIGNAL(generator_state(bool)), this, SLOT(running(bool)));

        connect(gen,SIGNAL(send_result2(qvect,Numbers,Numbers)), res, SLOT(insert2(qvect,Numbers,Numbers)), Qt::BlockingQueuedConnection);
        connect(gen,SIGNAL(ended()), res, SLOT(end()));
//        connect(this,SIGNAL(stop_generator()),res, SLOT(stop()), Qt::DirectConnection);
        connect(res,SIGNAL(finished()), res, SLOT(deleteLater()));
        connect(res, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(result_thread, SIGNAL(finished()), result_thread, SLOT(deleteLater()));

        result_thread->start();
        generator_thread->start();

    }
    else{
        emit stop_generator();
    }
}

void MainWindow::on_generate_rplus1_clicked()
{
    if(path_file.isEmpty()){
        info("Subor este nebol nacitany");
        return;
    }

    if(!min2()){
        info("Musia byt zadane aspon 2 kriteria pre vyhladavanie");
        return;
    }

    if(!generator_running){

        ui->generate_rplus1->setText("Stop");

        Glimits lim(archiv->get_n(), archiv->get_m(),archiv->get_1DO1(),archiv->get_ODDO1(), archiv->get_last_comb(),archiv->get_deltav());
        set_limits(lim);

        auto hrx = archiv->hrxAll;

        if(HrxFilter(hrx, lim)){
            return;
        }

//        lim.set_hrxPair();

        write_protocol("protokol.txt",lim.get_settings());

        QThread *generator_thread, *result_thread;
        Result *res = new Result(archiv,1,1);
        Generator *gen = new Generator(get_N(),get_M(),lim, hrx);

        generator_thread = new QThread;
        result_thread = new QThread;

        gen->moveToThread(generator_thread);
        res->moveToThread(result_thread);

        connect(generator_thread, SIGNAL(started()), gen, SLOT(process()));
        connect(this, SIGNAL(stop_generator()), gen, SLOT(stop()),Qt::DirectConnection);
        connect(gen, SIGNAL(finished()), generator_thread, SLOT(quit()));
        connect(gen, SIGNAL(finished()), gen, SLOT(deleteLater()));
        connect(gen, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(generator_thread, SIGNAL(finished()), generator_thread, SLOT(deleteLater()));
        connect(gen, SIGNAL(generator_state(bool)), this, SLOT(running(bool)));

        connect(gen,SIGNAL(send_result(qvect)), res, SLOT(insert(qvect)), Qt::BlockingQueuedConnection);
        connect(gen,SIGNAL(ended()), res, SLOT(end()));
//        connect(this,SIGNAL(stop_generator()),res, SLOT(stop()));
        connect(res,SIGNAL(finished()), res, SLOT(deleteLater()));
        connect(res, SIGNAL(info(QString)), this, SLOT(info(QString)));
        connect(result_thread, SIGNAL(finished()), result_thread, SLOT(deleteLater()));

        result_thread->start();
        generator_thread->start();
    }
    else{
        emit stop_generator();
    }
}

//void MainWindow::on_vytvor_oddo_clicked()
//{
//    if(path_file.isEmpty()){
//        info("Subor este nebol nacitany");
//        return;
//    }

//    if(ui->oddo_rozpetie->text().isEmpty()){
//        info("OD-DO nebolo zadane rozpetie");
//        return;
//    }

//    QStringList l = ui->oddo_rozpetie->text().split("-");
//    if(l.size() == 2){
//        archiv->set_od_do(l[0].toUInt(), l[1].toUInt());
//        archiv->process_od_do();
//        info("OD-DO vytvorene");
//    }
//}

void MainWindow::show_btns(){
    ui->show_limits->setEnabled(true);
    ui->generate_mix->setEnabled(true);
//    ui->generateButton->setEnabled(true);
    ui->generate_rplus1->setEnabled(true);
    ui->lim_r->setEnabled(true);
    ui->lim_r1->setEnabled(true);
//    ui->lim_zh->setEnabled(true);

    for(int i{1}; i <= get_N() && i <= 30; ++i)
        stlNtice[i-1]->setEnabled(true);
}

void MainWindow::on_show_limits_clicked()
{
//    qDebug() << archiv->get_last_numberings();
    qvect comb = archiv->get_last_comb();
    auto v = archiv->get_last_numberings();

    ui->r1R->setText(QString::number(archiv->get_1DO().sum_R(comb.begin(),comb.end())).replace(".",","));
    ui->stl1R->setText(QString::number(archiv->get_1DO().sum_STL(comb.begin(),comb.end())).replace(".",","));
    ui->r2R->setText(QString::number(archiv->get_ODDO().sum_R(comb.begin(),comb.end())).replace(".",","));
    ui->stl2R->setText(QString::number(archiv->get_ODDO().sum_STL(comb.begin(),comb.end())).replace(".",","));
    ui->HHRXr->setText(QString::number(archiv->hhrxLast).replace(".", ","));
    ui->HRXr->setText(QString::number(archiv->hrxLast).replace(".", ","));
    ui->kombR->setText(QString::number(sum_comb(comb.begin(),comb.end())));

    ui->dtr1->setText(QString::number(archiv->get_delta(0)).replace(".",","));
    ui->dtstl1->setText(QString::number(archiv->get_delta(1)).replace(".",","));
    ui->dtRSTL1->setText(QString::number( archiv->get_1DO().sum_R(comb.begin(),comb.end()) - archiv->get_1DO().sum_STL(comb.begin(),comb.end()) ).replace(".",","));

    ui->dtr2->setText(QString::number(archiv->get_delta(2)).replace(".",","));
    ui->dtstl2->setText(QString::number(archiv->get_delta(3)).replace(".",","));
    ui->dtRSTL2->setText(QString::number( archiv->get_ODDO().sum_R(comb.begin(),comb.end()) - archiv->get_ODDO().sum_STL(comb.begin(),comb.end()) ).replace(".",","));

    ui->P->setText(v[0]);
    ui->N->setText(v[1]);
    ui->PR->setText(v[2]);

    ui->Mc->setText(v[3]);
    ui->Vc->setText(v[4]);
    ui->c1_c9->setText(v[5]);

    ui->C0->setText(v[6]);
    ui->cC->setText(v[7]);
    ui->Cc->setText(v[8]);

    ui->CC->setText(v[9]);
    ui->ZH->setText(v[10]);

    ui->Sm->setText(v[11].replace("\"",""));
    ui->Kor->setText(v[12].replace("\"",""));

    ui->n_tice->setText(v[13]);

    QStringList xtice = v[14].split(" ");

    if(xtice.size() < 9){
        while(xtice.size() != 9)
            xtice.append("");
    }
    ui->x_tice1->setText(xtice[0]);
    ui->x_tice2->setText(xtice[1]);
    ui->x_tice3->setText(xtice[2]);
    ui->x_tice4->setText(xtice[3]);
    ui->x_tice5->setText(xtice[4]);
    ui->x_tice6->setText(xtice[5]);
    ui->x_tice7->setText(xtice[6]);
    ui->x_tice8->setText(xtice[7]);
    ui->x_tice9->setText(xtice[8]);

}

void MainWindow::on_lim_r_clicked()
{
    ui->r1od->setText(QString::number(archiv->get_1DO().sum_R_min()).replace(".",","));
    ui->r1do->setText(QString::number(archiv->get_1DO().sum_R_max()).replace(".",","));
    ui->stl1od->setText(QString::number(archiv->get_1DO().sum_STL_min()).replace(".",","));
    ui->stl1do->setText(QString::number(archiv->get_1DO().sum_STL_max()).replace(".",","));
    ui->kombod->setText(QString::number(archiv->get_1DO().sum_komb_min()).replace(".",","));
    ui->kombdo->setText(QString::number(archiv->get_1DO().sum_komb_max()).replace(".",","));
    ui->r2od->setText(QString::number(archiv->get_ODDO().sum_R_min()).replace(".",","));
    ui->r2do->setText(QString::number(archiv->get_ODDO().sum_R_max()).replace(".",","));
    ui->stl2od->setText(QString::number(archiv->get_ODDO().sum_STL_min()).replace(".",","));
    ui->stl2do->setText(QString::number(archiv->get_ODDO().sum_STL_max()).replace(".",","));
}

void MainWindow::on_lim_r1_clicked()
{
    ui->r1od->setText(QString::number(archiv->get_1DO1().sum_R_min()).replace(".",","));
    ui->r1do->setText(QString::number(archiv->get_1DO1().sum_R_max()).replace(".",","));
    ui->stl1od->setText(QString::number(archiv->get_1DO1().sum_STL_min()).replace(".",","));
    ui->stl1do->setText(QString::number(archiv->get_1DO1().sum_STL_max()).replace(".",","));
    ui->kombod->setText(QString::number(archiv->get_1DO1().sum_komb_min()).replace(".",","));
    ui->kombdo->setText(QString::number(archiv->get_1DO1().sum_komb_max()).replace(".",","));
    ui->r2od->setText(QString::number(archiv->get_ODDO1().sum_R_min()).replace(".",","));
    ui->r2do->setText(QString::number(archiv->get_ODDO1().sum_R_max()).replace(".",","));
    ui->stl2od->setText(QString::number(archiv->get_ODDO1().sum_STL_min()).replace(".",","));
    ui->stl2do->setText(QString::number(archiv->get_ODDO1().sum_STL_max()).replace(".",","));
}

void MainWindow::on_lim_zh_clicked()
{
    if(ui->mix_r->text().toInt() < 1)
        return;
    if(ui->mix_r->text().isEmpty())
        return;

    qvect a, b;

    double r1_min=999, r1_max=0, stl1_min=999, stl1_max=0, r2_min=999, r2_max=0, stl2_min=999, stl2_max=0;

    for(int i=0; i<get_N(); i++){
        a << i;
    }
    for(int i=0; i<ui->mix_r->text().toInt(); i++){
        b << i;
    }

    do{

        Nmap poc_1_do, poc_od_do;
        poc_1_do = archiv->get_1DO().get_pocetnost();
        poc_od_do = archiv->get_ODDO().get_pocetnost();

        for(unsigned i=0; i < b.size(); i++){

            int stl = b[i] + 1;
            int j= archiv->get_last_comb()[b[i]];

            poc_1_do[j].set_R(poc_1_do[j].get_R() + 1);
            poc_od_do[j].set_R(poc_od_do[j].get_R() + 1);

            poc_1_do[j].set_STL(stl, poc_1_do[j].get_STL(stl)+1);
            poc_od_do[j].set_STL(stl,poc_od_do[j].get_STL(stl)+1);
        }
//        for(unsigned i=1; i <= get_M(); i++){
//            if(archiv->get_last_comb().contains(i))
//                continue;
//            poc_1_do[i].set_R(poc_1_do[i].get_R() + 1);
//            poc_od_do[i].set_R(poc_od_do[i].get_R() + 1);
//        }

//        for(unsigned i=1; i <= get_N(); i++){
//            for(unsigned j=i; j<=get_M()-get_N()+i; j++){
//                if(archiv->get_last_comb().contains(j))
//                    continue;
//                poc_1_do[j].set_STL(i, poc_1_do[j].get_STL(i)+1);
//                poc_od_do[j].set_STL(i,poc_od_do[j].get_STL(i)+1);
//            }
//        }
        Numbers n1 = archiv->make_numbers(poc_1_do);
        Numbers n2 = archiv->make_numbers(poc_od_do);

        if(n1.sum_R_min() < r1_min)
            r1_min = n1.sum_R_min();
        if(n1.sum_R_max() > r1_max)
            r1_max = n1.sum_R_max();
        if(n1.sum_STL_min() < stl1_min)
            stl1_min = n1.sum_STL_min();
        if(n1.sum_STL_max() > stl1_max)
            stl1_max = n1.sum_STL_max();

        if(n2.sum_R_min() < r2_min)
            r2_min = n2.sum_R_min();
        if(n2.sum_R_max() > r2_max)
            r2_max = n2.sum_R_max();
        if(n2.sum_STL_min() < stl2_min)
            stl2_min = n2.sum_STL_min();
        if(n2.sum_STL_max() > stl2_max)
            stl2_max = n2.sum_STL_max();

    }while(stdcomb::next_combination(a.begin(),a.end(),b.begin(),b.end()));

    ui->r1od->setText(QString::number(r1_min ).replace(".",","));
    ui->r1do->setText(QString::number(r1_max ).replace(".",","));
    ui->stl1od->setText(QString::number(stl1_min ).replace(".",","));
    ui->stl1do->setText(QString::number(stl1_max ).replace(".",","));
    ui->kombod->setText(QString::number(archiv->get_1DO1().sum_komb_min()).replace(".",","));
    ui->kombdo->setText(QString::number(archiv->get_1DO1().sum_komb_max()).replace(".",","));
    ui->r2od->setText(QString::number(r2_min ).replace(".",","));
    ui->r2do->setText(QString::number(r2_max ).replace(".",","));
    ui->stl2od->setText(QString::number(stl2_min ).replace(".",","));
    ui->stl2do->setText(QString::number(stl2_max ).replace(".",","));
}

bool MainWindow::min2(){

    Glimits g(get_N(), get_M());
    set_limits(g);

    return (g.size() > 1);
}

bool MainWindow::set_limits(Glimits &g){

    qvect ntice;
    QSet<num> povinne,zakazane;

    auto f2 = [&g](QLineEdit* l, std::function<void(Glimits&, double)> f){
        if(!l->text().isEmpty()){
            bool ok;
            double d = l->text().replace(",", ".").toDouble(&ok);
            if(ok) f(g, d);
            else return false;
        }
        return true;
    };

    auto f1 = [&g, &f2](QVector<QLineEdit*> &line, QVector<std::function<void(Glimits&, double)>> &f){
        auto rod = line[0], r = line[1], rdo = line[2];
        auto fod = f[0], fdo = f[1];

        if(rod->isEnabled()){
            if(!f2(rod, fod)) return false;
            if(!f2(r, fdo)) return false;
        } else{
            if(!f2(r,fod)) return false;
            if(!f2(rdo,fdo)) return false;
        }
        return true;
    };

    // sumr1 ... kk
    for(int i{0}; i<=27; ++i){
        if(i == 13) continue;
        if(i == 25) continue;
        if(i == 5) g.set_hrx_numbers1(archiv->get_1DO());
        if(i == 12) g.set_hrx_numbers2(archiv->get_ODDO());
//        if(i == 12) continue;
        if(!f1(lines[i], gfuntions[i])){
//            for(auto l : lines[i]) l->setStyleSheet("QLineEdit{background:" + colorErr + ";}");
            info("Zle zadane hodnoty...");
            return false;
        }
        else{
//            for(auto l : lines[i]) l->setStyleSheet("QLineEdit{background:" + colorDefault + ";}");
        }
    }

    if(!ui->x_tice1->text().isEmpty()){
        QString xstr;

        xstr.append(ui->x_tice1->text()).append("|");

        if(!ui->x_tice2->text().isEmpty())
            xstr.append(ui->x_tice2->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice3->text().isEmpty())
            xstr.append(ui->x_tice3->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice4->text().isEmpty())
            xstr.append(ui->x_tice4->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice5->text().isEmpty())
            xstr.append(ui->x_tice5->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice6->text().isEmpty())
            xstr.append(ui->x_tice6->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice7->text().isEmpty())
            xstr.append(ui->x_tice7->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice8->text().isEmpty())
            xstr.append(ui->x_tice8->text()).append("|");
        else
            xstr.append("0 ");

        if(!ui->x_tice9->text().isEmpty())
            xstr.append(ui->x_tice9->text()).append("|");
        else
            xstr.append("0 ");

        g.set_xtice(xstr);

    }

    // ntice
    if(!ui->n_tice->text().isEmpty()){
        QStringList l = ui->n_tice->text().split(" ");
        unsigned sum = 0;

        for(int i=1; i<=l.size() && i<=get_N(); i++){
            sum += l[i-1].toUInt()*i;
            ntice.push_back((num)l[i-1].toUInt());
        }
        if(sum != (unsigned)get_N())
            info("N-tice zle zadane");
        else
            g.set_ntice(ntice);
    }

    // nticeStl
    if(!ui->n_tice->text().isEmpty()){
        qvect ntice_stl;

        for(int i{0}; i<get_N() && i<30; ++i){
            if(stlNtice[i]->isChecked()) ntice_stl.push_back(1);
            else ntice_stl.push_back(0);
        }

        QStringList l = ui->n_tice->text().split(" ");
        unsigned sum = 0, sum2=0;

        for(int i=1; i<l.size() && i<=get_N(); i++){
            sum += l[i].toUInt()*(i+1);
//            ntice.push_back((num)l[i-1].toUInt());
        }

        foreach (const int &i, ntice_stl) {
            if(i == 1)
                sum2 += 1;
        }
        if(sum != sum2){
            // zadane zle
        }
        else{
            g.set_ntice_stl(ntice_stl);
        }
    }

    //Povinne
    if(!ui->Povinne->text().isEmpty()){

        QStringList pov = ui->Povinne->text().split(",");
        foreach (const QString &str, pov) {
            if(str.contains("-")){
                QStringList a=str.split("-");
                for(int i=a[0].toInt(); i<=a[1].toInt(); i++){
                    povinne.insert((num)i);
                }
            }
            else if(str.toInt() == 0)
                continue;
            else
                povinne.insert((num)str.toUInt());
        }

//        if(povinne.size() > get_N()){
//            ui->Povinne->setStyleSheet("QLineEdit{background:" + colorErr + ";}");

//            info("Povinnych je prilis vela");
//        }
//        else{
//            ui->Povinne->setStyleSheet("QLineEdit{background:" + colorDefault + ";}");
//            g.set_povinne(povinne);
//        }
    }

    //PovinneSTL
    if(!ui->PovinneSTL->text().isEmpty()){
        QMultiHash<int, int> povMM;
        QStringList pov = ui->PovinneSTL->text().split(";");

        if(pov.size() > 0)
        {
            foreach (const QString& str, pov)
            {
                if(str.split(":").size() > 1)
                {
                    QString stl = str.split(":")[0];
                    QString args = str.split(":")[1];
                    foreach (auto& i, args.split(","))
                    {
                        if(i.contains("-") && i.split("-").size() == 2){
                            auto a = i.split("-")[0].toInt();
                            auto b = i.split("-")[1].toInt();
                            for(;a <= b; ++a)
                            {
                                if(a > 0) povMM.insert(stl.toInt(), a);
                            }
                        }
                        else if(i.toInt() > 0)
                        {
                            povMM.insert(stl.toInt(), i.toInt());
                        }
                    }

                }
            }
        }
        // setPovinneStl
        g.set_povinneSTL(povMM);
//        qDebug() << povMM;
    }

    //Zakazane
    if(!ui->Zakazane->text().isEmpty()){

        QStringList zak = ui->Zakazane->text().split(",");
        foreach (const QString &str, zak) {
            if(str.contains("-")){
                QStringList a=str.split("-");
                for(int i=a[0].toInt(); i<=a[1].toInt(); i++){
                    zakazane.insert((num)i);
                }
            }
            else if(str.toInt() == 0)
                continue;
            else
                zakazane.insert((num)str.toUInt());
        }

        if(zakazane.size() > get_M()-get_N())
            info("Zakazanych je prilis vela");
        else
            g.set_zakazane(zakazane);
    }

    //ZakazaneSTL
    if(!ui->ZakazaneSTL->text().isEmpty()){
        QMultiHash<int, int> zakMM;
        QStringList pov = ui->ZakazaneSTL->text().split(";");

        if(pov.size() > 0)
        {
            foreach (const QString& str, pov)
            {
                if(str.split(":").size() > 1)
                {
                    QString stl = str.split(":")[0];
                    QString args = str.split(":")[1];
                    foreach (auto& i, args.split(","))
                    {
                        if(i.contains("-") && i.split("-").size() == 2){
                            auto a = i.split("-")[0].toInt();
                            auto b = i.split("-")[1].toInt();
                            for(;a <= b; ++a)
                            {
                                if(a > 0) zakMM.insert(stl.toInt(), a);
                            }
                        }
                        else if(i.toInt() > 0)
                        {
                            zakMM.insert(stl.toInt(), i.toInt());
                        }
                    }

                }
            }
        }
        //set
        g.set_zakazaneSTL(zakMM);
//        qDebug() << zakMM;
    }

    return true;
}

void MainWindow::on_Pod_editingFinished()
{
    if(ui->Nod->isEnabled()){
        ui->N->setText(QString::number(get_N() - ui->Pod->text().toInt()));
    }
    else{
        ui->Ndo->setText(QString::number(get_N() - ui->Pod->text().toInt()));
    }
}

void MainWindow::on_Pdo_editingFinished()
{
    if(ui->Nod->isEnabled()){
        ui->Nod->setText(QString::number(get_N() - ui->Pdo->text().toInt()));
    }
    else{
        ui->N->setText(QString::number(get_N() - ui->Pdo->text().toInt()));
    }
}

void MainWindow::on_P_editingFinished()
{
    if(ui->Pod->isEnabled()){
        if(ui->Nod->isEnabled()){
            ui->Nod->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
        else{
            ui->N->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
    }
    else{
        if(ui->Nod->isEnabled()){
            ui->N->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
        else{
            ui->Ndo->setText(QString::number(get_N() - ui->P->text().toInt()));
        }
    }
}

void MainWindow::on_Nod_editingFinished()
{
    if(ui->Pod->isEnabled()){
        ui->P->setText(QString::number(get_N() - ui->Nod->text().toInt()));
    }
    else{
        ui->Pdo->setText(QString::number(get_N() - ui->Nod->text().toInt()));
    }

}

void MainWindow::on_N_editingFinished()
{
    if(ui->Nod->isEnabled()){
        if(ui->Pod->isEnabled()){
            ui->Pod->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
        else{
            ui->P->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
    }
    else{
        if(ui->Pod->isEnabled()){
            ui->P->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
        else{
            ui->Pdo->setText(QString::number(get_N() - ui->N->text().toInt()));
        }
    }
}

void MainWindow::on_Ndo_editingFinished()
{
    if(ui->Pod->isEnabled()){
        ui->Pod->setText(QString::number(get_N() - ui->Ndo->text().toInt()));
    }
    else{
        ui->P->setText(QString::number(get_N() - ui->Ndo->text().toInt()));
    }
}

void MainWindow::on_Mcod_editingFinished()
{
    if(ui->Vcod->isEnabled()){
        ui->Vc->setText(QString::number(get_N() - ui->Mcod->text().toInt()));
    }
    else{
        ui->Vcdo->setText(QString::number(get_N() - ui->Mcod->text().toInt()));
    }
}

void MainWindow::on_Mcdo_editingFinished()
{
    if(ui->Vcod->isEnabled()){
        ui->Vcod->setText(QString::number(get_N() - ui->Mcdo->text().toInt()));
    }
    else{
        ui->Vc->setText(QString::number(get_N() - ui->Mcdo->text().toInt()));
    }
}

void MainWindow::on_Mc_editingFinished()
{
    if(ui->Mcod->isEnabled()){
        if(ui->Vcod->isEnabled()){
            ui->Vcod->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
        else{
            ui->Vc->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
    }
    else{
        if(ui->Vcod->isEnabled()){
            ui->Vc->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
        else{
            ui->Vcdo->setText(QString::number(get_N() - ui->Mc->text().toInt()));
        }
    }
}

void MainWindow::on_Vcod_editingFinished()
{
    if(ui->Mcod->isEnabled()){
        ui->Mc->setText(QString::number(get_N() - ui->Vcod->text().toInt()));
    }
    else{
        ui->Mcdo->setText(QString::number(get_N() - ui->Vcod->text().toInt()));
    }
}

void MainWindow::on_Vcdo_editingFinished()
{
    if(ui->Mcod->isEnabled()){
        ui->Mcod->setText(QString::number(get_N() - ui->Vcdo->text().toInt()));
    }
    else{
        ui->Mc->setText(QString::number(get_N() - ui->Vcdo->text().toInt()));
    }
}

void MainWindow::on_Vc_editingFinished()
{
    if(ui->Vcod->isEnabled()){
        if(ui->Mcod->isEnabled()){
            ui->Mcod->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
        else{
            ui->Mc->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
    }
    else{
        if(ui->Mcod->isEnabled()){
            ui->Mc->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
        else{
            ui->Mcdo->setText(QString::number(get_N() - ui->Vc->text().toInt()));
        }
    }
}

void MainWindow::on_mix_r_textChanged(const QString &arg1)
{
    if(arg1.isEmpty()){
        ui->mix_r1->clear();
        return;
    }

    if(arg1.toInt() >= get_N()){
        ui->mix_r->setText(QString::number(get_N()-1));
        ui->mix_r1->setText(QString::number(1));
    }
    else
        ui->mix_r1->setText(QString::number(get_N()-arg1.toInt()));
}
//sum R     --0--
//sum STL   --1--
//dt R      --2--
//dt STL    --3--
//dt R-STL  --4--
//hhrx      --5--
//Komb      --6--
//sum R     --7--
//sum STL   --8--
//dt R      --9--
//dt STL    --10--
//dt R-STL  --11--
//hrx       --12--
//rozpatie  --13--
//P         --14--
//N         --15--
//PR        --16--
//MC        --17--
//VC        --18--
//c19       --19--
//c0        --20--
//cC        --21--
//Cc        --22--
//CC        --23--
//ZH        --24--
//ZH "r"    --25--
//Sm        --26--
//Kk        --27--
void MainWindow::swapEnabled(QLineEdit* a, QLineEdit* b){
    if(!a->isEnabled()){
        a->setEnabled(true);
        b->setEnabled(false);
    }
}

void MainWindow::on_r1gl_clicked(){ swapEnabled(lines[0][0], lines[0][2]); }
void MainWindow::on_r1gl_2_clicked(){ swapEnabled(lines[0][2], lines[0][0]); }
void MainWindow::on_stl1gl_clicked(){swapEnabled(lines[1][0], lines[1][2]);}
void MainWindow::on_stl1gl_2_clicked(){swapEnabled(lines[1][2], lines[1][0]);}
void MainWindow::on_dtr1gl_clicked(){swapEnabled(lines[2][0], lines[2][2]);}
void MainWindow::on_dtr1gl2_clicked(){swapEnabled(lines[2][2], lines[2][0]);}
void MainWindow::on_dtslt1gl_clicked(){swapEnabled(lines[3][0], lines[3][2]);}
void MainWindow::on_dtstl1gl2_clicked(){swapEnabled(lines[3][2], lines[3][0]);}
void MainWindow::on_dtRSTL1gl_clicked(){swapEnabled(lines[4][0], lines[4][2]);}
void MainWindow::on_dtRSTL1gl2_clicked(){swapEnabled(lines[4][2], lines[4][0]);}
void MainWindow::on_HHRXgl_clicked(){swapEnabled(lines[5][0], lines[5][2]);}
void MainWindow::on_HHRXgl2_clicked(){swapEnabled(lines[5][2], lines[5][0]);}
void MainWindow::on_kombgl_clicked(){swapEnabled(lines[6][0], lines[6][2]);}
void MainWindow::on_kombgl_2_clicked(){swapEnabled(lines[6][2], lines[6][0]);}

void MainWindow::on_r2gl_clicked(){swapEnabled(lines[7][0], lines[7][2]);}
void MainWindow::on_r2gl_2_clicked(){swapEnabled(lines[7][2], lines[7][0]);}
void MainWindow::on_stl2gl_clicked(){swapEnabled(lines[8][0], lines[8][2]);}
void MainWindow::on_stl2gl_2_clicked(){swapEnabled(lines[8][2], lines[8][0]);}
void MainWindow::on_dtr2gl_clicked(){swapEnabled(lines[9][0], lines[9][2]);}
void MainWindow::on_dtr2gl2_clicked(){swapEnabled(lines[9][2], lines[9][0]);}
void MainWindow::on_dtstl2gl_clicked(){swapEnabled(lines[10][0], lines[10][2]);}
void MainWindow::on_dtstl2gl2_clicked(){swapEnabled(lines[10][2], lines[10][0]);}
void MainWindow::on_dtRSTL2gl_clicked(){swapEnabled(lines[11][0], lines[11][2]);}
void MainWindow::on_dtRSTL2gl2_clicked(){swapEnabled(lines[11][2], lines[11][0]);}
void MainWindow::on_HRXgl_clicked(){swapEnabled(lines[12][0], lines[12][2]);}
void MainWindow::on_HRXgl2_clicked(){swapEnabled(lines[12][2], lines[12][0]);}

void MainWindow::on_pgl_clicked(){swapEnabled(lines[14][0], lines[14][2]);}
void MainWindow::on_pgl_2_clicked(){swapEnabled(lines[14][2], lines[14][0]);}
void MainWindow::on_ngl_clicked(){swapEnabled(lines[15][0], lines[15][2]);}
void MainWindow::on_ngl_2_clicked(){swapEnabled(lines[15][2], lines[15][0]);}
void MainWindow::on_prgl_clicked(){swapEnabled(lines[16][0], lines[16][2]);}
void MainWindow::on_prgl_2_clicked(){swapEnabled(lines[16][2], lines[16][0]);}
void MainWindow::on_mcgl_clicked(){swapEnabled(lines[17][0], lines[17][2]);}
void MainWindow::on_mcgl_2_clicked(){swapEnabled(lines[17][2], lines[17][0]);}
void MainWindow::on_vcgl_clicked(){swapEnabled(lines[18][0], lines[18][2]);}
void MainWindow::on_vcgl_2_clicked(){swapEnabled(lines[18][2], lines[18][0]);}
void MainWindow::on_c1c9gl_clicked(){swapEnabled(lines[19][0], lines[19][2]);}
void MainWindow::on_c1c9gl_2_clicked(){swapEnabled(lines[19][2], lines[19][0]);}
void MainWindow::on_c0gl_clicked(){swapEnabled(lines[20][0], lines[20][2]);}
void MainWindow::on_c0gl_2_clicked(){swapEnabled(lines[20][2], lines[20][0]);}
void MainWindow::on_cCgl_clicked(){swapEnabled(lines[21][0], lines[21][2]);}
void MainWindow::on_cCgl_2_clicked(){swapEnabled(lines[21][2], lines[21][0]);}
void MainWindow::on_Ccgl_clicked(){swapEnabled(lines[22][0], lines[22][2]);}
void MainWindow::on_Ccgl_2_clicked(){swapEnabled(lines[22][2], lines[22][0]);}
void MainWindow::on_CCgl_clicked(){swapEnabled(lines[23][0], lines[23][2]);}
void MainWindow::on_CCgl_2_clicked(){swapEnabled(lines[23][2], lines[23][0]);}
void MainWindow::on_zhgl_clicked(){swapEnabled(lines[24][0], lines[24][2]);}
void MainWindow::on_zhgl_2_clicked(){swapEnabled(lines[24][2], lines[24][0]);}
void MainWindow::on_smgl_clicked(){swapEnabled(lines[26][0], lines[26][2]);}
void MainWindow::on_smgl_2_clicked(){swapEnabled(lines[26][2], lines[26][0]);}
void MainWindow::on_korgl_clicked(){swapEnabled(lines[27][0], lines[27][2]);}
void MainWindow::on_korgl_2_clicked(){swapEnabled(lines[27][2], lines[27][0]);}


void MainWindow::on_del_all_clicked(){
    for(auto line : lines)
        for(auto i : line)
            i->clear();
    on_del_povinne_clicked();
    on_del_povinneSTL_clicked();
    on_del_zakazaneSTL_clicked();
    on_del_zakazane_clicked();
    on_del_Ntice_clicked();
    on_del_Ntice_2_clicked();
}

void MainWindow::on_del_r1_clicked(){ for(auto i : lines[0]){ i->clear(); } }
void MainWindow::on_del_stl1_clicked(){ for(auto i : lines[1]){ i->clear(); } }
void MainWindow::on_del_sum_komb_clicked(){ for(auto i : lines[6]){ i->clear(); } }
void MainWindow::on_del_rod_clicked(){ for(auto i : lines[7]){ i->clear(); } }
void MainWindow::on_del_stlod_clicked(){ for(auto i : lines[8]){ i->clear(); } }
void MainWindow::on_del_dtr1_clicked(){for(auto i : lines[2]){ i->clear(); }}
void MainWindow::on_del_dtSTL1_clicked(){for(auto i : lines[3]){ i->clear(); }}
void MainWindow::on_del_dtRSTL1_clicked(){for(auto i : lines[4]){ i->clear(); }}
void MainWindow::on_del_dtr2_clicked(){for(auto i : lines[9]){ i->clear(); }}
void MainWindow::on_del_dtstl2_clicked(){for(auto i : lines[10]){ i->clear(); }}
void MainWindow::on_del_dtRSTL2_clicked(){for(auto i : lines[11]){ i->clear(); }}
void MainWindow::on_del_P_clicked(){ for(auto i : lines[14]){ i->clear(); } }
void MainWindow::on_del_Mc_clicked(){ for(auto i : lines[17]){ i->clear(); } }
void MainWindow::on_del_c1c9_clicked() { for(auto i : lines[19]){ i->clear(); } }
void MainWindow::on_del_N_clicked(){ for(auto i : lines[15]){ i->clear(); } }
void MainWindow::on_del_Cc_clicked() { for(auto i : lines[22]){ i->clear(); } }
void MainWindow::on_del_C0_clicked() { for(auto i : lines[20]){ i->clear(); } }
void MainWindow::on_del_PR_clicked(){ for(auto i : lines[16]){ i->clear(); } }
void MainWindow::on_del_Vc_clicked(){ for(auto i : lines[18]){ i->clear(); } }
void MainWindow::on_del_cC_clicked(){ for(auto i : lines[21]){ i->clear(); } }
void MainWindow::on_del_ZH_clicked(){ for(auto i : lines[24]){ i->clear(); } }
void MainWindow::on_del_CC_clicked(){for(auto i : lines[23]){ i->clear(); } }
void MainWindow::on_del_Sm_clicked(){for(auto i : lines[26]){ i->clear(); } }
void MainWindow::on_del_Kor_clicked(){for(auto i : lines[27]){ i->clear(); }}
void MainWindow::on_del_povinne_clicked(){ui->Povinne->clear();}
void MainWindow::on_del_zakazane_clicked(){ui->Zakazane->clear();}
void MainWindow::on_del_Ntice_clicked(){ui->n_tice->clear();}
void MainWindow::on_del_Xtice_clicked(){for(auto i : lines[28]){ i->clear(); }}
void MainWindow::on_del_Ntice_2_clicked(){for(auto i : stlNtice) i->setChecked(false); }
void MainWindow::on_del_povinneSTL_clicked(){ui->PovinneSTL->clear();}
void MainWindow::on_del_zakazaneSTL_clicked(){ui->ZakazaneSTL->clear();}
void MainWindow::on_del_HHRX_clicked(){ for(auto i : lines[5]){ i->clear(); }}
void MainWindow::on_del_HRX_clicked(){ for(auto i : lines[12]) i->clear(); }

bool HrxFilter(QMap<double, Hrx> &hrx, Glimits &g){

    QMutableMapIterator<double, Hrx> itt(hrx);

    while(itt.hasNext()){
        itt.next();

        int Kombi = 0;
        if(g.SumKombiMin(Kombi)){
            if(Kombi > itt.value().sumMax){
                itt.remove();
                continue;
            }
        }
        if(g.SumKombiMax(Kombi)){
            if(Kombi < itt.value().sumMin){
                itt.remove();
                continue;
            }
        }

        double Sum = 0;

//        if(g.HhrxMin(Sum)){
//            if(Sum > itt.value().hhrx){
//                itt.remove();
//                continue;
//            }
//        }
//        if(g.HhrxMax(Sum)){
//            if(Sum < itt.value().hhrx){
//                itt.remove();
//                continue;
//            }
//        }

        if(g.HrxMin(Sum)){
            if(itt.key() < Sum){
                itt.remove();
                continue;
            }
        }
        if(g.HrxMax(Sum)){
            if(itt.key() > Sum){
                itt.remove();
                continue;
            }
        }

//        if(g.R1Min(Sum)){
//            if(Sum > itt.value().percR1Max){
//                itt.remove();
//                continue;
//            }
//        }
//        if(g.R1Max(Sum)){
//            if(Sum < itt.value().percR1Min){
//                itt.remove();
//                continue;
//            }
//        }

//        if(g.Stl1Min(Sum)){
//            if(Sum > itt.value().percStl1Max){
//                itt.remove();
//                continue;
//            }
//        }
//        if(g.Stl1Max(Sum)){
//            if(Sum < itt.value().percStl1Min){
//                itt.remove();
//                continue;
//            }
//        }

//        if(g.ROdMin(Sum)){
//            if(Sum > itt.value().sumXR){
//                itt.remove();
//                continue;
//            }
//        }
//        if(g.ROdMax(Sum)){
//            if(Sum < itt.value().sumXR){
//                itt.remove();
//                continue;
//            }
//        }

//        if(g.StlOdMin(Sum)){
//            if(Sum > itt.value().percStlOdMax){
//                itt.remove();
//                continue;
//            }
//        }
//        if(g.StlOdMax(Sum)){
//            if(Sum < itt.value().percStlOdMin){
//                itt.remove();
//                continue;
//            }
//        }

//        PocetKombiMax += itt.value().pocetKombi;
    }
    return hrx.isEmpty();
}

void MainWindow::on_KolkoKombi_clicked()
{
    auto all = archiv->hrxAll;
//    QMutableMapIterator<double, Hrx> itt(all);
    bigInt PocetKombiMax{0};

    Glimits g(archiv->get_n(), archiv->get_m());
    set_limits(g);

    if(!HrxFilter(all, g)){
        foreach (const Hrx& hrx, all) {
            PocetKombiMax += hrx.pocetKombi;
        }
    }
    info("Max. pocet Kombinacii: " + QString(PocetKombiMax.str().c_str()));
}

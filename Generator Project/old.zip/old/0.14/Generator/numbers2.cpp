#include "numbers2.h"

#include <boost/math/special_functions/binomial.hpp>


//PHCisla::PHCisla(unsigned n, unsigned m, TypePH hodnotaPocetnost) :
//    n{n},
//    m{m},
//    type{hodnotaPocetnost},
//    m_pocetnostRiadok{Pocetnost(m, hodnotaPocetnost)},
//    m_pocetnostStlpec{Pocetnost2D(m,Pocetnost(n, hodnotaPocetnost))},
//    hodnotaRiadok{Hodnota(m, 0.f)},
//    hodnotaStlpec{Hodnota2D(m, Hodnota(n, 0.f))}
//{}

//PHCisla PHCisla::operator++(int){
//    PHCisla phCisla{*this};

//    for(unsigned cislo{1}; cislo <= m; ++cislo){
//        phCisla.incrementRiadok(cislo);
//    }

//    for(unsigned stlpec{1}; stlpec <= n; ++stlpec){
//        for(unsigned cislo{stlpec}; cislo <= (m - n + stlpec); ++cislo){
//            phCisla.incrementStlpec(cislo, stlpec);
//        }
//    }
//    return phCisla;
//}

//void PHCisla::increment(const QVector<unsigned> &nums){
//    auto end = nums.size();
//    for(int i{1}; i <= end; ++i){
//        increment(nums[i-1], i);
//    }
//}

//void PHCisla::increment(unsigned cislo, unsigned stlpec){
//    incrementRiadok(cislo);
//    incrementStlpec(cislo, stlpec);
//}

//void PHCisla::incrementRiadok(unsigned cislo){

//    auto pocRiadok = ++m_pocetnostRiadok[cislo-1];

//    if(pocRiadok > 0){
//        bigFloat f{pocRiadok};
//        bigInt i{stlCC(1, 1, n, m)};
//        f /= i.convert_to<bigFloat>();
//        hodnotaRiadok[cislo-1] = f.convert_to<double>();
//    }
//}

//void PHCisla::incrementStlpec(unsigned cislo, unsigned stlpec){

//    auto pocStlpec = ++m_pocetnostStlpec[cislo-1][stlpec-1];

//    if(pocStlpec > 0){
//        bigFloat f(pocStlpec);
//        bigInt i(stlCC(cislo, stlpec, n, m));
//        f /= i.convert_to<bigFloat>();
//        hodnotaStlpec[cislo-1][stlpec-1] = f.convert_to<double>();
//    }
//}

//double PHCisla::Riadok(unsigned cislo) const{
//    return hodnotaRiadok[cislo-1];
//}

//double PHCisla::Stlpec(unsigned cislo, unsigned stlpec) const{
//    return hodnotaStlpec[cislo-1][stlpec-1];
//}

//int PHCisla::pocetnostRiadok(unsigned cislo) const{
//    return m_pocetnostRiadok[cislo-1];
//}

//int PHCisla::pocetnostStlpec(unsigned cislo, unsigned stlpec) const{
//    return m_pocetnostStlpec[cislo-1][stlpec-1];
//}



//bigInt stlCC(int cislo, int stlpec, int n, int m){

//    if( ((cislo-stlpec) < 0) || ((cislo-stlpec) > (m-n)) )
//        return 0;

//    return (nCm(n-stlpec, m-cislo) * nCm(stlpec-1, cislo-1));
//}

bigInt nCm(unsigned n, unsigned m){
    bigInt i{boost::math::binomial_coefficient<double>(m, n)};
    return i;
}

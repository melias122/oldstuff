#ifndef PHCISLA_H
#define PHCISLA_H

#include <boost/multiprecision/cpp_int.hpp>
//#include <boost/multiprecision/cpp_dec_float.hpp>
//#include <QVector>

using bigInt = boost::multiprecision::cpp_int;
//using bigFloat = boost::multiprecision::cpp_dec_float_100;

//using Pocetnost = QVector<int>;
//using Pocetnost2D = QVector<Pocetnost>;

//using Hodnota = QVector<double>;
//using Hodnota2D = QVector<Hodnota>;

///*
// * Pocetnost a Hodnota cisla v stlpci/riadku
//*/
//class PHCisla
//{
//    unsigned n, m;
//    TypePH type;

//    Pocetnost m_pocetnostRiadok;
//    Pocetnost2D m_pocetnostStlpec;

//    Hodnota hodnotaRiadok;
//    Hodnota2D hodnotaStlpec;

//    void incrementRiadok(unsigned cislo);
//    void incrementStlpec(unsigned cislo, unsigned stlpec);

//public:

//    enum TypePH {od0 = -1, odDo = 0};

//    PHCisla(){}
//    PHCisla(unsigned n, unsigned m, TypePH hodnotaPocetnost = TypePH::odDo);

//    PHCisla operator++(int);

//    void increment(const QVector<unsigned> &nums);
//    void increment(unsigned cislo, unsigned stlpec);

//    double Riadok(unsigned cislo) const;
//    double Stlpec(unsigned cislo, unsigned stlpec) const;

//    int pocetnostRiadok(unsigned cislo) const;
//    int pocetnostStlpec(unsigned cislo, unsigned stlpec) const;
//};

//bigInt stlCC(int cislo, int stlpec, int n, int m);
bigInt nCm(unsigned n, unsigned m);

#endif // PHCISLA_H
